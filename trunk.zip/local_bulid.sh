mvn clean install
#ssh root@192.168.1.77 

/u01/apache-tomcat-7.0.34/bin/catalina.sh stop

export /u01/apache-tomcat-7.0.34/bin/setenv.sh

rm -rfv  /u01/apache-tomcat-7.0.34/webapps/op-web*
rm -rfv /u01/apache-tomcat-7.0.34/logs/*
rm -rfv /u01/apache-tomcat-7.0.34/work/Catalina/localhost/op-web/

cp -rfv /home/dev/workspace/trunk/op-web/target/op-web-1.0-SNAPSHOT.war /u01/apache-tomcat-7.0.34/webapps/op-web.war

#/u01/apache-tomcat-7.0.34/bin/catalina.sh run &
