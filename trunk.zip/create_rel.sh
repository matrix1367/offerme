#rm -rfv ~/workspace/trunk/op-web/src/main/webapp/images/*.mp4
#rm -rfv ~/workspace/trunk/op-web/src/main/webapp/images/*.ogv
#rm -rfv ~/workspace/trunk/op-web/src/main/webapp/images/*.webm
cp -rfv ~/workspace/overwriting/* ~/workspace/trunk
