mvn clean install
scp /home/dev/workspace/trunk/op-web/target/op-web-1.0-SNAPSHOT.war root@192.168.1.218:/u01/apache-tomcat-7.0.34/webapps/op-web.war
