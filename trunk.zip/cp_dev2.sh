DATE_ST=`date`
sleep 3
#cp /home/dev/workspace/trunk/op-web/target/op-web-1.0-SNAPSHOT.war /tmp -rfv
scp /home/dev/workspace/trunk/op-web/target/op-web-1.0-SNAPSHOT.war root@192.168.1.218:/u01/apache-tomcat-7.0.34/webapps/op-web.war

SUBJECT="Nowe_wdrozenie - DEV"
TO="administrator@ogarniamprad.pl"
CC="operator@ogarniamprad.pl"
MD5=`md5sum /tmp/op-web-1.0-SNAPSHOT.war`
DATE_END=`date`
NAME="update"

if [ ! -z $1 ]; then
	$NAME=$1
fi

MSG='Rozpoczęcie wdrożenia: '$DATE_ST' \nZakończenie wdrożenia: '$DATE_END' \nSuma kontrolna wdrożenia: '$MD5'\nNazwa wdrożenia: '$NAME'\n\nZapraszam pod adres https://213.156.100.244/op-web/'

echo -e $MSG | mail -s $SUBJECT -c $CC $TO


