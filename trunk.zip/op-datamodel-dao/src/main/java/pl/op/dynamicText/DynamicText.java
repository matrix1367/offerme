package pl.op.dynamicText;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_DYNAMICTEXT")
public class DynamicText implements Serializable {

	private static final long serialVersionUID = 7332801549938990508L;

	private Integer dynamicTextId;
	private String dynamicTextType;
	private String dynamicTextName;
	private String dynamicTextValue;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DYNAMICTEXT_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "DYNAMICTEXT_SEQUENCE_GENERATOR", sequenceName = "DYNAMICTEXT_ID_SEQ", allocationSize = 1)
	@Index(name = "dynamicTextIndex")
	public Integer getDynamicTextId() {
		return dynamicTextId;
	}
	public void setDynamicTextId(Integer dynamicTextId) {
		this.dynamicTextId = dynamicTextId;
	}
	public String getDynamicTextName() {
		return dynamicTextName;
	}
	public void setDynamicTextName(String dynamicTextName) {
		this.dynamicTextName = dynamicTextName;
	}
	public String getDynamicTextValue() {
		return dynamicTextValue;
	}
	public void setDynamicTextValue(String dynamicTextValue) {
		this.dynamicTextValue = dynamicTextValue;
	}
	public String getDynamicTextType() {
		return dynamicTextType;
	}
	public void setDynamicTextType(String dynamicTextType) {
		this.dynamicTextType = dynamicTextType;
	}
}
