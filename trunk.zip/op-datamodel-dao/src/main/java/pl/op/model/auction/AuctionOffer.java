package pl.op.model.auction;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Index;

import pl.op.model.salesman.Salesman;

@Entity
@Table(name = "TB_AUCTIONOFFER")
public class AuctionOffer implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8566366493194609271L;

	private Integer auctionOfferId;
	private Date updatedAt;
	private Date createdAt;
	private Auction auction;
	private AuctionStatus status;
	private Salesman salesman;
	private Boolean isSalesmanVisible;
	private List<PriceComponentValue> priceComponentValues;
	private Double score;

	// Transient
	private List<PriceComponentValue> constantPriceComponentValues;
	private List<PriceComponentValue> notConstantPriceComponentValues;
	private Double constantPricesValue;
	private Double notConstantPricesValue;
	DecimalFormat formater = new DecimalFormat("0.00");
        
//        @Override
//        public  String toString() {
//            StringBuilder desc = new StringBuilder();
//            desc.append("\n\n AuctionOffer");
//            desc.append("\n auctionOfferId - " + auctionOfferId);
//            desc.append("\n updatedAt - " + updatedAt);
//            desc.append("\n createdAt - " + createdAt);
//            desc.append("\n auction - " + auction);
//            desc.append("\n status - " + status);
//            desc.append("\n salesman - " + salesman);
//            desc.append("\n isSalesmanVisible - " + isSalesmanVisible);
//            desc.append("\n priceComponentValues.size - " + priceComponentValues.size());
//            desc.append("\n score - " + score);
//            return desc;
//        }

        

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AUCTIONOFFER_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "AUCTIONOFFER_SEQUENCE_GENERATOR", sequenceName = "AUCTIONOFFER_ID_SEQ", allocationSize = 1)
	@Index(name = "auctionOfferIndex")
	public Integer getAuctionOfferId() {
		return auctionOfferId;
	}

	public void setAuctionOfferId(Integer auctionOfferId) {
		this.auctionOfferId = auctionOfferId;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	@ManyToOne
	@JoinColumn(name = "AUCTIONID", nullable = true)
	@Index(name = "auctionOfferAuctionIdIndex")
	public Auction getAuction() {
		return auction;
	}

	public void setAuction(Auction auction) {
		this.auction = auction;
	}

	@Enumerated(EnumType.STRING)
	public AuctionStatus getStatus() {
		return status;
	}

	public void setStatus(AuctionStatus status) {
		this.status = status;
	}

	@ManyToOne
	@JoinColumn(name = "SALESMANID", nullable = true)
	@Index(name = "auctionOfferSalesmanIdIndex")
	public Salesman getSalesman() {
		return salesman;
	}

	public void setSalesman(Salesman salesman) {
		this.salesman = salesman;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "auctionOffer")
	public List<PriceComponentValue> getPriceComponentValues() {
		return priceComponentValues;
	}

	public void setPriceComponentValues(
			List<PriceComponentValue> priceComponentValues) {
		this.priceComponentValues = priceComponentValues;
	}

	public Double getScore() {
		return score;
	}

	public void setScore(Double score) {
		this.score = score;
	}

	@Transient
	public List<PriceComponentValue> getConstantPriceComponentValues() {
		if (constantPriceComponentValues == null) {
			constantPriceComponentValues = new ArrayList<PriceComponentValue>();

			constantPricesValue = 0.00;

			for (PriceComponentValue pcv : priceComponentValues) {
				if (pcv.getPriceComponent().isConstant()) {
					constantPriceComponentValues.add(pcv);
					constantPricesValue += pcv.getValue();
				}
			}
		}
		return constantPriceComponentValues;
	}

	public void setConstantPriceComponentValues(
			List<PriceComponentValue> constantPriceComponentValues) {
		this.constantPriceComponentValues = constantPriceComponentValues;
	}

	@Transient
	public List<PriceComponentValue> getNotConstantPriceComponentValues() {
		notConstantPriceComponentValues = new ArrayList<PriceComponentValue>();
		notConstantPricesValue = 0.00;
		
		try {
                    
			for (PriceComponentValue pcv : priceComponentValues) {
				if (!pcv.getPriceComponent().isConstant()) {
					notConstantPriceComponentValues.add(pcv);
					notConstantPricesValue += pcv.getValue();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return notConstantPriceComponentValues;
	}
	
	@Transient
	public Double getOfferValue() {
		return getConstantPricesValue() + getNotConstantPricesValue();
	}

	public void setNotConstantPriceComponentValues(
			List<PriceComponentValue> notConstantPriceComponentValues) {
		this.notConstantPriceComponentValues = notConstantPriceComponentValues;
	}

	@Transient
	public Double getNotConstantPricesValue() {
		if (notConstantPricesValue == null)
			getNotConstantPriceComponentValues();

		return notConstantPricesValue;
	}

	public void setNotConstantPricesValue(Double notConstantPricesValue) {
		this.notConstantPricesValue = notConstantPricesValue;
	}

	@Transient
	public String getFormatedNotConstantPricesValue() {

		return formater.format(getNotConstantPricesValue());
	}

	@Transient
	public Double getConstantPricesValue() {
		if (constantPricesValue == null)
			getConstantPriceComponentValues();

		return constantPricesValue;
	}

	public void setConstantPricesValue(Double constantPricesValue) {
		this.constantPricesValue = constantPricesValue;
	}

	@Transient
	public String getFormatedConstantPricesValue() {
		DecimalFormat test = new DecimalFormat("0.00");
		return test.format(getConstantPricesValue());
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Boolean getIsSalesmanVisible() {
		return isSalesmanVisible;
	}

	public void setIsSalesmanVisible(Boolean isSalesmanVisible) {
		this.isSalesmanVisible = isSalesmanVisible;
	}
	
}