package pl.op.model.dict;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Index;

import pl.op.model.auction.PriceComponent;

@Entity
@Table(name = "TB_TARIFF")
public class Tariff implements Serializable {

	private static final long serialVersionUID = -9203933916075880745L;

	private Integer tariffId;
	private String tariffName;
	private List<PriceComponent> priceComponents;
	private Boolean removed;

	// Transient
	private String tariffNameFilter;
	private String profileIndicatorName;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TARIFF_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "TARIFF_SEQUENCE_GENERATOR", sequenceName = "TARIFF_ID_SEQ", allocationSize = 1)
	@Index(name = "tariffIndex")
	public Integer getTariffId() {
		return tariffId;
	}

	public void setTariffId(Integer tariffId) {
		this.tariffId = tariffId;
	}

	public String getTariffName() {
		return tariffName;
	}

	public void setTariffName(String tariffName) {
		this.tariffName = tariffName;
	}

	@ManyToMany
	@JoinTable(name = "tb_tariffPriceComponent", joinColumns = @JoinColumn(name = "tariffId"), inverseJoinColumns = @JoinColumn(name = "priceComponentId"))
	public List<PriceComponent> getPriceComponents() {
		return priceComponents;
	}

	public void setPriceComponents(List<PriceComponent> priceComponents) {
		this.priceComponents = priceComponents;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

	@Transient
	public String getTariffNameFilter() {
		return tariffNameFilter;
	}

	public void setTariffNameFilter(String tariffNameFilter) {
		this.tariffNameFilter = tariffNameFilter;
	}

	@Transient
	public String getProfileIndicatorName() {
		return profileIndicatorName;
	}

	public void setProfileIndicatorName(String profileIndicatorName) {
		this.profileIndicatorName = profileIndicatorName;
	}

}