package pl.op.model.cloud;

import pl.op.model.auction.ZoneType;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Street;
import pl.op.model.stereotype.Sector;
import pl.op.model.user.UserApp;

public class CloudFilter {

    private Cloud cloud;
    private String receiver;
    private VolumeEnum volume;
    private Double volumeFrom;
    private Double volumeTo;
    private String searchType;
    private City city;
    private Area area;
    private Street street;
    private Sector sector;
    private ZoneType zoneType;
    private UserApp user;

    // helpers
    private Double volumeFromInMWh;
    private Double volumeToInMWh;

    // lazy
    private Integer first;
    private Integer pageSize;

    public CloudFilter() {
        city = new City();
        area = new Area();
        street = new Street();
        sector = new Sector();
        user = new UserApp();
        cloud = new Cloud();
    }

    public Cloud getCloud() {
        return cloud;
    }

    public void setCloud(Cloud cloud) {
        this.cloud = cloud;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public VolumeEnum getVolume() {
        return volume;
    }

    public void setVolume(VolumeEnum volume) {
        this.volume = volume;
    }

    public Double getVolumeFrom() {
        return volumeFrom;
    }

    public void setVolumeFrom(Double volumeFrom) {
        this.volumeFrom = volumeFrom;
    }

    public Double getVolumeFromInMWh() {
        if(null == volumeFrom) {
            return 0.0;
        }
        if(VolumeEnum.MWH.equals(volume)) {
            return volumeFrom.doubleValue() * 1000.0;
        }
        if(VolumeEnum.GWH.equals(volume)) {
            return volumeFrom.doubleValue() * 1000000;
        }
        if(VolumeEnum.TWH.equals(volume)) {
            return volumeFrom.doubleValue() * 1000000000;
        }

        return volumeFrom.doubleValue();
    }

    public Double getVolumeToInMWh() {
        if(null == volumeTo) {
            return 0.0;
        }
        if(VolumeEnum.MWH.equals(volume)) {
            return volumeTo.doubleValue() * 1000.0;
        }
        if(VolumeEnum.GWH.equals(volume)) {
            return volumeTo.doubleValue() * 1000000;
        }
        if(VolumeEnum.TWH.equals(volume)) {
            return volumeTo.doubleValue() * 1000000000;
        }

        return volumeTo.doubleValue();
    }

    public Double getVolumeTo() {
        return volumeTo;
    }

    public void setVolumeTo(Double volumeTo) {
        this.volumeTo = volumeTo;
    }

    public String getSearchType() {
        return searchType;
    }

    public void setSearchType(String searchType) {
        this.searchType = searchType;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public Street getStreet() {
        return street;
    }

    public void setStreet(Street street) {
        this.street = street;
    }

    public Sector getSector() {
        return sector;
    }

    public void setSector(Sector sector) {
        this.sector = sector;
    }

    public ZoneType getZoneType() {
        return zoneType;
    }

    public void setZoneType(ZoneType zoneType) {
        this.zoneType = zoneType;
    }

    public Integer getFirst() {
        return first;
    }

    public void setFirst(Integer first) {
        this.first = first;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public UserApp getUser() {
        return user;
    }

    public void setUser(UserApp user) {
        this.user = user;
    }
    
    @Override
    public String toString() {
        String result = "CloudFilte: \n receiver:" + receiver + '\n' +
                "volumeFrom:" + volumeFrom + '\n' +
                "volumeTo:" + volumeTo + '\n'+
                "searchType:" + searchType + '\n';
        if (city != null) result+= "city:" + city.getCityName()+ '\n';
        if (area != null) result+= "area:" + area.getAreaName() + '\n';       
        if (street != null) result += "street:" + street.getStreetName() + '\n';
        if (sector != null) result += "sector:" + sector.getSectorName() + '\n';
        if (zoneType != null) result += "zoneType:" + zoneType.name() + '\n';
        if (user != null) result += "userID" + user.getUserId() + '\n';
        if (cloud != null) result += "cloud.name" + cloud.getName() + '\n'+
                "cloud.iscompany" + cloud.getIsCompany() + '\n'+
                "cloud.tarifid" + cloud.getTariff().getTariffName() + '\n'+
                "cloud.ismanual" + cloud.getIsManual() + '\n';
        for (Area aread : cloud.getAreas()) {
            result += "cloud.area:" + aread.getAreaName() + '\n';
        }
        
        return result;
    }
}