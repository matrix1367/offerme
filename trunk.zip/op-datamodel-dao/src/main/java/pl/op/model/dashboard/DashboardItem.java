package pl.op.model.dashboard;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_DASHBOARD_ITEM")
public class DashboardItem {

	private Integer dashboardItemId;
	private String dashboardItemName;
	private String dashboardItemShortName;
	private Integer orderId;
	private Boolean isActive;
	private Integer role;
	private Boolean roleUser;
	private Boolean roleUserJunior;
	private Boolean roleOperator;
	private Boolean roleSalesman;
	private Integer roleRule;
	private Boolean unpinnable;
	private DashboardItemSize size;

	public Boolean getRoleUser() {
		return roleUser;
	}

	public void setRoleUser(Boolean roleUser) {
		this.roleUser = roleUser;
	}

	public Boolean getRoleUserJunior() {
		return roleUserJunior;
	}

	public void setRoleUserJunior(Boolean roleUserJunior) {
		this.roleUserJunior = roleUserJunior;
	}

	public Boolean getRoleOperator() {
		return roleOperator;
	}

	public void setRoleOperator(Boolean roleOperator) {
		this.roleOperator = roleOperator;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DASHBOARD_ITEM_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "DASHBOARD_ITEM_SEQUENCE_GENERATOR", sequenceName = "DASHBOARD_ITEM_ID_SEQ", allocationSize = 1)
	@Index(name = "dashboardItemIndex")
	public Integer getDashboardItemId() {
		return dashboardItemId;
	}

	public void setDashboardItemId(Integer dashboardItemId) {
		this.dashboardItemId = dashboardItemId;
	}

	public String getDashboardItemName() {
		return dashboardItemName;
	}

	public void setDashboardItemName(String dashboardItemName) {
		this.dashboardItemName = dashboardItemName;
	}

	public String getDashboardItemShortName() {
		return dashboardItemShortName;
	}

	public void setDashboardItemShortName(String dashboardItemShortName) {
		this.dashboardItemShortName = dashboardItemShortName;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Integer getRole() {
		return role;
	}

	public void setRole(Integer role) {
		this.role = role;
	}

	public Integer getRoleRule() {
		return roleRule;
	}

	public void setRoleRule(Integer roleRule) {
		this.roleRule = roleRule;
	}

	public Boolean getUnpinnable() {
		return unpinnable;
	}

	public void setUnpinnable(Boolean unpinnable) {
		this.unpinnable = unpinnable;
	}

	public Boolean getRoleSalesman() {
		return roleSalesman;
	}

	public void setRoleSalesman(Boolean roleSalesman) {
		this.roleSalesman = roleSalesman;
	}

	public DashboardItemSize getSize() {
		return size;
	}

	public void setSize(DashboardItemSize size) {
		this.size = size;
	}

}
