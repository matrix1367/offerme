package pl.op.model.sms;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.*;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_SMSTEMPLATE")
public class SMSTemplate implements Serializable {
	private static final long serialVersionUID = 1122596876504899188L;
	
	/*
	 * Parametry oznaczane sa %X%, np.
	 * "Witaj, %X%. Twoj sms kod to %X%."
	 */
	
	private Long idSMSTemplate;
	private String name;
	private String content;
	private String language;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public Long getIdSMSTemplate() {
		return idSMSTemplate;
	}

	public void setIdSMSTemplate(Long idSMSTemplate) {
		this.idSMSTemplate = idSMSTemplate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}
	
	@Transient
	public String getMessageFromTemplate(String[] data) {
		String result = this.getContent();
		int i = 0;
		
		for(i=0;i<data.length;i=i+1) {
			result = result.replaceFirst("%X%", data[i]);
		}
		
		return result;
	}
}
