package pl.op.model.sms;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "TB_SMSOPERATIONTYPE")
public class SMSOperationType implements Serializable {

	private static final long serialVersionUID = -4817887392087342779L;

	private Integer idSMSOperationType;
	private String smsOperationType;
	private String smsOperationTypeDesc;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public Integer getIdSMSOperationType() {
		return idSMSOperationType;
	}

	public void setIdSMSOperationType(Integer idSMSOperationType) {
		this.idSMSOperationType = idSMSOperationType;
	}

	public String getSmsOperationType() {
		return smsOperationType;
	}

	public void setSmsOperationType(String smsOperationType) {
		this.smsOperationType = smsOperationType;
	}

	public String getSmsOperationTypeDesc() {
		return smsOperationTypeDesc;
	}

	public void setSmsOperationTypeDesc(String smsOperationTypeDesc) {
		this.smsOperationTypeDesc = smsOperationTypeDesc;
	}

}