package pl.op.model.dict;

import javax.persistence.Id;

public class Month {
	Integer numberofMonth;
	String name;
	
	@Id
	public Integer getNumberofMonth() {
		return numberofMonth;
	}
	public void setNumberofMonth(Integer numberofMonth) {
		this.numberofMonth = numberofMonth;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	} 
}