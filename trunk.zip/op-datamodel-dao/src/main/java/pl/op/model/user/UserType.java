package pl.op.model.user;

public enum UserType {

	type1tmp, type2tmp
	
}