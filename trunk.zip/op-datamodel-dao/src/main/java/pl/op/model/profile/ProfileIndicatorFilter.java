package pl.op.model.profile;

public class ProfileIndicatorFilter {

	private Integer tariffId;
	private Integer minHour;
	private Integer maxHour;
	private Double value;
	private boolean multiple;

	private DayType dayType;
	private String month;

	public ProfileIndicatorFilter() {
		multiple = false;
	}
	
	public Integer getTariffId() {
		return tariffId;
	}

	public void setTariffId(Integer tariffId) {
		this.tariffId = tariffId;
	}

	public Integer getMinHour() {
		return minHour;
	}

	public void setMinHour(Integer minHour) {
		this.minHour = minHour;
	}

	public Integer getMaxHour() {
		return maxHour;
	}

	public void setMaxHour(Integer maxHour) {
		this.maxHour = maxHour;
	}

	public DayType getDayType() {
		return dayType;
	}

	public void setDayType(DayType dayType) {
		this.dayType = dayType;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}
	
	public Double getValue() {
		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}

	public boolean isMultiple() {
		return multiple;
	}

	public void setMultiple(boolean multiple) {
		this.multiple = multiple;
	}
}
