package pl.op.model.contract;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.auction.PriceComponent;

@Entity
@Table(name = "TB_INVOICEPRICECOMPONENTVALUE")
public class InvoicePriceComponentValue implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = -9203933916075880745L;

    private Integer priceComponentValueId;
    private Double amount;
    private Double value;
    private PriceComponent priceComponent;
    private Invoice invoice;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "INVOPRICEVALUE_SEQUENCE_GENERATOR")
    @SequenceGenerator(name = "INVOPRICEVALUE_SEQUENCE_GENERATOR", sequenceName = "INVOPRICEVALUE_ID_SEQ", allocationSize = 1)
    @Index(name = "invoicePrcCompValueIndex")
    public Integer getPriceComponentValueId() {
        return priceComponentValueId;
    }

    public void setPriceComponentValueId(Integer priceComponentValueId) {
        this.priceComponentValueId = priceComponentValueId;
    }

    public Double getValue() {
        if(null == value) {
            return 0.0;
        }
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    @ManyToOne
    @JoinColumn(name = "PRICECOMPONENTID", nullable = true)
    @Index(name = "invoicePrcCompValuePCIdIndex")
    public PriceComponent getPriceComponent() {
        return priceComponent;
    }

    public void setPriceComponent(PriceComponent priceComponent) {
        this.priceComponent = priceComponent;
    }

    @ManyToOne
    @JoinColumn(name = "INVOICEID", nullable = true)
    @Index(name = "invoicePrcCompValueInvoiceIdIndex")
    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }

    public Double getAmount() {
        if(null == amount) {
            return 0.0;
        }
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }
}