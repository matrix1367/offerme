package pl.op.model.cloud;

import java.io.Serializable;
import static java.lang.Math.log;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import org.hibernate.annotations.Index;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.op.model.auction.Auction;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Street;
import pl.op.model.dict.Tariff;
import pl.op.model.salesman.Salesman;
import pl.op.model.stereotype.Stereotype;
import pl.op.model.user.UserApp;

@Entity
@Table(name = "TB_CLOUD")
public class Cloud implements Serializable {

    private static final long serialVersionUID = 8566366493194609271L;

    private Integer cloudId;
    private Date creationDate;
    private Date updatedAt;
    private String description;
    private String name;
    private Boolean removed;
    private List<UserApp> users = new ArrayList<UserApp>();
    private Stereotype stereotype;
    private Tariff tariff;
    private List<Auction> auctions;
    private Boolean isCompany;
    private List<City> cities = new ArrayList<City>();
    private List<Street> streets = new ArrayList<Street>();
    private List<Area> areas = new ArrayList<Area>();
    private Salesman salesman;
    private Double volume;
    private Boolean isManual;
    private Integer offersNumber = 0;

    private List<CloudVolume> cloudVolume;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CLOUD_SEQUENCE_GENERATOR")
    @SequenceGenerator(name = "CLOUD_SEQUENCE_GENERATOR", sequenceName = "CLOUD_ID_SEQ", allocationSize = 1)
    @Index(name = "cloudIndex")
    public Integer getCloudId() {
        return cloudId;
    }

    public void setCloudId(Integer cloudId) {
        this.cloudId = cloudId;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getRemoved() {
        return removed;
    }

    public void setRemoved(Boolean removed) {
        this.removed = removed;
    }
    
    public Boolean getIsCompany() {
        return isCompany;
    }

    public void setIsCompany(Boolean isCompany) {
        this.isCompany = isCompany;
    }

    @ManyToMany
    @JoinTable(name = "tb_UserCloud", joinColumns = @JoinColumn(name = "cloudId"), inverseJoinColumns = @JoinColumn(name = "userId"))
    public List<UserApp> getUsers() {
        if(users.size() == 1)
            if(users.get(0).getUserId() == null)
                users = new ArrayList<UserApp>();

        return users;
    }

    public void setUsers(List<UserApp> users) {
        this.users = users;
    }

    public void addUser(UserApp user) {
        if(this.users == null)
            this.users = new ArrayList<UserApp>();

        this.users.add(user);
    }

    @ManyToOne
    @JoinColumn(name = "TARIFFID", nullable = true)
    @Index(name = "cloudTariffIdIndex")
    public Tariff getTariff() {
        return tariff;
    }

    public void setTariff(Tariff tariff) {
        this.tariff = tariff;
    }

    @ManyToOne
    @JoinColumn(name = "STEREOTYPEID", nullable = true)
    @Index(name = "cloudStereotypeIndex")
    public Stereotype getStereotype() {
        return stereotype;
    }

    public void setStereotype(Stereotype stereotype) {
        this.stereotype = stereotype;
    }

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cloud")
    public List<Auction> getAuctions() {
        return auctions;
    }

    public void setAuctions(List<Auction> auctions) {
        this.auctions = auctions;
    }

    @ManyToMany
    @JoinTable(name = "tb_CloudCity", joinColumns = @JoinColumn(name = "cloudId"), inverseJoinColumns = @JoinColumn(name = "cityId"))
    public List<City> getCities() {
        return cities;
    }

    public void setCities(List<City> cities) {
        this.cities = cities;
    }

    public void addCity(City city) {
        if(this.cities == null)
            this.cities = new ArrayList<City>();

        this.cities.add(city);
    }

    @ManyToMany
    @JoinTable(name = "tb_CloudStreet", joinColumns = @JoinColumn(name = "cloudId"), inverseJoinColumns = @JoinColumn(name = "streetId"))
    public List<Street> getStreets() {
        return streets;
    }

    public void setStreets(List<Street> streets) {
        this.streets = streets;
    }

    public void addStreet(Street street) {
        if(this.streets == null)
            this.streets = new ArrayList<Street>();

        this.streets.add(street);
    }

    @ManyToMany
    @JoinTable(name = "tb_CloudArea", joinColumns = @JoinColumn(name = "cloudId"), inverseJoinColumns = @JoinColumn(name = "areaId"))
    public List<Area> getAreas() {
        return areas;
    }

    public void setAreas(List<Area> areas) {
        this.areas = areas;
    }

    public void addArea(Area area) {
        if(this.areas == null)
            this.areas = new ArrayList<Area>();

        this.areas.add(area);
    }

    @ManyToOne
    @JoinColumn(name = "SALESMANID", nullable = true)
    @Index(name = "cloudSalesmanIdIndex")
    public Salesman getSalesman() {
        return salesman;
    }

    public void setSalesman(Salesman salesman) {
        this.salesman = salesman;
    }

    @Transient
    public List<CloudVolume> getCloudVolume() {        
        return cloudVolume;
    }
    private Logger log = LoggerFactory.getLogger(Cloud.class);
    
    public void setCloudVolume(List<CloudVolume> cloudVolume) {       
        this.cloudVolume = cloudVolume;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Transient
    public void genereateName() {
        boolean stop = false;
        name = "";

        for(Area area : areas) {
            name += area.getAreaName().substring(0, 2);

            if(name.length() >= 27) {
                stop = true;
                break;
            }
        }

        if(!stop) {
            for(City city : cities) {
                name += city.getCityName().substring(0, 2);

                if(name.length() >= 27) {
                    stop = true;
                    break;
                }
            }
            if(!stop) {
                for(Street street : streets) {
                    name += street.getStreetName().substring(0, 2);

                    if(name.length() >= 27) {
                        stop = true;
                        break;
                    }
                }
            }
        }
        name += "_" + cloudId;
    }

    public Double getVolume() {
        if (volume == null) volume = 0.0;
        return volume;
    }

    public void setVolume(Double volume) {
        this.volume = volume;
    }

    public Boolean getIsManual() {
        return isManual;
    }

    public void setIsManual(Boolean isManual) {
        this.isManual = isManual;
    }

    @Override
    public String toString() {
        StringBuilder desc = new StringBuilder();

        desc.append("\n\n Cloud");
        desc.append("\n cloudId - " + cloudId);
        desc.append("\n creationDate - " + creationDate);
        desc.append("\n updatedAt - " + updatedAt);
        desc.append("\n description - " + description);
        desc.append("\n name - " + name);
        desc.append("\n removed - " + removed);
        desc.append("\n users - " + users);
        if(null != users) {
            desc.append("\n users.size() - " + users.size());
        }
        desc.append("\n stereotype - " + stereotype.getStereotypeId() + " " + stereotype.getStereotypeName());
        desc.append("\n tariff - " + tariff.getTariffName() + " " + tariff.getTariffId());
        desc.append("\n auctions - " + auctions);
        desc.append("\n isCompany - " + isCompany);
        desc.append("\n cities - " + cities);
        if(null != cities) {
            desc.append("\n cities.size() - " + cities.size());
        }
        desc.append("\n streets - " + streets);
        if(null != streets) {
            desc.append("\n streets.size() - " + streets.size());
        }
        desc.append("\n areas - " + areas);
        if(null != areas) {
            desc.append("\n areas.size() - " + areas.size());
        }
        desc.append("\n salesman - " + salesman);
        desc.append("\n volume - " + volume);
        desc.append("\n isManual - " + isManual);
        desc.append("\n END CLOUD \n");

        return desc.toString();
    }

    @Transient
    public Integer getOffersNumber() {
        return offersNumber;
    }

    public void setOffersNumber(Integer offersNumber) {
        this.offersNumber = offersNumber;
    }
}