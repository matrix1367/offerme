package pl.op.model.comment;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "TB_COMMENT_OLD")
public class Comment implements Serializable {

	private static final long serialVersionUID = -439491883399061846L;

	private Integer idComment;
	private String name;
	private String content;
	private String header;
	private Date dateComment;
	private Boolean removed;
	private Boolean active;
	private Date visibleDateFrom;
	private Date visibleDateTo;
	private String author;
	private List<File> files;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public Integer getIdComment() {
		return idComment;
	}

	public void setIdComment(Integer idComment) {
		this.idComment = idComment;
	}

	public Date getDateComment() {
		return dateComment;
	}

	public void setDateComment(Date dateComment) {
		this.dateComment = dateComment;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Column(nullable = false, length = 2000, columnDefinition = "TEXT")
	public String getContent() {
		return content;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Date getVisibleDateFrom() {
		return visibleDateFrom;
	}

	public void setVisibleDateFrom(Date visibleDateFrom) {
		this.visibleDateFrom = visibleDateFrom;
	}

	public Date getVisibleDateTo() {
		return visibleDateTo;
	}

	public void setVisibleDateTo(Date visibleDateTo) {
		this.visibleDateTo = visibleDateTo;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	@Column(length = 30)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "comment")
	public List<File> getFiles() {
		return files;
	}

	public void setFiles(List<File> files) {
		this.files = files;
	}
	
}
