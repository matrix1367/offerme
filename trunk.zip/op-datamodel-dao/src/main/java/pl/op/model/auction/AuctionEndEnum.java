package pl.op.model.auction;

public enum AuctionEndEnum {

	THIRTY_SEC (1), 
	FIFTEEN_MIN (0.25),
	THIRTY_MIN (0.5),
	FOURTY_MIN (0.75),
	ONE_HOUR(1),
	TWO_HOURS(2),
	SIX_HOURS(6),
	TWELVE_HOURS(12),
	DAY (24),
	TWODAYS (48);
	
	private String label;
	private double time;
	
	AuctionEndEnum(double time){
		this.setTime(time);
	}
		
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public double getTime() {
		return time;
	}

	public void setTime(double time) {
		this.time = time;
	}
}