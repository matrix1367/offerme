package pl.op.model.bonus;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.user.UserApp;

@Entity
@Table(name = "TB_USERPOINTS")
public class UserPoints implements Serializable {

	private static final long serialVersionUID = -8078561855376134526L;
	
	private Integer userPointsId;
	private Boolean isGranted;
	private Integer noRepeats;
	private Date updatedAt;	
	
	private UserApp user;
	private PointsRules pointsRules;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "USERPOINTS_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "USERPOINTS_SEQUENCE_GENERATOR", sequenceName = "USERPOINTS_ID_SEQ", allocationSize = 1)
	@Index(name = "userPointsIndex")
	public Integer getUserPointsId() {
		return userPointsId;
	}
	public void setUserPointsId(Integer userPointsId) {
		this.userPointsId = userPointsId;
	}
	
	public Boolean getIsGranted() {
		return isGranted;
	}
	public void setIsGranted(Boolean isGranted) {
		this.isGranted = isGranted;
	}
	
	public Integer getNoRepeats() {
		return noRepeats;
	}
	public void setNoRepeats(Integer noRepeats) {
		this.noRepeats = noRepeats;
	}
	
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	@ManyToOne
	@JoinColumn(name = "USERID", nullable = false)
	@Index(name = "userPointsUserIdIndex")
	public UserApp getUser() {
		return user;
	}
	public void setUser(UserApp user) {
		this.user = user;
	}
	
	@ManyToOne
	@JoinColumn(name = "POINTSRULESID", nullable = false)
	@Index(name = "userPointsRulesIdIndex")
	public PointsRules getPointsRules() {
		return pointsRules;
	}
	public void setPointsRules(PointsRules pointsRules) {
		this.pointsRules = pointsRules;
	}

}
