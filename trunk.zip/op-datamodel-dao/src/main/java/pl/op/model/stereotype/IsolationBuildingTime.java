package pl.op.model.stereotype;

public enum IsolationBuildingTime {

	one_five, six_fifteen, more_fifteen;
	
	private String label;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
}