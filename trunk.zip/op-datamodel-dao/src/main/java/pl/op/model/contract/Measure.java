package pl.op.model.contract;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.auction.ZoneType;
import pl.op.model.cloud.VolumeEnum;
import pl.op.model.dict.Obis;

@Entity
@Table(name = "TB_MEASURE")
public class Measure implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9203933916075880745L;

	private Integer measureId;
	private Date dateFrom;
	private Date dateTo;
	private Date measureDate;
	private Double value;
	private VolumeEnum valueUnit;
	private ZoneType zoneType;
	private PPE ppe;
	private Priority priority;
	private Obis obis;
	private Invoice invoice;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MEASURE_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "MEASURE_SEQUENCE_GENERATOR", sequenceName = "MEASURE_ID_SEQ", allocationSize = 1)
	@Index(name = "measureIndex")
	public Integer getMeasureId() {
		return measureId;
	}

	public void setMeasureId(Integer measureId) {
		this.measureId = measureId;
	}

	public Date getDateFrom() {
		return dateFrom;
	}

	public void setDateFrom(Date dateFrom) {
		this.dateFrom = dateFrom;
	}

	public Date getDateTo() {
		return dateTo;
	}

	public void setDateTo(Date dateTo) {
		this.dateTo = dateTo;
	}

	public Date getMeasureDate() {
		return measureDate;
	}

	public void setMeasureDate(Date measureDate) {
		this.measureDate = measureDate;
	}

	public Double getValue() {
		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}

	@Enumerated(EnumType.STRING)
	public ZoneType getZoneType() {
		return zoneType;
	}

	public void setZoneType(ZoneType zoneType) {
		this.zoneType = zoneType;
	}

	@ManyToOne
	@JoinColumn(name = "PPEID", nullable = true)
	@Index(name = "measurePPEIndex")
	public PPE getPpe() {
		return ppe;
	}

	public void setPpe(PPE ppe) {
		this.ppe = ppe;
	}

	@Enumerated(EnumType.STRING)
	public Priority getPriority() {
		return priority;
	}

	public void setPriority(Priority priority) {
		this.priority = priority;
	}

	@Enumerated(EnumType.STRING)
	public VolumeEnum getValueUnit() {
		if(valueUnit == null){
			valueUnit = VolumeEnum.MWH;
		}
		return valueUnit;
	}

	public void setValueUnit(VolumeEnum valueUnit) {
		this.valueUnit = valueUnit;
	}

	@ManyToOne
	@JoinColumn(name = "OBISID", nullable = true)
	@Index(name = "measureOBISIndex")
	public Obis getObis() {
		return obis;
	}

	public void setObis(Obis obis) {
		this.obis = obis;
	}

	@ManyToOne
	@JoinColumn(name = "INVOICEID", nullable = true)
	@Index(name = "measureInvoiceIndex")
	public Invoice getInvoice() {
		return invoice;
	}

	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}

}