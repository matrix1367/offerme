package pl.op.model.dict;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_CITY")
public class City implements Serializable {

	private static final long serialVersionUID = -5259134391123547231L;

	private Integer cityId;
	private String cityName;
	private Area area;
	private Boolean hasStatus;
	private String symbol;

	// Transient
	private Integer cloudId;
	private Integer areaId;
	private Integer limit;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CITY_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "CITY_SEQUENCE_GENERATOR", sequenceName = "CITY_ID_SEQ", allocationSize = 1)
	@Index(name = "cityIndex")
	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cityId == null) ? 0 : cityId.hashCode());
		result = prime * result
				+ ((cityName == null) ? 0 : cityName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof City)) {
			return false;
		}
		City other = (City) obj;
		if (cityId == null) {
			if (other.cityId != null) {
				return false;
			}
		} else if (!cityId.equals(other.cityId)) {
			return false;
		}
		if (cityName == null) {
			if (other.cityName != null) {
				return false;
			}
		} else if (!cityName.equals(other.cityName)) {
			return false;
		}

		return true;
	}

	@ManyToOne
	@JoinColumn(name = "AREAID", nullable = true)
	@Index(name = "cityAreaIndex")
	public Area getArea() {
		return area;
	}

	public void setArea(Area area) {
		this.area = area;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	@Transient
	public Integer getCloudId() {
		return cloudId;
	}

	public void setCloudId(Integer cloudId) {
		this.cloudId = cloudId;
	}

	public Boolean getHasStatus() {
		return hasStatus;
	}

	public void setHasStatus(Boolean hasStatus) {
		this.hasStatus = hasStatus;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	@Transient
	public Integer getLimit() {
		return limit;
	}

	public void setLimit(Integer limit) {
		this.limit = limit;
	}

	@Transient
	public Integer getAreaId() {
		return areaId;
	}

	public void setAreaId(Integer areaId) {
		this.areaId = areaId;
	}
}
