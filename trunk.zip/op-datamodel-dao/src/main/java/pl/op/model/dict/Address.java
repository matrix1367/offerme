package pl.op.model.dict;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_ADDRESS")
public class Address implements Serializable {

	private static final long serialVersionUID = -5259134391123547231L;

	private Integer addressId;
	private String zipCode;
	private String flatNo;
	private String homeNo;
	private Street street;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ADDRESS_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "ADDRESS_SEQUENCE_GENERATOR", sequenceName = "ADDRESS_ID_SEQ", allocationSize = 1)
	@Index(name = "addressIndex")
	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getFlatNo() {
		return flatNo;
	}

	public void setFlatNo(String flatNo) {
		this.flatNo = flatNo;
	}

	public String getHomeNo() {
		return homeNo;
	}

	public void setHomeNo(String homeNo) {
		this.homeNo = homeNo;
	}

	@ManyToOne
	@JoinColumn(name = "STREETID", nullable = true)
	@Index(name = "addressStreetIndex")
	public Street getStreet() {
		return street;
	}

	public void setStreet(Street street) {
		this.street = street;
	}

}
