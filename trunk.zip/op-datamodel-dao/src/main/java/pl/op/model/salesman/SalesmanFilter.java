package pl.op.model.salesman;

import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Street;

public class SalesmanFilter {

	private Salesman salesman;
	
	private Area area;
	private City city;
	private Street street;
	
	public void salesmanFilter() {
		city = new City();
		area = new Area();
		street = new Street();
		salesman = new Salesman();
	}

	public Salesman getSalesman() {
		return salesman;
	}

	public void setSalesman(Salesman salesman) {
		this.salesman = salesman;
	}

	public Area getArea() {
		return area;
	}

	public void setArea(Area area) {
		this.area = area;
	}

	public City getCity() {
		return city;
	}

	public void setCity(City city) {
		this.city = city;
	}

	public Street getStreet() {
		return street;
	}

	public void setStreet(Street street) {
		this.street = street;
	}
}
