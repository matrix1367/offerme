package pl.op.model.profile;

public enum DayType {
	MONDAY_FRIDAY, SATURDAY, SUNDAY;

	private String label;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
}
