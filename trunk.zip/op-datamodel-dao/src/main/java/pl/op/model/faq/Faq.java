package pl.op.model.faq;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.msg.Message;

@Entity
@Table(name = "TB_FAQ")
public class Faq implements Serializable {

	private static final long serialVersionUID = -7981962247043147631L;

	private Integer askQuestionId;
	private String question;
	private Boolean removed;
	private QuestionType questionType;
	private String questionAnswer;
	private Boolean visible;
	private Message message;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "FAQ_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "FAQ_SEQUENCE_GENERATOR", sequenceName = "FAQ_ID_SEQ")
	@Index(name = "faqIndex")
	public Integer getAskQuestionId() {
		return askQuestionId;
	}

	public void setAskQuestionId(Integer askQuestionId) {
		this.askQuestionId = askQuestionId;
	}

	@Enumerated(EnumType.STRING)
	public QuestionType getQuestionType() {
		return questionType;
	}

	public void setQuestionType(QuestionType questionType) {
		this.questionType = questionType;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

	public String getQuestionAnswer() {
		return questionAnswer;
	}

	public void setQuestionAnswer(String questionAnswer) {
		this.questionAnswer = questionAnswer;
	}

	public Boolean getVisible() {
		return visible;
	}

	public void setVisible(Boolean visible) {
		this.visible = visible;
	}

	@OneToOne
	@JoinColumn(name = "messageId", nullable = true)
	@Index(name = "messageIdFaqIndex")
	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}
}
