package pl.op.model.question;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.stereotype.Stereotype;
import pl.op.model.user.UserApp;

@Entity
@Table(name = "TB_QUESTIONVALUE")
public class QuestionValue implements Serializable {

	private static final long serialVersionUID = 2473808985961874113L;

	private Integer questionValueId;
	private String questionValueString;
	private Boolean questionValueBoolean;
	private UserApp userApp;
	private Stereotype stereotype;
	private PreferenceQuestion preferenceQuestion;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "QUESTIONVALUE_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "QUESTIONVALUE_SEQUENCE_GENERATOR", sequenceName = "QUESTIONVALUE_ID_SEQ", allocationSize = 1)
	@Index(name = "questionValueIndex")
	public Integer getQuestionValueId() {
		return questionValueId;
	}

	public void setQuestionValueId(Integer questionValueId) {
		this.questionValueId = questionValueId;
	}

	public String getQuestionValueString() {
		return questionValueString;
	}

	public void setQuestionValueString(String questionValueString) {
		this.questionValueString = questionValueString;
	}

	public Boolean getQuestionValueBoolean() {
                if (questionValueBoolean == null) questionValueBoolean = false;
		return questionValueBoolean;
	}

	public void setQuestionValueBoolean(Boolean questionValueBoolean) {
		this.questionValueBoolean = questionValueBoolean;
	}

	@ManyToOne
	@JoinColumn(name = "USERID", nullable = true)
	@Index(name = "questionValueUserIndex")
	public UserApp getUserApp() {
		return userApp;
	}

	public void setUserApp(UserApp userApp) {
		this.userApp = userApp;
	}

	@ManyToOne
	@JoinColumn(name = "STEREOTYPEID", nullable = true)
	@Index(name = "questionValueStereotypeIndex")
	public Stereotype getStereotype() {
		return stereotype;
	}

	public void setStereotype(Stereotype stereotype) {
		this.stereotype = stereotype;
	}

	@ManyToOne
	@JoinColumn(name = "PREFERENCEQUESTIONID", nullable = true)
	public PreferenceQuestion getPreferenceQuestion() {
		return preferenceQuestion;
	}

	public void setPreferenceQuestion(PreferenceQuestion preferenceQuestion) {
		this.preferenceQuestion = preferenceQuestion;
	}
}