package pl.op.model.auction;

public class AuctionOfferDiffrent {
    private Double actualPrice;
    private Double newPrice;
    private Double diff;
    private Double diffPercent;
    private int diffType;
    private String diffTypeName;

    public AuctionOfferDiffrent(Double invoicePrice, Double offerPrice) {
        if(isValidPrice(invoicePrice)) {
            actualPrice = invoicePrice;
        } else {
            actualPrice = 0.0;
        }
        if(isValidPrice(offerPrice)) {
            newPrice = offerPrice;
        } else {
            newPrice = 0.0;
        }

        diffType = actualPrice.compareTo(newPrice);

        diff = 0.0;
        diffPercent = 0.0;

        calculateDiff();
    }

    private boolean isValidPrice(Double price) {
        if(null == price) {
            return false;
        }

        return true;
    }

    private void calculateDiff() {
        if(diffType >= 0) {
            diff = actualPrice - newPrice;
            diffPercent = 100 - ((newPrice * 100) / actualPrice);
            if(diffType > 0) {
                diffTypeName = "less";
            } else {
                diffTypeName = "";
            }
        } else {
            diff = newPrice - actualPrice;
            diffPercent = 100 - ((actualPrice * 100) / newPrice);

            diffTypeName = "more";
        }
    }

    public Double getActualPrice() {
        return actualPrice;
    }

    public Double getNewPrice() {
        return newPrice;
    }

    public String getDiffTypeName() {
        return diffTypeName;
    }

    public Double getDiffPercent() {
        return diffPercent;
    }
}
