package pl.op.model.stereotype;

public enum WarmBuildingOutside {

	mineral_wool , styrofoam_eps, polystyrene_xps, neopor, cellulose_fibers, mineral_plate;
	
	private String label;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
}