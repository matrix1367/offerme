package pl.op.model.contract;

public enum PPEStatus {

    READY_TO_JOIN, JOINED, AIMED_TO_AGREEMENT, REFUSED_AGREEMENT, DURING_AGREEMENT, INVOICE_MISSING;

    private String label;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}