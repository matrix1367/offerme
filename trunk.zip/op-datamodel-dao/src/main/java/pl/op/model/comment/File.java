package pl.op.model.comment;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name = "TB_FILE")
public class File implements Serializable {

	private static final long serialVersionUID = -4056287257761252139L;

	private Integer fileId;
	private String name;
	private String url;
	private Comment comment;
	private byte[] image;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public Integer getFileId() {
		return fileId;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@ManyToOne
	@JoinColumn(name = "IDCOMMENT", nullable = false)
	public Comment getComment() {
		return comment;
	}

	public void setComment(Comment comment) {
		this.comment = comment;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

}
