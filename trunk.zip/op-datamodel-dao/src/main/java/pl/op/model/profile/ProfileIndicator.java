package pl.op.model.profile;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.dict.Tariff;

@Entity
@Table(name = "TB_PROFILEINDICATOR")
public class ProfileIndicator implements Serializable {

	private static final long serialVersionUID = -2591133661175007982L;

	private Integer profileIndicatorId;
	private Integer dayQuantity;
	private DayType dayType;
	private String month;
	private Tariff tariff;
	private List<ProfileValue> profileValues;
	private String profileName;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PROFILEINDICATOR_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "PROFILEINDICATOR_SEQUENCE_GENERATOR", sequenceName = "PROFILEINDICATOR_ID_SEQ", allocationSize = 1)
	@Index(name = "profileIndicatorIndex")
	public Integer getProfileIndicatorId() {
		return profileIndicatorId;
	}

	public void setProfileIndicatorId(Integer profileIndicatorId) {
		this.profileIndicatorId = profileIndicatorId;
	}

	public Integer getDayQuantity() {
		return dayQuantity;
	}

	public void setDayQuantity(Integer dayQuantity) {
		this.dayQuantity = dayQuantity;
	}

	@Enumerated(EnumType.STRING)
	public DayType getDayType() {
		return dayType;
	}

	public void setDayType(DayType dayType) {
		this.dayType = dayType;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "profileIndicator")
	public List<ProfileValue> getProfileValues() {
		return profileValues;
	}

	public void setProfileValues(List<ProfileValue> profileValues) {
		this.profileValues = profileValues;
	}

	@ManyToOne
	@JoinColumn(name = "TARIFFID", nullable = true)
	@Index(name = "profileIndicatorTariffIndex")
	public Tariff getTariff() {
		return tariff;
	}

	public void setTariff(Tariff tariff) {
		this.tariff = tariff;
	}

	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}
}