package pl.op.model.device;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_DEVICECATEGORY")
public class DeviceCategory implements Serializable {

	private static final long serialVersionUID = -6172075784260721340L;

	private Integer deviceCategoryId;
	private String name;
	private ImportanceEnum importance;
	private List<DeviceType> deviceType;
	private Boolean removed;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DEVCATEGORY_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "DEVCATEGORY_SEQUENCE_GENERATOR", sequenceName = "DEVCATEGORY_ID_SEQ", allocationSize = 1)
	@Index(name = "deviceCategoryIndex")
	public Integer getDeviceCategoryId() {
		return deviceCategoryId;
	}

	public void setDeviceCategoryId(Integer deviceCategoryId) {
		this.deviceCategoryId = deviceCategoryId;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	@Enumerated(EnumType.STRING)
	public ImportanceEnum getImportance() {
		return importance;
	}
	
	public void setImportance(ImportanceEnum importance) {
		this.importance = importance;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "deviceCategory")
	public List<DeviceType> getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(List<DeviceType> deviceType) {
		this.deviceType = deviceType;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}


}