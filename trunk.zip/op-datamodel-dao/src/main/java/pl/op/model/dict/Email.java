/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pl.op.model.dict;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.hibernate.annotations.Index;

/**
 *
 * @author dev
 */
@Entity
@Table(name = "TB_EMAIL")
public class Email  implements Serializable {
    private static final long serialVersionUID = -3259134391123547231L;
    
    
    private Integer emailId;
    private String email;
    private String category;
    private Boolean removed;
    
   
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "EMAIL_SEQUENCE_GENERATOR")
    @SequenceGenerator(name = "EMAIL_SEQUENCE_GENERATOR", sequenceName = "EMAIL_ID_SEQ", allocationSize = 1)
    @Index(name = "emailIndex")
    public Integer getEmailId() {
        return emailId;
    }

    public void setEmailId(Integer emailId) {
        this.emailId = emailId;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }        

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Boolean isRemoved() {
        return removed;
    }
    
    public Boolean getRemoved() {
        return removed;
    }

    public void setRemoved(Boolean removed) {
        this.removed = removed;
    }
    
    
    
}
