package pl.op.model.dict;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.contract.PPE;

@Entity
@Table(name = "TB_PPETARIFF")
public class PPETariff implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9203933916075880745L;

	private Integer ppeTariffId;
	private Date startDate;
	private Date endDate;
	private Tariff tariff;
	private PPE ppe;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PPETARIFF_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "PPETARIFF_SEQUENCE_GENERATOR", sequenceName = "PPETARIFF_ID_SEQ", allocationSize = 1)
	@Index(name = "ppeTariffIndex")
	public Integer getPpeTariffId() {
		return ppeTariffId;
	}

	public void setPpeTariffId(Integer ppeTariffId) {
		this.ppeTariffId = ppeTariffId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	@ManyToOne
	@JoinColumn(name = "TARIFFID", nullable = true)
	@Index(name = "ppeTariffTariffIdIndex")
	public Tariff getTariff() {
		return tariff;
	}

	public void setTariff(Tariff tariff) {
		this.tariff = tariff;
	}

	@ManyToOne
	@JoinColumn(name = "PPEID", nullable = true)
	@Index(name = "ppeTariffPPEIdIndex")
	public PPE getPpe() {
		return ppe;
	}

	public void setPpe(PPE ppe) {
		this.ppe = ppe;
	}

}