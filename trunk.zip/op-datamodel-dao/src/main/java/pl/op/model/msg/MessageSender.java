package pl.op.model.msg;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.user.UserApp;

@Entity
@Table(name = "TB_USERAPPSENDER_TB_MESSAGE")
public class MessageSender implements Serializable {

	private static final long serialVersionUID = 1989800337156214780L;

	private Integer messageSenderId;
	private Message message;
	private UserApp user;
	private Boolean removed;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MSGSENDER_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "MSGSENDER_SEQUENCE_GENERATOR", sequenceName = "MSGSENDER_ID_SEQ")
	@Index(name = "messageSenderIndex")
	public Integer getMessageSenderId() {
		return messageSenderId;
	}

	public void setMessageSenderId(Integer messageSenderId) {
		this.messageSenderId = messageSenderId;
	}

	@OneToOne
	@JoinColumn(name = "messageId", nullable = false)
	@Index(name = "messageMessageIdIndex")
	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

	@ManyToOne
	@JoinColumn(name = "userId", nullable = false)
	@Index(name = "messageMessageSenderUserIndex")
	public UserApp getUser() {
		return user;
	}

	public void setUser(UserApp user) {
		this.user = user;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

}
