package pl.op.model.bonus;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;
import org.hibernate.annotations.Type;

import pl.op.model.user.UserApp;

@Entity
@Table(name = "TB_POINTSRULES")
public class PointsRules implements Serializable {

	private static final long serialVersionUID = -907849950062743887L;

	private Integer pointsRulesId;
	private Integer pointsAmount;
	private Integer repeatsNeed;
	private String bonusName;
	private String bonusDescription;
	private String contact;
	private String photoLink;
	private Boolean isActive;
	private Boolean isOncePerDay;
	private Boolean isRepeatable;
	private Boolean isAccepted;
	private Boolean isDeleted;
	private Date updatedAt;
	private Date createdAt;

	private Event event;
	private UserApp user;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "POINTSRULES_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "POINTSRULES_SEQUENCE_GENERATOR", sequenceName = "POINTSRULES_ID_SEQ", allocationSize = 1)
	@Index(name = "pointRulesIndex")
	public Integer getPointsRulesId() {
		return pointsRulesId;
	}

	public void setPointsRulesId(Integer pointsRulesId) {
		this.pointsRulesId = pointsRulesId;
	}

	public String getBonusName() {
		return bonusName;
	}

	public void setBonusName(String bonusName) {
		this.bonusName = bonusName;
	}

	@Type(type = "text")
	public String getBonusDescription() {
		return bonusDescription;
	}

	public void setBonusDescription(String bonusDescription) {
		this.bonusDescription = bonusDescription;
	}

	@Type(type = "text")
	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getPhotoLink() {
		return photoLink;
	}

	public void setPhotoLink(String photoLink) {
		this.photoLink = photoLink;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean getIsOncePerDay() {
		return isOncePerDay;
	}

	public void setIsOncePerDay(Boolean isOncePerDay) {
		this.isOncePerDay = isOncePerDay;
	}

	public Boolean getIsRepeatable() {
		return isRepeatable;
	}

	public void setIsRepeatable(Boolean isRepeatable) {
		this.isRepeatable = isRepeatable;
	}

	public Boolean getIsAccepted() {
		return isAccepted;
	}

	public void setIsAccepted(Boolean isAccepted) {
		this.isAccepted = isAccepted;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Integer getPointsAmount() {
		return pointsAmount;
	}

	public void setPointsAmount(Integer pointsAmount) {
		this.pointsAmount = pointsAmount;
	}

	public Integer getRepeatsNeed() {
		return repeatsNeed;
	}

	public void setRepeatsNeed(Integer repeatsNeed) {
		this.repeatsNeed = repeatsNeed;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	@ManyToOne
	@JoinColumn(name = "EVENTID", nullable = false)
	@Index(name = "pointRulesEventIdIndex")
	public Event getEvent() {
		return event;
	}

	public void setEvent(Event event) {
		this.event = event;
	}

	@ManyToOne
	@JoinColumn(name = "USERID", nullable = false)
	@Index(name = "pointRulesUserIdIndex")
	public UserApp getUser() {
		return user;
	}

	public void setUser(UserApp user) {
		this.user = user;
	}

}