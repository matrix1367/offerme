package pl.op.model.cloud;

import pl.op.model.auction.ZoneType;

public class CloudVolume {

	private Double volume;
	private ZoneType zoneType;
	
	public Double getVolume() {
		return volume;
	}
        
        public Double getPercentVolume(Double volumeGlobal) {
            if (volumeGlobal > 0) {
                return (volume/ volumeGlobal) * 100;
            } 
            
            return 0.0;
        }

	public void setVolume(Double volume) {
		this.volume = volume;
	}

	public ZoneType getZoneType() {
		return zoneType;
	}

	public void setZoneType(ZoneType zoneType) {
		this.zoneType = zoneType;
	}

}