package pl.op.model.user;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Index;
import org.hibernate.validator.NotNull;

import pl.op.model.cloud.Cloud;
import pl.op.model.contract.Location;
import pl.op.model.msg.MessageSender;
import pl.op.model.msg.UserToMessage;
import pl.op.model.question.QuestionValue;
import pl.op.model.salesman.Salesman;
import pl.op.model.stereotype.Sector;
import pl.op.validation.annotations.NipValidator;
import pl.op.validation.annotations.PhoneValidator;

@Entity
@Table(name = "TB_USERAPP")
public class UserApp implements Serializable {

    private static final long serialVersionUID = -1517854890490461015L;

    private Integer userId;
    private Boolean active;
    private Boolean removed;
    private Boolean fromFacebook;
    private String facebookUsername;
    private String facebookUserId;
    private String firstName;
    private String login;
    private String nip;
    private String password;
    private String password2;
    private String surname;
    private String phone;
    private String recommendation;
    private Boolean agree;
    private Boolean canBeDeleted;
    private Boolean firstLogin;
    private UserType userType;
    private UserRole userRole;
    private String activateKey;
    private Boolean phoneActivated;
    private String login2;
    private String oldPassword;
    private String pesel;
    private Date creationDate;
    private List<Location> locations;
    private List<UserToMessage> userTomessage;
    private List<MessageSender> messageSender;
    private Group group;
    private List<QuestionValue> questionValues;
    private Sector sector;
    private Date birthDate;
    private Salesman salesman;
    private List<Cloud> clouds;
    private Boolean isCompany;
    private String krs;
    private String regon;
    private String companyName;
    private String fullName;

    private Integer cloudId;
    private Integer sectorId;
    private Location location;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "USERAPP_SEQUENCE_GENERATOR")
    @SequenceGenerator(name = "USERAPP_SEQUENCE_GENERATOR", sequenceName = "USER_ID_SEQ")
    @Index(name = "userAppIndex")
    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getPesel() {
        return pesel;
    }

    public void setPesel(String pesel) {
        this.pesel = pesel;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @Transient
    public String getLogin2() {
        return login2;
    }

    @Transient
    public void setLogin2(String login2) {
        this.login2 = login2;
    }

    @NotNull
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Transient
    public String getPassword2() {
        return password2;
    }

    @Transient
    public void setPassword2(String password2) {
        this.password2 = password2;
    }

    @Transient
    public String getOldPassword() {
        return oldPassword;
    }

    @Transient
    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    @Enumerated(EnumType.STRING)
    public UserRole getUserRole() {
        return userRole;
    }

    public void setUserRole(UserRole userRole) {
        this.userRole = userRole;
    }

    @Enumerated(EnumType.STRING)
    public UserType getUserType() {
        return userType;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    public Boolean getAgree() {
        return agree;
    }

    public void setAgree(Boolean agree) {
        this.agree = agree;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    @PhoneValidator
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @NipValidator
    public String getNip() {
        return nip;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Boolean getRemoved() {
        return removed;
    }

    public void setRemoved(Boolean removed) {
        this.removed = removed;
    }

    public Boolean getCanBeDeleted() {
        return canBeDeleted;
    }

    public void setCanBeDeleted(Boolean canBeDeleted) {
        this.canBeDeleted = canBeDeleted;
    }

    public Boolean getFirstLogin() {
        return firstLogin;
    }

    public void setFirstLogin(Boolean firstLogin) {
        this.firstLogin = firstLogin;
    }

    public String getRecommendation() {
        return recommendation;
    }

    public void setRecommendation(String recommendation) {
        this.recommendation = recommendation;
    }

    public String getActivateKey() {
        return activateKey;
    }

    public void setActivateKey(String activateKey) {
        this.activateKey = activateKey;
    }

    public Boolean getPhoneActivated() {
        return phoneActivated;
    }

    public void setPhoneActivated(Boolean phoneActivated) {
        this.phoneActivated = phoneActivated;
    }

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userApp")
    public List<QuestionValue> getQuestionValues() {
        return questionValues;
    }

    public void setQuestionValues(List<QuestionValue> questionValues) {
        this.questionValues = questionValues;
    }

    @ManyToOne
    @JoinColumn(name = "IDGROUP", nullable = true)
    @Index(name = "userAppGroupIndex")
    public Group getGroup() {
        return group;
    }

    public void setGroup(Group group) {
        this.group = group;
    }

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userApp")
    public List<Location> getLocations() {
        return locations;
    }

    public void setLocations(List<Location> locations) {
        this.locations = locations;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    @ManyToOne
    @JoinColumn(name = "SALESMANID", nullable = true)
    @Index(name = "userAppSalesmanIndex")
    public Salesman getSalesman() {
        return salesman;
    }

    public void setSalesman(Salesman salesman) {
        this.salesman = salesman;
    }

    /**
     * @return the fromFacebook
     */
    public Boolean isFromFacebook() {
        return fromFacebook;
    }

    /**
     * @param fromFacebook
     *            the fromFacebook to set
     */
    public void setFromFacebook(Boolean fromFacebook) {
        this.fromFacebook = fromFacebook;
    }

    @ManyToMany(mappedBy = "users")
    public List<Cloud> getClouds() {
        return clouds;
    }

    public void setClouds(List<Cloud> clouds) {
        this.clouds = clouds;
    }

    @OneToMany(mappedBy = "user")
    public List<UserToMessage> getUserTomessage() {
        return userTomessage;
    }

    public void setUserTomessage(List<UserToMessage> userTomessage) {
        this.userTomessage = userTomessage;
    }

    @OneToMany(mappedBy = "user")
    public List<MessageSender> getMessageSender() {
        return messageSender;
    }

    public void setMessageSender(List<MessageSender> messageSender) {
        this.messageSender = messageSender;
    }

    @Transient
    public Integer getCloudId() {
        return cloudId;
    }

    public void setCloudId(Integer cloudId) {
        this.cloudId = cloudId;
    }

    @ManyToOne
    @JoinColumn(name = "SECTORID", nullable = true)
    @Index(name = "userAppSectorIndex")
    public Sector getSector() {
        return sector;
    }

    public void setSector(Sector sector) {
        this.sector = sector;
    }

    public String getKrs() {
        return krs;
    }

    public void setKrs(String krs) {
        this.krs = krs;
    }

    public String getRegon() {
        return regon;
    }

    public void setRegon(String regon) {
        this.regon = regon;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    /**
     * @return the facebookUsername
     */
    @Column(name = "facebookUsername")
    public String getFacebookUsername() {
        return facebookUsername;
    }

    /**
     * @param facebookUsername
     *            the facebookUsername to set
     */
    public void setFacebookUsername(String facebookUsername) {
        this.facebookUsername = facebookUsername;
    }

    /**
     * @return the facebookUserId
     */
    @Column(name = "facebookUserId")
    public String getFacebookUserId() {
        return facebookUserId;
    }

    /**
     * @param facebookUserId
     *            the facebookUserId to set
     */
    public void setFacebookUserId(String facebookUserId) {
        this.facebookUserId = facebookUserId;
    }

    @Transient
    public Integer getSectorId() {
        return sectorId;
    }

    public void setSectorId(Integer sectorId) {
        this.sectorId = sectorId;
    }

    public Boolean getIsCompany() {
        return isCompany;
    }

    public void setIsCompany(Boolean isCompany) {
        this.isCompany = isCompany;
    }

    @Transient
    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    @Transient
    public String getFullName() {
        return firstName + " " + surname;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
}