package pl.op.model.faq;

public enum QuestionType {

	energy, how_works, general, tariff_help, technical, account
	
}