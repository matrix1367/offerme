package pl.op.model.user;

public enum UserRole {

	admin, operator, user, user_premium, user_junior, salesman, supplier, user_blocked
	
}