package pl.op.model.dict;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_METERMODEL")
public class MeterModel implements Serializable {

	private static final long serialVersionUID = -5259134391123547231L;

	private Integer meterModelId;
	private String model;
	private Boolean isIntelligent;
	private Boolean removed;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "METERMODEL_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "METERMODEL_SEQUENCE_GENERATOR", sequenceName = "METERMODEL_ID_SEQ", allocationSize = 1)
	@Index(name = "meterModelIndex")
	public Integer getMeterModelId() {
		return meterModelId;
	}

	public void setMeterModelId(Integer meterModelId) {
		this.meterModelId = meterModelId;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}


	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

	public Boolean getIsIntelligent() {
		return isIntelligent;
	}

	public void setIsIntelligent(Boolean isIntelligent) {
		this.isIntelligent = isIntelligent;
	}
}
