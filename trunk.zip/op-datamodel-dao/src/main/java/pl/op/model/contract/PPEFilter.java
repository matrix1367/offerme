package pl.op.model.contract;

import pl.op.model.cloud.VolumeEnum;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Distributor;
import pl.op.model.dict.MeterModel;
import pl.op.model.dict.Street;
import pl.op.model.dict.Tariff;
import pl.op.model.salesman.Salesman;
import pl.op.model.user.UserApp;

public class PPEFilter {

	private PPE ppe;
	private Agreement agreement;
	private VolumeEnum volumeType;
	private Double volumeFrom;
	private Double volumeTo;
	private Tariff tariff;
	private Salesman salesman;
	private UserApp user;
	
	public PPEFilter() {
		ppe = new PPE();
		City c = new City();
		c.setArea(new Area());
		
		Street s = new Street();
		s.setCity(c);
		
		Location l = new Location();
		l.setStreet(s);
		l.setUserApp(new UserApp());
		
		ppe.setLocation(l);
		ppe.setCurrentDistributor(new Distributor());	
		
		ppe.setMeterModel(new MeterModel());
		
		volumeType = VolumeEnum.KWH;
		agreement = new Agreement();
		tariff = new Tariff();
		salesman = new Salesman();
		
		user = new UserApp();
	}
	
	public void countVolume(){
		if(volumeFrom != null){
			volumeFrom = volumeFrom * volumeType.ordinal();
		}
		
		if(volumeTo != null){
			volumeTo = volumeTo * volumeType.ordinal();
		}
	}

	public PPE getPpe() {
		return ppe;
	}

	public void setPpe(PPE ppe) {
		this.ppe = ppe;
	}

	public Agreement getAgreement() {
		return agreement;
	}

	public void setAgreement(Agreement agreement) {
		this.agreement = agreement;
	}

	public VolumeEnum getVolumeType() {
		return volumeType;
	}

	public void setVolumeType(VolumeEnum volumeType) {
		this.volumeType = volumeType;
	}

	public Double getVolumeFrom() {
		return volumeFrom;
	}

	public void setVolumeFrom(Double volumeFrom) {
		this.volumeFrom = volumeFrom;
	}

	public Double getVolumeTo() {
		return volumeTo;
	}

	public void setVolumeTo(Double volumeTo) {
		this.volumeTo = volumeTo;
	}
	public Tariff getTariff() {
		return tariff;
	}

	public void setTariff(Tariff tariff) {
		this.tariff = tariff;
	}

	public Salesman getSalesman() {
		return salesman;
	}

	public void setSalesman(Salesman salesman) {
		this.salesman = salesman;
	}

	public UserApp getUser() {
		return user;
	}

	public void setUser(UserApp user) {
		this.user = user;
	}
}