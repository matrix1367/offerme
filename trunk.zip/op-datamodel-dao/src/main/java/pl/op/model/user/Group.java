package pl.op.model.user;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_GROUP")
public class Group implements Serializable {

	private static final long serialVersionUID = 7980637688686940213L;
	private Integer groupId;
	private String groupName;
	private Boolean removed;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "GROUP_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "GROUP_SEQUENCE_GENERATOR", sequenceName = "GROUP_ID_SEQ", allocationSize = 1)
	@Index(name = "groupIndex")
	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

}