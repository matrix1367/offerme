package pl.op.model.dict;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Index;
import org.hibernate.annotations.Type;

import pl.op.model.device.DeviceType;

@Entity
@Table(name = "TB_MESSAGERECOMMENDATIONS")
public class MessageRecommendations implements Serializable {

	private static final long serialVersionUID = -5725934671196582771L;
	
	private Integer messageRecommendationsId;
	private String content;
	private Date writeDate;
	private Boolean isConstant;
	private Date dateFrom;
	private Date dateTo;
	
	private Tariff tariff;
	private DeviceType deviceType;
	
	private String contentTruncate;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MESSAGERECOMMENDATIONS_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "MESSAGERECOMMENDATIONS_SEQUENCE_GENERATOR", sequenceName = "MESSAGERECOMMENDATIONS_ID_SEQ", allocationSize = 1)
	@Index(name = "messageRecommendationsIndex")
	public Integer getMessageRecommendationsId() {
		return messageRecommendationsId;
	}
	public void setMessageRecommendationsId(Integer messageRecommendationsId) {
		this.messageRecommendationsId = messageRecommendationsId;
	}
	
	@Type(type="text")
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	public Date getWriteDate() {
		return writeDate;
	}
	public void setWriteDate(Date writeDate) {
		this.writeDate = writeDate;
	}
	
	public Boolean getIsConstant() {
		return isConstant;
	}
	public void setIsConstant(Boolean isConstant) {
		this.isConstant = isConstant;
	}
	
	public Date getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(Date dateFrom) {
		this.dateFrom = dateFrom;
	}
	
	public Date getDateTo() {
		return dateTo;
	}
	public void setDateTo(Date dateTo) {
		this.dateTo = dateTo;
	}
	
	@ManyToOne
	@JoinColumn(name = "TARIFFID", nullable = true)
	@Index(name = "messageRecommendationsTariffIndex")
	public Tariff getTariff() {
		return tariff;
	}
	public void setTariff(Tariff tariff) {
		this.tariff = tariff;
	}
	
	@ManyToOne
	@JoinColumn(name = "DEVICETYPEID", nullable = true)	
	@Index(name = "messageRecommendationsDeviceTypeIndex")
	public DeviceType getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(DeviceType deviceType) {
		this.deviceType = deviceType;
	}
	
	@Transient
	public String getContentTruncate() {
		Integer endIndex = 50;
		if(endIndex > this.content.length()){
			return content;
		}
		return content.substring(0, endIndex);
	}

}
