package pl.op.model.auction;

public enum AuctionAttributesEnum {

	PRICE, EVALUATION, NUMBER;
	
	private String label;

		
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

}