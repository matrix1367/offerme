package pl.op.model.sms;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import pl.op.model.user.UserApp;

@Entity
@Table(name = "TB_SMS")
public class SMS implements Serializable {

	private static final long serialVersionUID = -4817887392087342779L;

	private Long idSMS;
	private Date sendTime;
	private String smsPhoneNumber;
	private String smsType;
	private Integer smsCode;
	private Integer smsCounter;
	private String smsTemplateId;
	private String smsData;
	private String smsSendStatus;
	private UserApp userApp;
	private SMSOperationType operationType;
	//oznacza ile razy weryfikowano kod SMS
	private Integer smsCodeCounter;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public Long getIdSMS() {
		return idSMS;
	}

	public void setIdSMS(Long idSMS) {
		this.idSMS = idSMS;
	}

	public Date getSendTime() {
		return sendTime;
	}

	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}

	public String getSmsPhoneNumber() {
		return smsPhoneNumber;
	}

	public void setSmsPhoneNumber(String smsPhoneNumber) {
		this.smsPhoneNumber = smsPhoneNumber;
	}

	public String getSmsType() {
		return smsType;
	}

	public void setSmsType(String smsType) {
		this.smsType = smsType;
	}

	public Integer getSmsCode() {
		return smsCode;
	}

	public void setSmsCode(Integer smsCode) {
		this.smsCode = smsCode;
	}

	public Integer getSmsCounter() {
		return smsCounter;
	}

	public void setSmsCounter(Integer smsCounter) {
		this.smsCounter = smsCounter;
	}

	public String getSmsTemplateId() {
		return smsTemplateId;
	}

	public void setSmsTemplateId(String smsTemplateId) {
		this.smsTemplateId = smsTemplateId;
	}

	public String getSmsData() {
		return smsData;
	}

	public void setSmsData(String smsData) {
		this.smsData = smsData;
	}

	public String getSmsSendStatus() {
		return smsSendStatus;
	}

	public void setSmsSendStatus(String smsSendStatus) {
		this.smsSendStatus = smsSendStatus;
	}

	@ManyToOne
	@JoinColumn(name = "USERID", nullable = false)
	public UserApp getUserApp() {
		return userApp;
	}

	public void setUserApp(UserApp userApp) {
		this.userApp = userApp;
	}

	@ManyToOne
	public SMSOperationType getOperationType() {
		return operationType;
	}

	public void setOperationType(SMSOperationType operationType) {
		this.operationType = operationType;
	}

	public Integer getSmsCodeCounter() {
		return smsCodeCounter;
	}

	public void setSmsCodeCounter(Integer smsCodeCounter) {
		this.smsCodeCounter = smsCodeCounter;
	}

}
