package pl.op.model.salesman;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.contract.Agreement;
import pl.op.model.contract.OperatorInvoice;
import pl.op.model.dict.Address;
import pl.op.model.user.UserApp;

@Entity
@Table(name = "TB_SALESMAN")
public class Salesman implements Serializable {

	private static final long serialVersionUID = 1861974650098966440L;
	
	private Integer salesmanId;
	private String salesmanName;
	private Boolean removed;
	private String nip;
	private String regon;
	private String email;
	private String krs;
	private String licenseNumber;
	private Integer greenEnergyPercent;
	private Address address;
	private Date createdAt;
	private BusinessType businessType;
	private List<UserApp> userList;
	private List<Agreement> agreements;
	private List<OperatorInvoice> OperatorInvoices;
	private Double rating;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SALESMAN_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "SALESMAN_SEQUENCE_GENERATOR", sequenceName = "SALESMAN_ID_SEQ")
	@Index(name = "salesmanIndex")
	public Integer getSalesmanId() {
		return salesmanId;
	}

	public void setSalesmanId(Integer salesmanId) {
		this.salesmanId = salesmanId;
	}

	public String getSalesmanName() {
		return salesmanName;
	}

	public void setSalesmanName(String salesmanName) {
		this.salesmanName = salesmanName;
	}

	public String getNip() {
		return nip;
	}

	public void setNip(String nip) {
		this.nip = nip;
	}

	public String getRegon() {
		return regon;
	}

	public void setRegon(String regon) {
		this.regon = regon;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getKrs() {
		return krs;
	}

	public void setKrs(String krs) {
		this.krs = krs;
	}

	public String getLicenseNumber() {
		return licenseNumber;
	}

	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

	public Integer getGreenEnergyPercent() {
		return greenEnergyPercent;
	}

	public void setGreenEnergyPercent(Integer greenEnergyPercent) {
		this.greenEnergyPercent = greenEnergyPercent;
	}

	@OneToOne
	@JoinColumn(name = "addressId")
	@Index(name = "salesmanAddressIndex")
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "salesman")
	public List<UserApp> getUserList() {
		return userList;
	}

	public void setUserList(List<UserApp> userList) {
		this.userList = userList;
	}

	@Column(name = "REMOVED")
	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "salesman")
	public List<Agreement> getAgreements() {
		return agreements;
	}

	public void setAgreements(List<Agreement> agreements) {
		this.agreements = agreements;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "salesman")
	public List<OperatorInvoice> getOperatorInvoices() {
		return OperatorInvoices;
	}

	public void setOperatorInvoices(List<OperatorInvoice> operatorInvoices) {
		OperatorInvoices = operatorInvoices;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	@Enumerated(EnumType.STRING)
	public BusinessType getBusinessType() {
		return businessType;
	}

	public void setBusinessType(BusinessType businessType) {
		this.businessType = businessType;
	}
	
	@Column(precision=2, scale=2, columnDefinition = "DECIMAL(4,2)")
	public Double getRating() {
		return rating;
	}
	
	public void setRating(Double rating) {
		this.rating = rating;
	}

}