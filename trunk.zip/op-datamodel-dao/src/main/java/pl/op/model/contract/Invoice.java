package pl.op.model.contract;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Index;

import pl.op.model.cloud.VolumeEnum;

@Entity
@Table(name = "TB_INVOICE")
public class Invoice implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = -9203933916075880745L;

    private Integer invoiceId;
    private Date dateFrom;
    private Date dateTo;
    // private double powerConsumption;
    private Integer usagePower;
    private double netValue;
    private Location location;
    private PPE ppe;
    private List<InvoicePriceComponentValue> invoicePriceComponentValue;

    // Transient
    private Integer ppeId;
    private VolumeEnum volumeEnum;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "INVOICE_SEQUENCE_GENERATOR")
    @SequenceGenerator(name = "INVOICE_SEQUENCE_GENERATOR", sequenceName = "INVOICE_ID_SEQ", allocationSize = 1)
    @Index(name = "invoiceIndex")
    public Integer getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Integer invoiceId) {
        this.invoiceId = invoiceId;
    }

    public Date getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(Date dateFrom) {
        this.dateFrom = dateFrom;
    }

    public Date getDateTo() {
        return dateTo;
    }

    public void setDateTo(Date dateTo) {
        this.dateTo = dateTo;
    }

    public double getNetValue() {
        return netValue;
    }

    public void setNetValue(double netValue) {
        this.netValue = netValue;
    }

    @ManyToOne
    @JoinColumn(name = "LOCATIONID", nullable = true)
    @Index(name = "invoiceLocationIndex")
    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    @ManyToOne
    @JoinColumn(name = "PPEID", nullable = true)
    @Index(name = "invoicePPEIndex")
    public PPE getPpe() {
        return ppe;
    }

    public void setPpe(PPE ppe) {
        this.ppe = ppe;

    }

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "invoice")
    public List<InvoicePriceComponentValue> getInvoicePriceComponentValue() {
        return invoicePriceComponentValue;
    }

    public void setInvoicePriceComponentValue(List<InvoicePriceComponentValue> invoicePriceComponentValue) {
        this.invoicePriceComponentValue = invoicePriceComponentValue;
    }

    @Transient
    public VolumeEnum getVolumeEnum() {
        return volumeEnum;
    }

    public void setVolumeEnum(VolumeEnum volumeEnum) {
        this.volumeEnum = volumeEnum;
    }

    public Integer getUsagePower() {
        return usagePower;
    }

    public void setUsagePower(Integer usagePower) {
        this.usagePower = usagePower;
    }

    @Transient
    public Integer getPpeId() {
        return ppeId;
    }

    public void setPpeId(Integer ppeId) {
        this.ppeId = ppeId;
    }
}