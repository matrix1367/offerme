package pl.op.model.device;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_DEVICETYPE")
public class DeviceType implements Serializable {

	private static final long serialVersionUID = -6172075784260721340L;

	private Integer deviceTypeId;
	private String name;
	private DeviceCategory deviceCategory;
	private List<Device> devices;
	private ConsumptionLevelEnum consumptionLevel;
	private DeviceTypeEnum deviceType;
	private Boolean removed;

	// Transient
	private Integer tabId;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DEVTYPE_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "DEVTYPE_SEQUENCE_GENERATOR", sequenceName = "DEVTYPE_ID_SEQ", allocationSize = 1)
	@Index(name = "deviceTypeIndex")
	public Integer getDeviceTypeId() {
		return deviceTypeId;
	}

	public void setDeviceTypeId(Integer deviceTypeId) {
		this.deviceTypeId = deviceTypeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@ManyToOne
	@JoinColumn(name = "DEVICECATEGORYID", nullable = true)
	@Index(name = "deviceDeviceCategoryIndex")
	public DeviceCategory getDeviceCategory() {
		return deviceCategory;
	}

	public void setDeviceCategory(DeviceCategory deviceCategory) {
		this.deviceCategory = deviceCategory;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "deviceType")
	public List<Device> getDevices() {
		return devices;
	}

	public void setDevices(List<Device> devices) {
		this.devices = devices;
	}

	@Transient
	public Integer getTabId() {
		return tabId;
	}

	public void setTabId(Integer tabId) {
		this.tabId = tabId;
	}

	@Enumerated(EnumType.STRING)
	public ConsumptionLevelEnum getConsumptionLevel() {
		return consumptionLevel;
	}

	public void setConsumptionLevel(ConsumptionLevelEnum consumptionLevel) {
		this.consumptionLevel = consumptionLevel;
	}

	@Enumerated(EnumType.STRING)
	public DeviceTypeEnum getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(DeviceTypeEnum deviceTypeEnum) {
		this.deviceType = deviceTypeEnum;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

}