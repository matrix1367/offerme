package pl.op.model.stereotype;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_SECTOR")
public class Sector implements Serializable {

	private static final long serialVersionUID = -6065719799517193381L;
	private Integer sectorId;
	private String sectorName;
	private Boolean isHidden;
	private Stereotype stereotype;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SECTOR_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "SECTOR_SEQUENCE_GENERATOR", sequenceName = "SECTOR_ID_SEQ", allocationSize = 1)
	@Index(name = "sectorIndex")
	public Integer getSectorId() {
		return sectorId;
	}

	public void setSectorId(Integer sectorId) {
		this.sectorId = sectorId;
	}

	public String getSectorName() {
		return sectorName;
	}

	public void setSectorName(String sectorName) {
		this.sectorName = sectorName;
	}

	@Column(name = "isHidden")
	public Boolean getIsHidden() {
		return isHidden;
	}

	public void setIsHidden(Boolean isHidden) {
		this.isHidden = isHidden;
	}

	@ManyToOne
	@JoinColumn(name = "STEREOTYPEID", nullable = true)
	@Index(name = "sectorStereotypeIndex")
	public Stereotype getStereotype() {
		return stereotype;
	}

	public void setStereotype(Stereotype stereotype) {
		this.stereotype = stereotype;
	}

}