package pl.op.model.auction;

public enum AuctionStatus {

	SUSPENDED, FINISHED, INPROGRESS;
	
	private String label;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
}