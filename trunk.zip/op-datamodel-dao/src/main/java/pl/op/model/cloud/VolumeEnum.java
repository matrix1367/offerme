package pl.op.model.cloud;

public enum VolumeEnum {

	KWH (1.0), 
	MWH (1000.0),
	GWH (1000000.0),
	TWH (1000000000.0);
	
	private String label;
	private Double value;
	
	VolumeEnum(Double value){
		this.setValue(value);
	}
		
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public Double getValue() {
		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}


}