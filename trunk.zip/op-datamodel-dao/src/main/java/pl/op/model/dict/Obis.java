package pl.op.model.dict;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_OBIS")
public class Obis implements Serializable {

	private static final long serialVersionUID = -605704720327494513L;

	private Integer obisId;
	private Integer classId;
	private Integer type;

	private String logicalName;
	private String obisShort;
	private String symbol;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "OBIS_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "OBIS_SEQUENCE_GENERATOR", sequenceName = "OBIS_ID_SEQ", allocationSize = 1)
	@Index(name = "obisIndex")
	public Integer getObisId() {
		return obisId;
	}

	public void setObisId(Integer obisId) {
		this.obisId = obisId;
	}

	public Integer getClassId() {
		return classId;
	}

	public void setClassId(Integer classId) {
		this.classId = classId;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getLogicalName() {
		return logicalName;
	}

	public void setLogicalName(String logicalName) {
		this.logicalName = logicalName;
	}

	public String getObisShort() {
		return obisShort;
	}

	public void setObisShort(String obisShort) {
		this.obisShort = obisShort;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

}
