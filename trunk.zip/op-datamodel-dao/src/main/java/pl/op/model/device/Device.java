package pl.op.model.device;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Index;

import pl.op.model.contract.Location;

@Entity
@Table(name = "TB_DEVICE")
public class Device implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8566366493194609271L;

	private Integer deviceId;
	private Integer devicePower;
	private Integer quantity;
	private BigDecimal dailyConsumption;
	private EnergyClassEnum energyClass;
	private Location location;
	private DeviceType deviceType;
	private Integer hours;
	private Integer minutes;
	private Boolean removed;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DEVICE_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "DEVICE_SEQUENCE_GENERATOR", sequenceName = "DEVICE_ID_SEQ", allocationSize = 1)
	@Index(name = "deviceIndex")
	public Integer getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(Integer deviceId) {
		this.deviceId = deviceId;
	}

	public Integer getDevicePower() {
		return devicePower;
	}

	public void setDevicePower(Integer devicePower) {
		this.devicePower = devicePower;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getDailyConsumption() {
		return dailyConsumption;
	}

	public void setDailyConsumption(BigDecimal dailyConsumption) {
		this.dailyConsumption = dailyConsumption;
	}

	@Enumerated(EnumType.STRING)
	public EnergyClassEnum getEnergyClass() {
		return energyClass;
	}

	public void setEnergyClass(EnergyClassEnum energyClass) {
		this.energyClass = energyClass;
	}

	@ManyToOne
	@JoinColumn(name = "DEVICETYPEID", nullable = true)
	@Index(name = "deviceDeviceTypeIndex")
	public DeviceType getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(DeviceType deviceType) {
		this.deviceType = deviceType;
	}

	@ManyToOne
	@JoinColumn(name = "LOCATIONID", nullable = true)
	@Index(name = "deviceDeviceLocationIndex")
	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	@Transient
	public Integer getHours() {
		return hours;
	}

	public void setHours(Integer hours) {
		this.hours = hours;
	}

	@Transient
	public Integer getMinutes() {
		return minutes;
	}

	public void setMinutes(Integer minutes) {
		this.minutes = minutes;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}
}