package pl.op.model.dict;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_DISTRIBUTOR")
public class Distributor implements Serializable {

	private static final long serialVersionUID = -5259134391123547231L;

	private Integer distributorId;
	private String name;
	private Boolean removed;
	private String RSS;
	private Boolean hasRSS;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DISTRIBUTOR_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "DISTRIBUTOR_SEQUENCE_GENERATOR", sequenceName = "DISTRIBUTOR_ID_SEQ", allocationSize = 1)
	@Index(name = "distributorIndex")
	public Integer getDistributorId() {
		return distributorId;
	}

	public void setDistributorId(Integer distributorId) {
		this.distributorId = distributorId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

	public Boolean getHasRSS() {
		return hasRSS;
	}

	public void setHasRSS(Boolean hasRSS) {
		this.hasRSS = hasRSS;
	}

	public String getRSS() {
		return RSS;
	}

	public void setRSS(String rSS) {
		RSS = rSS;
	}

}
