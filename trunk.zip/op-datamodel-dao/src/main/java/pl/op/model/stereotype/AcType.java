package pl.op.model.stereotype;

public enum AcType {

	window, split, multi_split, vrf;
	
	private String label;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
}