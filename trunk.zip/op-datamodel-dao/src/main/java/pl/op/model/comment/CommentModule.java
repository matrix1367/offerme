package pl.op.model.comment;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Entity
@Table(name = "TB_COMMENT")
public class CommentModule implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 926468162376210683L;
			
	private Integer commentId;
	private String author;
	private String content;
	private String userOpinion;
	private int likePage;
	private Date dateComment;
	private Boolean removed;
	private CommentTypeEnum commentType;
	private Integer objectId;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "COMMENT_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "COMMENT_SEQUENCE_GENERATOR", sequenceName = "COMMENT_ID_SEQ", allocationSize = 1)
	@Index(name = "commentIndex")
	public Integer getCommentId() {
		return commentId;
	}

	public void setCommentId(Integer commentId) {
		this.commentId = commentId;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getDateComment() {
		return dateComment;
	}

	public void setDateComment(Date dateComment) {
		this.dateComment = dateComment;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

	@Enumerated(EnumType.STRING)
	public CommentTypeEnum getCommentType() {
		return commentType;
	}

	public void setCommentType(CommentTypeEnum commentType) {
		this.commentType = commentType;
	}

	public Integer getObjectId() {
		return objectId;
	}

	public void setObjectId(Integer objectId) {
		this.objectId = objectId;
	}

	public String getUserOpinion() {
		return userOpinion;
	}

	public void setUserOpinion(String userOpinion) {
		this.userOpinion = userOpinion;
	}
	
	public void setUserOpinion(List<String> userOpinion) {
		String result = "";
		
		for(String tmp : userOpinion) {
			if(!result.equals(""))
				result += ",";
			
			result += tmp;
		}
		
		this.userOpinion = result;
	}

	public int getLikePage() {
		return likePage;
	}

	public void setLikePage(int likePage) {
		this.likePage = likePage;
	}
}