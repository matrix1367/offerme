package pl.op.model.dict;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.Index;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Entity
@Table(name = "TB_AREA")
public class Area implements Serializable {

	private static final long serialVersionUID = -5259134391123547231L;

	private Integer areaId;
	private String areaName;
	private String areaSymbol;

	// Transient
	private Integer cloudId;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AREA_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "AREA_SEQUENCE_GENERATOR", sequenceName = "AREA_ID_SEQ", allocationSize = 1)
	@Index(name = "areaIndex")
	public Integer getAreaId() {
		return areaId;
	}

	public void setAreaId(Integer areaId) {
		this.areaId = areaId;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public String getAreaSymbol() {
		return areaSymbol;
	}

	public void setAreaSymbol(String areaSymbol) {
		this.areaSymbol = areaSymbol;
	}

	@Transient
	public Integer getCloudId() {
		return cloudId;
	}

	public void setCloudId(Integer cloudId) {
		this.cloudId = cloudId;
	}
}
