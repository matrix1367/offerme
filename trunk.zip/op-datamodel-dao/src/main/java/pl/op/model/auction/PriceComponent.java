package pl.op.model.auction;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_PRICECOMPONENT")
public class PriceComponent implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8566366493194609271L;

	private Integer priceComponentId;
	private String currency;
	private String description;
	private boolean isConstant;
	private String name;
	private ZoneType zoneType;
	private Boolean removed;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRICECOMPONENT_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "PRICECOMPONENT_SEQUENCE_GENERATOR", sequenceName = "PRICECOMPONENT_ID_SEQ", allocationSize = 1)
	@Index(name = "priceComponentIndex")
	public Integer getPriceComponentId() {
		return priceComponentId;
	}

	public void setPriceComponentId(Integer priceComponentId) {
		this.priceComponentId = priceComponentId;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "isConstant")
	public boolean isConstant() {
		return isConstant;
	}

	public void setConstant(boolean isConstant) {
		this.isConstant = isConstant;
	}

	@Enumerated(EnumType.STRING)
	public ZoneType getZoneType() {
		return zoneType;
	}

	public void setZoneType(ZoneType zoneType) {
		this.zoneType = zoneType;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

}