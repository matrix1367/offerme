package pl.op.model.msg;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_MESSAGEATTACHMENT")
public class MessageAttachment implements Serializable {

	private static final long serialVersionUID = -3348891231845250050L;

	private Integer messageAttachmentId;
	private String displayName;
	private String filePath;
	private Message message;
	private byte[] fileBlob;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MSGATTCH_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "MSGATTCH_SEQUENCE_GENERATOR", sequenceName = "MSGATTCH_ID_SEQ")
	@Index(name = "messageAttachmentIndex")
	public Integer getMessageAttachmentId() {
		return messageAttachmentId;
	}

	public void setMessageAttachmentId(Integer messageAttachmentId) {
		this.messageAttachmentId = messageAttachmentId;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	@ManyToOne
	@JoinColumn(name = "IDMESSAGE", nullable = true)
	@Index(name = "messageAttachmentMessageIndex")
	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

	public byte[] getFileBlob() {
		return fileBlob;
	}

	public void setFileBlob(byte[] fileBlob) {
		this.fileBlob = fileBlob;
	}

    public MessageAttachment () {
    }    
}