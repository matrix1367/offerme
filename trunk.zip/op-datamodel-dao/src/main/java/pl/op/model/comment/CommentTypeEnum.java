package pl.op.model.comment;

public enum CommentTypeEnum {
	AUCTION, AUCTIONOFFER, PPE, WEBSITE;
}
