package pl.op.model.contract;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Index;
import org.slf4j.LoggerFactory;

import pl.op.model.device.Device;
import pl.op.model.device.DeviceTypeEnum;
import pl.op.model.dict.Street;
import pl.op.model.stereotype.Building;
import pl.op.model.user.UserApp;

@Entity
@Table(name = "TB_LOCATION")
public class Location implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = -9203933916075880745L;

    private Integer locationId;
    private String flatNo;
    private String homeNo;
    private String zipCode;
    private UserApp userApp;
    private Building building;
    private List<Device> devices;
    private List<Invoice> invoices;
    private List<PPE> ppes;
    private Street street;

    private String locationName;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "LOCATION_SEQUENCE_GENERATOR")
    @SequenceGenerator(name = "LOCATION_SEQUENCE_GENERATOR", sequenceName = "LOCATION_ID_SEQ", allocationSize = 1)
    @Index(name = "locationIndex")
    public Integer getLocationId() {
        return locationId;
    }

    public void setLocationId(Integer locationId) {
        this.locationId = locationId;
    }

    public String getFlatNo() {
        return flatNo;
    }

    public void setFlatNo(String flatNo) {
        this.flatNo = flatNo;
    }

    public String getHomeNo() {
        return homeNo;
    }

    public void setHomeNo(String homeNo) {
        this.homeNo = homeNo;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    @ManyToOne
    @JoinColumn(name = "USERID", nullable = true)
    @Index(name = "locationUserIndex")
    public UserApp getUserApp() {
        return userApp;
    }

    public void setUserApp(UserApp userApp) {
        this.userApp = userApp;
    }

    @OneToOne
    @JoinColumn(name = "BUILDINGID", nullable = true)
    @Index(name = "locationBuildingIndex")
    public Building getBuilding() {
        return building;
    }

    public void setBuilding(Building building) {
        this.building = building;
    }

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "location")
    public List<Device> getDevices() {
        return devices;
    }

    public void setDevices(List<Device> devices) {
        this.devices = devices;
    }

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "location")
    public List<Invoice> getInvoices() {
        return invoices;
    }

    public void setInvoices(List<Invoice> invoices) {
        this.invoices = invoices;
    }

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "location")
    public List<PPE> getPpes() {
        return ppes;
    }

    public void setPpes(List<PPE> ppes) {
        this.ppes = ppes;
    }

    @ManyToOne
    @JoinColumn(name = "STREETID", nullable = true)
    @Index(name = "locationStreetIndex")
    public Street getStreet() {
        return street;
    }

    public void setStreet(Street street) {
        this.street = street;
    }

    @Transient
    public String getLocationName() {

        try {
            locationName = zipCode + " " + street.getCity().getCityName();
            locationName += ", " + street.getStreetName() + " " + homeNo;
            if(flatNo != null)
                locationName += "/" + flatNo;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    @Transient
    public Double getDevicesDailyConsumption() throws Exception {
        Double sum = 0.00;

        LoggerFactory.getLogger(Location.class).info("getDevicesDailyConsumption - devices: " + devices.size());
        for(int i = 0; i < devices.size(); i++) {
            if(devices.get(i).getDeviceType().getDeviceType().equals(DeviceTypeEnum.PRODUCER))
                continue;
            sum = sum.doubleValue() + devices.get(i).getDailyConsumption().doubleValue();
        }

        return sum.doubleValue();
    }
}