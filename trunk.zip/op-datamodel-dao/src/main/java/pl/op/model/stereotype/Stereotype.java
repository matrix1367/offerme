package pl.op.model.stereotype;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.question.PreferenceQuestion;
import pl.op.model.question.QuestionValue;

@Entity
@Table(name = "TB_STEREOTYPE")
public class Stereotype implements Serializable {

	private static final long serialVersionUID = -6065719799517193381L;
	private Integer stereotypeId;
	private String stereotypeName;
	private String stereotypeDescription;
	private Boolean removed;
	private Double mediumYearConsumption;
	private Double mediumYearProduction;
	private Date creationDate;
	private List<QuestionValue> questionValues;
	private List<PreferenceQuestion> preferenceQuestions;
	private Building building;
	private String iconPath;
	private byte[] iconContent;
	private StereotypeType stereotypeType;
	private Integer orderId;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "STEREOTYPE_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "STEREOTYPE_SEQUENCE_GENERATOR", sequenceName = "STEREOTYPE_ID_SEQ", allocationSize = 1)
	@Index(name = "stereotypeIndex")
	public Integer getStereotypeId() {
		return stereotypeId;
	}

	public void setStereotypeId(Integer stereotypeId) {
		this.stereotypeId = stereotypeId;
	}

	public String getStereotypeName() {
		return stereotypeName;
	}

	public void setStereotypeName(String stereotypeName) {
		this.stereotypeName = stereotypeName;
	}

	public String getStereotypeDescription() {
		return stereotypeDescription;
	}

	public void setStereotypeDescription(String stereotypeDescription) {
		this.stereotypeDescription = stereotypeDescription;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

	public Double getMediumYearConsumption() {
		return mediumYearConsumption;
	}

	public void setMediumYearConsumption(Double mediumYearConsumption) {
		this.mediumYearConsumption = mediumYearConsumption;
	}

	public Double getMediumYearProduction() {
		return mediumYearProduction;
	}

	public void setMediumYearProduction(Double mediumYearProduction) {
		this.mediumYearProduction = mediumYearProduction;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "stereotype")
	public List<QuestionValue> getQuestionValues() {
		return questionValues;
	}

	public void setQuestionValues(List<QuestionValue> questionValues) {
		this.questionValues = questionValues;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "stereotype")
	public List<PreferenceQuestion> getPreferenceQuestions() {
		return preferenceQuestions;
	}

	public void setPreferenceQuestions(List<PreferenceQuestion> preferenceQuestions) {
		this.preferenceQuestions = preferenceQuestions;
	}

	@OneToOne
	@Index(name = "stereotypeBuildingIndex")
	public Building getBuilding() {
		return building;
	}

	public void setBuilding(Building building) {
		this.building = building;
	}

	public String getIconPath() {
		return iconPath;
	}

	public void setIconPath(String iconPath) {
		this.iconPath = iconPath;
	}

	public byte[] getIconContent() {
		return iconContent;
	}

	public void setIconContent(byte[] iconContent) {
		this.iconContent = iconContent;
	}
	
	@Enumerated(EnumType.STRING)
	public StereotypeType getStereotypeType() {
		return stereotypeType;
	}

	public void setStereotypeType(StereotypeType stereotypeType) {
		this.stereotypeType = stereotypeType;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
}