package pl.op.model.salesman;

public enum BusinessType {

	company, cooperative, civilLawPartnership, generalPartnership, limitedPartnership, limitedAndStock_offeringCompany, limitedLiabilityParntership, stock_offeringCompny, privateLimitedCompany, publicCompany;

	private String label;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
}