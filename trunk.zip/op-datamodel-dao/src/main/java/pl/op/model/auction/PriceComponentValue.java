package pl.op.model.auction;

import java.io.Serializable;
import java.text.DecimalFormat;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_PRICECOMPONENTVALUE")
public class PriceComponentValue implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 8566366493194609271L;

    private Integer priceComponentValueId;
    private Double value;
    private AuctionOffer auctionOffer;
    private PriceComponent priceComponent;

    private Double sumValue;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRICECOMPONENTVALUE_SEQUENCE_GENERATOR")
    @SequenceGenerator(name = "PRICECOMPONENTVALUE_SEQUENCE_GENERATOR", sequenceName = "PRICECOMPONENTVALUE_ID_SEQ", allocationSize = 1)
    @Index(name = "priceComponentValueIndex")
    public Integer getPriceComponentValueId() {
        return priceComponentValueId;
    }

    public void setPriceComponentValueId(Integer priceComponentValueId) {
        this.priceComponentValueId = priceComponentValueId;
    }

    public Double getValue() {
        if(null == value) {
            value = Double.valueOf("0.0");
        }
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    @Transient
    public String getFormatedValue() {
        DecimalFormat formater = new DecimalFormat("0.0000");

        return formater.format(value);
    }

    @ManyToOne
    @JoinColumn(name = "AUCTIONOFFERID", nullable = true)
    @Index(name = "priceComponentValueAuctionOfferIndex")
    public AuctionOffer getAuctionOffer() {
        return auctionOffer;
    }

    public void setAuctionOffer(AuctionOffer auctionOffer) {
        this.auctionOffer = auctionOffer;
    }

    @ManyToOne
    @JoinColumn(name = "PRICECOMPONENTID", nullable = true)
    @Index(name = "priceComponentValueIdIndex")
    public PriceComponent getPriceComponent() {
        return priceComponent;
    }

    public void setPriceComponent(PriceComponent priceComponent) {
        this.priceComponent = priceComponent;
    }

    @Transient
    public Double getSumValue() {
        return sumValue;
    }

    public void setSumValue(Double sumValue) {
        this.sumValue = sumValue;
    }

}