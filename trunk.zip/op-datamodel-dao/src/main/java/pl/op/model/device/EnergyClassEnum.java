package pl.op.model.device;

public enum EnergyClassEnum {

	Aplus, A, B, C, D, E, F, G, one_to_five_years, five_to_ten_years, ten_to_fifteen_years, fifteen_to_twenty_years;
	
	private String label;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
}