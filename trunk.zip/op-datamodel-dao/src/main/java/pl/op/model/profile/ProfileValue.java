package pl.op.model.profile;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_PROFILEVALUE")
public class ProfileValue implements Serializable {

	private static final long serialVersionUID = -2591133661175007982L;

	private Integer profileValueId;
	private Double value;
	private ProfileIndicator profileIndicator;
	private Integer hour;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PROFILEVALUE_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "PROFILEVALUE_SEQUENCE_GENERATOR", sequenceName = "PROFILEVALUE_ID_SEQ", allocationSize = 1)
	@Index(name = "profileValueIndex")
	public Integer getProfileValueId() {
		return profileValueId;
	}

	public void setProfileValueId(Integer profileValueId) {
		this.profileValueId = profileValueId;
	}

	public Double getValue() {
		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}
	
	@ManyToOne
	@JoinColumn(name = "PROFILEINDICATORID", nullable = true)
	@Index(name = "profileValueProfileIndicatorIndex")
	public ProfileIndicator getProfileIndicator() {
		return profileIndicator;
	}

	public void setProfileIndicator(ProfileIndicator profileIndicator) {
		this.profileIndicator = profileIndicator;
	}

	public Integer getHour() {
		return hour;
	}

	public void setHour(Integer hour) {
		this.hour = hour;
	}

}