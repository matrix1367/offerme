package pl.op.model.stereotype;

public enum HeatingBuildingType {

	iron_radiators, panel_radiators,electric, electric_floor, water_floor, mixed_electric, mixed_water, air, radiant;
	
	private String label;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
}