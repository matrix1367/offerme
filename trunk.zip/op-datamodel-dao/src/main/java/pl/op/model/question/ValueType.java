package pl.op.model.question;

public enum ValueType {

	ListValues, OneValue, BooleanValue;
	
	private String label;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
}