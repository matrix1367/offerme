package pl.op.model.stereotype;

public enum HeatingWaterType {

	gas, electric, eco, urban;
	
	private String label;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
}