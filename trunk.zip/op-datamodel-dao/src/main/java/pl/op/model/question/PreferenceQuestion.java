package pl.op.model.question;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Index;

import pl.op.model.stereotype.Stereotype;

@Entity
@Table(name = "TB_PREFERENCEQUESTION")
public class PreferenceQuestion implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7209014315744187408L;

	
	private Integer preferenceQuestionId;
	private String question;
	private Boolean removed;
	private ValueType valueType;
	private List<QuestionItem> questionItems;
	private Stereotype stereotype;
	
	private QuestionValue questionValue;
	private Integer userId;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PREFQUEST_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "PREFQUEST_SEQUENCE_GENERATOR", sequenceName = "PREFQUEST_ID_SEQ")
	@Index(name = "preferenceQuestionIndex")
	public Integer getPreferenceQuestionId() {
		return preferenceQuestionId;
	}
	
	public void setPreferenceQuestionId(Integer preferenceQuestionId) {
		this.preferenceQuestionId = preferenceQuestionId;
	}
	
	public String getQuestion() {
		return question;
	}
	
	public void setQuestion(String question) {
		this.question = question;
	}
	
	public Boolean getRemoved() {
		return removed;
	}
	
	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}
	
	@Enumerated(EnumType.STRING)
	public ValueType getValueType() {
		return valueType;
	}
	
	public void setValueType(ValueType valueType) {
		this.valueType = valueType;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "preferenceQuestion")
	public List<QuestionItem> getQuestionItems() {
		return questionItems;
	}

	public void setQuestionItems(List<QuestionItem> questionItems) {
		this.questionItems = questionItems;
	}

	@ManyToOne
	@JoinColumn(name = "STEREOTYPEID", nullable = true)
	@Index(name = "preferenceQuestionStereotypeIndex")
	public Stereotype getStereotype() {
		return stereotype;
	}

	public void setStereotype(Stereotype stereotype) {
		this.stereotype = stereotype;
	}

	public QuestionValue getQuestionValue() {
		if(questionValue == null)
			questionValue = new QuestionValue();
		return questionValue;
	}

	public void setQuestionValue(QuestionValue questionValue) {
		this.questionValue = questionValue;
	}

	@Transient
	public Integer getUserId() {
                if(userId == null) userId = -1;
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}
}