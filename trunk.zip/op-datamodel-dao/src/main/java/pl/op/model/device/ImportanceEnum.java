package pl.op.model.device;

public enum ImportanceEnum {

	LOW, MEDIUM, HIGH;
	
	private String label;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
}
