package pl.op.model.contract;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Index;

import pl.op.model.cloud.VolumeEnum;
import pl.op.model.dict.Distributor;
import pl.op.model.dict.MeterModel;
import pl.op.model.dict.Tariff;
import pl.op.model.salesman.Salesman;



@Entity
@Table(name = "TB_PPE")
public class PPE implements Serializable {

    private static final long serialVersionUID = -2591133661175007982L;

    private Integer ppeId;
    private String code;
    private String number;
    private Distributor currentDistributor;
    private MeterModel meterModel;
    private String meterNo;
    private Date writeTime;
    private Location location;
    private String objectType;
    private Double value;
    private VolumeEnum valueUnit;
    private Date valueUpdatedAt;
    private Integer contractualPower;
    private List<Agreement> agreements;
    private List<Invoice> invoices;
    private PPEStatus ppeStatus;
    private Boolean removed;

    // Transient
    private Tariff tariff;
    private Salesman salesman;
    private Agreement actualAgremenet;
    private Invoice actualInvoice;

    public PPE() {
    }

    public PPE(PPE source) {
        try {
            ppeId = source.getPpeId();
            code = source.getCode();
            number = source.getNumber();
            currentDistributor = source.getCurrentDistributor();
            meterModel = source.getMeterModel();
            meterNo = source.getMeterNo();
            writeTime = source.getWriteTime();
            location = source.getLocation();
            objectType = source.getObjectType();
            value = source.getValue();
            valueUpdatedAt = source.getValueUpdatedAt();
            contractualPower = source.getContractualPower();
            agreements = source.getAgreements();
            invoices = source.getInvoices();
            ppeStatus = source.getPpeStatus();
            removed = source.getRemoved();

            tariff = source.getTariff();
            salesman = source.getSalesman();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PPE_SEQUENCE_GENERATOR")
    @SequenceGenerator(name = "PPE_SEQUENCE_GENERATOR", sequenceName = "PPE_ID_SEQ", allocationSize = 1)
    @Index(name = "ppeIndex")
    public Integer getPpeId() {
        return ppeId;
    }

    public void setPpeId(Integer ppeId) {
        this.ppeId = ppeId;
    }

    public String getMeterNo() {
        return meterNo;
    }

    public void setMeterNo(String meterNo) {
        this.meterNo = meterNo;
    }

    public Date getWriteTime() {
        return writeTime;
    }

    public void setWriteTime(Date writeTime) {
        this.writeTime = writeTime;
    }

    @ManyToOne
    @JoinColumn(name = "LOCATIONID", nullable = true)
    @Index(name = "ppeLocationIndex")
    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    @ManyToOne
    @JoinColumn(name = "DISTRIBUTORID", nullable = true)
    @Index(name = "ppeDistributorIndex")
    public Distributor getCurrentDistributor() {
        return currentDistributor;
    }

    public void setCurrentDistributor(Distributor currentDistributor) {
        this.currentDistributor = currentDistributor;
    }

    public String getObjectType() {
        return objectType;
    }

    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }

    @ManyToOne
    @JoinColumn(name = "METERMODELID", nullable = true)
    @Index(name = "ppeMeterModelIndex")
    public MeterModel getMeterModel() {
        return meterModel;
    }

    public void setMeterModel(MeterModel meterModel) {
        this.meterModel = meterModel;
    }

    @ManyToMany
    @JoinTable(name = "tb_agreementPPE", joinColumns = @JoinColumn(name = "ppeId"), inverseJoinColumns = @JoinColumn(name = "agreementId"))
    public List<Agreement> getAgreements() {
        return agreements;
    }

    public void setAgreements(List<Agreement> agreements) {
        this.agreements = agreements;
    }
 /*   
    @Transient
    public  List<ZoneType, Double> getPercentValue() {
        PpeUtil util = GuiceSingleton.getInstance().getInstance(PpeUtil.class);
    }
*/
    @Transient
    public Tariff getTariff() {
        return tariff;
    }

    public void setTariff(Tariff tariff) {
        this.tariff = tariff;
    }

    @Enumerated(EnumType.STRING)
    public PPEStatus getPpeStatus() {
        return ppeStatus;
    }

    public void setPpeStatus(PPEStatus ppeStatus) {
        this.ppeStatus = ppeStatus;
    }

    @Transient
    public Salesman getSalesman() {
        return salesman;
    }

    public void setSalesman(Salesman salesman) {
        this.salesman = salesman;
    }

    public Boolean getRemoved() {
        return removed;
    }

    public void setRemoved(Boolean removed) {
        this.removed = removed;
    }

    public Double getValue() {
        if (null == value) {
            value = Double.valueOf("0.0");
        }
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public Date getValueUpdatedAt() {
        return valueUpdatedAt;
    }

    public void setValueUpdatedAt(Date valueUpdatedAt) {
        this.valueUpdatedAt = valueUpdatedAt;
    }

    public Integer getContractualPower() {
        return contractualPower;
    }

    public void setContractualPower(Integer contractualPower) {
        this.contractualPower = contractualPower;
    }

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "ppe")
    public List<Invoice> getInvoices() {
        return invoices;
    }

    public void setInvoices(List<Invoice> invoices) {
        this.invoices = invoices;
    }

    @Enumerated(EnumType.STRING)
    public VolumeEnum getValueUnit() {
        if (valueUnit == null) {
            valueUnit = VolumeEnum.MWH;
        }
        return valueUnit;
    }

    public void setValueUnit(VolumeEnum valueUnit) {
        this.valueUnit = valueUnit;
    }

    @Transient
    public Agreement getActualAgreement() {
        return actualAgremenet;
    }

    public void updateActualAgreement(Agreement agreement) {
        actualAgremenet = agreement;
    }

    @Transient
    public Invoice getActualInvoice() {
        return actualInvoice;
    }

    public void updateActualInvoice(Invoice invoice) {
        actualInvoice = invoice;
    }
}