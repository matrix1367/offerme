package pl.op.model.device;

public enum DeviceTypeEnum {

	CONSUMER, PRODUCER;
	
	private String label;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
}