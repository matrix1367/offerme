package pl.op.model.contract;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Index;

import pl.op.model.salesman.Salesman;
import pl.op.model.user.UserApp;

@Entity
@Table(name = "TB_AGREEMENT")
public class Agreement implements Serializable {

	private static final long serialVersionUID = -2591133661175007982L;

	private Integer agreementId;
	private Date dateFrom;
	private Date dateTo;
	private Boolean active;
	private String agreementNo;
	private Integer power;
	private AgreementType agreementType;
	private UserApp userApp;
	private Salesman salesman;
	private List<PPE> ppes;
	private DurationType durationType;
	
	//Transient
	private Integer ppeId;
	
	public Agreement() {}
	
	public Agreement(Agreement source) {
		try {
			agreementId = source.getAgreementId();
			dateFrom = (source.getDateFrom() != null) ? new Date(source.getDateFrom().getTime()) : null;
			dateTo = (source.getDateTo() != null) ? new Date(source.getDateTo().getTime()) : null;
			active = source.getActive();
			agreementNo = source.getAgreementNo();
			power = source.getPower();
			agreementType = (source.getAgreementType().equals(AgreementType.master)) ? AgreementType.master : AgreementType.sellAndDistr;
			userApp = source.getUserApp();
			salesman = source.getSalesman();
			ppes = source.getPpes();
			durationType = (source.getDurationType().equals(DurationType.fixed))? DurationType.fixed : DurationType.permanent;
			
			ppeId = source.getPpeId();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AGREEMENT_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "AGREEMENT_SEQUENCE_GENERATOR", sequenceName = "AGREEMENT_ID_SEQ", allocationSize = 1)
	@Index(name = "agreementIndex")
	public Integer getAgreementId() {
		return agreementId;
	}

	public void setAgreementId(Integer agreementId) {
		this.agreementId = agreementId;
	}

	public Date getDateFrom() {
		return dateFrom;
	}

	public void setDateFrom(Date dateFrom) {
		this.dateFrom = dateFrom;
	}

	public Date getDateTo() {
		return dateTo;
	}

	public void setDateTo(Date dateTo) {
		this.dateTo = dateTo;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public String getAgreementNo() {
		return agreementNo;
	}

	public void setAgreementNo(String agreementNo) {
		this.agreementNo = agreementNo;
	}

	public Integer getPower() {
		return power;
	}

	public void setPower(Integer power) {
		this.power = power;
	}

	@OneToOne
	@JoinColumn(name = "USERID", nullable = true)
	@Index(name = "agreementUserIndex")
	public UserApp getUserApp() {
		return userApp;
	}

	public void setUserApp(UserApp userApp) {
		this.userApp = userApp;
	}
	
	@ManyToOne
	@JoinColumn(name = "SALESMANID", nullable = true)
	@Index(name = "agreementSalesmanIndex")
	public Salesman getSalesman() {
		return salesman;
	}

	public void setSalesman(Salesman salesman) {
		this.salesman = salesman;
	}

	@ManyToMany(mappedBy = "agreements")
	public List<PPE> getPpes() {
		return ppes;
	}

	public void setPpes(List<PPE> ppes) {
		this.ppes = ppes;
	}

	@Transient
	public Integer getPpeId() {
		return ppeId;
	}

	public void setPpeId(Integer ppeId) {
		this.ppeId = ppeId;
	}
	
	@Enumerated(EnumType.STRING)
	public DurationType getDurationType() {
		return durationType;
	}

	public void setDurationType(DurationType durationType) {
		this.durationType = durationType;
	}
	
	@Enumerated(EnumType.STRING)
	public AgreementType getAgreementType() {
		return agreementType;
	}

	public void setAgreementType(AgreementType agreementType) {
		this.agreementType = agreementType;
	}
}