package pl.op.model.contract;

public enum DurationType {

	fixed, permanent;

	private String label;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
}