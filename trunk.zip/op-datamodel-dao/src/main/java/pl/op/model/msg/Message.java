package pl.op.model.msg;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.user.Group;
import pl.op.model.user.UserApp;

@Entity
@Table(name = "TB_MESSAGE")
public class Message implements Serializable {

	private static final long serialVersionUID = -3269385047818242728L;

	private Integer messageId;
	private String topic;
	private String content;
	private Date sendTime;
	private String priority;
	private UserApp sender;
	private Group receiverGroup;
	private List<MessageAttachment> messageAttachments;

	private List<UserToMessage> selectedReceivers;
	private MessageSender messageSender;

	public Message() {
		selectedReceivers = new ArrayList<UserToMessage>();
		messageSender = new MessageSender();
		content = "";
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MSG_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "MSG_SEQUENCE_GENERATOR", sequenceName = "MSG_ID_SEQ")
	@Index(name = "messageIndex")
	public Integer getMessageId() {
		return messageId;
	}

	public void setMessageId(Integer messageId) {
		this.messageId = messageId;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getSendTime() {
		return sendTime;
	}

	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	@ManyToOne
	@JoinColumn(name = "IDSENDERUSER", nullable = true)
	@Index(name = "messageSenderUserIndex")
	public UserApp getSender() {
		return sender;
	}

	public void setSender(UserApp sender) {
		this.sender = sender;
	}

	@OneToOne
	@Index(name = "messageReceiverGroupIndex")
	public Group getReceiverGroup() {
		return receiverGroup;
	}

	public void setReceiverGroup(Group receiverGroup) {
		this.receiverGroup = receiverGroup;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "message")
	public List<MessageAttachment> getMessageAttachments() {
		return messageAttachments;
	}

	public void setMessageAttachments(List<MessageAttachment> messageAttachments) {
		this.messageAttachments = messageAttachments;
	}

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "message")
	public List<UserToMessage> getSelectedReceivers() {
		return selectedReceivers;
	}

	public void setSelectedReceivers(List<UserToMessage> selectedReceivers) {
		this.selectedReceivers = selectedReceivers;
	}
	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@Index(name = "messageMessageSenderIndex")
	public MessageSender getMessageSender() {
		return messageSender;
	}

	public void setMessageSender(MessageSender messageSender) {
		this.messageSender = messageSender;
	}
}