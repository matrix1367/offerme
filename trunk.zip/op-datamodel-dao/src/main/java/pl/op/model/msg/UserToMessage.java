package pl.op.model.msg;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.user.UserApp;

@Entity
@Table(name = "TB_USERAPP_TB_MESSAGE")
public class UserToMessage implements Serializable {

	private static final long serialVersionUID = 4193516280794225536L;

	private Integer userToMessageId;
	private UserApp user;
	private Message message;
	private Boolean read;
	private Boolean removed;
	private Boolean favorite;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MSGTOUSER_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "MSGTOUSER_SEQUENCE_GENERATOR", sequenceName = "MSGTOUSER_ID_SEQ")
	@Index(name = "userToMessageIndex")
	public Integer getUserToMessageId() {
		return userToMessageId;
	}

	public void setUserToMessageId(Integer userToMessageId) {
		this.userToMessageId = userToMessageId;
	}

	@ManyToOne
	@JoinColumn(name = "userId", nullable = false)
	@Index(name = "userToMessageUserIndex")
	public UserApp getUser() {
		return user;
	}

	public void setUser(UserApp user) {
		this.user = user;
	}

	@ManyToOne
	@JoinColumn(name = "messageId", nullable = false)
	@Index(name = "userToMessageMessageIdIndex")
	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

	public Boolean getRead() {
		return read;
	}

	public void setRead(Boolean read) {
		this.read = read;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

	public Boolean getFavorite() {
		return favorite;
	}

	public void setFavorite(Boolean favorite) {
		this.favorite = favorite;
	}
}
