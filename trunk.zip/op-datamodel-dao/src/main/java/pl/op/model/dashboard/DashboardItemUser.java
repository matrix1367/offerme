package pl.op.model.dashboard;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.user.UserApp;

@Entity
@Table(name = "TB_DASHBOARD_ITEM_USER")
public class DashboardItemUser implements Serializable {

	private static final long serialVersionUID = 1439651316560140130L;
	private Integer dashboardItemUserId;
	private DashboardItem dashboardItem;
	private UserApp user;
	private Boolean isDashboardItemUserActive;

	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DASHBOARDITEMUSER_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "DASHBOARDITEMUSER_SEQUENCE_GENERATOR", sequenceName = "DASHBOARDITEMUSER_ID_SEQ")
	@Index(name = "dashboardItemUserIndex")
	public Integer getDashboardItemUserId() {
		return dashboardItemUserId;
	}

	public void setDashboardItemUserId(Integer dashboardItemUserId) {
		this.dashboardItemUserId = dashboardItemUserId;
	}
	
	@ManyToOne
	@JoinColumn(name = "dashboardItemId", nullable = false)
	@Index(name = "dashboardItemUserItemIndex")
	public DashboardItem getDashboardItem() {
		return dashboardItem;
	}

	public void setDashboardItem(DashboardItem dashboardItem) {
		this.dashboardItem = dashboardItem;
	}

	public Boolean getIsDashboardItemUserActive() {
		return isDashboardItemUserActive;
	}

	public void setIsDashboardItemUserActive(Boolean isDashboardItemUserActive) {
		this.isDashboardItemUserActive = isDashboardItemUserActive;
	}

	@ManyToOne
	@JoinColumn(name = "userId", nullable = false)
	@Index(name = "dashboardItemUserIdIndex")
	public UserApp getUser() {
		return user;
	}

	public void setUser(UserApp user) {
		this.user = user;
	}

}
