package pl.op.model.comment;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "TB_NEWS")
public class News implements Serializable {

	private static final long serialVersionUID = 1661278033715026112L;

	private Integer idNews;
	private String name;
	private String content;
	private String header;
	private Date dateNews;
	private Boolean removed;
	private Boolean active;
	private Date visibleDateFrom;
	private Date visibleDateTo;
	private String author;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public Integer getIdNews() {
		return idNews;
	}

	public void setIdNews(Integer idNews) {
		this.idNews = idNews;
	}

	@Column(nullable = false, length = 2000, columnDefinition = "TEXT")
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public Date getDateNews() {
		return dateNews;
	}

	public void setDateNews(Date dateNews) {
		this.dateNews = dateNews;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Date getVisibleDateFrom() {
		return visibleDateFrom;
	}

	public void setVisibleDateFrom(Date visibleDateFrom) {
		this.visibleDateFrom = visibleDateFrom;
	}

	public Date getVisibleDateTo() {
		return visibleDateTo;
	}

	public void setVisibleDateTo(Date visibleDateTo) {
		this.visibleDateTo = visibleDateTo;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	@Column(length = 30)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
