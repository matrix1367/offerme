package pl.op.model.contract;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.salesman.Salesman;
import pl.op.model.user.UserApp;

@Entity
@Table(name = "TB_OPERATORAGREEMENT")
public class OperatorAgreement implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer operatorAgreementId;
	private byte[] file;
	private Date dateFrom;
	private Date dateTo;
	private Boolean removed;
	private UserApp user;
	private Salesman salesman;
	private Boolean agreementSigned;

	public OperatorAgreement() {
		
	}
	
	public OperatorAgreement(UserApp userApp) {
		user = userApp;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "OPERATORAGREEMENT_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "OPERATORAGREEMENT_SEQUENCE_GENERATOR", sequenceName = "OPERATORAGREEMENT_ID_SEQ", allocationSize = 1)
	@Index(name = "operatorAgreementIndex")
	public Integer getOperatorAgreementId() {
		return operatorAgreementId;
	}

	public void setOperatorAgreementId(Integer operatorAgreementId) {
		this.operatorAgreementId = operatorAgreementId;
	}

	@OneToOne
	@JoinColumn(name = "USERID", nullable = true)
	@Index(name = "operatorAgreementUserIndex")
	public UserApp getUser() {
		return user;
	}

	public void setUser(UserApp user) {
		this.user = user;
	}

	@OneToOne
	@JoinColumn(name = "SALESMANID", nullable = true)
	@Index(name = "operatorAgreementSalesmanIndex")
	public Salesman getSalesman() {
		return salesman;
	}

	public void setSalesman(Salesman salesman) {
		this.salesman = salesman;
	}

	public byte[] getFile() {
		return file;
	}

	public void setFile(byte[] file) {
		this.file = file;
	}

	public Date getDateFrom() {
		return dateFrom;
	}

	public void setDateFrom(Date dateFrom) {
		this.dateFrom = dateFrom;
	}

	public Date getDateTo() {
		return dateTo;
	}

	public void setDateTo(Date dateTo) {
		this.dateTo = dateTo;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

	public Boolean getAgreementSigned() {
		return agreementSigned;
	}

	public void setAgreementSigned(Boolean agreementSigned) {
		this.agreementSigned = agreementSigned;
	}

}