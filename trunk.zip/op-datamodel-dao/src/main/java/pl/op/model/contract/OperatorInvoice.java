package pl.op.model.contract;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.salesman.Salesman;
import pl.op.model.user.UserApp;

@Entity
@Table(name = "TB_OPERATORINVOICE")
public class OperatorInvoice implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer operatorInvoiceId;
	private BigDecimal amountGross;
	private BigDecimal amountNet;
	private Integer amountTax;
	private byte[] file;
	private Date invoiceDate;
	private String number;
	private Date paymentDate;
	private Boolean removed;
	private UserApp user;
	private Salesman salesman;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "OPERATORINVOICE_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "OPERATORINVOICE_SEQUENCE_GENERATOR", sequenceName = "OPERATORINVOICE_ID_SEQ", allocationSize = 1)
	@Index(name = "operatorInvoiceIndex")
	public Integer getOperatorInvoiceId() {
		return operatorInvoiceId;
	}

	public void setOperatorInvoiceId(Integer operatorInvoiceId) {
		this.operatorInvoiceId = operatorInvoiceId;
	}

	public BigDecimal getAmountGross() {
		return amountGross;
	}

	public void setAmountGross(BigDecimal amountGross) {
		this.amountGross = amountGross;
	}

	public BigDecimal getAmountNet() {
		return amountNet;
	}

	public void setAmountNet(BigDecimal amountNet) {
		this.amountNet = amountNet;
	}

	public Integer getAmountTax() {
		return amountTax;
	}

	public void setAmountTax(Integer amountTax) {
		this.amountTax = amountTax;
	}

	public byte[] getFile() {
		return file;
	}

	public void setFile(byte[] file) {
		this.file = file;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

	@ManyToOne
	@JoinColumn(name = "USERID", nullable = true)
	@Index(name = "operatorInvoiceUserIndex")
	public UserApp getUser() {
		return user;
	}

	public void setUser(UserApp user) {
		this.user = user;
	}

	@ManyToOne
	@JoinColumn(name = "SALESMANID", nullable = true)
	@Index(name = "operatorInvoiceSalesmanIndex")
	public Salesman getSalesman() {
		return salesman;
	}

	public void setSalesman(Salesman salesman) {
		this.salesman = salesman;
	}

}