package pl.op.model.auction;

public enum ZoneType {

	day, night, peak, offpeak, wholeday, none;
	
	private String label;

	
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
}

