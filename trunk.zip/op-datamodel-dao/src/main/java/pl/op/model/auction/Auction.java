package pl.op.model.auction;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Index;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.model.cloud.Cloud;
import pl.op.model.contract.Invoice;
import pl.op.model.contract.InvoicePriceComponentValue;
import pl.op.model.salesman.Salesman;

@Entity
@Table(name = "TB_AUCTION")
public class Auction implements Serializable {

    private static final long serialVersionUID = 2232576382559475752L;

    private Logger log = LoggerFactory.getLogger(Auction.class);
    private Integer auctionId;
    private Date beginContractDate;
    private Date endContractDate;
    private Date finishDate;
    private Date startDate;
    private AuctionStatus status;
    private Cloud cloud;
    private List<AuctionOffer> auctionOffers;
    private List<AuctionUser> auctionUsers;
    private Boolean priceGuarantee;
    private Boolean proecological;
    private Double auctionSavings;
   

    // Transient
    private AuctionOffer actualAuctionOffer = new AuctionOffer();
    private Invoice actualUserInvoice;
    private String stringExpiredAt;
    private String formatedDiff;
    private Double diff = 0.00;
    private Integer potentialUsers;
    private List<Salesman> salesmans = new ArrayList<Salesman>();
    private Integer agreementDuration;
    private boolean isBetterThanActual;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AUCTION_SEQUENCE_GENERATOR")
    @SequenceGenerator(name = "AUCTION_SEQUENCE_GENERATOR", sequenceName = "AUCTION_ID_SEQ", allocationSize = 1)
    @Index(name = "auctionIndex")
    public Integer getAuctionId() {
        return auctionId;
    }

    public void setAuctionId(Integer auctionId) {
        this.auctionId = auctionId;
    }

    public Date getBeginContractDate() {
        return beginContractDate;
    }

    public void setBeginContractDate(Date beginContractDate) {
        this.beginContractDate = beginContractDate;
    }

    public Date getEndContractDate() {
        return endContractDate;
    }

    public void setEndContractDate(Date endContractDate) {
        this.endContractDate = endContractDate;
    }

    public Date getFinishDate() {
        return finishDate;
    }

    public void setFinishDate(Date finishDate) {
        this.finishDate = finishDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    @Enumerated(EnumType.STRING)
    public AuctionStatus getStatus() {
        return status;
    }

    public void setStatus(AuctionStatus status) {
        this.status = status;
    }

    @ManyToOne
    @JoinColumn(name = "CLOUDID", nullable = true)
    @Index(name = "auctionCloudIndex")
    public Cloud getCloud() {
        return cloud;
    }

    public void setCloud(Cloud cloud) {
        this.cloud = cloud;
    }

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "auction")
    public List<AuctionOffer> getAuctionOffers() {
        return auctionOffers;
    }

    public void setAuctionOffers(List<AuctionOffer> auctionOffers) {
        this.auctionOffers = auctionOffers;
    }

    @SuppressWarnings("deprecation")
    @Transient
    public Integer getAgreementDurationMonth() {
        Integer agreementDuration = 0;
        if(beginContractDate != null && endContractDate != null) {
            agreementDuration = ((endContractDate.getYear() - beginContractDate.getYear()) * 12)
                    + (endContractDate.getMonth() - beginContractDate.getMonth());
        }

        return agreementDuration;
    }

    @Transient
    public AuctionOffer getActualAuctionOffer() {
        try {
            actualAuctionOffer = new AuctionOffer();

            if(auctionOffers != null) {
                if(!auctionOffers.isEmpty()) {
                    actualAuctionOffer = this.auctionOffers.get(0);
                    if(actualAuctionOffer.getAuctionOfferId() == null)
                        return null;

                    Date actualOfferDate;
                    if(actualAuctionOffer.getUpdatedAt() == null)
                        actualOfferDate = actualAuctionOffer.getCreatedAt();
                    else
                        actualOfferDate = actualAuctionOffer.getUpdatedAt();
                    for(int i = 0; i < auctionOffers.size(); i++) {
                        AuctionOffer offer;

                        offer = auctionOffers.get(i);

                        Date offerDate;
                        if(offer.getUpdatedAt() == null) {
                            offerDate = offer.getCreatedAt();
                        } else {
                            offerDate = offer.getUpdatedAt();
                        }
                        if(offerDate.getTime() > actualOfferDate.getTime())
                            actualAuctionOffer = offer;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return actualAuctionOffer;
    }

    public void setActualAuctionOffer(AuctionOffer actualAuctionOffer) {
        this.actualAuctionOffer = actualAuctionOffer;
    }

    @Transient
    public String getstringExpiredAt() {
        try {

            Date actualDate = new Date();
            if(finishDate.getTime() < actualDate.getTime())
                return "aukcja zakończona";

            // in milliseconds
            long diff = finishDate.getTime() - actualDate.getTime();

            long diffSeconds = diff / 1000 % 60;
            long diffMinutes = diff / (60 * 1000) % 60;
            long diffHours = diff / (60 * 60 * 1000) % 24;
            long diffDays = diff / (24 * 60 * 60 * 1000);

            if(diffDays > 0)
                stringExpiredAt = diffDays + "d ";
            if(diffDays > 0 || diffHours > 0)
                stringExpiredAt += diffHours + "g ";
            if(diffDays > 0 || diffHours > 0 || diffMinutes > 0)
                stringExpiredAt += diffMinutes + "m ";
            if(diffMinutes > 0 || diffSeconds > 0)
                stringExpiredAt += diffSeconds + "s ";

        } catch (Exception e) {
            e.printStackTrace();
        }

        return stringExpiredAt;
    }

    public void setstringExpiredAt(String stringExpiredAt) {
        this.stringExpiredAt = stringExpiredAt;
    }

    @Transient
    public Invoice getActualUserInvoice() {
        return actualUserInvoice;
    }

    public void setActualUserInvoice(Invoice actualUserInvoice) {
        this.actualUserInvoice = actualUserInvoice;
    }

    public void prepareDiffByTarriffPriceComponentValue(PriceComponentValue priceComponentValue) {
        ZoneType selZoneType = priceComponentValue.getPriceComponent().getZoneType();

        try {
            if(hasInvoicePriceComponentValue()) {
                for(InvoicePriceComponentValue invoicePCV : actualUserInvoice.getInvoicePriceComponentValue()) {
                    if(isZoneSameAs(invoicePCV, selZoneType)) {
                        LoggerFactory.getLogger(Auction.class).info("invoicePCV.getValue(): " + invoicePCV.getValue());
                        LoggerFactory.getLogger(Auction.class).info(
                                "priceComponentValue.getValue(): " + priceComponentValue.getValue());

                        diff = (invoicePCV.getValue().doubleValue() / 1000)
                                - priceComponentValue.getValue().doubleValue();
                        DecimalFormat formater = new DecimalFormat("0.0000");

                        LoggerFactory.getLogger(Auction.class).info("diff: " + diff);
                        Double diff2 = diff.doubleValue();
                        if(diff.doubleValue() > 0) {
                            isBetterThanActual = true;
                        }
                        if(diff2 < 0) {
                            diff2 = diff2.doubleValue() * -1;
                        }

                        formatedDiff = formater.format(diff2);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            log.error("Problem while prepareDiffByTarriffPriceComponentValue: ", e);
        }
    }

    private boolean hasInvoicePriceComponentValue() {
        if(null == actualUserInvoice) {
            return false;
        }
        if(null == actualUserInvoice.getInvoicePriceComponentValue()) {
            return false;
        }
        if(actualUserInvoice.getInvoicePriceComponentValue().isEmpty()) {
            return false;
        }

        return true;
    }

    private boolean isZoneSameAs(InvoicePriceComponentValue invoicePriceComponentValue, ZoneType zone) {
        if(null == invoicePriceComponentValue.getPriceComponent()) {
            return false;
        }
        if(!zone.equals(invoicePriceComponentValue.getPriceComponent().getZoneType())) {
            return false;
        }

        return true;
    }

    @Transient
    public String getDiffSign() {
        if(diff.doubleValue() > 0) {
            return "less";
        } else if(diff.doubleValue() < 0) {
            return "more";
        }

        return "same";
    }

    @Transient
    public Double getDiff() {
        return diff;
    }

    public void setDiff(double diff) {
        this.diff = diff;
    }

    @Transient
    public String getFormatedDiff() {
        return formatedDiff;
    }

    public void setFormatedDiff(String formatedDiff) {
        this.formatedDiff = formatedDiff;
    }

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "auction")
    public List<AuctionUser> getAuctionUsers() {
       // log.info(">>>>>>>>>>>>>>>[getAuctionUsers]" + auctionUsers.size());
        return auctionUsers;
    }

    public void setAuctionUsers(List<AuctionUser> auctionUsers) {
        //log.info(">>>>>>>>>>>>>>>[auctionID: " + auctionId +" setAuctionUsers]" + auctionUsers.size());
        this.auctionUsers = auctionUsers;
    }

    public void addAuctionUser(AuctionUser auctionUser) {
        
        if(this.auctionUsers == null)
            this.auctionUsers = new ArrayList<AuctionUser>();

        this.auctionUsers.add(auctionUser);
        log.info(">>>>>>>>>>>>>>>[addAuctionUser]" + auctionUsers.size());
    }

    @Transient
    public Integer getPotentialUsers() {
        return potentialUsers;
    }

    public void setPotentialUsers(Integer potentialUsers) {
        this.potentialUsers = potentialUsers;
    }

    @Transient
    public List<Salesman> getSalesmans() {
        List<Integer> salesmansId = new ArrayList<Integer>();
        salesmans = new ArrayList<Salesman>();

        if(isAuctionOffersNotNull()) {
            for(AuctionOffer offer : auctionOffers) {
                if(salesmans.contains(offer.getSalesman()) && salesmansId.contains(offer.getSalesman().getSalesmanId())) {
                    continue;
                }
                salesmans.add(offer.getSalesman());
                salesmansId.add(offer.getSalesman().getSalesmanId());
            }
        }

        return salesmans;
    }

    public void setSalesmans(List<Salesman> salesmans) {
        this.salesmans = salesmans;
    }

    @SuppressWarnings("deprecation")
    @Transient
    public Integer getAgreementDuration() {
        try {
            if(endContractDate != null && beginContractDate != null)
                agreementDuration = ((endContractDate.getYear() - beginContractDate.getYear()) * 12)
                        + (endContractDate.getMonth() - beginContractDate.getMonth());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return agreementDuration;
    }

    public void setAgreementDuration(Integer agreementDuration) {
        this.agreementDuration = agreementDuration;
    }

    @Transient
    public Integer getSalesmansCount() {
        Integer salesmanCount = 0;
        List<Salesman> countedSalesman = new ArrayList<Salesman>();

        try {
            if(auctionOffers != null) {
                if(!auctionOffers.isEmpty()) {
                    for(AuctionOffer auctionOffer : auctionOffers) {
                        if(!countedSalesman.contains(auctionOffer.getSalesman())) {
                            salesmanCount++;
                            countedSalesman.add(auctionOffer.getSalesman());
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return salesmanCount;
    }

    public Boolean getPriceGuarantee() {
        return priceGuarantee;
    }

    public void setPriceGuarantee(Boolean priceGuarantee) {
        this.priceGuarantee = priceGuarantee;
    }

    public Boolean getProecological() {
        return proecological;
    }

    public void setProecological(Boolean proecological) {
        this.proecological = proecological;
    }

    public Double getAuctionSavings() {
        return auctionSavings;
    }

    public void setAuctionSavings(Double auctionSavings) {
        this.auctionSavings = auctionSavings;
    }

    @Transient
    public boolean isAuctionOffersNotNull() {
        if(auctionOffers == null) {
            return false;
        }

        if(auctionOffers.isEmpty()) {
            return false;
        }

        if(auctionOffers.size() == 0) {
            return false;
        }

        return true;
    }

    @Transient
    public AuctionOffer getLastOffer() {
        return auctionOffers.get(0);
    }
    
    @Transient
    public AuctionOffer getLastOfferForEmail() {
        return auctionOffers.get(auctionOffers.size()-1);
    }


    @Transient
    public Integer getUserCount() {       
        if(null == auctionUsers) {
            log.info(">>>>>>>>>>>>>>>[Auction.getUserCount()] is null");
            return 0;
        }
        if(auctionUsers.isEmpty()) {
            log.info(">>>>>>>>>>>>>>>[Auction.getUserCount] is empty");
            return 0;
        }
        if(auctionUsers.size() == 1) {
            log.info(">>>>>>>>>>>>>>>[Auction.getUserCount()] == 1");
            if(null == auctionUsers.get(0).getAuctionUserId()) {
                log.info(">>>>>>>>>>>>>>>[getUserCount] auctionUsers.get(0).getAuctionUserID()==null");
                return 0;
            }
        }

        return auctionUsers.size();
    }

    @Transient
    public boolean isInProgress() {
        if(!AuctionStatus.INPROGRESS.equals(status)) {
            return false;
        }

        return true;
    }

    @Transient
    public boolean isBetterThanActual() {
        return isBetterThanActual;
    }
}