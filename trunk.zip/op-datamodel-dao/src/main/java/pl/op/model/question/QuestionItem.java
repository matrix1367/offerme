package pl.op.model.question;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_QUESTIONITEM")
public class QuestionItem implements Serializable {

	private static final long serialVersionUID = 3242723144446616175L;

	private Integer questionItemId;
	private String questionItemValue;
	private String questionItemName;
	private PreferenceQuestion preferenceQuestion;
	private Boolean removed;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "QUESTIONITEM_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "QUESTIONITEM_SEQUENCE_GENERATOR", sequenceName = "QUESTIONITEM_ID_SEQ", allocationSize = 1)
	@Index(name = "questionItemIndex")
	public Integer getQuestionItemId() {
		return questionItemId;
	}

	public void setQuestionItemId(Integer questionItemId) {
		this.questionItemId = questionItemId;
	}

	public String getQuestionItemValue() {
		return questionItemValue;
	}

	public void setQuestionItemValue(String questionItemValue) {
		this.questionItemValue = questionItemValue;
	}

	public String getQuestionItemName() {
		return questionItemName;
	}

	public void setQuestionItemName(String questionItemName) {
		this.questionItemName = questionItemName;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

	@ManyToOne
	@JoinColumn(name = "PREFERENCEQUESTIONID", nullable = true)
	@Index(name = "questionItemPreferenceQuestionIndex")
	public PreferenceQuestion getPreferenceQuestion() {
		return preferenceQuestion;
	}

	public void setPreferenceQuestion(PreferenceQuestion preferenceQuestion) {
		this.preferenceQuestion = preferenceQuestion;
	}
}