package pl.op.model.auction;

import java.util.ArrayList;
import java.util.Date;

import org.slf4j.LoggerFactory;

import pl.op.model.cloud.Cloud;
import pl.op.model.cloud.VolumeEnum;
import pl.op.model.contract.Location;
import pl.op.model.contract.PPE;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Street;
import pl.op.model.dict.Tariff;
import pl.op.model.salesman.Salesman;
import pl.op.model.stereotype.Stereotype;

public class AuctionFilter {

    private Auction auction;
    private Integer offerId;
    private Integer evaluation;
    private Double endTime;
    private VolumeEnum volume;
    private Double volumeFrom;
    private Double volumeTo;
    private AuctionAttributesEnum auctionAttribute;
    private String attributeValue;
    private String agreementDurationMonth;
    private String agreementDurationType;
    private Integer agreementDurationValue;
    private String locationAddress;
    private String locationTariffName;
    private String orderBy;
    private String orderColumn;
    private String orderType;
    private boolean seller;
    private String userOrCompanyName;
    private City city;
    private Area area;
    private String streetName;
    private Date finishDate;
    private Date startDate;
    private Salesman salesman;

    public AuctionFilter() {
        city = new City();
        area = new Area();
        auctionAttribute = null;
        endTime = null;
        seller = false;
        salesman = new Salesman();

        auction = new Auction();
        auction.setAuctionOffers(new ArrayList<AuctionOffer>());

        Cloud cloud = new Cloud();
        cloud.setTariff(new Tariff());
        cloud.setStereotype(new Stereotype());
        cloud.setAreas(new ArrayList<Area>());
        cloud.setCities(new ArrayList<City>());
        cloud.setStreets(new ArrayList<Street>());

        auction.setCloud(cloud);
    }

    public VolumeEnum getVolume() {
        return volume;
    }

    public void setVolume(VolumeEnum volume) {
        this.volume = volume;
    }

    public Double getVolumeFrom() {
        return volumeFrom;
    }

    public void setVolumeFrom(Double volumeFrom) {
        this.volumeFrom = volumeFrom;
    }

    public Double getVolumeTo() {
        return volumeTo;
    }

    public void setVolumeTo(Double volumeTo) {
        this.volumeTo = volumeTo;
    }

    public Double getVolumeFromInMWh() {
        if(null == volumeFrom) {
            return 0.0;
        }
        if(VolumeEnum.MWH.equals(volume)) {
            return volumeFrom.doubleValue() * 1000.0;
        }
        if(VolumeEnum.GWH.equals(volume)) {
            return volumeFrom.doubleValue() * 1000000.0;
        }
        if(VolumeEnum.TWH.equals(volume)) {
            return volumeFrom.doubleValue() * 1000000000.0;
        }

        return volumeFrom.doubleValue();
    }

    public Double getVolumeToInMWh() {
        if(null == volumeTo) {
            return 0.0;
        }
        if(VolumeEnum.MWH.equals(volume)) {
            return volumeTo.doubleValue() * 1000.0;
        }
        if(VolumeEnum.GWH.equals(volume)) {
            return volumeTo.doubleValue() * 1000000.0;
        }
        if(VolumeEnum.TWH.equals(volume)) {
            return volumeTo.doubleValue() * 1000000000.0;
        }

        return volumeTo.doubleValue();
    }

    public Auction getAuction() {
        return auction;
    }

    public void setAuction(Auction auction) {
        this.auction = auction;
    }

    public Integer getOfferId() {
        return offerId;
    }

    public void setOfferId(Integer offerId) {
        this.offerId = offerId;
    }

    public Integer getEvaluation() {
        return evaluation;
    }

    public void setEvaluation(Integer evaluation) {
        this.evaluation = evaluation;
    }

    public Double getEndTime() {
        return endTime;
    }

    public void setEndTime(Double endTime) {
        this.endTime = endTime;
    }

    public AuctionAttributesEnum getAuctionAttribute() {
        return auctionAttribute;
    }

    public void setAuctionAttribute(AuctionAttributesEnum auctionAttribute) {
        this.auctionAttribute = auctionAttribute;
    }

    public boolean isSeller() {
        return seller;
    }

    public void setSeller(boolean seller) {
        this.seller = seller;
    }

    public String getAttributeValue() {
        return attributeValue;
    }

    public void setAttributeValue(String attributeValue) {
        this.attributeValue = attributeValue;
    }

    public String getAgreementDurationMonth() {
        return agreementDurationMonth;
    }

    public void setAgreementDurationMonth(String agreementDurationMonth) {
        this.agreementDurationMonth = agreementDurationMonth;
    }

    public String getLocationAddress() {
        return locationAddress;
    }

    public void setLocationAddress(String locationAddress) {
        this.locationAddress = locationAddress;
    }

    public void updateLocationDataInCloud(PPE ppe, Boolean clear, Boolean onlyOne) {

        try {
            Location location = ppe.getLocation();

            if(clear.equals(true)) {
                this.auction.getCloud().setAreas(null);
                this.auction.getCloud().setCities(null);
                this.auction.getCloud().setStreets(null);
                this.auction.getCloud().setTariff(new Tariff());
                this.locationAddress = null;
                this.locationTariffName = null;
            }

            if(onlyOne.equals(true)) {
                try {
                    this.locationAddress = location.getStreet().getCity().getArea().getAreaName();

                    this.locationAddress += ", ";
                    this.locationAddress += location.getZipCode();

                    this.locationAddress += " ";
                    this.locationAddress += location.getStreet().getCity().getCityName();

                    this.locationAddress += ", ";
                    this.locationAddress += location.getStreet().getStreetName() + " " + location.getHomeNo();
                    if(!"".equals(location.getFlatNo())) {
                        this.locationAddress += "/" + location.getFlatNo();
                    }

                    if(ppe.getTariff() != null)
                        this.locationTariffName = ppe.getTariff().getTariffName();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            this.auction.getCloud().addStreet(location.getStreet());
            this.auction.getCloud().addCity(location.getStreet().getCity());
            this.auction.getCloud().addArea(location.getStreet().getCity().getArea());
            if(onlyOne.equals(true)) {
                this.auction.getCloud().setTariff(ppe.getTariff());
            }
        } catch (Exception e) {
            LoggerFactory.getLogger(AuctionFilter.class).error("Problem while updateLocationDataInCloud: ", e);
        }
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public String getOrderColumn() {
        if(this.orderBy != null) {
            String[] splited = this.orderBy.split("-");
            this.orderColumn = splited[0];
        }

        return orderColumn;
    }

    public void setOrderColumn(String orderColumn) {
        this.orderColumn = orderColumn;
    }

    public String getOrderType() {
        if(this.orderBy != null) {
            String[] splited = this.orderBy.split("-");
            this.orderType = splited[1];
        }

        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getAgreementDurationType() {
        if(this.agreementDurationMonth != null) {
            String[] splited = this.agreementDurationMonth.split("-");
            this.agreementDurationType = splited[0];
        }

        return agreementDurationType;
    }

    public void setAgreementDurationType(String agreementDurationType) {
        this.agreementDurationType = agreementDurationType;
    }

    public Integer getAgreementDurationValue() {
        if(this.agreementDurationMonth != null) {
            String[] splited = this.agreementDurationMonth.split("-");
            Integer val = Integer.valueOf(splited[1]);

            this.agreementDurationValue = val;
        }

        return agreementDurationValue;
    }

    public void setAgreementDurationValue(Integer agreementDurationValue) {
        this.agreementDurationValue = agreementDurationValue;
    }

    public String getLocationTariffName() {
        return locationTariffName;
    }

    public void setLocationTariffName(String locationTariffName) {
        this.locationTariffName = locationTariffName;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public Date getFinishDate() {
        return finishDate;
    }

    public void setFinishDate(Date finishDate) {
        this.finishDate = finishDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Salesman getSalesman() {
        return salesman;
    }

    public void setSalesman(Salesman salesman) {
        this.salesman = salesman;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    @Override
    public String toString() {
        StringBuilder desc = new StringBuilder();

        desc.append("\n\n Auction filter");
        desc.append("\n evaluation - " + evaluation);
        desc.append("\n volume - " + volume);
        desc.append("\n volumeFrom - " + volumeFrom);
        desc.append("\n volumeTo - " + volumeTo);
        desc.append("\n auctionAttribute - " + auctionAttribute);
        desc.append("\n agreementDurationMonth - " + getAgreementDurationMonth());
        desc.append("\n agreementDurationType - " + getAgreementDurationType());
        desc.append("\n agreementDurationValue - " + getAgreementDurationValue());
        desc.append("\n orderBy - " + orderBy);
        desc.append("\n orderType - " + orderType);
        desc.append("\n seller - " + seller);
        desc.append("\n city.cityId - " + city.getCityId());
        desc.append("\n city.cityName - " + city.getCityName());
        desc.append("\n area.areaId - " + area.getAreaId());
        desc.append("\n area.areaName - " + area.getAreaName());
        desc.append("\n streetName - " + streetName);
        desc.append("\n finishDate - " + finishDate);
        desc.append("\n startDate - " + startDate);
        desc.append("\n salesman.salesmanName - " + salesman.getSalesmanName());
        desc.append("\n salesman.salesmanId - " + salesman.getSalesmanId());
        desc.append("\n ");

        desc.append(auction.getCloud().toString());
        desc.append("\n ");
        desc.append(auction.toString());

        return desc.toString();
    }

    public String getUserOrCompanyName() {
        return userOrCompanyName;
    }

    public void setUserOrCompanyName(String userOrCompanyName) {
        this.userOrCompanyName = userOrCompanyName;
    }
}