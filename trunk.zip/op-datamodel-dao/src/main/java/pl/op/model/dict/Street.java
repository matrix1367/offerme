package pl.op.model.dict;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_STREET")
public class Street implements Serializable {

	private static final long serialVersionUID = -5259134391123547231L;

	private Integer streetId;
	private String streetName;
	private City city;
	private Boolean removed;
	private String symbol;

	// Transient
	private Integer cloudId;
	private Integer cityId;
	private Integer limit;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "STREET_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "STREET_SEQUENCE_GENERATOR", sequenceName = "STREET_ID_SEQ", allocationSize = 1)
	@Index(name = "streetIndex")
	public Integer getStreetId() {
		return streetId;
	}

	public void setStreetId(Integer streetId) {
		this.streetId = streetId;
	}

	@ManyToOne
	@JoinColumn(name = "CITYID", nullable = true)
	@Index(name = "streetCityIndex")
	public City getCity() {
		return city;
	}

	public void setCity(City city) {
		this.city = city;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	@Transient
	public Integer getCloudId() {
		return cloudId;
	}

	public void setCloudId(Integer cloudId) {
		this.cloudId = cloudId;
	}

	public Boolean getRemoved() {
		return removed;
	}

	public void setRemoved(Boolean removed) {
		this.removed = removed;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	@Transient
	public Integer getLimit() {
		return limit;
	}

	public void setLimit(Integer limit) {
		this.limit = limit;
	}

	@Transient
	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}
}
