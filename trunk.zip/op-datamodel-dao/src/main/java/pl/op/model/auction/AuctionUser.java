package pl.op.model.auction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import pl.op.model.contract.PPE;
import pl.op.model.user.UserApp;

@Entity
@Table(name = "TB_AUCTIONUSER")
public class AuctionUser implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 8566366493194609271L;

    private Integer auctionUserId;
    private Date joinedAt;
    private UserApp userApp;
    private Auction auction;
    private PPE ppe;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AUCTIONUSER_SEQUENCE_GENERATOR")
    @SequenceGenerator(name = "AUCTIONUSER_SEQUENCE_GENERATOR", sequenceName = "AUCTIONUSER_ID_SEQ", allocationSize = 1)
    @Index(name = "auctionUserIndex")
    public Integer getAuctionUserId() {
        return auctionUserId;
    }

    public void setAuctionUserId(Integer auctionUserId) {
        this.auctionUserId = auctionUserId;
    }

    public Date getJoinedAt() {
        return joinedAt;
    }

    public void setJoinedAt(Date joinedAt) {
        this.joinedAt = joinedAt;
    }

    @ManyToOne
    @JoinColumn(name = "USERID", nullable = true)
    @Index(name = "auctionUserUserIdIndex")
    public UserApp getUserApp() {
        return userApp;
    }

    public void setUserApp(UserApp userApp) {
        this.userApp = userApp;
    }

    @ManyToOne
    @JoinColumn(name = "AUCTIONID", nullable = true)
    @Index(name = "auctionUserAuctionIdIndex")
    public Auction getAuction() {
        return auction;
    }

    public void setAuction(Auction auction) {
        this.auction = auction;
    }

    @ManyToOne
    @JoinColumn(name = "PPEID", nullable = false)
    @Index(name = "auctionUserPpeIdIndex")
    public PPE getPpe() {
        return ppe;
    }

    public void setPpe(PPE ppe) {
        this.ppe = ppe;
    }
    

}