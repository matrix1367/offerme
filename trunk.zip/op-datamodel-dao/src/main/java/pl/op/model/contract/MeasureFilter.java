package pl.op.model.contract;

import java.util.Date;

import pl.op.model.auction.ZoneType;

public class MeasureFilter {
	private Date dateFrom;
	private Date dateTo;
	private ZoneType zoneType;
	private Integer ppeId;
	private Priority priority;
	
	
	public Date getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(Date dateFrom) {
		this.dateFrom = dateFrom;
	}
	public Date getDateTo() {
		return dateTo;
	}
	public void setDateTo(Date dateTo) {
		this.dateTo = dateTo;
	}
	public ZoneType getZoneType() {
		return zoneType;
	}
	public void setZoneType(ZoneType zoneType) {
		this.zoneType = zoneType;
	}
	public Priority getPriority() {
		return priority;
	}
	public void setPriority(Priority priority) {
		this.priority = priority;
	}
	public Integer getPpeId() {
		return ppeId;
	}
	public void setPpeId(Integer ppeId) {
		this.ppeId = ppeId;
	}
}
