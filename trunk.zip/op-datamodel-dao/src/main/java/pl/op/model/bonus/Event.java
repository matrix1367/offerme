package pl.op.model.bonus;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_EVENT")
public class Event implements Serializable {

	private static final long serialVersionUID = 7088710898583391463L;

	private Integer eventId;
	private String eventName;
	private String eventCodeName;
	private String eventDescription;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "EVENT_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "EVENT_SEQUENCE_GENERATOR", sequenceName = "EVENT_ID_SEQ", allocationSize = 1)
	@Index(name = "eventIndex")
	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventCodeName() {
		return eventCodeName.toLowerCase();
	}

	public void setEventCodeName(String eventCodeName) {
		this.eventCodeName = eventCodeName.toLowerCase();
	}

	public String getEventDescription() {
		return eventDescription;
	}

	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}

}
