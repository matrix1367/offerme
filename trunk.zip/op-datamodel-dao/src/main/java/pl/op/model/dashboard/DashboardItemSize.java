package pl.op.model.dashboard;

public enum DashboardItemSize {

	SMALL, MEDIUM, BIG

}
