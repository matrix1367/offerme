package pl.op.model.newsletter;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_NEWSLETTER")
public class Newsletter implements Serializable {

    private static final long serialVersionUID = -8078561855376134526L;

    private Integer newsletterId;
    private String content;
    private Date createdAt;
    private Boolean isSendNoRegisterUser;
    private Integer type;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "NEWSLETTER_SEQUENCE_GENERATOR")
    @SequenceGenerator(name = "NEWSLETTER_SEQUENCE_GENERATOR", sequenceName = "NEWSLETTER_ID_SEQ", allocationSize = 1)
    @Index(name = "newsletterIndex")
    public Integer getNewsletterId() {
        return newsletterId;
    }

    public void setNewsletterId(Integer newsletterId) {
        this.newsletterId = newsletterId;
    }

    public String getContent() {
        return content;
    }    

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Boolean getIsSendNoRegisterUser() {
        return isSendNoRegisterUser;
    }

    public void setIsSendNoRegisterUser(Boolean isSendNoRegisterUser) {
        this.isSendNoRegisterUser = isSendNoRegisterUser;
    }

}
