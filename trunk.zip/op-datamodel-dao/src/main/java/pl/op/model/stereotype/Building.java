package pl.op.model.stereotype;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_BUILDING")
public class Building implements Serializable {

	private static final long serialVersionUID = 1675462860387094165L;
	
	private Integer buildingId;
	private Double area;
	private HeatingWaterType heatingWaterType;
	private HeatingBuildingType heatingBuildingType;
	private Integer roomNo;
	private WarmBuildingOutside warmBuildingOutside;
	private WindowsType windowsType;
	private IsolationBuildingTime isolationBuildingTime;
	private Integer personsNoKids;
	private Integer personsNoAdults;
	private Integer floor;
	private BuildingType buildingType;
	private AcType acType;
	private Integer bulbs;
	private String year;
	private boolean isProperty;
	private Integer certificate;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "BUILDING_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "BUILDING_SEQUENCE_GENERATOR", sequenceName = "BUILDING_ID_SEQ", allocationSize = 1)
	@Index(name = "buildingIndex")
	public Integer getBuildingId() {
		return buildingId;
	}
	
	public void setBuildingId(Integer buildingId) {
		this.buildingId = buildingId;
	}
        
    //public Building()
    //{
    //    isProperty =true;
    //}

	public Double getArea() {
		return area;
	}

	public void setArea(Double area) {
		this.area = area;
	}

	public Integer getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(Integer roomNo) {
		this.roomNo = roomNo;
	}

	@Enumerated(EnumType.STRING)
	public HeatingWaterType getHeatingWaterType() {
		return heatingWaterType;
	}

	public void setHeatingWaterType(HeatingWaterType heatingWaterType) {
		this.heatingWaterType = heatingWaterType;
	}

	@Enumerated(EnumType.STRING)
	public HeatingBuildingType getHeatingBuildingType() {
		return heatingBuildingType;
	}

	public void setHeatingBuildingType(HeatingBuildingType heatingBuildingType) {
		this.heatingBuildingType = heatingBuildingType;
	}

	@Enumerated(EnumType.STRING)
	public WindowsType getWindowsType() {
		return windowsType;
	}

	public void setWindowsType(WindowsType windowsType) {
		this.windowsType = windowsType;
	}

	@Enumerated(EnumType.STRING)
	public WarmBuildingOutside getWarmBuildingOutside() {
		return warmBuildingOutside;
	}

	public void setWarmBuildingOutside(WarmBuildingOutside warmBuildingOutside) {
		this.warmBuildingOutside = warmBuildingOutside;
	}

	@Enumerated(EnumType.STRING)
	public IsolationBuildingTime getIsolationBuildingTime() {
		return isolationBuildingTime;
	}

	public void setIsolationBuildingTime(
			IsolationBuildingTime isolationBuildingTime) {
		this.isolationBuildingTime = isolationBuildingTime;
	}

	public Integer getFloor() {
		return floor;
	}

	public void setFloor(Integer floor) {
		this.floor = floor;
	}
	
	@Enumerated(EnumType.STRING)
	public BuildingType getBuildingType() {
		return buildingType;
	}

	public void setBuildingType(BuildingType buildingType) {
		this.buildingType = buildingType;
	}
	
	@Enumerated(EnumType.STRING)
	public AcType getAcType() {
		return acType;
	}

	public void setAcType(AcType acType) {
		this.acType = acType;
	}

	public Integer getBulbs() {
		return bulbs;
	}

	public void setBulbs(Integer bulbs) {
		this.bulbs = bulbs;
	}

	public Integer getPersonsNoKids() {
		return personsNoKids;
	}

	public void setPersonsNoKids(Integer personsNoKids) {
		this.personsNoKids = personsNoKids;
	}

	public Integer getPersonsNoAdults() {
		return personsNoAdults;
	}

	public void setPersonsNoAdults(Integer personsNoAdults) {
		this.personsNoAdults = personsNoAdults;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	@Column(name="isProperty")
	public boolean isProperty() {
		return isProperty;
	}

	public void setProperty(boolean isProperty) {
		this.isProperty = isProperty;
	}

	public Integer getCertificate() {
		return certificate;
	}

	public void setCertificate(Integer certificate) {
		this.certificate = certificate;
	}
}