package pl.op.settings;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TB_SETTINGS")
public class Settings implements Serializable {

	private static final long serialVersionUID = 7332801549938990508L;

	private Integer settingId;
	private String settingType;
	private String settingName;
	private Integer settingValue;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SETTING_SEQUENCE_GENERATOR")
	@SequenceGenerator(name = "SETTING_SEQUENCE_GENERATOR", sequenceName = "SETTING_ID_SEQ", allocationSize = 1)
	@Index(name = "settingIndex")
	public Integer getSettingId() {
		return settingId;
	}
	public void setSettingId(Integer settingId) {
		this.settingId = settingId;
	}
	public String getSettingName() {
		return settingName;
	}
	public void setSettingName(String settingName) {
		this.settingName = settingName;
	}
	public Integer getSettingValue() {
		return settingValue;
	}
	public void setSettingValue(Integer settingValue) {
		this.settingValue = settingValue;
	}
	public String getSettingType() {
		return settingType;
	}
	public void setSettingType(String settingType) {
		this.settingType = settingType;
	}
}
