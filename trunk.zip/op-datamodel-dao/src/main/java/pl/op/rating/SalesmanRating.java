package pl.op.rating;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AuctionDao;
import pl.op.dao.SalesmanDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.salesman.Salesman;

/**
 * This class consists methods that operate on finished auctions list and map of
 * best offers.
 * 
 * @see List
 * @see Map
 */
public class SalesmanRating implements Serializable {

    private static final long serialVersionUID = -966103378361783937L;
    private Logger log = LoggerFactory.getLogger(SalesmanRating.class);

    AuctionDao auctionDao;
    SalesmanDao salesmanDao;

    private Auction auction;
    private AuctionOffer oldestOffer;
    private AuctionOffer winningOffer;
    private Salesman salesman;

    private List<Auction> finishedAuctions;
    private Map<String, AuctionOffer> offersMap;

    private String key;

    private long daysBetween;
    private Integer salesmanId;
    private Integer greenEnergyPercent;

    private Double auctionSavings;
    private Double oldestOfferPrice;
    private Double winningOfferPrice;
    private Double constPriceComponentValue;
    private Double agreementDays;
    private Double greenEnergyShare;
    private Double salesmanRating;

    public SalesmanRating() {
    }

    public SalesmanRating(AuctionDao auctionDao, SalesmanDao salesmanDao) {
        this.auctionDao = auctionDao;
        this.salesmanDao = salesmanDao;
    }

    /**
     * <p>
     * The method using private methods to calculate the salesman's rating. It
     * starts from finding a list of auctions for which status is FINISHED and
     * auctionSavings is NULL. See method {@link #findAuctionList()}.
     * </p>
     * <p>
     * If the list of finished auctions contains at least one element, for each
     * auction from the list performs the necessary operations to complete a map
     * of best offers. See methods:
     * <ul>
     * <li>{@link #findOldestOffer(Auction)}</li>
     * <li>{@link #findWinningOffer(Auction)}</li>
     * <li>{@link #calculateAuctionSavings(Auction)}</li>
     * <li>{@link #calculateAgreementDays(Auction)}</li>
     * <li>{@link #offersMapIterator(Auction)}</li>
     * </ul>
     * </p>
     */
    public void ratingAction() {
        log.info("ratingAction...");
        findAuctionList();

        if (!finishedAuctions.isEmpty()) {
            offersMap = new HashMap<String, AuctionOffer>();

            for (Auction a : finishedAuctions) {
                log.debug("Start calculating from auction " + a.getAuctionId());
                findOldestOffer(a);
                findWinningOffer(a);
                calculateAuctionSavings(a);
                calculateAgreementDays(a);
                offersMapIterator(a);
            }
        }
    }

    /**
     * The method initializes the finishedAuctions list and fills it with data.
     */
    private void findAuctionList() {
        log.info("findAuctionList...");
        finishedAuctions = new ArrayList<Auction>();
        try {
            finishedAuctions = auctionDao.getFinishedAuctions();
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
        }
        log.info("finishedAuctions size: " + finishedAuctions.size());

    }

    /**
     * The method finds an object of type AuctionOffer that initialize a given
     * auction
     * 
     * @param auction
     *            - parameter passed from the list of finished auctions
     */
    private void findOldestOffer(Auction auction) {
        log.info("[auctionId " + auction.getAuctionId() + "] findOldestOffer...");
        oldestOffer = new AuctionOffer();
        try {
            oldestOffer = auctionDao.getOldestOffer(auction.getAuctionId());

            log.debug("oldestOffer " + oldestOffer.getAuctionOfferId());
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
        }
    }

    /**
     * The method finds an object of type AuctionOffer that has won a given
     * auction and put it into the map
     * 
     * @param auction
     *            - parameter passed from the list of finished auctions
     */
    private void findWinningOffer(Auction auction) {
        log.info("[auctionId " + auction.getAuctionId() + "] findWinningOffer...");
        winningOffer = new AuctionOffer();
        salesman = new Salesman();

        try {
            winningOffer = auctionDao.getWinningOffer(auction.getAuctionId());
            winningOffer.setAuction(auction);
            salesmanId = auctionDao.getSalesmanByOffer(winningOffer.getAuctionOfferId());
            salesman = salesmanDao.getSalesmanById(salesmanId);
            winningOffer.setSalesman(salesman);

            log.debug("winningOffer " + winningOffer.getAuctionOfferId());
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
        }

        key = getWinningPrefix() + auction.getAuctionId();
        offersMap.put(key, winningOffer);
    }

    /**
     * The method calculates the value of the auctionSavings on the basis of the
     * PriceComponentValue correlated with the offers that initialize and has
     * won a given auction
     * 
     * @param auction
     *            - parameter passed from the list of finished auctions
     */
    private void calculateAuctionSavings(Auction auction) {
        log.info("[auctionId " + auction.getAuctionId() + "] calculateAuctionSavings...");

        try {
            oldestOfferPrice = auctionDao.getSavings(oldestOffer.getAuctionOfferId());
            winningOfferPrice = auctionDao.getSavings(winningOffer.getAuctionOfferId());
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
        }

        if(oldestOfferPrice == null) {
        	oldestOfferPrice = Double.valueOf(getZero());
        }
        
        if(winningOfferPrice == null) {
        	winningOfferPrice = Double.valueOf(getZero());
        }
        
        auctionSavings = oldestOfferPrice - winningOfferPrice;
        auction.setAuctionSavings(auctionSavings);

        try {
            auctionDao.updateAuction(auction);
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
        }

        log.debug("auctionSavings = " + auction.getAuctionSavings());
    }

    /**
     * The method calculates the number of agreement days for a given auction.
     * If it is NULL then set the value to zero.
     * 
     * @param auction
     *            - parameter passed from the list of finished auctions
     */
    private void calculateAgreementDays(Auction auction) {
        log.info("[auctionId " + auction.getAuctionId() + "] calculateAgreementDays...");
        Date start = auction.getBeginContractDate();
        Date end = auction.getEndContractDate();

        if (start != null && end != null) {
            daysBetween = RatingUtil.daysBetween(start, end);
        } else {
            log.info("beginContractDate " + start + " - endContractDate " + end);
            daysBetween = getZero();
        }
        agreementDays = Double.valueOf(daysBetween);
        log.debug("agreementDays = " + agreementDays);
    }

    /**
     * The method iterates through the map of winning offers and performs the
     * actions for a given winning offer
     * 
     * @param auction
     *            - parameter passed from the list of finished auctions
     */
    private void offersMapIterator(Auction auction) {
        String winningKey = getWinningPrefix() + auction.getAuctionId();
        log.debug("[auctionId " + auction.getAuctionId() + "] offersMap size: " + offersMap.values().size());

        for (String key : offersMap.keySet()) {
            if (key.equals(winningKey)) {
                AuctionOffer ao = offersMap.get(key);

                findConstPriceComponentValue(ao);
                findGreenEnergyPercent(ao);
                calculateSalesmanRating(ao);
                saveSalesmanRating(ao);
            }
        }
    }

    /**
     * The method finds the value of priceComponentValue ​​for the winning offer
     * for which boolean flag isConstant is TRUE. If it is NULL then set the
     * value to zero.
     * 
     * @param auctionOffer
     *            - parameter passed from the map of winning offers
     */
    private void findConstPriceComponentValue(AuctionOffer auctionOffer) {
        log.info("[auctionId " + auctionOffer.getAuction().getAuctionId() + "] findConstPriceComponentValue...");
        try {
            constPriceComponentValue = auctionDao.getConstPriceComponentValue(auctionOffer.getAuctionOfferId());
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
        }

        if (constPriceComponentValue == null) {
            constPriceComponentValue = Double.valueOf(getZero());
        }

        log.debug("constPriceComponentValue = " + constPriceComponentValue);
    }

    /**
     * The method finds the value of greenEnergyPercent for salesman who won a
     * given auction. If it is NULL then set the value to zero and update
     * salesman.
     * 
     * @param auctionOffer
     *            - parameter passed from the map of winning offers
     */
    private void findGreenEnergyPercent(AuctionOffer auctionOffer) {
        log.info("[auctionId " + auctionOffer.getAuction().getAuctionId() + "] findGreenEnergyPercent...");
        try {
            greenEnergyPercent = salesmanDao.getGreenEnergyBySalesmanId(auctionOffer.getSalesman().getSalesmanId());

            if (greenEnergyPercent == null) {
                salesman = auctionOffer.getSalesman();
                greenEnergyPercent = getZero();
                salesman.setGreenEnergyPercent(greenEnergyPercent);
                salesmanDao.updateSalesman(salesman);
            }

            greenEnergyShare = Double.valueOf(greenEnergyPercent);
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
        }
        log.debug("greenEnergyShare = " + greenEnergyShare);
    }

    /**
     * The method implements an algorithm to calculate the salesman's rating
     * 
     * @param auctionOffer
     *            - parameter passed from the map of winning offers
     */
    private void calculateSalesmanRating(AuctionOffer auctionOffer) {
        log.info("[auctionId " + auctionOffer.getAuction().getAuctionId() + "] calculateSalesmanRating...");
        Double addend1, addend2, addend3, addend4;

        addend1 = auctionOffer.getAuction().getAuctionSavings() * getSavingsWeight();
        addend2 = getAgreementDaysWeight() / agreementDays;
        addend3 = constPriceComponentValue * getFixedFeeWeight();
        addend4 = greenEnergyShare * getGreenEnergyWeight();

        salesmanRating = addend1 + addend2 + addend3 + addend4;
        salesmanRating *= getRatingWeight();

        log.debug("salesmanRating = " + salesmanRating);
    }

    /**
     * The method checks the salesman's rating and updates it. If the salesman's
     * rating is NULL save salesmanRating calculated by the method.
     * 
     * @param auctionOffer
     *            - parameter passed from the map of winning offers
     */
    private void saveSalesmanRating(AuctionOffer auctionOffer) {
        log.info("[auctionId " + auctionOffer.getAuction().getAuctionId() + "] saveSalesmanRating...");
        salesman = auctionOffer.getSalesman();
        Double currentRating = salesman.getRating();

        try {
            if (currentRating != null) {
                currentRating += salesmanRating;
                currentRating /= getHalfValueWeight();

                salesman.setRating(currentRating);
                salesmanDao.updateSalesman(salesman);
            } else {
                salesman.setRating(salesmanRating);
                salesmanDao.updateSalesman(salesman);
            }
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
        }

        log.debug("Salesman " + salesman.getSalesmanId() + " rating: " + salesman.getRating());
    }

    public Integer getZero() {
        return RatingUtil.ZERO_INIT;
    }

    public Double getHalfValueWeight() {
        return RatingUtil.HALF_VALUE_WEIGHT;
    }

    public Double getSavingsWeight() {
        return RatingUtil.SAVINGS_WEIGHT;
    }

    public Double getAgreementDaysWeight() {
        return RatingUtil.AGREEMENT_DAYS_WEIGHT;
    }

    public Double getFixedFeeWeight() {
        return RatingUtil.FIXED_FEE_WEIGHT;
    }

    public Double getGreenEnergyWeight() {
        return RatingUtil.GREEN_ENERGY_WEIGHT;
    }

    public Double getRatingWeight() {
        return RatingUtil.RATING_WEIGHT;
    }

    public String getWinningPrefix() {
        return RatingUtil.WINNING_PREFIX;
    }

    public Auction getAuction() {
        return auction;
    }

    public void setAuction(Auction auction) {
        this.auction = auction;
    }

    public AuctionOffer getOldestOffer() {
        return oldestOffer;
    }

    public void setOldestOffer(AuctionOffer oldestOffer) {
        this.oldestOffer = oldestOffer;
    }

    public AuctionOffer getWinningOffer() {
        return winningOffer;
    }

    public void setWinningOffer(AuctionOffer winningOffer) {
        this.winningOffer = winningOffer;
    }

    public Salesman getSalesman() {
        return salesman;
    }

    public void setSalesman(Salesman salesman) {
        this.salesman = salesman;
    }

    public List<Auction> getFinishedAuctions() {
        return finishedAuctions;
    }

    public void setFinishedAuctions(List<Auction> finishedAuctions) {
        this.finishedAuctions = finishedAuctions;
    }

    public Map<String, AuctionOffer> getOffersMap() {
        return offersMap;
    }

    public void setOffersMap(Map<String, AuctionOffer> offersMap) {
        this.offersMap = offersMap;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public long getDaysBetween() {
        return daysBetween;
    }

    public void setDaysBetween(long daysBetween) {
        this.daysBetween = daysBetween;
    }

    public Integer getSalesmanId() {
        return salesmanId;
    }

    public void setSalesmanId(Integer salesmanId) {
        this.salesmanId = salesmanId;
    }

    public Integer getGreenEnergyPercent() {
        return greenEnergyPercent;
    }

    public void setGreenEnergyPercent(Integer greenEnergyPercent) {
        this.greenEnergyPercent = greenEnergyPercent;
    }

    public Double getAuctionSavings() {
        return auctionSavings;
    }

    public void setAuctionSavings(Double auctionSavings) {
        this.auctionSavings = auctionSavings;
    }

    public Double getOldestOfferPrice() {
        return oldestOfferPrice;
    }

    public void setOldestOfferPrice(Double oldestOfferPrice) {
        this.oldestOfferPrice = oldestOfferPrice;
    }

    public Double getWinningOfferPrice() {
        return winningOfferPrice;
    }

    public void setWinningOfferPrice(Double winningOfferPrice) {
        this.winningOfferPrice = winningOfferPrice;
    }

    public Double getConstPriceComponentValue() {
        return constPriceComponentValue;
    }

    public void setConstPriceComponentValue(Double constPriceComponentValue) {
        this.constPriceComponentValue = constPriceComponentValue;
    }

    public Double getAgreementDays() {
        return agreementDays;
    }

    public void setAgreementDays(Double agreementDays) {
        this.agreementDays = agreementDays;
    }

    public Double getGreenEnergyShare() {
        return greenEnergyShare;
    }

    public void setGreenEnergyShare(Double greenEnergyShare) {
        this.greenEnergyShare = greenEnergyShare;
    }

    public Double getSalesmanRating() {
        return salesmanRating;
    }

    public void setSalesmanRating(Double salesmanRating) {
        this.salesmanRating = salesmanRating;
    }
}
