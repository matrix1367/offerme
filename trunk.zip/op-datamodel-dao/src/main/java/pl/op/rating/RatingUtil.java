package pl.op.rating;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class RatingUtil { 
	
	public enum DateUtilReturn {
		MINUTES, SECONDS, HOURS, DAYS
	};

	public static final String WINNING_PREFIX = "W";
	public static final Integer ZERO_INIT = 0;
	
	public static final Double HALF_VALUE_WEIGHT = 2.0;
	public static final Double SAVINGS_WEIGHT = 0.6;
	public static final Double AGREEMENT_DAYS_WEIGHT = 0.1;
	public static final Double FIXED_FEE_WEIGHT = 0.01;
	public static final Double GREEN_ENERGY_WEIGHT = 0.1;
	
	/** 
	 * According to the algorithm provided by the customer
	 * RATING_WEIGHT equals 10 divided by 2,59950684
	 */
	public static final Double RATING_WEIGHT = 3.846883511181682;

    /**
     * Calculates the number of days between start and end dates, taking into
     * consideration leap years, year boundaries etc.
     * 
     * @param start
     *            the start date
     * @param end
     *            the end date, must be later than the start date
     * @return the number of days between the start and end dates
     */
    public static long daysBetween(Date start, Date end) {
        return timeBetween(start, end, DateUtilReturn.DAYS);
    }

    public static long timeBetween(Date start, Date end, DateUtilReturn returnType) {
        if (end.before(start)) {
            throw new IllegalArgumentException("The end date must be later than the start date");
        }

        // reset all hours mins and secs to zero on start date
        Calendar startCal = GregorianCalendar.getInstance();
        startCal.setTime(start);
        if (returnType.equals(DateUtilReturn.DAYS)) {
            startCal.set(Calendar.HOUR_OF_DAY, 0);
            startCal.set(Calendar.MINUTE, 0);
            startCal.set(Calendar.SECOND, 0);
        }
        long startTime = startCal.getTimeInMillis();

        // reset all hours mins and secs to zero on end date
        Calendar endCal = GregorianCalendar.getInstance();
        endCal.setTime(end);
        if (returnType.equals(DateUtilReturn.DAYS)) {
            endCal.set(Calendar.HOUR_OF_DAY, 0);
            endCal.set(Calendar.MINUTE, 0);
            endCal.set(Calendar.SECOND, 0);
        }
        long endTime = endCal.getTimeInMillis();
        if (returnType.equals(DateUtilReturn.DAYS))
            return (endTime - startTime) / (1000 * 60 * 60 * 24);
        else if (returnType.equals(DateUtilReturn.HOURS))
            return (endTime - startTime) / (1000 * 60 * 60);
        else if (returnType.equals(DateUtilReturn.MINUTES))
            return (endTime - startTime) / (1000 * 60);
        else
            return (endTime - startTime) / 1000;
    }
}
