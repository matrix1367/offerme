package pl.op.module;

import org.mybatis.guice.XMLMyBatisModule;

public class ExternalModule extends XMLMyBatisModule {

	@Override
	protected void initialize() {
		// TODO Auto-generated method stub
		setClassPathResource("mybatis.external.xml");
	}

}
