package pl.op.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import pl.op.model.contract.Measure;
import pl.op.model.contract.MeasureFilter;

import com.google.inject.Inject;

public class MeasureDao implements Serializable {

	private static final long serialVersionUID = -1643409711153472771L;
	
	@Inject
	MeasureInterface measureInterface;

	public void saveMeasure(Measure measure) throws Exception{
		measureInterface.saveMeasure(measure);
	}
	
	public void removeMeasureByInvoiceId(Integer invoiceId) throws Exception{
		measureInterface.removeMeasureByInvoiceId(invoiceId);
	}

	public List<Measure> getMeasureByFilter(MeasureFilter measure) throws Exception {
		return measureInterface.getMeasureByFilter(measure);
	}
	
}