package pl.op.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import pl.op.model.dict.Address;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;

public interface CityInterface {

	public List<City> getCities(City city) throws Exception;
	public List<City> getCitiesByAreas(@Param("areas") List<Area> areas) throws Exception;
	public List<City> searchCities(City city) throws Exception;
	public List<City> getCitiesStarts(City city, @Param("cityStartsFrom") String cityStartsFrom) throws Exception;
	public List<City> getCitiesList() throws Exception;
	public City getCitiesById(Integer id) throws Exception;
	public List<City> getCitiesByName(String cityName) throws Exception;
	public City getCityByStreetId(Integer id) throws Exception;
	public Area getAreaByCityId(Integer id) throws Exception;
	public City getCityByAddress(Address address) throws Exception;
	public City getCity(City city) throws Exception;
	public City getCityBySymbol(String symbol) throws Exception;
	public void saveCity (City city) throws Exception;
	public void saveCityWithAreaId (@Param("city") City city,@Param("areaId") Integer areaId) throws Exception;
	public void deleteCity (City city) throws Exception;
	public void updateCity (City city) throws Exception;
}
