package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.auction.PriceComponent;
import pl.op.model.dict.Tariff;

import com.google.inject.Inject;

public class PriceComponentDao implements Serializable {

	private static final long serialVersionUID = 4121484575234668125L;

	@Inject
	PriceComponentInterface priceComponentInterface;
	
	public List<PriceComponent> getPriceComponent() throws Exception {
		return priceComponentInterface.getPriceComponent();
	}
	
	public List<PriceComponent> getPriceComponentByTariff(Tariff tariff) throws Exception {
		return priceComponentInterface.getPriceComponentByTariff(tariff);
	}
	
	public PriceComponent savePriceComponent(PriceComponent priceComponent) throws Exception {
		return priceComponentInterface.savePriceComponent(priceComponent);
	}
	
	public void updatePriceComponent(PriceComponent priceComponent) throws Exception {
		priceComponentInterface.updatePriceComponent(priceComponent);
	}
	
	public void deletePriceComponent(PriceComponent priceComponent) throws Exception {
		priceComponentInterface.deletePriceComponent(priceComponent);
	}
}
