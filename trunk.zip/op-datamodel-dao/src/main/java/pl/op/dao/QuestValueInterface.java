package pl.op.dao;

import pl.op.model.question.PreferenceQuestion;
import pl.op.model.question.QuestionValue;

public interface QuestValueInterface {
	public void saveQuestionValue(QuestionValue questionValue) throws Exception;

	public void updateQuestionValue(QuestionValue questionValue) throws Exception;

	public QuestionValue getQuestionValue(PreferenceQuestion preferenceQuestion) throws Exception;
}
