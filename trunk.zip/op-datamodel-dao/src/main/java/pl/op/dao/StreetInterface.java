package pl.op.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import pl.op.model.dict.Street;

public interface StreetInterface {

	public List<Street> getStreets(Street street) throws Exception;
	public List<Street> searchStreets(Street street) throws Exception;
	public List<Street> getStreetsList() throws Exception;
	public Street getStreet(Street street) throws Exception;
	public Street getStreetBySymbol(String symbol) throws Exception;
	public List<Street> getStreetsByName(String streetName) throws Exception;
	public void saveStreet(Street street) throws Exception;
	public void saveStreetWithCityId (@Param("street") Street street,@Param("cityId") Integer cityId) throws Exception;
	public void updateStreet(Street street) throws Exception;
	public void deleteStreet(Street street) throws Exception;
}
