package pl.op.dao;

import java.util.List;

import pl.op.model.device.DeviceCategory;
import pl.op.model.device.DeviceType;


public interface DeviceTypeInterface {
	public List<DeviceType> getDeviceTypesByCategory(Integer categoryId) throws Exception;
	public DeviceType getDevicesTypeByDeviceCategoryId(Integer id) throws Exception;
	public DeviceCategory getDevicesCategoryByDeviceTypesId(Integer id) throws Exception;
	public List<DeviceType> getDeviceTypes() throws Exception;
	public DeviceType getDeviceTypeById(Integer deviceTypeById) throws Exception;
	public void saveDeviceType(DeviceType deviceType) throws Exception;
	public void updateDeviceType(DeviceType deviceType) throws Exception;
	public void deleteDeviceType(DeviceType deviceType) throws Exception;
}
