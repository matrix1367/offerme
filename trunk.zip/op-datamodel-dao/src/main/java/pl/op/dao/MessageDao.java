package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import com.google.inject.Inject;

import pl.op.model.msg.Message;
import pl.op.model.msg.UserToMessage;

public class MessageDao implements Serializable {

	@Inject
	MessageInterface messageInterface;

	private static final long serialVersionUID = 6458686783208103971L;
	
	public UserToMessage getUserToMessage(UserToMessage userToMessage) throws Exception {
		return messageInterface.getUserToMessage(userToMessage);
	}

	public Integer unreadMessagesCounter(Integer userId) throws Exception {
		return messageInterface.unreadMessagesCounter(userId);
	}

	public List<Message> getMessageList(Message message) throws Exception {
		return messageInterface.getMessageList(message);
	}

	public List<Message> getInboxMessageList(Message message, Integer userId)
			throws Exception {
		return messageInterface.getInboxMessageList(message, userId);
	}

	public List<Message> getOutboxMessageList(Message message, Integer userId)
			throws Exception {
		return messageInterface.getOutboxMessageList(message, userId);
	}

	public void newMessage(Message message, Integer messageSenderId)
			throws Exception {
		messageInterface.newMessage(message);
	}

	public void assignMessageSenderToUsers(Integer senderId, Integer messageId)
			throws Exception {
		messageInterface.assignMessagesSenderToUsers(senderId, messageId);
	}

	public void assignMessagesToUsers(Integer receiverId, Integer messageId)
			throws Exception {
		messageInterface.assignMessagesToUsers(receiverId, messageId);
	}

	public void deleteInboxMessage(Message message, Integer userId)
			throws Exception {
		messageInterface.deleteInboxMessage(message, userId);
	}

	public void deleteOutboxMessage(Message message, Integer userId)
			throws Exception {
		messageInterface.deleteOutboxMessage(message, userId);
	}

	public void markFavorite(Message message, Integer userId) throws Exception {
		messageInterface.markFavorite(message, userId);
	}

	public void markAsRead(Message message, Integer userId) throws Exception {
		messageInterface.markAsRead(message, userId);
	}

	public void markAsUnread(Message message, Integer userId) throws Exception {
		messageInterface.markAsUnread(message, userId);
	}
}
