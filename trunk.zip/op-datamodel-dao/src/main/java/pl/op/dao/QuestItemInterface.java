package pl.op.dao;

import java.util.List;

import pl.op.model.question.PreferenceQuestion;
import pl.op.model.question.QuestionItem;

public interface QuestItemInterface {
	public void saveQuestionItem(QuestionItem questionItem) throws Exception;

	public void updateQuestionItem(QuestionItem questionItem) throws Exception;

	public void deleteQuestionItem(QuestionItem questionItem) throws Exception;
}
