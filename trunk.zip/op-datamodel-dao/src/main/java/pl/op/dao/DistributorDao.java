package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.dict.Distributor;

import com.google.inject.Inject;

public class DistributorDao implements Serializable {

	private static final long serialVersionUID = 1025108011703756933L;

	@Inject DistributorInterface distributorInterface;
	
	public List<Distributor> getDistributors() throws Exception {
		return distributorInterface.getDistributors();
	}

	public Distributor getDistributorById(Integer id) throws Exception {
		return distributorInterface.getDistributorById(id);
	}
	
	public Distributor getDistributorByName(String name) throws Exception {
		return distributorInterface.getDistributorByName(name);
	}

	public void saveDistributor(Distributor distributor) throws Exception {
		distributorInterface.saveDistributor(distributor);
	}

	public void deleteDistributor(Distributor distributor) throws Exception {
		distributorInterface.deleteDistributor(distributor);
	}

	public void updateDistributor(Distributor distributor) throws Exception {
		distributorInterface.updateDistributor(distributor);
	}
}
