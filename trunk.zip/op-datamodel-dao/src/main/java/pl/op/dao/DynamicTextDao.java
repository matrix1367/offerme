package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import com.google.inject.Inject;

import pl.op.dynamicText.DynamicText;

public class DynamicTextDao implements Serializable {

	private static final long serialVersionUID = -2935167916617405712L;

	@Inject
	DynamicTextInterface dynamicTextInterface;

	public List<DynamicText> getDynamicTextList(DynamicText dynamicText) throws Exception {
		return dynamicTextInterface.getDynamicTextList(dynamicText);
	}

	public void updateDynamicText(DynamicText dynamicText) throws Exception {
		dynamicTextInterface.updateDynamicText(dynamicText);
	}
	
	public DynamicText getDynamicTextByType(String type) throws Exception {
		return dynamicTextInterface.getDynamicTextByType(type);
	}
	
	public void saveDynamicText(DynamicText setting) throws Exception {
		dynamicTextInterface.saveDynamicText(setting);
	}
}
