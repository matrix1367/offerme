package pl.op.dao;

import java.util.List;

import pl.op.model.stereotype.Sector;
import pl.op.model.user.UserApp;

public interface SectorInterface {
	
	public List<Sector> getSector() throws Exception;
	public List<Sector> getSector(Sector sector) throws Exception;
	public void saveSector(Sector sector) throws Exception;
	public void updateSector(Sector sector) throws Exception;
	public void deleteSector(Sector sector) throws Exception;
	public Sector getSectorByUser(UserApp user)throws Exception;
}
