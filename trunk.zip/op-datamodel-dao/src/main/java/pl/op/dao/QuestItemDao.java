package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.question.PreferenceQuestion;
import pl.op.model.question.QuestionItem;

import com.google.inject.Inject;

public class QuestItemDao implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2879377651328831813L;

	@Inject
	QuestItemInterface questItemInterface;
	
	public void saveQuestionItem(QuestionItem questionItem) throws Exception{
		questItemInterface.saveQuestionItem(questionItem);
	}	
	
	public void updateQuestionItem(QuestionItem questionItem) throws Exception{
		questItemInterface.updateQuestionItem(questionItem);
	}
	
	public void deleteQuestionIten(QuestionItem questionItem) throws Exception{
		questItemInterface.deleteQuestionItem(questionItem);
	}
}

