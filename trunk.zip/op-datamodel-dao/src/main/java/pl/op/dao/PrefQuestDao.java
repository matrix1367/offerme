package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.question.PreferenceQuestion;

import com.google.inject.Inject;

public class PrefQuestDao implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2879377651328831813L;

	@Inject
	PrefQuestInterface prefQuestInterface;

	public List<PreferenceQuestion> getPreferenceQuestionList(
			PreferenceQuestion preferenceQuestion) throws Exception {
		return prefQuestInterface.getPreferenceQuestionList(preferenceQuestion);
	}

	public void savePreferenceQuestion(PreferenceQuestion preferenceQuestion)
			throws Exception {
		prefQuestInterface.savePreferenceQuestion(preferenceQuestion);
	}

	public void updatePreferenceQuestion(PreferenceQuestion preferenceQuestion)
			throws Exception {
		prefQuestInterface.updatePreferenceQuestion(preferenceQuestion);
	}

	public void deletePreferenceQuestion(PreferenceQuestion preferenceQuestion)
			throws Exception {
		prefQuestInterface.deletePreferenceQuestion(preferenceQuestion);
	}

	public PreferenceQuestion getPreference(
			PreferenceQuestion preferenceQuestion) throws Exception {
		return prefQuestInterface.getPreference(preferenceQuestion);
	}
}
