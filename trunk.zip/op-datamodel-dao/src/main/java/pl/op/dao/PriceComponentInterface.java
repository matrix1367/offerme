package pl.op.dao;

import java.util.List;

import pl.op.model.auction.PriceComponent;
import pl.op.model.dict.Tariff;

public interface PriceComponentInterface {

	public List<PriceComponent> getPriceComponent() throws Exception;
	public List<PriceComponent> getPriceComponentByTariff(Tariff tariff) throws Exception;
	public PriceComponent savePriceComponent(PriceComponent priceComponent) throws Exception;
	public void updatePriceComponent(PriceComponent priceComponent) throws Exception;
	public void deletePriceComponent(PriceComponent priceComponent) throws Exception;
}
