package pl.op.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import pl.op.model.dict.Area;

public interface AreaInterface {

	public List<Area> getAreas(Area area) throws Exception;

	public List<Area> getAreasByPage(Area area,
			@Param("pageSize") Integer pageSize, @Param("first") Integer first)
			throws Exception;

	public Area getAreaById(Integer id) throws Exception;

	public Area getAreaByName(String areaName) throws Exception;
	
	public List<Area> getAreasByName(String areaName) throws Exception;

	public Area getAreaBySymbol(String areaSymbol) throws Exception;
	
	public Area getAreaByCityId(Integer cityId) throws Exception;

	public void saveArea(Area area) throws Exception;

	public void updateArea(Area area) throws Exception;

	public void deleteArea(Area area) throws Exception;
}
