package pl.op.dao;

import java.util.List;

import pl.op.model.contract.Agreement;

public interface AgreementInterface {
	public void saveAgreement(Agreement agreement) throws Exception;

	public void saveAgreementPPE(Agreement agreement) throws Exception;

	public Agreement getLastAgreementByPpeId(Integer id) throws Exception;

	public List<Agreement> getAgreements(Agreement agreement) throws Exception;

	public void updateAgreement(Agreement agreement) throws Exception;
}
