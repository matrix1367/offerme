package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.msg.MessageAttachment;

import com.google.inject.Inject;

public class MessageAttachmentDao implements Serializable {

	@Inject
	MessageAttachmentInterface messageAttachmentInterface;

	private static final long serialVersionUID = -2635236983697342682L;

	public List<MessageAttachment> getAttachmentsList(
			List<MessageAttachment> messageAttachment) throws Exception {
		return messageAttachmentInterface.getAttachmentsList(messageAttachment);
	}

	public MessageAttachment getSelectedAttachment(Integer messageAttachmentId) throws Exception {
		return messageAttachmentInterface.getSelectedAttachment(messageAttachmentId);
	}
	
	public void newAttachment(MessageAttachment messageAttachment)
			throws Exception {
		messageAttachmentInterface.newAttachment(messageAttachment);
	}

}
