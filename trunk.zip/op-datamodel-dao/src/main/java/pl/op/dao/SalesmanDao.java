package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.dict.Address;
import pl.op.model.salesman.Salesman;

import com.google.inject.Inject;

public class SalesmanDao implements Serializable {

	private static final long serialVersionUID = -1643409711153472771L;

	@Inject
	SalesmanInterface salesmanInterface;

	public void saveSalesman(Salesman salesman) throws Exception {
		salesmanInterface.saveSalesman(salesman);
	}

	public void deleteSalesman(Salesman salesman) throws Exception {
		salesmanInterface.deleteSalesman(salesman);
	}

	public void updateSalesman(Salesman salesman) throws Exception {
		salesmanInterface.updateSalesman(salesman);
	}

	public List<Salesman> getSalesmans(Salesman salesman) throws Exception {
		return salesmanInterface.getSalesmans(salesman);
	}
	
	public Salesman getSalesmanById(Integer salesmanId) throws Exception{
		return salesmanInterface.getSalesmanById(salesmanId);
	}
	
	public Salesman getSalesmanByUserId(Integer userId) throws Exception {
		return salesmanInterface.getSalesmanByUserId(userId);
	}
	
	public List<Salesman> getAllSalesmans() throws Exception{
		return salesmanInterface.getAllSalesmans();
	}

	public Salesman getSalesmanByName(String name) throws Exception{
		return salesmanInterface.getSalesmanByName(name);
	}
	
	public void saveAddress(Address address) throws Exception {
		salesmanInterface.saveAddress(address);
	}
	
	public void updateAddress(Address address) throws Exception {
		salesmanInterface.updateAddress(address);
	}
	
	public Integer getGreenEnergyBySalesmanId(Integer salesmanId) throws Exception {
		return salesmanInterface.getGreenEnergyBySalesmanId(salesmanId);
	}
	
}