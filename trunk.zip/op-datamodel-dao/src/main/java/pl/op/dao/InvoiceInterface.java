package pl.op.dao;

import java.util.List;

import pl.op.model.auction.PriceComponent;
import pl.op.model.contract.Invoice;
import pl.op.model.contract.InvoicePriceComponentValue;
import pl.op.model.contract.PPE;

public interface InvoiceInterface {
    public void saveInvoice(Invoice invoice) throws Exception;

    public void updateInvoice(Invoice invoice) throws Exception;

    public List<PriceComponent> getPPEPriceComponents(PPE ppe) throws Exception;

    public void removeInvoicePriceComponentValues(Invoice invoice) throws Exception;

    public void savePriceComponentValue(InvoicePriceComponentValue priceValue) throws Exception;

    public void updateInvoicePriceComponentValue(InvoicePriceComponentValue priceValue) throws Exception;

    public void removeInvoice(Invoice invoice) throws Exception;

    public List<Invoice> getLastInvoiceByPpeId(Integer id) throws Exception;

    public List<Invoice> getInvoicesByPpeId(Integer id) throws Exception;

    public List<Invoice> searchInvoices(Invoice invoice) throws Exception;
}
