package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.stereotype.Sector;
import pl.op.model.stereotype.Stereotype;
import pl.op.model.stereotype.StereotypePPEReport;

import com.google.inject.Inject;

public class StereotypeDao implements Serializable {

	private static final long serialVersionUID = -1643409711153472771L;
	
	@Inject
	StereotypeInterface stereotypeInterface;

	public List<Stereotype> getStereotypes(Sector sector) throws Exception {
		return stereotypeInterface.getStereotypes(sector);
	}

	public Stereotype getStereotypeById(Integer id) throws Exception {
		return stereotypeInterface.getStereotypeById(id);
	}
	
	public void saveStereotype(Stereotype stereotype) throws Exception{
		 stereotypeInterface.saveStereotype(stereotype);
	}
	
	public void updateStereotype(Stereotype stereotype) throws Exception{
		stereotypeInterface.updateStereotype(stereotype);
	}
	
	public Stereotype getStereotypeByImageName(String iconPath) throws Exception {
		return stereotypeInterface.getStereotypeByImageName(iconPath);
	}
	
	public Sector getSectorByStereotypeId(Integer stereotypeId) throws Exception{
		return stereotypeInterface.getSectorByStereotypeId(stereotypeId);
	}
	
	public List<Sector> getSectors(Sector sector) throws Exception{
		return stereotypeInterface.getSectors(sector);
	}
	
	public Stereotype getStereotypeBySector(Sector sector) throws Exception{
		return stereotypeInterface.getStereotypeBySector(sector);
	}
	
	public Stereotype getStereotypeBySectorId(Integer id) throws Exception{
		return stereotypeInterface.getStereotypeBySectorId(id);
	}
	
	public List<StereotypePPEReport> getStereotypePPEReport() throws Exception{
		return stereotypeInterface.getStereotypePPEReport();
	}
	
}