package pl.op.dao;

import java.util.List;

import pl.op.model.device.DeviceCategory;


public interface DeviceCategoryInterface {
	public List<DeviceCategory> getDeviceCategories() throws Exception;
	public DeviceCategory getDevicesCategoriesByDeviceTypeId(Integer id) throws Exception;
	public DeviceCategory getDevicesCategoriesById (Integer id) throws Exception;
	public void saveDeviceCategory(DeviceCategory deviceCategory) throws Exception;
	public void updateDeviceCategory(DeviceCategory deviceCategory) throws Exception;
	public void deleteDeviceCategory(DeviceCategory deviceCategory) throws Exception;
}
