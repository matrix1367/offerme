package pl.op.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import pl.op.model.dict.MessageRecommendations;

public interface MessageRecommendationsInterface {

	public List<MessageRecommendations> getMessageRecommendations() throws Exception;

	public List<MessageRecommendations> getMessageRecommendationsAllByNull(
			Boolean isConstant) throws Exception;

	public List<MessageRecommendations> getMessageRecommendationsAllByDeviceTypeId(
			@Param("dtId") Integer deviceTypeId,
			@Param("constant") Boolean isConstant) throws Exception;

	public List<MessageRecommendations> getMessageRecommendationsAllByTariffId(
			@Param("tId") Integer tariffId,
			@Param("constant") Boolean isConstant) throws Exception;

	public List<MessageRecommendations> getMessageRecommendationsAllByDeviceTypeIdAndTariffId(
			@Param("dtId") Integer deviceTypeId,
			@Param("tId") Integer tariffId,
			@Param("constant") Boolean isConstant) throws Exception;

	public MessageRecommendations getMessageRecommendationsById(Integer id)
			throws Exception;

	public void saveMessageRecommendations(
			MessageRecommendations messageRecommendations) throws Exception;

	public void deleteMessageRecommendations(
			MessageRecommendations messageRecommendations) throws Exception;

	public void updateMessageRecommendations(
			MessageRecommendations messageRecommendations) throws Exception;

}
