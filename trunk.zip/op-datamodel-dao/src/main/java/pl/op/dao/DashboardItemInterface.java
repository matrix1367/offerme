package pl.op.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import pl.op.model.dashboard.DashboardItem;
import pl.op.model.dashboard.DashboardItemUser;
import pl.op.model.user.UserApp;

public interface DashboardItemInterface {

	public List<DashboardItem> getDashboardItems() throws Exception;

	public List<DashboardItem> getActiveDashboardItems() throws Exception;

	public List<DashboardItem> getUserActiveDashboardItems() throws Exception;

	public List<DashboardItem> getUserDashboardItems(UserApp user)
			throws Exception;
	
	public List<DashboardItemUser> getDashboardItemUsersByUserId(Integer userId) throws Exception;

	public DashboardItem getDashboardItemById(Integer id) throws Exception;

	public Integer saveDashboardItemUser(
			@Param("dashboardItemId") Integer dashboardItemId,
			@Param("userId") Integer userId,
			@Param("isDashboardItemUserActive") Boolean isDashboardItemUserActive) throws Exception;
	
	public Integer updateDashboardItemUser(
			@Param("dashboardItemId") Integer dashboardItemId,
			@Param("userId") Integer userId,
			@Param("isDashboardItemUserActive") Boolean isDashboardItemUserActive) throws Exception;

	public void saveDashboardItem(DashboardItem dashboardItem) throws Exception;

	public void updateDashboardItem(DashboardItem dashboardItem)
			throws Exception;

	public void deleteDashboardItem(DashboardItem dashboardItem)
			throws Exception;

}
