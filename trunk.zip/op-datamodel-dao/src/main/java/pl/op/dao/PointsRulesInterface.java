package pl.op.dao;

import java.util.List;

import pl.op.model.bonus.Event;
import pl.op.model.bonus.PointsRules;
import pl.op.model.user.UserApp;

public interface PointsRulesInterface {

	public List<PointsRules> getPointsRules() throws Exception;
	public List<PointsRules> getPointsRulesByEvent(Event event) throws Exception;
	public List<PointsRules> getPointsRulesByEventActive(Event event) throws Exception;
	public List<PointsRules> getPointsRulesActive() throws Exception;
	public List<PointsRules> getBonusRules() throws Exception;
	public List<PointsRules> getBonusRulesByUser(UserApp userApp) throws Exception;
	public List<PointsRules> getBonusRulesActive() throws Exception;
	public List<PointsRules> getBonusRulesActiveAndAccepted() throws Exception;
	public List<PointsRules> getBonusRulesOnlyUsers(Boolean isActive) throws Exception;
	public PointsRules getPointsRulesById(Integer id) throws Exception;
	public void savePointsRules(PointsRules userPoints) throws Exception;
	public void deletePointsRules(PointsRules userPoints) throws Exception;
	public void updatePointsRules(PointsRules userPoints) throws Exception;
}
