package pl.op.dao;

import java.io.Serializable;

import pl.op.model.profile.ProfileIndicator;
import pl.op.model.profile.ProfileIndicatorFilter;
import pl.op.model.profile.ProfileValue;

import com.google.inject.Inject;

public class ProfileDao implements Serializable {

	private static final long serialVersionUID = -1643409711153472771L;
	
	@Inject
	ProfileInterface profileInterface;

	public void saveProfileIndicator(ProfileIndicator profileIndicator) throws Exception{
		profileInterface.saveProfileIndicator(profileIndicator);
	}
	
	public void updateProfileIndicator(ProfileIndicator profileIndicator) throws Exception{
		profileInterface.updateProfileIndicator(profileIndicator);
	}
	
	
	public void saveProfileValue(ProfileValue profileValue) throws Exception{
		profileInterface.saveProfileValue(profileValue);
	}
	
	public Double getSumValueByFilter(ProfileIndicatorFilter filter) throws Exception {
		return profileInterface.getSumValueByFilter(filter);
	}
	
	public void deleteProfileIndicatorToTariff(Integer tariffId) throws Exception {
		profileInterface.deleteProfileIndicatorToTariff(tariffId);
	}
	
	public void deleteProfileValueToTariff(Integer tariffId) throws Exception {
		profileInterface.deleteProfileValueToTariff(tariffId);
	}
}