package pl.op.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import pl.op.model.auction.Auction;
import pl.op.model.cloud.Cloud;
import pl.op.model.cloud.CloudFilter;
import pl.op.model.contract.PPE;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Street;
import pl.op.model.user.UserApp;

public interface CloudInterface {
    public List<Cloud> getClouds(CloudFilter cloudFilter) throws Exception;
    
    public List<Cloud> getCloudsForCreator(CloudFilter cloudFilter) throws Exception;    

    public List<String> getStreetsByCity(String city) throws Exception;

    public Integer getCloudsCount() throws Exception;

    public void saveCloud(Cloud cloud) throws Exception;

    public void saveUserCloud(UserApp user) throws Exception;

    public void saveCloudArea(Area area) throws Exception;

    public void saveCloudCity(City city) throws Exception;

    public void saveCloudStreet(Street street) throws Exception;

    public void updateCloudMemberNo(Cloud cloud) throws Exception;

    public Integer getPPECount(Cloud cloud) throws Exception;

    public List<PPE> getPpeByCloudId(Cloud cloud) throws Exception;
    
    public List<PPE> getPpeByCloudIdNoStereotype(Cloud cloud) throws Exception;

    public void updateCloud(Cloud cloud) throws Exception;

    public Integer getCloudsCount(CloudFilter cloudFilter) throws Exception;

    public List<UserApp> getCloudPotentialUsers(Cloud cloud) throws Exception;

    public void deleteCloudUsers(Cloud cloud) throws Exception;

    public void deleteCloudUsersBatch(@Param("cloud") Cloud cloud, @Param("list") List<UserApp> list) throws Exception;

    public List<UserApp> getUsersForCloud(Cloud cloud) throws Exception;

    public Integer getAuctionOffersForAuctionsCount(Auction auction) throws Exception;

    public void updateCloudVolume(Cloud cloud) throws Exception;

    public List<Cloud> getCloudsByPpeId(Integer ppeId) throws Exception;
}
