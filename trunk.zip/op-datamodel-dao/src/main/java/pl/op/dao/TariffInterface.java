package pl.op.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import pl.op.model.dict.PPETariff;
import pl.op.model.dict.Tariff;

public interface TariffInterface {

	public List<Tariff> getTariffs(Tariff tariff) throws Exception;

	public Tariff getTariffById(Integer id) throws Exception;

	public void saveTariff(Tariff tariff) throws Exception;

	public void saveTariffPriceComponent(@Param("tariffId") Integer tariffId,
			@Param("priceComponentList") List<Integer> priceComponentsIdList)
			throws Exception;
	
	public void deleteTariffPriceComponent(@Param("tariffId") Integer tariffId,
			@Param("selectedPriceComponentList") List<Integer> selectedPriceComponentsIdList)
			throws Exception;
	
	public void updateTariff(Tariff tariff) throws Exception;

	public void deleteTariff(Tariff tariff) throws Exception;

	public void savePPETariff(PPETariff ppeTariff) throws Exception;

	public void updatePPETariff(PPETariff ppeTariff) throws Exception;
}
