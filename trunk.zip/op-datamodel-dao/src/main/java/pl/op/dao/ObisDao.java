package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.dict.Obis;

import com.google.inject.Inject;

public class ObisDao implements Serializable {

	private static final long serialVersionUID = -8430630204152209740L;

	@Inject
	ObisInterface obisInterface;
	
	public List<Obis> getObisList() throws Exception {
		return obisInterface.getObisList();
	}
	
	public Obis getObieById (Integer id) throws Exception {
		return obisInterface.getObisById(id);
	}
	
	public void saveObis(Obis obis) throws Exception {
		obisInterface.saveObis(obis);
	}
	
	public void deleteObis(Obis obis) throws Exception {
		obisInterface.deleteObis(obis);
	}
	
	public void updateObis(Obis obis) throws Exception {
		obisInterface.updateObis(obis);
	}
}
