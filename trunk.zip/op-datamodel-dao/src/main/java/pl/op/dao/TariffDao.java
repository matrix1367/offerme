package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.dict.PPETariff;
import pl.op.model.dict.Tariff;

import com.google.inject.Inject;

public class TariffDao implements Serializable {

	private static final long serialVersionUID = 3377967205173864114L;

	@Inject
	TariffInterface tariffInterface;

	public List<Tariff> getTariffs(Tariff tariff) throws Exception {
		return tariffInterface.getTariffs(tariff);
	}

	public Tariff getTariffById(Integer id) throws Exception {
		return tariffInterface.getTariffById(id);
	}

	public void saveTariff(Tariff tariff, List<Integer> priceComponentsIdList) throws Exception {
		tariffInterface.saveTariff(tariff);
		tariffInterface.saveTariffPriceComponent(tariff.getTariffId(), priceComponentsIdList);
	}

	public void deleteTariff(Tariff tariff) throws Exception {
		tariffInterface.deleteTariff(tariff);
	}

	public void updateTariff(Tariff tariff, List<Integer> priceComponentsIdList, List<Integer> selectedPriceComponentsIdList) throws Exception {
		tariffInterface.updateTariff(tariff);
		tariffInterface.deleteTariffPriceComponent(tariff.getTariffId(), selectedPriceComponentsIdList);
		tariffInterface.saveTariffPriceComponent(tariff.getTariffId(), priceComponentsIdList);
	}

	public void savePPETariff(PPETariff ppeTariff) throws Exception {
		tariffInterface.savePPETariff(ppeTariff);
	}

	public void updatePPETariff(PPETariff ppeTariff) throws Exception {
		tariffInterface.updatePPETariff(ppeTariff);
	}

}
