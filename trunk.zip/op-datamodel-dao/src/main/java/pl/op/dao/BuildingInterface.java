package pl.op.dao;

import pl.op.model.stereotype.Building;


public interface BuildingInterface {
	public void saveBuilding(Building building) throws Exception;

	public void updateBuilding(Building building) throws Exception;
}
