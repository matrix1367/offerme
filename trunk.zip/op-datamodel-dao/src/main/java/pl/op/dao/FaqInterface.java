package pl.op.dao;

import java.util.List;

import pl.op.model.faq.Faq;

public interface FaqInterface {

	public List<Faq> showFaq() throws Exception;
	public List<Faq> getFaq() throws Exception;
	public List<Faq> getFaqByQuestionType(String type) throws Exception;
	public Faq getFaqByMessageId(Integer messageId) throws Exception;
	public void newFaqFromUser(Faq faq) throws Exception;
	public void newFaq(Faq faq) throws Exception;
	public void updateFaq(Faq faq) throws Exception;
	public void deleteFaq(Faq faq) throws Exception;

}
