package pl.op.dao;

import java.util.List;

import pl.op.model.dict.Distributor;

public interface DistributorInterface {

	public List<Distributor> getDistributors() throws Exception;
	public Distributor getDistributorById(Integer id) throws Exception;
	public Distributor getDistributorByName(String name) throws Exception;
	public void saveDistributor(Distributor distributor) throws Exception;
	public void deleteDistributor (Distributor distributor) throws Exception;
	public void updateDistributor (Distributor distributor) throws Exception;
}
