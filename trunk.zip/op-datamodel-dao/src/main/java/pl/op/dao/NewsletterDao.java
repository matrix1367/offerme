package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.newsletter.Newsletter;

import com.google.inject.Inject;

public class NewsletterDao implements Serializable {

	private static final long serialVersionUID = -3963171589883460036L;

	@Inject
	NewsletterInterface newsletterInterface;

	public List<Newsletter> getNewsletters(Newsletter newsletter) throws Exception {
		return newsletterInterface.getNewsletters(newsletter);
	}
        
        public List<Newsletter> getMailing() throws Exception {
            return newsletterInterface.getMailing();
        }

	public void saveNewsletter(Newsletter newsletter) throws Exception {
		newsletterInterface.saveNewsletter(newsletter);
	}
}
