package pl.op.dao;

import java.util.List;

import pl.op.model.bonus.Event;

public interface EventInterface {

	public List<Event> getEvents() throws Exception;
	public Event getEventById(Integer id) throws Exception;
	public Event getEventByCodeName(String codeName) throws Exception;
	public void saveEvent(Event event) throws Exception;
	public void deleteEvent(Event event) throws Exception;
	public void updateEvent(Event event) throws Exception;
}
