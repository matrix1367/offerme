package pl.op.dao;

import java.io.Serializable;
import java.util.*;

import pl.op.model.cloud.Cloud;
import pl.op.model.salesman.Salesman;
import pl.op.model.user.UserApp;

import com.google.inject.Inject;

public class UserDao implements Serializable {

	private static final long serialVersionUID = -6341311714599204137L;

	@Inject
	UserInterface userInterface;

	public List<Integer> getOperatorsIdList(List<Integer> integer) throws Exception {
		return userInterface.getOperatorsIdList(integer);
	}

	public void setUserInterface(UserInterface userInterface) {
		this.userInterface = userInterface;
	}

	public void updatePassword(UserApp user) throws Exception {
		userInterface.updatePassword(user);
	}

	public void saveUser(UserApp user) throws Exception {
		userInterface.saveUser(user);
	}

	public void deleteUser(UserApp user) throws Exception {
		userInterface.deleteUser(user);
	}

	public void updateActivationCode(UserApp userApp) throws Exception {
		userInterface.updateActivationCode(userApp);
	}

	public void updateUser(UserApp user) throws Exception {
		userInterface.updateUser(user);
	}

	public Boolean checkLocalUserExist(String login) throws Exception {

		boolean exist = false;

		UserApp userApps = userInterface.getUserByLogin(login);

		if (userApps != null) {
			exist = true;
		}

		return exist;
	}

	public Boolean checkLocalScreenNameExist(String screenName) {

		boolean exist = false;

		UserApp userApps = userInterface.getUserByScreenName(screenName);

		if (userApps != null) {
			exist = true;
		}

		return exist;
	}

	public UserApp getUserByLogin(String login) throws Exception {

		UserApp user = userInterface.getUserByLogin(login);

		return user;
	}
        
        public UserApp getUserByPPE(Integer idPPE) throws Exception {
            UserApp user = userInterface.getUserByPPE(idPPE);
            return user;
        }
	
	public List<UserApp> filterUsers(UserApp userApp) throws Exception {
		return userInterface.filterUsers(userApp);
	}

	public List<UserApp> getUsers(UserApp userApp) throws Exception {
		return userInterface.getUsers(userApp);
	}
	
	public List<UserApp> getUsersList() throws Exception {
		return userInterface.getUsersList();
	}

	public List<UserApp> getUsersByRoleNoAdminAndOperator() throws Exception {
		return userInterface.getUsersByRoleNoAdminAndOperator();
	}

	public UserApp getUserAppbyId(Integer userId) throws Exception {
		return userInterface.getUserAppbyId(userId);
	}

	public List<UserApp> getAllUserApp(UserApp userApp) throws Exception {
		return userInterface.getAllUserApp(userApp);
	}

	public List<UserApp> getOrderCreators() throws Exception {
		return userInterface.getOrderCreators();
	}

	public List<UserApp> getOperators() throws Exception {
		return userInterface.getOperators();
	}

	public Boolean checkPinExist(UserApp userApp) throws Exception {
		boolean exist = false;

		List<UserApp> userApps = userInterface.getPinForOperators(userApp);

		if (userApps != null) {
			if (userApps.size() > 0) {
				exist = true;
			}
		}

		return exist;
	}

	public List<UserApp> getUsersBySalesman(Salesman salesman) throws Exception {
		return userInterface.getUsersBySalesman(salesman);
	}

	public List<UserApp> getUsersMatchToCloud(Cloud cloud) throws Exception {
		return userInterface.getUsersMatchToCloud(cloud);
	}
}