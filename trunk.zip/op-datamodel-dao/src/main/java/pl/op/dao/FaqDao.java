package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.faq.Faq;

import com.google.inject.Inject;

public class FaqDao implements Serializable {

	private static final long serialVersionUID = -3929263285569399494L;

	@Inject
	FaqInterface faqInterface;

	public List<Faq> showFaq() throws Exception {
		return faqInterface.showFaq();
	}

	public List<Faq> getFaqByQuestionType(String type) throws Exception {
		return faqInterface.getFaqByQuestionType(type);
	}

	public Faq getFaqByMessageId(Integer messageId) throws Exception {
		return faqInterface.getFaqByMessageId(messageId);
	}

	public List<Faq> getFaq() throws Exception {
		return faqInterface.getFaq();
	}

	public void newFaq(Faq faq) throws Exception {
		faqInterface.newFaq(faq);
	}

	public void updateFaq(Faq faq) throws Exception {
		faqInterface.updateFaq(faq);
	}

	public void deleteFaq(Faq faq) throws Exception {
		faqInterface.deleteFaq(faq);
	}
}
