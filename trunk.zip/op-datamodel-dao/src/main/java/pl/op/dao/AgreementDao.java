package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.contract.Agreement;

import com.google.inject.Inject;

public class AgreementDao implements Serializable {

	private static final long serialVersionUID = -1643409711153472771L;
	
	@Inject
	AgreementInterface agreementInterface;

	public void saveAgreement(Agreement agreement) throws Exception {
		agreementInterface.saveAgreement(agreement);
	}
	
	public void updateAgreement(Agreement agreement) throws Exception {
		agreementInterface.updateAgreement(agreement);
	}
	
	public void saveAgreementPPE(Agreement agreement) throws Exception {
		agreementInterface.saveAgreementPPE(agreement);		
	}

	public Agreement getLastAgreementByPpeId(Integer id) throws Exception {
		return agreementInterface.getLastAgreementByPpeId(id);
	}
	public List<Agreement> getAgreements(Agreement agreement) throws Exception {
		return agreementInterface.getAgreements(agreement);
	}
	

}