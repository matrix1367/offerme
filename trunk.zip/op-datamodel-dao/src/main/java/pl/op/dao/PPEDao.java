package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.cloud.Cloud;
import pl.op.model.contract.PPE;
import pl.op.model.contract.PPEFilter;
import pl.op.model.contract.PPEStatus;
import pl.op.model.dict.Tariff;
import pl.op.model.user.UserApp;

import com.google.inject.Inject;

public class PPEDao implements Serializable {

    private static final long serialVersionUID = -1643409711153472771L;

    @Inject
    PPEInterface ppeInterface;

    public PPE getPPEById(Long ppeId) throws Exception {
        return ppeInterface.getPPEById(ppeId);
    }
    
    public List<PPE> getPPEs(PPE ppe) throws Exception {
        return ppeInterface.getPPEs(ppe);
    }

    public List<PPE> getPPEsByFilter(PPEFilter ppeFilter) throws Exception {
        return ppeInterface.getPPEsByFilter(ppeFilter);
    }

    public Tariff getActualTariff(PPE ppe) throws Exception {
        return ppeInterface.getActualTariff(ppe);
    }

    public List<PPE> getPPEsByUser(UserApp user) throws Exception {
        return ppeInterface.getPPEsByUser(user);
    }

    public List<PPE> getPpesGroup(String selectMode, Integer userId, Integer cityId, Integer areaId,
            Integer stereotypeId, Integer tariffId) throws Exception {
        return ppeInterface.getPpesGroup(selectMode, userId, cityId, areaId, stereotypeId, tariffId);
    }

    public void savePPE(PPE ppe) throws Exception {
        ppeInterface.savePPE(ppe);
    }

    public void updatePPE(PPE ppe) throws Exception {
        ppeInterface.updatePPE(ppe);
    }

    public void deletePPE(PPE ppe) throws Exception {
        ppeInterface.deletePPE(ppe);
    }

    public void updatePPEStatus() throws Exception {
        ppeInterface.updatePPEStatusToReady();
    }

    public void updatePPEStatus(Integer ppeId, PPEStatus ppeStatus) throws Exception {
        ppeInterface.updatePPEStatus(ppeId, ppeStatus);
    }

    public void updatePPEValue(PPE ppe) throws Exception {
        ppeInterface.updatePPEValue(ppe);
    }
}