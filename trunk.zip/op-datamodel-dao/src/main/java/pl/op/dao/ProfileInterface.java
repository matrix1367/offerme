package pl.op.dao;

import pl.op.model.profile.ProfileIndicator;
import pl.op.model.profile.ProfileIndicatorFilter;
import pl.op.model.profile.ProfileValue;


public interface ProfileInterface {

	public void saveProfileIndicator(ProfileIndicator profileIndicator) throws Exception;

	public void saveProfileValue(ProfileValue profileValue) throws Exception;

	public void updateProfileIndicator(ProfileIndicator profileIndicator) throws Exception;

	public Double getSumValueByFilter(ProfileIndicatorFilter filter) throws Exception;

	public void deleteProfileIndicatorToTariff(Integer tariffId) throws Exception;

	public void deleteProfileValueToTariff(Integer tariffId) throws Exception;
}
