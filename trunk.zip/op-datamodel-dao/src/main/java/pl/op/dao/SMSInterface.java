package pl.op.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import pl.op.model.sms.SMS;
import pl.op.model.sms.SMSOperationType;
import pl.op.model.sms.SMSTemplate;
import pl.op.model.user.UserApp;

public interface SMSInterface {

	public SMS getSMSById(Long id) throws Exception;

	public SMS getSMSByCode(Integer code) throws Exception;

	public void saveSMS(SMS sms) throws Exception;

	public void saveSMSOperationType(SMSOperationType smsOperationType)
			throws Exception;

	public void updateSMS(SMS sms) throws Exception;

	public SMSTemplate getSMSTemplateByName(@Param("name") String name,
			@Param("language") String language) throws Exception;

	public SMS getLastSMSByUserAndOperation(@Param("user") UserApp userApp,
			@Param("smsOperationType") String smsOperationType)
			throws Exception;

	public List<Integer> getSMSCodesTodayByUserAndOperation(
			@Param("user") UserApp userApp,
			@Param("smsOperationType") String smsOperationType)
			throws Exception;

	public SMSOperationType getSMSOperationTypeByType(String smsOperationType)
			throws Exception;
}
