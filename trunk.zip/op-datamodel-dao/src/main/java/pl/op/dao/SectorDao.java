package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.stereotype.Sector;
import pl.op.model.user.UserApp;

import com.google.inject.Inject;

public class SectorDao implements Serializable {

	private static final long serialVersionUID = 3874434164465615409L;

	@Inject
	SectorInterface sectorInterface;
	public List<Sector> getSector() throws Exception {
		return sectorInterface.getSector();
	}
	
	public List<Sector> getSector(Sector sector) throws Exception {
		return sectorInterface.getSector(sector);
	}
	
	public void saveSector(Sector sector) throws Exception {
		sectorInterface.saveSector(sector);
	}
	
	public void updateSector(Sector sector) throws Exception {
		sectorInterface.updateSector(sector);
	}
	
	public void deleteSector(Sector sector) throws Exception {
		sectorInterface.deleteSector(sector);
	}

	public Sector getSectorByUser(UserApp user) throws Exception {
		return sectorInterface.getSectorByUser(user);
	}
}
