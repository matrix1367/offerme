package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.contract.Location;
import pl.op.model.user.UserApp;

import com.google.inject.Inject;

public class LocationDao implements Serializable {

	private static final long serialVersionUID = -1643409711153472771L;

	@Inject
	LocationInterface locationInterface;

	public List<Location> getLocationByUserApp(UserApp userApp)
			throws Exception {
		return locationInterface.getLocationByUserApp(userApp);
	}

	public void saveLocation(Location location) throws Exception {
		locationInterface.saveLocation(location);
	}
	
	public void updateLocation(Location location) throws Exception {
		locationInterface.updateLocation(location);
	}
	
}