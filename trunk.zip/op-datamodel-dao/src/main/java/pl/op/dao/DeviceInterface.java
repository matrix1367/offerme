package pl.op.dao;

import java.util.List;

import pl.op.model.device.Device;


public interface DeviceInterface {
	public List<Device> getDevices() throws Exception;
	public void saveDevice(Device device);
	public void updateDevice(Device device) throws Exception;
	public void deleteDevice(Device device) throws Exception;
	public void removeAllDeviceByLocation(Integer locationId) throws Exception;
}

