package pl.op.dao;

import java.util.List;

import pl.op.model.sms.*;
import pl.op.model.user.UserApp;

import com.google.inject.Inject;

public class SMSDao {

	@Inject
	SMSInterface smsInterface;
	
	public void setSmsInterface(SMSInterface smsInterface) {
		this.smsInterface = smsInterface;
	}

	public SMS getSMSById(Long id) throws Exception {
		return smsInterface.getSMSById(id);
	}
	
	public SMS getSMSByCode(Integer code) throws Exception {
		return smsInterface.getSMSByCode(code);
	}
	
	public Long saveSMS(SMS sms) throws Exception {
		smsInterface.saveSMS(sms);
		return sms.getIdSMS();
	}
	
	public void updateSMS(SMS sms) throws Exception {
		smsInterface.updateSMS(sms);
	}
	
	public Integer saveSMSOperationType(SMSOperationType smsOperationType) throws Exception {
		smsInterface.saveSMSOperationType(smsOperationType);
		return smsOperationType.getIdSMSOperationType();
	}
	
	public SMSTemplate getSMSTemplateByName(String name, String language) throws Exception {
		return smsInterface.getSMSTemplateByName(name, language);
	}
	
	public SMS getLastSMSByUserAndOperation(UserApp userApp, String smsOperationType) throws Exception {
		return smsInterface.getLastSMSByUserAndOperation(userApp, smsOperationType);
	}
	
	public List<Integer> getSMSCodesTodayByUserAndOperation(UserApp userApp, String smsOperationType) throws Exception {
		return smsInterface.getSMSCodesTodayByUserAndOperation(userApp,smsOperationType);
	}
	
	public SMSOperationType getSMSOperationTypeByType(String smsOperationType) throws Exception{
		return smsInterface.getSMSOperationTypeByType(smsOperationType);
	}

}
