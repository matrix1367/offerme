package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.model.comment.CommentModule;
import pl.op.model.comment.CommentTypeEnum;

import com.google.inject.Inject;

public class CommentModuleDao implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1116158672742139145L;
	
	@Inject
	CommentModuleInterface commentModuleInterface;
	
	public void saveComment(CommentModule comment) throws Exception {
		commentModuleInterface.saveComment(comment);
	}
	
	public void updateComment(CommentModule comment) throws Exception {
		commentModuleInterface.updateComment(comment);
	}
	
	public void deleteComment(CommentModule comment) throws Exception { 
		commentModuleInterface.deleteComment(comment);
	}
	
	public List<CommentModule> getComments(Integer objectId, CommentTypeEnum commentType) throws Exception {
		return commentModuleInterface.getComments(objectId, commentType);
	}
}
