package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.dict.Area;

import com.google.inject.Inject;

public class AreaDao implements Serializable {

	private static final long serialVersionUID = -3963171589883460036L;

	@Inject
	AreaInterface areaInterface;

	public List<Area> getAreas(Area area) throws Exception {
		return areaInterface.getAreas(area);
	}

	public List<Area> getAreasByPage(Area area, Integer pageSize, Integer first) throws Exception {
		return areaInterface.getAreasByPage(area, pageSize, first);
	}

	public Area getAreaById(Integer id) throws Exception {
		return areaInterface.getAreaById(id);
	}

	public Area getAreaByName(String areaName) throws Exception {
		return areaInterface.getAreaByName(areaName);
	}
	
	public List<Area> getAreasByName(String areaName) throws Exception {
		return areaInterface.getAreasByName(areaName);
	}

	public Area getAreaBySymbol(String areaSymbol) throws Exception {
		return areaInterface.getAreaBySymbol(areaSymbol);
	}
	
	public Area getAreaByCityId(Integer cityId) throws Exception {
		return areaInterface.getAreaByCityId(cityId);
	}

	public void saveArea(Area area) throws Exception {
		areaInterface.saveArea(area);
	}

	public void updateArea(Area area) throws Exception {
		areaInterface.updateArea(area);
	}

	public void deleteArea(Area area) throws Exception {
		areaInterface.deleteArea(area);
	}
}
