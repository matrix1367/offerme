package pl.op.dao;

import pl.op.model.contract.OperatorAgreement;


public interface OperatorAgreementInterface {
	public void saveOperatorAgreement(OperatorAgreement operatorAgreement) throws Exception;
	public void updateOperatorAgreement(OperatorAgreement operatorAgreement) throws Exception;
	public OperatorAgreement getOperatorAgreement(OperatorAgreement operatorAgreement) throws Exception;
	
}
