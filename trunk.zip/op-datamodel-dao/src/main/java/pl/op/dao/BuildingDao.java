package pl.op.dao;

import java.io.Serializable;

import pl.op.model.stereotype.Building;

import com.google.inject.Inject;

public class BuildingDao implements Serializable {

	private static final long serialVersionUID = -1643409711153472771L;
	
	@Inject
	BuildingInterface buildingInterface;

	public void saveBuilding(Building building) throws Exception {
		buildingInterface.saveBuilding(building);
	}
	
	public void updateBuilding(Building building) throws Exception {
		buildingInterface.updateBuilding(building);
	}

}