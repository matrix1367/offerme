package pl.op.dao;

import java.util.List;

import pl.op.model.msg.MessageAttachment;

public interface MessageAttachmentInterface {

	public List<MessageAttachment> getAttachmentsList(List<MessageAttachment> messageAttachment) throws Exception;
	
	public MessageAttachment getSelectedAttachment(Integer messageAttachmentId) throws Exception;
	
	public void newAttachment(MessageAttachment messageAttachment) throws Exception;
}
