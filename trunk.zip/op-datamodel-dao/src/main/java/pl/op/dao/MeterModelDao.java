package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.dict.MeterModel;

import com.google.inject.Inject;

public class MeterModelDao implements Serializable {

	private static final long serialVersionUID = 7075056906970773520L;

	@Inject MeterModelInterface meterModelInterface;
	
	public List<MeterModel> getMeterModels() throws Exception {
		return meterModelInterface.getMeterModels();
	}

	public MeterModel getMeterModelById(Integer id) throws Exception {
		return meterModelInterface.getMeterModelById(id);
	}

	public void deleteMeterModel(MeterModel meterModel) throws Exception {
		meterModelInterface.deleteMeterModel(meterModel);
	}

	public void saveMeterModel(MeterModel meterModel) throws Exception {
		meterModelInterface.saveMeterModel(meterModel);
	}

	public void updateMeterModel(MeterModel meterModel) throws Exception {
		meterModelInterface.updateMeterModel(meterModel);
	}
}
