package pl.op.dao;

import java.util.List;

import pl.op.model.comment.Comment;
import pl.op.model.comment.File;
import pl.op.model.comment.News;

public interface CommentInterface {

	public List<Comment> getComments(Comment comment) throws Exception;
	public List<News> getNews(News news) throws Exception;

	public Comment getComment(Integer idComment) throws Exception;
	
	public List<Comment> getActualComments() throws Exception;
	public List<News> getActualNews() throws Exception;
	
	public void addComment(Comment comment) throws Exception;
	public void addNews(News news) throws Exception;
	public void addFile(File file) throws Exception;
	
	public void updateComment(Comment comment) throws Exception;
	public void updateNews(News news) throws Exception;
	public void updateFileUrl(File file) throws Exception;

	public void activateComment(Integer idComment) throws Exception;
	public void removeComment(Integer idComment) throws Exception;
	
	public void activateNews(Integer idNews) throws Exception;
	public void removeNews(Integer idNews) throws Exception;
	
}
