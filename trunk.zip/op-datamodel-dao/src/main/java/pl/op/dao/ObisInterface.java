package pl.op.dao;

import java.util.List;

import pl.op.model.dict.Obis;

public interface ObisInterface {
	
	public List<Obis> getObisList() throws Exception;
	public Obis getObisById(Integer id) throws Exception;
	public void saveObis(Obis obis) throws Exception;
	public void deleteObis(Obis obis) throws Exception;
	public void updateObis(Obis obis) throws Exception;
}
