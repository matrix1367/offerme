package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.contract.OperatorInvoice;

import com.google.inject.Inject;

public class OperatorInvoiceDao implements Serializable {

	private static final long serialVersionUID = -1643409711153472771L;
	
	@Inject
	OperatorInvoiceInterface operatorInvoiceInterface;

	public List<OperatorInvoice> getOperatorInvoices(OperatorInvoice operatorInvoice) throws Exception{
		return operatorInvoiceInterface.getOperatorInvoices(operatorInvoice);
	}
	
	public void saveOperatorInvoice(OperatorInvoice operatorInvoice) throws Exception{
		operatorInvoiceInterface.saveOperatorInvoice(operatorInvoice);
	}
	
	public void updateOperatorInvoice(OperatorInvoice operatorInvoice) throws Exception{
		operatorInvoiceInterface.updateOperatorInvoice(operatorInvoice);
	}
	
	public void deleteOperatorInvoice(OperatorInvoice operatorInvoice) throws Exception{
		operatorInvoiceInterface.deleteOperatorInvoice(operatorInvoice);
	}
	
}