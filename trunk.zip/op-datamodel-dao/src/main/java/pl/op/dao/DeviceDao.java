package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.device.Device;

import com.google.inject.Inject;

public class DeviceDao implements Serializable {

	private static final long serialVersionUID = -1643409711153472771L;
	
	@Inject
	DeviceInterface deviceInterface;

	public List<Device> getDevices() throws Exception {
		return deviceInterface.getDevices();
	}	
	public void saveDevice(Device device) throws Exception {
		deviceInterface.saveDevice(device);
	}
	public void updateDevice(Device device) throws Exception {
		deviceInterface.updateDevice(device);
	}
	public void deleteDevice(Device device) throws Exception {
		deviceInterface.deleteDevice(device);
	}
	
	public void removeAllDeviceByLocation(Integer locationId) throws Exception {
		deviceInterface.removeAllDeviceByLocation(locationId);
	}
}