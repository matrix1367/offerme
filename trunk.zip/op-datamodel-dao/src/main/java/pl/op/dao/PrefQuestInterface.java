package pl.op.dao;

import java.util.List;

import pl.op.model.question.PreferenceQuestion;

public interface PrefQuestInterface {
	public List<PreferenceQuestion> getPreferenceQuestionList(
			PreferenceQuestion preferenceQuestion) throws Exception;

	public void savePreferenceQuestion(PreferenceQuestion preferenceQuestion)
			throws Exception;

	public void updatePreferenceQuestion(PreferenceQuestion preferenceQuestion)
			throws Exception;

	public void deletePreferenceQuestion(PreferenceQuestion preferenceQuestion)
			throws Exception;

	public PreferenceQuestion getPreference(
			PreferenceQuestion preferenceQuestion) throws Exception;
}
