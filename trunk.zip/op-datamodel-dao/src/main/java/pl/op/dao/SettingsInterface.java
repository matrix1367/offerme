package pl.op.dao;

import java.util.List;

import pl.op.settings.Settings;

public interface SettingsInterface {
	
	public List<Settings> getSettingsList(Settings settings) throws Exception;
	public void updateSetting(Settings settings) throws Exception;
	public Settings getSettingByType(String type) throws Exception;
	public void saveSetting(Settings setting) throws Exception;
}
