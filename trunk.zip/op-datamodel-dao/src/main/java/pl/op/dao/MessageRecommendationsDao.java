package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.dict.MessageRecommendations;

import com.google.inject.Inject;

public class MessageRecommendationsDao implements Serializable {

	private static final long serialVersionUID = -5983628058966561693L;
	
	@Inject
	MessageRecommendationsInterface messageRecommendationsInterface;
	
	public List<MessageRecommendations> getMessageRecommendations() throws Exception {
		return messageRecommendationsInterface.getMessageRecommendations();
	}

	public List<MessageRecommendations> getMessageRecommendationsAllByNull(
			Boolean constant) throws Exception {
		return messageRecommendationsInterface
				.getMessageRecommendationsAllByNull(constant);
	}

	public List<MessageRecommendations> getMessageRecommendationsAllByDeviceTypeId(
			Integer deviceTypeId, Boolean constant) throws Exception {
		return messageRecommendationsInterface
				.getMessageRecommendationsAllByDeviceTypeId(deviceTypeId,
						constant);
	}

	public List<MessageRecommendations> getMessageRecommendationsAllByTariffId(
			Integer tariffId, Boolean constant) throws Exception {
		return messageRecommendationsInterface
				.getMessageRecommendationsAllByTariffId(tariffId, constant);
	}

	public List<MessageRecommendations> getMessageRecommendationsAllByDeviceTypeIdAndTariffId(
			Integer deviceTypeId, Integer tariffId, Boolean constant)
			throws Exception {
		return messageRecommendationsInterface
				.getMessageRecommendationsAllByDeviceTypeIdAndTariffId(
						deviceTypeId, tariffId, constant);
	}

	public MessageRecommendations getMessageRecommendationsById(Integer id)
			throws Exception {
		return messageRecommendationsInterface
				.getMessageRecommendationsById(id);
	}

	public void saveMessageRecommendations(
			MessageRecommendations messageRecommendations) throws Exception {
		messageRecommendationsInterface
				.saveMessageRecommendations(messageRecommendations);
	}

	public void deleteMessageRecommendations(
			MessageRecommendations messageRecommendations) throws Exception {
		messageRecommendationsInterface
				.deleteMessageRecommendations(messageRecommendations);
	}

	public void updateMessageRecommendations(
			MessageRecommendations messageRecommendations) throws Exception {
		messageRecommendationsInterface
				.updateMessageRecommendations(messageRecommendations);
	}

}
