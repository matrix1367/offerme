package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;

import pl.op.model.cms.HelpPage;

public class HelpPageDao implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private HelpPageInterface helpInterface;
	@Inject
	public HelpPageDao(HelpPageInterface helpInterface) {
		this.helpInterface = helpInterface;
	}
	
	
	public HelpPage findByViewId(String viewId){
		return helpInterface.findByViewId(viewId);
	}


	public List<HelpPage> findAll() {
		return helpInterface.findAll();
	}
	
	
}
