package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.dashboard.DashboardItem;
import pl.op.model.dashboard.DashboardItemUser;
import pl.op.model.user.UserApp;

import com.google.inject.Inject;

public class DashboardItemDao implements Serializable {
	
	private static final long serialVersionUID = 6416717585377010694L;
	@Inject DashboardItemInterface dashboardItemInterface;
	
	public List<DashboardItem> getDashboardItems() throws Exception {
		return dashboardItemInterface.getDashboardItems();
	}
	
	public List<DashboardItem> getUserDashboardItems(UserApp user) throws Exception{
		return dashboardItemInterface.getUserDashboardItems(user);
	}
	
	public List<DashboardItem> getActiveDashboardItems() throws Exception {
		return dashboardItemInterface.getActiveDashboardItems();
	}
	
	public List<DashboardItem> getUserActiveDashboardItems() throws Exception {
		return dashboardItemInterface.getUserActiveDashboardItems();
	}

	public DashboardItem getDashboardItemById(Integer id) throws Exception {
		return dashboardItemInterface.getDashboardItemById(id);
	}
	
	public List<DashboardItemUser> getDashboardItemUsersByUserId(Integer userId) throws Exception{
		return dashboardItemInterface.getDashboardItemUsersByUserId(userId);
	}
	
	public Integer saveDashboardItemUser(Integer dashboardItemId, Integer userId, Boolean isDashboardItemUserActive) throws Exception{
		return dashboardItemInterface.saveDashboardItemUser(dashboardItemId, userId, isDashboardItemUserActive);
	}
	
	public Integer updateDashboardItemUser(Integer dashboardItemId, Integer userId, Boolean isDashboardItemUserActive) throws Exception{
		return dashboardItemInterface.updateDashboardItemUser(dashboardItemId, userId, isDashboardItemUserActive);
	}

	public void saveDashboardItem(DashboardItem dashboardItem) throws Exception {
		dashboardItemInterface.saveDashboardItem(dashboardItem);
	}

	public void updateDashboardItem(DashboardItem dashboardItem) throws Exception {
		dashboardItemInterface.updateDashboardItem(dashboardItem);
	}

	public void deleteDashboardItem(DashboardItem dashboardItem) throws Exception {
		dashboardItemInterface.deleteDashboardItem(dashboardItem);
	}

}
