package pl.op.dao;

import java.util.List;

import pl.op.model.cloud.Cloud;
import pl.op.model.salesman.Salesman;
import pl.op.model.user.UserApp;

public interface UserInterface {

	public UserApp getUserByLogin(String login) throws Exception;
        
        public UserApp getUserByPPE(Integer idPPE) throws Exception;
	
	public List<UserApp> filterUsers(UserApp userApp) throws Exception;
	
	public List<Integer> getOperatorsIdList(List<Integer> integer) throws Exception;

	public UserApp getUserByScreenName(String screenName);

	public void saveUser(UserApp user) throws Exception;

	public void updateUser(UserApp user) throws Exception;

	public void updatePassword(UserApp user) throws Exception;

	public UserApp getUserAppbyId(Integer userId) throws Exception;
	
	public List<UserApp> getAllUserApp(UserApp userApp) throws Exception;

	public void deleteUser(UserApp user) throws Exception;

	public void updateActivationCode(UserApp userApp) throws Exception;
	
	public List<UserApp> getUsers(UserApp user) throws Exception;
	
	public List<UserApp> getUsersList() throws Exception;
	
	public List<UserApp> getUsersByRoleNoAdminAndOperator() throws Exception;

	public List<UserApp> getOperators() throws Exception;
	
	public List<UserApp> getOrderCreators() throws Exception;
	
	public List<UserApp> getPinForOperators(UserApp userApp) throws Exception;
	
	public List<UserApp> getUsersBySalesman(Salesman salesman) throws Exception;

	public List<UserApp> getUsersMatchToCloud(Cloud cloud) throws Exception;
}
