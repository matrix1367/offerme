package pl.op.dao;

import java.util.List;

import pl.op.dynamicText.DynamicText;

public interface DynamicTextInterface {
	
	public List<DynamicText> getDynamicTextList(DynamicText dynamicText) throws Exception;
	public void updateDynamicText(DynamicText dynamicText) throws Exception;
	public DynamicText getDynamicTextByType(String type) throws Exception;
	public void saveDynamicText(DynamicText dynamicText) throws Exception;
}
