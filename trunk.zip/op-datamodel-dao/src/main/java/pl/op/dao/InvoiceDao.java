package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import org.slf4j.LoggerFactory;

import pl.op.model.auction.PriceComponent;
import pl.op.model.contract.Invoice;
import pl.op.model.contract.InvoicePriceComponentValue;
import pl.op.model.contract.PPE;

import com.google.inject.Inject;

public class InvoiceDao implements Serializable {

    private static final long serialVersionUID = -1643409711153472771L;

    @Inject
    InvoiceInterface invoiceInterface;

    public void saveInvoice(Invoice invoice) throws Exception {
        invoiceInterface.saveInvoice(invoice);
    }

    public void removeInvoicePriceComponentValues(Invoice invoice) throws Exception {
        invoiceInterface.removeInvoicePriceComponentValues(invoice);
    }

    public void updateInvoice(Invoice invoice) throws Exception {
        invoiceInterface.updateInvoice(invoice);
    }

    public void removeInvoice(Invoice invoice) throws Exception {
        invoiceInterface.removeInvoice(invoice);
    }

    public List<PriceComponent> getPPEPriceComponents(PPE ppe) throws Exception {
        return invoiceInterface.getPPEPriceComponents(ppe);
    }

    public void savePriceComponentValue(InvoicePriceComponentValue priceValue) throws Exception {
        invoiceInterface.savePriceComponentValue(priceValue);
    }

    public void updateInvoicePriceComponentValue(InvoicePriceComponentValue priceValue) throws Exception {
        invoiceInterface.updateInvoicePriceComponentValue(priceValue);
    }

    public Invoice getLastInvoiceByPpeId(Integer id) throws Exception {
        List<Invoice> invoices = invoiceInterface.getLastInvoiceByPpeId(id);
        if(null == invoices || 0 == invoices.size()) {
            return null;
        }

        LoggerFactory.getLogger(InvoiceDao.class).info("Found invoices: " + invoices.size());
        return invoices.get(0);
    }

    public List<Invoice> getInvoicesByPpeId(Integer id) throws Exception {
        return invoiceInterface.getInvoicesByPpeId(id);
    }

    public List<Invoice> searchInvoices(Invoice invoice) throws Exception {
        return invoiceInterface.searchInvoices(invoice);
    }

}