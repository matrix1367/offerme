package pl.op.dao;

import java.util.List;

import pl.op.model.dict.MeterModel;

public interface MeterModelInterface {

	public List<MeterModel> getMeterModels() throws Exception;
	public MeterModel getMeterModelById(Integer id) throws Exception;
	public void saveMeterModel (MeterModel meterModel) throws Exception;
	public void updateMeterModel (MeterModel meterModel) throws Exception;
	public void deleteMeterModel (MeterModel meterModel) throws Exception;
	
}
