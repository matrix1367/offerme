package pl.op.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import pl.op.model.msg.Message;
import pl.op.model.msg.UserToMessage;

public interface MessageInterface {

	public UserToMessage getUserToMessage(UserToMessage userToMessage) throws Exception;
	
	public Integer unreadMessagesCounter(Integer userId) throws Exception;
	
	public List<Message> getMessageList(Message message) throws Exception;

	public List<Message> getInboxMessageList(@Param("message") Message message,
			@Param("userId") Integer userId) throws Exception;

	public List<Message> getOutboxMessageList(
			@Param("message") Message message, @Param("userId") Integer userId)
			throws Exception;

	public void newMessage(Message message) throws Exception;

	public void assignMessagesToUsers(
			@Param("receiverId") Integer receiverId,
			@Param("messageId") Integer messageId) throws Exception;

	public void assignMessagesSenderToUsers(
			@Param("senderId") Integer senderId,
			@Param("messageId") Integer messageId) throws Exception;

	public void deleteInboxMessage(@Param("message") Message message,
			@Param("userId") Integer userId) throws Exception;
	
	public void deleteOutboxMessage(@Param("message") Message message,
			@Param("userId") Integer userId) throws Exception;

	public void markFavorite(@Param("message") Message message,
			@Param("userId") Integer userId) throws Exception;

	public void markAsRead(@Param("message") Message message,
			@Param("userId") Integer userId) throws Exception;
	
	public void markAsUnread(@Param("message") Message message,
			@Param("userId") Integer userId) throws Exception;
}
