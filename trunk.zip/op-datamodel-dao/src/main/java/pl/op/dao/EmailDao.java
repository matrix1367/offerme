package pl.op.dao;

import com.google.inject.Inject;
import java.io.Serializable;
import java.util.List;
import pl.op.model.dict.Email;

public class EmailDao implements Serializable {

    private static final long serialVersionUID = 3234624060313988111L;

    @Inject
    EmailInterface emailInterface;
    
    public List<Email> getEmailByFiltr(Email filtr) throws Exception {
        return emailInterface.getEmailByFiltr(filtr);
    }

    public Integer getEmailCount() throws Exception {
        return emailInterface.getEmailCount();
    }

    public Integer getEmailMaxId(String category) throws Exception {
        return emailInterface.getEmailMaxId(category);
    }

    public List<String> getCategory() throws Exception {
        return emailInterface.getCategory();
    }

    public List<Email> getEmailList() throws Exception {
        return emailInterface.getEmailList();
    }

    public List<Email> getEmailListPart(Integer start, Integer end, String category) throws Exception {
        return emailInterface.getEmailListPart(start, end, category);
    }

    public void saveEmail(Email email) throws Exception {
        emailInterface.saveEmail(email);
    }

    public void saveEmailNoExist(Email email) throws Exception {
        emailInterface.saveEmailNoExist(email);
    }

    public void updateEmail(Email email) throws Exception {
        emailInterface.updateEmail(email);
    }

    public void deleteEmail(Email email) throws Exception {
        emailInterface.deleteEmail(email);
    }
}
