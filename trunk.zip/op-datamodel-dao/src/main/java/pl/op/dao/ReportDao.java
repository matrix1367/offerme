package pl.op.dao;

import java.io.Serializable;
import com.google.inject.Inject;

public class ReportDao  implements Serializable{

	private static final long serialVersionUID = -5249215918422181737L;
	
	
	@Inject
	ReportInterface reportInterface;
	
		
}
