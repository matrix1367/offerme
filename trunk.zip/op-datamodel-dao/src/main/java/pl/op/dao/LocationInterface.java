package pl.op.dao;

import java.util.List;

import pl.op.model.contract.Location;
import pl.op.model.user.UserApp;

public interface LocationInterface {

	public List<Location> getLocationByUserApp(UserApp userApp)
			throws Exception;
	public void saveLocation(Location location) throws Exception;
	public void updateLocation(Location location) throws Exception;
}