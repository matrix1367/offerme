package pl.op.dao;

public interface ReportInterface {

}