package pl.op.dao;

import java.io.Serializable;

import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.ExecutorType;
import org.mybatis.guice.transactional.Isolation;
import org.mybatis.guice.transactional.Transactional;

import pl.op.model.comment.*;

import com.google.inject.Inject;

public class CommentDao implements Serializable {

	private Logger log = LoggerFactory.getLogger(CommentDao.class);

	private static final long serialVersionUID = -6893570188297028826L;

	@Inject
	CommentInterface commentInterface;
	
	public void setCommentInterface(CommentInterface commentInterface) {
		this.commentInterface = commentInterface;
	}

	public List<Comment> getComments(Comment comment) throws Exception {
		return commentInterface.getComments(comment);
	}

	public Comment getComment(Integer idComment) throws Exception {
		return commentInterface.getComment(idComment);
	}
	
	public List<News> getNews(News news) throws Exception {
		return commentInterface.getNews(news);
	}

	public List<Comment> getActualComments() throws Exception {
		return commentInterface.getActualComments();
	}

	public List<News> getActualNews() throws Exception {
		return commentInterface.getActualNews();
	}
	
	public void addComment(Comment comment) throws Exception {
		commentInterface.addComment(comment);
	}

	public void addFile(File file) throws Exception {
		commentInterface.addFile(file);
	}
	
	public void addNews(News news) throws Exception {
		commentInterface.addNews(news);
	}

	public void updateComment(Comment comment) throws Exception {
		commentInterface.updateComment(comment);
	}

	public void updateNews(News news) throws Exception {
		commentInterface.updateNews(news);
	}

	public void updateFileUrl(File file) throws Exception {
		commentInterface.updateFileUrl(file);
	}
	
	public void activateComment(Integer idComment) throws Exception
	{
		commentInterface.activateComment(idComment);
	}

	public void activateNews(Integer idNews) throws Exception
	{
		commentInterface.activateNews(idNews);
	}
	
	public void removeComment(Integer idComment) throws Exception
	{
		commentInterface.removeComment(idComment);
	}

	public void removeNews(Integer idNews) throws Exception
	{
		commentInterface.removeNews(idNews);
	}
	
	@Transactional(executorType = ExecutorType.BATCH, isolation = Isolation.READ_UNCOMMITTED)
	public void addCommentAndNews(Comment comment, News news)
			throws PersistenceException {

		log.info("Transactional addCommentAndNews...");
		try {
			commentInterface.addComment(comment);
			commentInterface.addNews(news);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new PersistenceException();
		}
		
	}

}
