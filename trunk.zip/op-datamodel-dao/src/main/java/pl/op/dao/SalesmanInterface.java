package pl.op.dao;

import java.util.List;

import pl.op.model.dict.Address;
import pl.op.model.salesman.Salesman;

public interface SalesmanInterface {
	public void saveSalesman(Salesman salesman) throws Exception;
	public void deleteSalesman(Salesman salesman) throws Exception;
	public void updateSalesman(Salesman salesman) throws Exception;
	public List<Salesman> getSalesmans(Salesman sRalesman) throws Exception;
	public Salesman getSalesmanById(Integer salesmanId) throws Exception;
	public Salesman getSalesmanByUserId(Integer userId) throws Exception;
	public List<Salesman> getAllSalesmans() throws Exception;
	public Salesman getSalesmanByName(String name) throws Exception;
	public void saveAddress(Address address) throws Exception;
	public void updateAddress(Address address) throws Exception;	
	public Integer getGreenEnergyBySalesmanId(Integer salesmanId) throws Exception;
}
