package pl.op.dao;

import java.util.List;

import pl.op.model.cms.HelpPage;

public interface HelpPageInterface {
	
	public HelpPage findByViewId(String viewId);
	
	public List<HelpPage> findAll();
}
