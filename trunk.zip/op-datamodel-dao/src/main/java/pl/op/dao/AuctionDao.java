package pl.op.dao;

import java.io.Serializable;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionAgreement;
import pl.op.model.auction.AuctionFilter;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.auction.AuctionUser;
import pl.op.model.auction.PriceComponent;
import pl.op.model.auction.PriceComponentValue;
import pl.op.model.auction.VolumeProfitability;
import pl.op.model.contract.PPE;
import pl.op.model.dict.Tariff;
import pl.op.model.salesman.Salesman;
import pl.op.model.user.UserApp;

import com.google.inject.Inject;

public class AuctionDao implements Serializable {

    private static final long serialVersionUID = -1643409711153472771L;
    private final Logger log = LoggerFactory.getLogger(AuctionDao.class);
    
    @Inject
    AuctionInterface auctionInterface;

    // Auctions
    public List<Auction> getAuctions(AuctionFilter auctionFilter) throws Exception {
        return auctionInterface.getAuctions(auctionFilter);
    }
    
    public List<Auction> getAuctionsForUsers(AuctionFilter auctionFilter) throws Exception {
        return auctionInterface.getAuctionsForUsers(auctionFilter);
    }
    
        // Auctions
    public List<Auction> getAuctionsFull(AuctionFilter auctionFilter) throws Exception {
        return auctionInterface.getAuctionsFull(auctionFilter);
    }

    public Auction getAuction(Auction auction) throws Exception {
        return auctionInterface.getAuction(auction);
    }

    public Integer getAuctionsCount(AuctionFilter auctionFilter) throws Exception {
        return auctionInterface.getAuctionsCount(auctionFilter);
    }

    public void updateAuction(Auction auction) throws Exception {
        auctionInterface.updateAuction(auction);
    }

    public List<AuctionUser> getAuctionUsers(Auction auction) throws Exception {
        return auctionInterface.getAuctionUsers(auction);
    }
    
 
    
    public List<AuctionUser> getAuctionUsersSimple(Auction auction) throws Exception {
        return auctionInterface.getAuctionUsersSimple(auction);
    }
    
    
    public Auction getAuctionFromPPE(Integer ppeId) throws Exception {
        return auctionInterface.getAuctionFromPPE(ppeId);
    }

    public List<UserApp> getAuctionUsersToDelete(Auction auction) throws Exception {
        return auctionInterface.getAuctionUsersToDelete(auction);
    }

    public AuctionOffer getUserOffer(AuctionUser auctionUser) throws Exception {
        return auctionInterface.getUserOffer(auctionUser);
    }

    public void deleteUsersFromAuction(Auction auction) throws Exception {
        auctionInterface.deleteUsersFromAuction(auction);
    }

    public Integer getPotentialUsers(Auction auction) throws Exception {
        return auctionInterface.getPotentialUsers(auction);
    }

    public List<Salesman> getAuctionSalesmans(Auction auction) throws Exception {
        return auctionInterface.getAuctionSalesmans(auction);
    }

    public List<Auction> getAuctionsBySalesman(Salesman salesman) throws Exception {
        return auctionInterface.getAuctionsBySalesman(salesman);
    }

    public List<Auction> getAuctionsInProgress() throws Exception {
        return auctionInterface.getAuctionsInProgress();
    }

    public void saveAuction(Auction auction) throws Exception {
        auctionInterface.saveAuction(auction);
    }

    public void saveAuctionOffer(AuctionOffer auctionOffer) throws Exception {
        auctionInterface.saveAuctionOffer(auctionOffer);
    }

    public void closeAuctions() throws Exception {
        auctionInterface.closeAuctions();
    }

    public Integer getReadyUsers(Auction auction) throws Exception {
        return auctionInterface.getReadyUsers(auction);
    }

    public Integer getJoinedUsers(Auction auction) throws Exception {
        return auctionInterface.getJoinedUsers(auction);
    }

    public List<VolumeProfitability> getVolumeProfitability(Auction auction) throws Exception {
        return auctionInterface.getVolumeProfitability(auction);
    }

    // Price Componentnts
    public Double getPriceComponentValuesByConstant(PriceComponentValue priceComponentValue) throws Exception {
        return auctionInterface.getPriceComponentValuesByConstant(priceComponentValue);
    }

    public void savePriceComponentValue(PriceComponentValue priceComponentValue) throws Exception {
        auctionInterface.savePriceComponentValue(priceComponentValue);
    }

    // Auction Offers
    public List<AuctionOffer> getAuctionOffers(Auction auction) throws Exception {
        return auctionInterface.getAuctionOffers(auction);
    }

    public AuctionOffer getLastAuctionOffer(AuctionOffer auctionOffer) throws Exception {
        return auctionInterface.getLastAuctionOffer(auctionOffer);
    }

    public void updateAuctionOffer(AuctionOffer auctionOffer) throws Exception {
        auctionInterface.updateAuctionOffer(auctionOffer);
    }

    public List<PriceComponentValue> getAuctionOfferTariff(AuctionOffer auctionOffer) throws Exception {
        return auctionInterface.getAuctionOfferTariff(auctionOffer);
    }

    public void assignUserToAuction(AuctionUser auctionUser) throws Exception {
        auctionInterface.assignUserToAuction(auctionUser);
    }

    public List<UserApp> getSalesmanAuctionUsers(Salesman salesman) throws Exception {
        return auctionInterface.getSalesmanAuctionUsers(salesman);
    }

    public List<PriceComponent> getPriceComponents(Tariff tariff) throws Exception {
        return auctionInterface.getPriceComponents(tariff);
    }

    public List<PriceComponentValue> getOfferPriceComponentValues(Auction auction) throws Exception {
        return auctionInterface.getOfferPriceComponentValues(auction);
    }

    public List<AuctionAgreement> getAuctionAgreements(AuctionOffer auctionOffer) throws Exception {
        return auctionInterface.getAuctionAgreements(auctionOffer);
    }

    public List<AuctionAgreement> getGroupedAuctionAgreements(AuctionOffer auctionOffer) throws Exception {
        return auctionInterface.getGroupedAuctionAgreements(auctionOffer);
    }

    public Double getCounterSaving() throws Exception {        
        if (auctionInterface == null) log.info("[AuctionDao::counterSaving] AuctionDao == null !!!" );
        return auctionInterface.getCounterSaving();
    }

    public Double getBestAuctionOfferScore(Auction auction) throws Exception {
        return auctionInterface.getBestAuctionOfferScore(auction);
    }

    /** Using in RatingBean */
    public List<Auction> getFinishedAuctions() throws Exception {          
        return auctionInterface.getFinishedAuctions();
    }

    public AuctionOffer getOldestOffer(Integer auctionId) throws Exception {
        return auctionInterface.getOldestOffer(auctionId);
    }

    public AuctionOffer getWinningOffer(Integer auctionId) throws Exception {
        return auctionInterface.getWinningOffer(auctionId);
    }

    public Integer getSalesmanByOffer(Integer auctionOfferId) throws Exception {
        return auctionInterface.getSalesmanByOffer(auctionOfferId);
    }

    public Double getSavings(Integer auctionOfferId) throws Exception {
        return auctionInterface.getSavings(auctionOfferId);
    }

    public Double getConstPriceComponentValue(Integer auctionOfferId) throws Exception {
        return auctionInterface.getConstPriceComponentValue(auctionOfferId);
    }

    public Integer getAuctionCount(AuctionFilter auctionFilter) throws Exception {
        return auctionInterface.getAuctionCount(auctionFilter);
    }

    public List<Auction> getJoinedAuctionByPpe(PPE ppe) throws Exception {
        return auctionInterface.getJoinedAuctionByPpe(ppe);
    }

    public Auction getAuctionAndOffers(Integer auctionId) throws Exception {
        return auctionInterface.getAuctionAndOffers(auctionId);
    }
}