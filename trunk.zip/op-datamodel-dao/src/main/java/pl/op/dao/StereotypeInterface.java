package pl.op.dao;

import java.util.List;

import pl.op.model.stereotype.Sector;
import pl.op.model.stereotype.Stereotype;
import pl.op.model.stereotype.StereotypePPEReport;


public interface StereotypeInterface {
	public List<Stereotype> getStereotypes(Sector sector)  throws Exception;	
	public Stereotype getStereotypeById(Integer id) throws Exception;
	public void saveStereotype(Stereotype stereotype) throws Exception;
	public void updateStereotype(Stereotype stereotype) throws Exception;
	public Stereotype getStereotypeByImageName(String iconPath) throws Exception;
	public Sector getSectorByStereotypeId(Integer stereotypeId) throws Exception;
	public List<Sector> getSectors(Sector sector) throws Exception;
	public Stereotype getStereotypeBySector(Sector sector) throws Exception;
	public Stereotype getStereotypeBySectorId(Integer id) throws Exception;
	public List<StereotypePPEReport> getStereotypePPEReport() throws Exception;
}
