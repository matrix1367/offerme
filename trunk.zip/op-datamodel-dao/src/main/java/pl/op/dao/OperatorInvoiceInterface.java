package pl.op.dao;

import java.util.List;

import pl.op.model.contract.OperatorInvoice;

public interface OperatorInvoiceInterface {
	public List<OperatorInvoice> getOperatorInvoices(
			OperatorInvoice operatorInvoice) throws Exception;

	public void saveOperatorInvoice(OperatorInvoice operatorInvoice)
			throws Exception;

	public void updateOperatorInvoice(OperatorInvoice operatorInvoice)
			throws Exception;

	public void deleteOperatorInvoice(OperatorInvoice operatorInvoice)
			throws Exception;

}
