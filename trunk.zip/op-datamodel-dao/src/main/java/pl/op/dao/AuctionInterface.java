package pl.op.dao;

import java.util.List;

import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionAgreement;
import pl.op.model.auction.AuctionFilter;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.auction.AuctionUser;
import pl.op.model.auction.PriceComponent;
import pl.op.model.auction.PriceComponentValue;
import pl.op.model.auction.VolumeProfitability;
import pl.op.model.contract.PPE;
import pl.op.model.dict.Tariff;
import pl.op.model.salesman.Salesman;
import pl.op.model.user.UserApp;

public interface AuctionInterface {
    public List<Auction> getAuctions(AuctionFilter auctionFilter) throws Exception;
    
    public List<Auction> getAuctionsForUsers(AuctionFilter auctionFilter) throws Exception;
    
    public List<Auction> getAuctionsFull(AuctionFilter auctionFilter) throws Exception;

    public void updateAuction(Auction auction) throws Exception;

    public Auction getAuction(Auction auction) throws Exception;

    public List<AuctionUser> getAuctionUsers(Auction auction) throws Exception;
    
    
    
    public List<AuctionUser> getAuctionUsersSimple(Auction auction) throws Exception;
    
    public Auction getAuctionFromPPE(Integer ppeId) throws Exception;

    public Double getPriceComponentValuesByConstant(PriceComponentValue priceComponentValue) throws Exception;

    public List<AuctionOffer> getAuctionOffers(Auction auction) throws Exception;

    public void updateAuctionOffer(AuctionOffer auctionOffer) throws Exception;

    public List<PriceComponentValue> getAuctionOfferTariff(AuctionOffer auctionOffer) throws Exception;

    public List<UserApp> getAuctionUsersToDelete(Auction auction) throws Exception;

    public void deleteUsersFromAuction(Auction auction) throws Exception;

    public AuctionOffer getUserOffer(AuctionUser auctionUser) throws Exception;

    public Integer getPotentialUsers(Auction auction) throws Exception;

    public List<Salesman> getAuctionSalesmans(Auction auction) throws Exception;

    public void assignUserToAuction(AuctionUser auctionUser) throws Exception;

    public List<Auction> getAuctionsBySalesman(Salesman salesman) throws Exception;

    public List<UserApp> getSalesmanAuctionUsers(Salesman salesman) throws Exception;

    public Integer getAuctionsCount(AuctionFilter auctionFilter) throws Exception;

    public List<PriceComponent> getPriceComponents(Tariff tariff) throws Exception;

    public void saveAuction(Auction auction) throws Exception;

    public void saveAuctionOffer(AuctionOffer auctionOffer) throws Exception;

    public void savePriceComponentValue(PriceComponentValue priceComponentValue) throws Exception;

    public void closeAuctions() throws Exception;

    public List<Auction> getAuctionsInProgress() throws Exception;

    public Integer getReadyUsers(Auction auction) throws Exception;

    public Integer getJoinedUsers(Auction auction) throws Exception;

    public List<VolumeProfitability> getVolumeProfitability(Auction auction) throws Exception;

    public List<PriceComponentValue> getOfferPriceComponentValues(Auction auction) throws Exception;

    public List<AuctionAgreement> getAuctionAgreements(AuctionOffer auctionOffer) throws Exception;

    public List<AuctionAgreement> getGroupedAuctionAgreements(AuctionOffer auctionOffer) throws Exception;

    public AuctionOffer getLastAuctionOffer(AuctionOffer auctionOffer) throws Exception;

    public Double getCounterSaving() throws Exception;

    public Double getBestAuctionOfferScore(Auction auction) throws Exception;

    /** Interfaces using in RatingBean */
    public List<Auction> getFinishedAuctions() throws Exception;

    public AuctionOffer getOldestOffer(Integer auctionId) throws Exception;

    public AuctionOffer getWinningOffer(Integer auctionId) throws Exception;

    public Integer getSalesmanByOffer(Integer auctionOfferId) throws Exception;

    public Double getSavings(Integer auctionOfferId) throws Exception;

    public Double getConstPriceComponentValue(Integer auctionOfferId) throws Exception;

    public Integer getAuctionCount(AuctionFilter auctionFilter) throws Exception;

    public List<Auction> getJoinedAuctionByPpe(PPE ppe) throws Exception;

    public Auction getAuctionAndOffers(Integer auctionId) throws Exception;
}