package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.dict.Street;

import com.google.inject.Inject;

public class StreetDao implements Serializable {

	private static final long serialVersionUID = -952751492673990296L;

	@Inject
	StreetInterface streetInterface;
	
	public List<Street> getStreets(Street street) throws Exception {
		return streetInterface.getStreets(street);
	}
	
	public List<Street> searchStreets(Street street) throws Exception {
		return streetInterface.searchStreets(street);
	}
	
	public List<Street> getStreetsList() throws Exception {
		return streetInterface.getStreetsList();
	}

	public Street getStreet(Street street) throws Exception {
		return streetInterface.getStreet(street);
	}
	
	public Street getStreetBySymbol(String symbol) throws Exception {
		return streetInterface.getStreetBySymbol(symbol);
	}

	public List<Street> getStreetsByName(String streetName) throws Exception {
		return streetInterface.getStreetsByName(streetName);
	}

	public void saveStreet(Street street) throws Exception {
		streetInterface.saveStreet(street);
	}
	
	public void saveStreetWithCityId(Street street, Integer cityId) throws Exception {
		streetInterface.saveStreetWithCityId(street,cityId);
	}

	public void updateStreet(Street street) throws Exception {
		streetInterface.updateStreet(street);
	}

	public void deleteStreet(Street street) throws Exception {
		streetInterface.deleteStreet(street);
	}

}
