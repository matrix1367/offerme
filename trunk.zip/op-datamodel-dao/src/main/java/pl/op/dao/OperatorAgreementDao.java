package pl.op.dao;

import java.io.Serializable;

import pl.op.model.contract.OperatorAgreement;

import com.google.inject.Inject;

public class OperatorAgreementDao implements Serializable {

	private static final long serialVersionUID = -1643409711153472771L;
	
	@Inject
	OperatorAgreementInterface operatorAgreementInterface;

	public void saveOperatorAgreement(OperatorAgreement operatorAgreement) throws Exception{
		operatorAgreementInterface.saveOperatorAgreement(operatorAgreement);
	}
	
	public void updateOperatorAgreement(OperatorAgreement operatorAgreement) throws Exception{
		operatorAgreementInterface.updateOperatorAgreement(operatorAgreement);
	}
	
	public OperatorAgreement getOperatorAgreement(OperatorAgreement operatorAgreement) throws Exception{
		return operatorAgreementInterface.getOperatorAgreement(operatorAgreement);
	}
}