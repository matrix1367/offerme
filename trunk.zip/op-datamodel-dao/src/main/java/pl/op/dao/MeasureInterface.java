package pl.op.dao;

import java.util.List;

import pl.op.model.contract.Measure;
import pl.op.model.contract.MeasureFilter;


public interface MeasureInterface {
	public void saveMeasure(Measure measure) throws Exception;
	public void removeMeasureByInvoiceId(Integer invoiceId) throws Exception;
	public List<Measure> getMeasureByFilter(MeasureFilter measure) throws Exception;
}
