package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.bonus.PointsRules;
import pl.op.model.bonus.UserPoints;
import pl.op.model.user.UserApp;

import com.google.inject.Inject;

public class UserPointsDao implements Serializable {

	private static final long serialVersionUID = 6212053122835742365L;
	
	@Inject
	UserPointsInterface userPointsInterface;

	public List<UserPoints> getUserPoints() throws Exception {
		return userPointsInterface.getUserPoints();
	}
	
	public List<UserPoints> getUserPointsByPointsRules(PointsRules pointsRules) throws Exception {
		return userPointsInterface.getUserPointsByPointsRules(pointsRules);
	}
	
	public List<UserPoints> getUserPointsByUserApp(UserApp userApp) throws Exception {
		return userPointsInterface.getUserPointsByUserApp(userApp);
	}
	
	public List<UserPoints> getUserPointsIsBuy(List<PointsRules> pointsRulesIds, Boolean isGranted) throws Exception {
		return userPointsInterface.getUserPointsIsBuy(pointsRulesIds, isGranted);
	}
	
	public List<UserPoints> getUserPointsByUserAppIsBuy(List<PointsRules> pointsRulesIds, Integer userId) throws Exception {
		return userPointsInterface.getUserPointsByUserAppIsBuy(pointsRulesIds, userId);
	}
	
	public List<UserPoints> getUserPointsByPointsRulesAndUserApp(Integer pointsRulesId, Integer userId) throws Exception {
		return userPointsInterface.getUserPointsByPointsRulesAndUserApp(pointsRulesId, userId);
	}
	
	public List<UserPoints> getUserPointsNotGrantedByPointsRulesAndUserApp(Integer pointsRulesId, Integer userId) throws Exception {
		return userPointsInterface.getUserPointsNotGrantedByPointsRulesAndUserApp(pointsRulesId, userId);
	}
	
	public List<UserPoints> getUserPointsGrantedByPointsRulesAndUserApp(Integer pointsRulesId, Integer userId) throws Exception {
		return userPointsInterface.getUserPointsGrantedByPointsRulesAndUserApp(pointsRulesId, userId);
	}
	
	public UserPoints getUserPointsLastGrantedByPointsRulesAndUserApp(Integer pointsRulesId, Integer userId) throws Exception {
		return userPointsInterface.getUserPointsLastGrantedByPointsRulesAndUserApp(pointsRulesId, userId);
	}
	
	public UserPoints getUserPointsLastNotGrantedByPointsRulesAndUserApp(Integer pointsRulesId, Integer userId) throws Exception {
		return userPointsInterface.getUserPointsLastNotGrantedByPointsRulesAndUserApp(pointsRulesId, userId);
	}
	
	public UserPoints getUserPointsById(Integer id) throws Exception {
		return userPointsInterface.getUserPointsById(id);
	}
	
	public void saveUserPoints(UserPoints userPoints) throws Exception {
		userPointsInterface.saveUserPoints(userPoints);
	}
	
	public void deleteUserPoints(UserPoints userPoints) throws Exception {
		userPointsInterface.deleteUserPoints(userPoints);
	}
	
	public void updateUserPoints(UserPoints userPoints) throws Exception {
		userPointsInterface.updateUserPoints(userPoints);
	}
	
}
