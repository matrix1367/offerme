package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.device.DeviceCategory;
import pl.op.model.device.DeviceType;

import com.google.inject.Inject;

public class DeviceTypeDao implements Serializable {

	private static final long serialVersionUID = -1643409711153472771L;
	
	@Inject
	DeviceTypeInterface deviceTypeInterface;

	public List<DeviceType> getDeviceTypesByCategory(Integer categoryId) throws Exception {
		return deviceTypeInterface.getDeviceTypesByCategory(categoryId);
	}
	public List<DeviceType> getDeviceTypes() throws Exception {
		return deviceTypeInterface.getDeviceTypes();
	}
	public DeviceType getDeviceTypeById(Integer deviceTypeById) throws Exception{
		return deviceTypeInterface.getDeviceTypeById(deviceTypeById);
	}
	public DeviceType getDevicesTypeByDeviceCategoryId(Integer id) throws Exception {
		return deviceTypeInterface.getDevicesTypeByDeviceCategoryId(id);
	}
	public DeviceCategory getDevicesCategoryByDeviceTypesId(Integer id) throws Exception {
		return deviceTypeInterface.getDevicesCategoryByDeviceTypesId(id);
	}
	public void saveDeviceType(DeviceType deviceType) throws Exception {
		deviceTypeInterface.saveDeviceType(deviceType);
	}
	public void updateDeviceType(DeviceType deviceType) throws Exception {
		deviceTypeInterface.updateDeviceType(deviceType);
	}
	public void deleteDeviceType(DeviceType deviceType) throws Exception {
		deviceTypeInterface.deleteDeviceType(deviceType);
	}
}