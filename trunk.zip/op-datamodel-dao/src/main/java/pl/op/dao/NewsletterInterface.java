package pl.op.dao;


import java.util.List;
import pl.op.model.newsletter.Newsletter;

public interface NewsletterInterface {

	public void saveNewsletter(Newsletter newsletter) throws Exception;

	public List<Newsletter> getNewsletters(Newsletter newsletter) throws Exception;
        
        public List<Newsletter> getMailing() throws Exception;
}
