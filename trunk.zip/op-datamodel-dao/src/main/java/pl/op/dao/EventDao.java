package pl.op.dao;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pl.op.model.bonus.Event;

import com.google.inject.Inject;

public class EventDao implements Serializable {

	private static final long serialVersionUID = 4718676201310727292L;
	
	@Inject
	EventInterface eventInterface;
	
	public List<Event> getEvents() throws Exception {
		return eventInterface.getEvents();
	}
	
	public Event getEventById(Integer id) throws Exception {
		return eventInterface.getEventById(id);
	}
	
	public Event getEventByCodeName(String codeName) throws Exception {
		return eventInterface.getEventByCodeName(codeName);
	}
	
	public void saveEvent(Event event) throws Exception {
		eventInterface.saveEvent(event);
	}
	
	public void deleteEvent(Event event) throws Exception {
		eventInterface.deleteEvent(event);
	}
	
	public void updateEvent(Event event) throws Exception {
		eventInterface.updateEvent(event);
	}
	
	public Map<String, Event> prepareMap() throws Exception {
		
		List<Event> list = eventInterface.getEvents();
		
		HashMap<String, Event> eventMap = new HashMap<String, Event>();
		for(Event item:list){
			eventMap.put(item.getEventName(), item);
		}		
		
		return eventMap;
		
	}
}
