package pl.op.dao;

import com.google.inject.Inject;
import java.io.Serializable;
import static java.lang.Math.log;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.op.model.auction.Auction;
import pl.op.model.cloud.Cloud;
import pl.op.model.cloud.CloudFilter;
import pl.op.model.contract.PPE;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Street;
import pl.op.model.user.UserApp;

public class CloudDao implements Serializable {

    private static final long serialVersionUID = -1643409711153472771L;

    @Inject
    CloudInterface cloudInterface;

    public List<Cloud> getClouds(CloudFilter cloudFilter) throws Exception {
        return cloudInterface.getClouds(cloudFilter);
    }
    
        public List<Cloud> getCloudsForCreator(CloudFilter cloudFilter) throws Exception {
        return cloudInterface.getCloudsForCreator(cloudFilter);
    }
    
    

    public List<String> getStreetsByCity(String city) throws Exception {
        return cloudInterface.getStreetsByCity(city);
    }

    public List<PPE> getPpeByCloudId(Cloud cloud) throws Exception {
        return cloudInterface.getPpeByCloudId(cloud);
    }
    
    public List<PPE> getPpeByCloudIdNoStereotype(Cloud cloud) throws Exception {
        return cloudInterface.getPpeByCloudIdNoStereotype(cloud);
    }

    public Integer getCloudsCount() throws Exception {
        return cloudInterface.getCloudsCount();
    }

    public Integer getAuctionOffersForAuctionsCount(Auction auction) throws Exception {
        return cloudInterface.getAuctionOffersForAuctionsCount(auction);
    }

    public void saveCloud(Cloud cloud) throws Exception {
        cloudInterface.saveCloud(cloud);
        if(!cloud.getAreas().isEmpty())
            saveCloudAreas(cloud, cloud.getAreas());
        if(!cloud.getCities().isEmpty())
            saveCloudCities(cloud, cloud.getCities());
        if(!cloud.getStreets().isEmpty())
            saveCloudStreets(cloud, cloud.getStreets());
    }

    public void saveUserCloud(UserApp user) throws Exception {
        cloudInterface.saveUserCloud(user);
    }
    
    

    public void saveCloudAreas(Cloud cloud, List<Area> areas) throws Exception {
        for(Area area : areas) {
            area.setCloudId(cloud.getCloudId());         
            cloudInterface.saveCloudArea(area);
        }
    }

    public void saveCloudCities(Cloud cloud, List<City> cities) throws Exception {
        for(City city : cities) {
            city.setCloudId(cloud.getCloudId());
            cloudInterface.saveCloudCity(city);
        }
    }

    public void saveCloudStreets(Cloud cloud, List<Street> streets) throws Exception {
        for(Street street : streets) {
            street.setCloudId(cloud.getCloudId());
            cloudInterface.saveCloudStreet(street);
        }
    }

    public void updateCloudMemberNo(Cloud cloud) throws Exception {
        cloudInterface.updateCloudMemberNo(cloud);
    }

    public Integer getPPECount(Cloud cloud) throws Exception {
        return cloudInterface.getPPECount(cloud);
    }

    public void updateCloud(Cloud cloud) throws Exception {
        cloudInterface.updateCloud(cloud);
    }

    public Integer getCloudsCount(CloudFilter cloudFilter) throws Exception {
        return cloudInterface.getCloudsCount(cloudFilter);
    }

    public List<UserApp> getCloudPotentialUsers(Cloud cloud) throws Exception {
        return cloudInterface.getCloudPotentialUsers(cloud);
    }

    public void deleteCloudUsers(Cloud cloud) throws Exception {
        cloudInterface.deleteCloudUsers(cloud);
    }

    public void deleteCloudUsersBatch(Cloud cloud, List<UserApp> list) throws Exception {
        cloudInterface.deleteCloudUsersBatch(cloud, list);
    }

    public List<UserApp> getUsersForCloud(Cloud cloud) throws Exception {
        return cloudInterface.getUsersForCloud(cloud);
    }

    public void updateCloudVolume(Cloud cloud) throws Exception {
        cloudInterface.updateCloudVolume(cloud);
    }

    public List<Cloud> getCloudsByPpeId(Integer ppeId) throws Exception {
        return cloudInterface.getCloudsByPpeId(ppeId);
    }
}