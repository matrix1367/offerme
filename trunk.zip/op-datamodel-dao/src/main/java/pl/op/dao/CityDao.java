package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import pl.op.model.dict.Address;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;

import com.google.inject.Inject;

public class CityDao implements Serializable {

	private static final long serialVersionUID = 8234624060313988111L;

	@Inject 
	CityInterface cityInterface;
	
	public void saveCity(City city) throws Exception {
		cityInterface.saveCity(city);
	}
	
	public void saveCityWithAreaId(City city, Integer areaId) throws Exception {
		cityInterface.saveCityWithAreaId(city,areaId);
	}
	
	public void deleteCity(City city) throws Exception {
		cityInterface.deleteCity(city);
	}

	public void updateCity(City city) throws Exception {
		cityInterface.updateCity(city);
	}
	
	public City getCityByAddress(Address address) throws Exception {
		return cityInterface.getCityByAddress(address);
	}

	public City getCity(City city) throws Exception {
		return cityInterface.getCity(city);
	}
	
	public City getCityBySymbol(String symbol) throws Exception {
		return cityInterface.getCityBySymbol(symbol);
	}
	
	public City getCitiesById(Integer id) throws Exception {
		return cityInterface.getCitiesById(id);
	}
	
	public List<City> getCitiesByName(String cityName) throws Exception {
		return cityInterface.getCitiesByName(cityName);
	}

	public List<City> getCities(City city) throws Exception {
		return cityInterface.getCities(city);
	}

	public List<City> getCitiesByAreas(List<Area> areas) throws Exception {
		return cityInterface.getCitiesByAreas(areas);
	}

	public List<City> searchCities(City city) throws Exception {
		return cityInterface.searchCities(city);
	}
	
	public List<City> getCitiesStarts(City city, @Param("cityStartsFrom") String cityStartsFrom) throws Exception {
		return cityInterface.getCities(city);
	}
	
	public List<City> getCitiesList() throws Exception {
		return cityInterface.getCitiesList();
	}
	
	public City getCityByStreetId(Integer id) throws Exception {
		return cityInterface.getCityByStreetId(id);
	}
	
	public Area getAreaByCityId(Integer id) throws Exception {
		return cityInterface.getAreaByCityId(id);
	}
}
