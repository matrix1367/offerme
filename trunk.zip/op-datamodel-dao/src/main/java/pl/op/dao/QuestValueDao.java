package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.question.PreferenceQuestion;
import pl.op.model.question.QuestionItem;
import pl.op.model.question.QuestionValue;

import com.google.inject.Inject;

public class QuestValueDao implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2879377651328831813L;

	@Inject
	QuestValueInterface questValueInterface;
	
	public QuestionValue getQuestionValue(PreferenceQuestion preferenceQuestion) throws Exception{
		return questValueInterface.getQuestionValue(preferenceQuestion);
	}
	
	public void saveQuestionValue(QuestionValue questionValue) throws Exception{
		questValueInterface.saveQuestionValue(questionValue);
	}	
	
	public void updateQuestionValue(QuestionValue questionValue) throws Exception{
		questValueInterface.updateQuestionValue(questionValue);
	}
}

