package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import com.google.inject.Inject;

import pl.op.settings.Settings;

public class SettingsDao implements Serializable {

	private static final long serialVersionUID = -2935167916617405712L;

	@Inject
	SettingsInterface settingsInterface;

	public List<Settings> getSettingsList(Settings settings) throws Exception {
		return settingsInterface.getSettingsList(settings);
	}

	public void updateSetting(Settings settings) throws Exception {
		settingsInterface.updateSetting(settings);
	}
	
	public Settings getSettingByType(String type) throws Exception {
		return settingsInterface.getSettingByType(type);
	}
	
	public void saveSetting(Settings setting) throws Exception {
		settingsInterface.saveSetting(setting);
	}
}
