package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.device.DeviceCategory;


import com.google.inject.Inject;

public class DeviceCategoryDao implements Serializable {

	private static final long serialVersionUID = -1643409711153472771L;
	
	@Inject
	DeviceCategoryInterface deviceCategoryInterface;

	public List<DeviceCategory> getDeviceCategories() throws Exception {
		return deviceCategoryInterface.getDeviceCategories();
	}
	public DeviceCategory getDevicesCategoriesByDeviceTypeId(Integer id) throws Exception {
		return deviceCategoryInterface.getDevicesCategoriesByDeviceTypeId(id);
	}
	public DeviceCategory getDevicesCategoriesById(Integer id) throws Exception {
		return deviceCategoryInterface.getDevicesCategoriesById(id);
	}
	public void saveDeviceCategory(DeviceCategory deviceCategory) throws Exception {
		deviceCategoryInterface.saveDeviceCategory(deviceCategory);
	}
	public void updateDeviceCategory(DeviceCategory deviceCategory) throws Exception {
		deviceCategoryInterface.updateDeviceCategory(deviceCategory);
	}
	public void deleteDeviceCategory(DeviceCategory deviceCategory) throws Exception {
		deviceCategoryInterface.deleteDeviceCategory(deviceCategory);
	}

}