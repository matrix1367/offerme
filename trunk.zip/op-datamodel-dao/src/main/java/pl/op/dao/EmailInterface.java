package pl.op.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;

import pl.op.model.dict.Email;

public interface EmailInterface {

    public List<Email> getEmailList() throws Exception;
    
    public List<Email> getEmailByFiltr(Email filtr) throws Exception;
    
    public Integer getEmailMaxId(String category) throws Exception;    
    
    public List<String> getCategory() throws Exception;

    public void saveEmail(Email email) throws Exception;
    
    public void saveEmailNoExist(Email email) throws Exception;
    
    public void updateEmail(Email email) throws Exception;

    public void deleteEmail(Email email) throws Exception;

    public List<Email> getEmailListPart(@Param("start") Integer start, 
          @Param("end")  Integer end, @Param("category") String category) throws Exception;
    
    public Integer getEmailCount() throws Exception;
}
