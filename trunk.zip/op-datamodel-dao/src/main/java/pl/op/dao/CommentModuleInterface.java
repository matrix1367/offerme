package pl.op.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import pl.op.model.comment.CommentModule;
import pl.op.model.comment.CommentTypeEnum;

public interface CommentModuleInterface {

	public void saveComment(CommentModule comment) throws Exception;

	public void updateComment(CommentModule comment) throws Exception;

	public void deleteComment(CommentModule comment) throws Exception;

	public List<CommentModule> getComments(@Param("objectId") Integer objectId, @Param("commentType") CommentTypeEnum commentType) throws Exception;

}
