package pl.op.dao;

import java.io.Serializable;
import java.util.List;

import pl.op.model.bonus.Event;
import pl.op.model.bonus.PointsRules;
import pl.op.model.user.UserApp;

import com.google.inject.Inject;

public class PointsRulesDao implements Serializable {

	private static final long serialVersionUID = -7398299461992620428L;
	
	@Inject
	PointsRulesInterface pointsRulesInterface;

	public List<PointsRules> getPointsRules() throws Exception {
		return pointsRulesInterface.getPointsRules();
	}

	public List<PointsRules> getBonusRules() throws Exception {
		return pointsRulesInterface.getBonusRules();
	}

	public List<PointsRules> getBonusRulesOnlyUsers(Boolean isActive) throws Exception {
		return pointsRulesInterface.getBonusRulesOnlyUsers(isActive);
	}

	public List<PointsRules> getBonusRulesByUser(UserApp userApp) throws Exception {
		return pointsRulesInterface.getBonusRulesByUser(userApp);
	}

	public List<PointsRules> getBonusRulesActive() throws Exception {
		return pointsRulesInterface.getBonusRulesActive();
	}
	
	public List<PointsRules> getPointsRulesByEvent(Event event) throws Exception {
		return pointsRulesInterface.getPointsRulesByEvent(event);
	}

	public List<PointsRules> getPointsRulesActive() throws Exception {
		return pointsRulesInterface.getPointsRulesActive();
	}

	public List<PointsRules> getBonusRulesActiveAndAccepted() throws Exception {
		return pointsRulesInterface.getBonusRulesActiveAndAccepted();
	}
	
	public List<PointsRules> getPointsRulesByEventActive(Event event) throws Exception {
		return pointsRulesInterface.getPointsRulesByEventActive(event);
	}
	
	public PointsRules getPointsRulesById(Integer id) throws Exception {
		return pointsRulesInterface.getPointsRulesById(id);
	}
	
	public void savePointsRules(PointsRules userPoints) throws Exception {
		pointsRulesInterface.savePointsRules(userPoints);
	}
	
	public void deletePointsRules(PointsRules userPoints) throws Exception {
		pointsRulesInterface.deletePointsRules(userPoints);
	}
	
	public void updatePointsRules(PointsRules userPoints) throws Exception {
		pointsRulesInterface.updatePointsRules(userPoints);
	}
	
}
