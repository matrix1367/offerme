package pl.op.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import pl.op.model.cloud.Cloud;
import pl.op.model.contract.PPE;
import pl.op.model.contract.PPEFilter;
import pl.op.model.contract.PPEStatus;
import pl.op.model.dict.Tariff;
import pl.op.model.user.UserApp;

public interface PPEInterface {
    public PPE getPPEById(Long ppeId) throws Exception;

    public List<PPE> getPPEs(PPE ppe) throws Exception;

    public Tariff getActualTariff(PPE ppe) throws Exception;

    public void savePPE(PPE ppe) throws Exception;

    public void updatePPE(PPE ppe) throws Exception;

    public void deletePPE(PPE ppe) throws Exception;

    public List<PPE> getPPEsByUser(UserApp user) throws Exception;

    public void updatePPEStatusToReady() throws Exception;

    public List<PPE> getPPEsByFilter(PPEFilter ppeFilter) throws Exception;

    public List<PPE> getPpesGroup(@Param("selectMode") String selectMode, @Param("userId") Integer userId,
            @Param("cityId") Integer cityId, @Param("areaId") Integer areaId,
            @Param("stereotypeId") Integer stereotypeId, @Param("tariffId") Integer tariffId) throws Exception;

    public void updatePPEValue(PPE ppe) throws Exception;

    public void updatePPEStatus(@Param("ppeId") Integer ppeId, @Param("ppeStatus") PPEStatus ppeStatus)
            throws Exception;
}
