package pl.op.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import pl.op.model.bonus.PointsRules;
import pl.op.model.bonus.UserPoints;
import pl.op.model.user.UserApp;

public interface UserPointsInterface {

	public List<UserPoints> getUserPoints() throws Exception;
	public List<UserPoints> getUserPointsByPointsRules(PointsRules pointsRules) throws Exception;
	public List<UserPoints> getUserPointsByUserApp(UserApp userApp) throws Exception;
	public List<UserPoints> getUserPointsIsBuy(@Param("pointsRulesIds") List<PointsRules> pointsRules, @Param("isGranted") Boolean isGranted) throws Exception;
	public List<UserPoints> getUserPointsByUserAppIsBuy(@Param("pointsRulesIds") List<PointsRules> pointsRules, @Param("userId") Integer userId) throws Exception;
	public List<UserPoints> getUserPointsByPointsRulesAndUserApp(@Param("pointsRulesId") Integer pointsRulesId, @Param("userId") Integer userId) throws Exception;
	public List<UserPoints> getUserPointsNotGrantedByPointsRulesAndUserApp(@Param("pointsRulesId") Integer pointsRulesId, @Param("userId") Integer userId) throws Exception;
	public List<UserPoints> getUserPointsGrantedByPointsRulesAndUserApp(@Param("pointsRulesId") Integer pointsRulesId, @Param("userId") Integer userId) throws Exception;
	public UserPoints getUserPointsLastGrantedByPointsRulesAndUserApp(@Param("pointsRulesId") Integer pointsRulesId, @Param("userId") Integer userId) throws Exception;
	public UserPoints getUserPointsLastNotGrantedByPointsRulesAndUserApp(@Param("pointsRulesId") Integer pointsRulesId, @Param("userId") Integer userId) throws Exception;
	public UserPoints getUserPointsById(Integer id) throws Exception;
	public void saveUserPoints(UserPoints userPoints) throws Exception;
	public void deleteUserPoints(UserPoints userPoints) throws Exception;
	public void updateUserPoints(UserPoints userPoints) throws Exception;
}
