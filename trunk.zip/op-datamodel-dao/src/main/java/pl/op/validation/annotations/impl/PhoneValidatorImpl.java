package pl.op.validation.annotations.impl;

import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.validator.Validator;

import pl.op.validation.annotations.PhoneValidator;

public class PhoneValidatorImpl implements Validator<PhoneValidator>{
	private Logger log = LoggerFactory.getLogger(PhoneValidatorImpl.class);

	public void initialize(PhoneValidator arg0) {
		
	}

	public boolean isValid(Object phone) {
		
		String phoneValue = phone.toString();
		boolean result = false;
		
		boolean phoneRegex = Pattern.matches(  
        "^[-0-9 ()\\+]*$",  phoneValue);

			
		if(phoneRegex){
			if(phoneValue.length()==3 || phoneValue.length()==12){
				result = true;
			}
		}
		
		return result;
	}
}
