package pl.op.validation.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.hibernate.validator.ValidatorClass;

import pl.op.validation.annotations.impl.PhoneValidatorImpl;


@ValidatorClass(PhoneValidatorImpl.class)
@Target({ElementType.FIELD, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface PhoneValidator {
	String message() default "Niepoprawny numer telefonu";
	
}
