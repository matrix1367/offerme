package pl.op.validation.annotations.impl;

import org.hibernate.validator.Validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.validation.Validations;
import pl.op.validation.annotations.NipValidator;

public class NipValidatorImpl implements Validator<NipValidator>{
	private Logger log = LoggerFactory.getLogger(NipValidatorImpl.class);

	public void initialize(NipValidator arg0) {
		
	}

	public boolean isValid(Object nip) {
		
		String nipNormalized = normalize(nip.toString());
		
		
		boolean result = true;
		
//		boolean nipNatural = Pattern.matches(  
//                "^[0-9]{3}[0-9]{3}[0-9]{2}[0-9]{2}$",  nipNormalized);
//		boolean nipLegal = Pattern.matches(  
//                "^[0-9]{3}[0-9]{2}[0-9]{2}[0-9]{3}$",  nipNormalized);
		
		
		if(nipNormalized.length()==10){
			try {
				result = Validations.validNip(nipNormalized);
			} catch (Exception e) {
				log.error("",e);
			}
		}
		else{
			return false;
		}

		
		return result;
	}
	
	public static String normalize(String nip) {
		return nip.replaceAll("[^\\d]", "");
	}
		
}
