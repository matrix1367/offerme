package pl.op.validation.annotations.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.validator.Validator;

import pl.op.validation.Validations;
import pl.op.validation.annotations.NRBValidator;
import pl.op.validation.annotations.NipValidator;

public class NRBValidatorImpl implements Validator<NRBValidator>{
	private Logger log = LoggerFactory.getLogger(NRBValidatorImpl.class);

	public void initialize(NipValidator arg0) {
		
	}

	public boolean isValid(Object iban) {
		boolean result = true;
		try {
			result = Validations.isValidIban("PL"+(String) iban);
		} catch (Exception e) {
			log.error("",e);
		}
		
		return result;
	}

	public void initialize(NRBValidator arg0) {
				
	}
}
