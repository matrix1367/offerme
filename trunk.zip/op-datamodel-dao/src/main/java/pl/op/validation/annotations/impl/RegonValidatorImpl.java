package pl.op.validation.annotations.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.validator.Validator;

import pl.op.validation.Validations;
import pl.op.validation.annotations.RegonValidator;

public class RegonValidatorImpl implements Validator<RegonValidator>{
	private Logger log = LoggerFactory.getLogger(RegonValidatorImpl.class);

	public void initialize(RegonValidator arg0) {
		
	}
	
	public boolean isValid(Object regon) {
		boolean result = true;
		try {
			result = Validations.validRegon((String)regon);
		} catch (Exception e) {
			log.error("",e);
		}
		
		return result;
	}
}
