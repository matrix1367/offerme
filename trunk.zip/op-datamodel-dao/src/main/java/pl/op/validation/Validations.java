package pl.op.validation;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Validations {

    private static Logger log = LoggerFactory.getLogger(Validations.class);

    /**
     * Walidacja PESEL-u.
     * 
     * @param pesel
     *            pesel do walidacji
     * @param birthday
     *            data urodzenia
     * @return wynik walidacji 0 - OK 1 - niezgodnosc dlugosci 2 - bledna suma
     *         kontrolna 3 - niezgodnosc daty urodzenia 4 - niezgodnosc plci
     * 
     */
    public static int validPesel(String pesel, Date birthday) throws Exception {
        log.info("Pesel: >>" + pesel + "<<");

        int res = 0;
        int suma = 0;
        int bit = 0;
        int[] maska = new int[] { 1, 3, 7, 9, 1, 3, 7, 9, 1, 3 };

        String birthDate = null;
        if(birthday != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            birthDate = sdf.format(birthday);
        }
        if(birthDate == null) {
            birthDate = "";
        }

        if(pesel.length() != 11) {
            res = 1;
        } else {
            pesel = pesel.replaceAll(" ", "");
            if(pesel.length() != 11) {
                res = 1;
            } else {
                for(int i = 0; i < 10; i++) {
                    log.info(Integer.parseInt("" + pesel.charAt(i)) + " * " + maska[i]);
                    suma += Integer.parseInt("" + pesel.charAt(i)) * maska[i];
                    log.info("suma: " + suma);
                }
                suma = suma % 10;
                bit = 10 - suma;
                if(bit == 10) {
                    bit = 0;
                }
                if(bit - Integer.parseInt("" + pesel.charAt(pesel.length() - 1)) != 0) {
                    res = 2;
                }
                log.info("birthDate: " + birthDate);
                if(birthDate.length() == 10) {
                    String[] data = birthDate.split("-");
                    // dzien
                    log.info("data[2]: " + data[2] + " = " + pesel.substring(4, 6));
                    if(!data[2].equals(pesel.substring(4, 6))) {
                        res = 3;
                    } else {
                        // miesiac
                        int mm = Integer.parseInt(pesel.substring(2, 4));
                        log.info("mm: " + mm + " data[1]: " + Integer.parseInt(data[1]));
                        log.info("yy: " + data[0].substring(2, 4) + " data[1]: " + pesel.substring(0, 2));
                        int yy = Integer.parseInt(data[0].substring(0, 2)); // wiek
                        if(yy == 18 && (mm != (Integer.parseInt(data[1]) + 80))) {
                            res = 3;
                        } else if(yy == 19 && (mm != (Integer.parseInt(data[1]) - 0))) {
                            res = 3;
                        } else if(yy == 20 && (mm != (Integer.parseInt(data[1]) + 20))) {
                            res = 3;
                        } else if(yy == 21 && (mm != (Integer.parseInt(data[1]) + 40))) {
                            res = 3;
                            // rok
                        } else if(!data[0].substring(2, 4).equals(pesel.substring(0, 2))) {
                            res = 3;
                        }
                    }
                }
            }
        }

        return res;

    }

    /**
     * Weryfikacja numeru REGON
     * 
     * @param regon
     * @return true jesli prawidlowy
     */
    public static boolean validRegon(String regon) {
        regon = trimInput(regon);
        int rsize = regon.length();
        if(!((rsize == 9) || (rsize == 14))) {
            return false;
        }
        int[] weights = { 8, 9, 2, 3, 4, 5, 6, 7 };
        int j = 0, sum = 0, control = 0;
        int csum = new Integer(regon.substring(rsize - 1)).intValue();
        for(int i = 0; i < rsize - 1; i++) {
            char c = regon.charAt(i);
            j = new Integer(String.valueOf(c)).intValue();
            sum += j * weights[i];
        }
        control = sum % 11;
        if(control == 10) {
            control = 0;
        }
        return (control == csum);
    }

    /**
     * Weryfikacja numeru NIP
     * 
     * @param nip
     * @return true jesli prawidlowy
     */
    public static boolean validNip(String nip) {        
        nip = trimInput(nip);
        log.debug("validNip: " + nip);
        int nsize = nip.length();
        if(nsize != 10) {
            return false;
        }
        int[] weights = { 6, 5, 7, 2, 3, 4, 5, 6, 7 };
        int j = 0, sum = 0, control = 0;
        int csum = new Integer(nip.substring(nsize - 1)).intValue();
    
        for(int i = 0; i < nsize - 1; i++) {
            char c = nip.charAt(i);
            j = new Integer(String.valueOf(c)).intValue();
            sum += j * weights[i];
        }
        control = sum % 11;        
        return (control == csum);
    }

    /**
     * Weryfikacje numeru IBAN
     * 
     * @param iban
     * @return true jeśli prawidłowy
     */
    public static boolean isValidIban(String iban) {
        // Algorytm (c) R.J.Żyłła 2000-2004 */
        // 0. Zamiana na wielkie litery i usunięcie śmieci
        // i spacji
        // WSZ - niewycinanie śmieci, tylko spacje
        // iban = iban.toUpperCase().replaceAll("[\\p{Punct}\\p{Space}]*", "");
        iban = iban.toUpperCase().replaceAll("[\\p{Space}]*", "");
        if(!iban.matches("^[A-Z]{2}[0-9]{12,}"))
            return false;
        // if (iban.length() < 16)
        // return false;
        // 1. Pierwsze 4 znaki na koniec
        iban = iban.substring(4, iban.length()) + iban.substring(0, 4);
        // 2. Litery na cyfry
        for(int i = 0; i < iban.length(); i++) {
            char c = iban.charAt(i);
            if(Character.isUpperCase(c)) {
                int code = Character.getNumericValue(c);
                iban = iban.substring(0, i) + code + iban.substring(i + 1, iban.length());
            }
        }
        // 3. Modulo 97
        int mod = 0;
        int isize = iban.length();
        for(int i = 0; i < isize; i = i + 6) {
            try {
                mod = Integer.parseInt("" + mod + iban.substring(i, i + 6), 10) % 97;
            } catch (StringIndexOutOfBoundsException e) {
                return false;
            }
        }
        return (mod == 1);
    }

    private static String trimInput(String input) {
        return input.replaceAll("\\-*", "");
    }
}
