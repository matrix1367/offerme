#!/bin/bash

IPDEVLOCAL="192.168.1.77"
IPDEV="192.168.1.218"
IPOGICOM="ogarniamprad.pl"

function build()
{
echo "==========================="
echo " Budowanie obrazu"
echo "==========================="



file="/home/dev/workspace/trunk/op-web/src/main/resources/messages_en.properties"
file2="/home/dev/workspace/trunk/op-web/src/main/resources/messages_en.properties.tmp"
head -n -1 $file > $file2; 
echo "build.time=`date`" >> $file2 ;
rm -rf $file
mv $file2 $file


file="/home/dev/workspace/trunk/op-web/src/main/resources/messages_pl.properties"
file2="/home/dev/workspace/trunk/op-web/src/main/resources/messages_pl.properties.tmp"
head -n -1 $file > $file2;
echo "build.time=`date`" >> $file2 ;
rm -rf $file
mv $file2 $file


mvn clean install

}

function cp_local() {

}


function pressAnyKay() {
	read -p "Press [Enter] key to continue ....";
}


while :
do
    clear
    cat<<EOF
    ==============================
    System budowy Ogarniamprad.pl
    ------------------------------
    Please enter your choice:

    1) Build && install local dev server
    2) Only build 
    3) Copy Hijka to dev
    Q) Quit
    ------------------------------
EOF
    read -n1 -s
    case "$REPLY" in
    "1")  build; pressAnyKay ;;
    "2")  echo "you chose choice 2";  pressAnyKay ;;
    "3")  echo "you chose choice 3" ;;
    "Q")  exit                      ;;
    "q")  echo "case sensitive!!"   ;; 
     * )  echo "invalid option"     ;;
    esac
    sleep 1
done
