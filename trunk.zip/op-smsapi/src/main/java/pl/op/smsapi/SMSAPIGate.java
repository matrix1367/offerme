package pl.op.smsapi;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.configuration.CompositeConfiguration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.SystemConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Charsets;

public class SMSAPIGate {
	private static final Pattern TELEPHONE_NUMBER_PATTERN = Pattern
			.compile("\\+?(48)?(\\d{9})");
	private static final Logger log = LoggerFactory.getLogger(SMSAPIGate.class);
	private static final SMSAPIGate defaultInstance = new SMSAPIGate();

	enum Mode {NO_REQUESTS, TEST, PRODUCTION};
	
	private String apiUrlMain;
	private String apiUrlBckp;
	private String apiUsername;
	private String apiPassword;
	private Mode mode;

	private SMSAPIGate() {
		log.debug("Loadnig configuration for SMSAPI...");
		
		try {
			CompositeConfiguration config = new CompositeConfiguration();
			config.setThrowExceptionOnMissing(true);
			
			config.addConfiguration(new SystemConfiguration());
			
			try {
				config.addConfiguration(new PropertiesConfiguration("smsapi-config.properties"));
			} catch (ConfigurationException e) {
				log.warn("Can't load smsapi-config.properties");
				log.debug("Can't load smsapi-config.properties", e);
			}
			
			try {
				config.addConfiguration(new PropertiesConfiguration("portal-ext.properties"));
			} catch (ConfigurationException e) {
				log.warn("Can't load portal-ext.properties");
				log.debug("Can't load portal-ext.properties", e);
			}
			
			if (log.isTraceEnabled()){
				log.trace("smsapi.account.username: " + config.getString("smsapi.account.username"));
				log.trace("smsapi.account.password: " + config.getString("smsapi.account.password"));
				log.trace("smsapi.url: " + config.getString("smsapi.url.http"));
				log.trace("smsapi.urlbckp: "+ config.getString("smsapi.url.http.bckp"));
			}

			apiUsername = config.getString("smsapi.account.username");
			apiPassword = config.getString("smsapi.account.password");
			apiUrlMain = config.getString("smsapi.url");
			apiUrlBckp = config.getString("smsapi.url.bckp");
			try {
				mode = Mode.valueOf(config.getString("smsapi.mode", "NO_REQUESTS"));
			} catch (IllegalArgumentException  e) {
				log.warn("Illegal smsapi.mode specified, it can be one of "+Arrays.toString(Mode.values())+". Failed to defaults.");
				throw e;
			}
			
		} catch (Exception e) {
			this.mode = Mode.NO_REQUESTS;
			
			log.info("Key: " + e.getMessage() + " (switch to debug to see stacktrace)");
			log.debug("Error details: ", e);
			log.warn("Incomplete configuration. Defaulted to " + mode + " mode.");
		}
		
		if (log.isDebugEnabled()){
			log.debug(String.format("SMSAPI is ready for use. Configuration bellow:\n" +
					"apiUsername: " + apiUsername +
					"\napiPassword: " + apiPassword +
					"\napiUrlMain: " + apiUrlMain +
					"\napiUrlBckp: " + apiUrlBckp +
					"\nmode: " + mode));
		}
	};

	public static SMSAPIGate getDefault() {
		return defaultInstance;
	}

	java.util.logging.Logger smsLog = java.util.logging.Logger.getLogger("pl.op.smsapi.messages");
	public Response send(Request req) throws SMSAPIException {
		switch (mode) {
			case NO_REQUESTS:
				log.warn("SMSAPIGate in "+mode+" mode. Request not send.");
				return Response.OK;
			case TEST:
				log.warn("SMSAPIGate in "+mode+" mode. Request will be send with additional 'test=1' parameter.");
				req.addParam(Param.TEST, "1");
				break;
		}
		
		req.addParam(Param.USERNAME, apiUsername);
		req.addParam(Param.PASSWORD, apiPassword);
		
		System.out.println("queryString: " + req.getQuery());
		
		try {
			System.out.println("fullURL: " + req.getURL(apiUrlMain));
			URL url = req.getURL(apiUrlMain);
			try {
				HttpURLConnection connection = (HttpURLConnection) url.openConnection();
				InputStream inputStream = connection.getInputStream();
				byte[] buff = new byte[64];
				int readLen = inputStream.read(buff);
				String response = new String(buff, 0, readLen, Charsets.UTF_8);
				return Response.valueOf(response);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//XXX get rid of this
		return null;
	}

	public String sendTemplateMessage(String phoneNumber, TemplateMessage msg)
			throws SMSAPIException {
		
		Request req =  new Request();
		{
			int idx = 0;
			for (Param param : Param.params) {
				req.addParam(param, msg.getParams()[idx++]);
			}
		}
		req.addParam(Param.TEMPLATE, msg.getTemplate().getTemplateName());
		req.addParam(Param.TO, getValidNumber(phoneNumber));

		Response resp = send(req);
		if (resp.isOK()){
			smsLog.info(phoneNumber + " " + msg.getTemplate().getTemplateName() + Arrays.toString(msg.getParams()));
			return resp.getId();
		} 
		
		throw new SMSAPIException(resp.getErrorCode());
	}

	public String sendTextMessage(String phoneNumber, TextMessage msg)
			throws SMSAPIException {
		
		
		Request req = new Request();
		req.addParam(Param.TO, getValidNumber(phoneNumber));
		req.addParam(Param.MESSAGE, msg.getPayloadText());

		System.out.format("sending to phone:'%s' message: '%s'\n", phoneNumber,
				msg.getPayloadText());
		
		System.out.println("queryString: " + req.getQuery());
		
		Response resp = send(req);
		if (resp.isOK()){
			smsLog.info(phoneNumber+" "+msg);
			return resp.getId();
		} 
		
		throw new SMSAPIException(resp.getErrorCode());
	}

	public String getValidNumber(String number) throws SMSAPIException {
		Matcher matcher = TELEPHONE_NUMBER_PATTERN.matcher(number);
		if (!matcher.matches()){
			throw new SMSAPIException(13);
		} 
		
		return matcher.group(2);
	}
}
