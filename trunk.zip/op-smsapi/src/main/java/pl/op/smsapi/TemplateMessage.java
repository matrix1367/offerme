package pl.op.smsapi;

public class TemplateMessage {
	private final Template template;
	private final String[] params = new String[4];
	
	public TemplateMessage(Template template, String... params) {
		if (params.length > 4){
			throw new IllegalArgumentException("Max 4 params allowed");
		}
		this.template = template;
		System.arraycopy(params, 0, this.params, 0, Math.min(params.length, this.params.length));
	}

	public Template getTemplate() {
		return template;
	}

	public String[] getParams() {
		return params;
	}
	
}
