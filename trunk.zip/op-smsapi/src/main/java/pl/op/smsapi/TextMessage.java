package pl.op.smsapi;

public class TextMessage {
	final static int partLen = 160;
	final static int partLenSpecial = 70;
	final static int maxLen = 459;
	final static int maxLenSpecial = 201;
	
	final String payloadText;
	
	public TextMessage(String payloadText) {
		//TODO: verify length before assignment
		this.payloadText = payloadText;
	}

	public String getPayloadText() {
		return payloadText;
	}
	
	@Override
	public String toString() {
		return "SMS: "+payloadText;
	}
}
