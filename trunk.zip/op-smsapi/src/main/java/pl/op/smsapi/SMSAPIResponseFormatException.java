package pl.op.smsapi;

import java.security.InvalidParameterException;

public class SMSAPIResponseFormatException extends InvalidParameterException{ 
	final static String MSG_FORMAT = "Invalid response: %s";
	private static final long serialVersionUID = 4689542615896698499L;
	
	private final String resp; 

	public SMSAPIResponseFormatException(String invalidResponse) {
		resp = invalidResponse;
	}
	@Override
	public String getMessage() {
		return String.format(MSG_FORMAT, resp);
	}
}
