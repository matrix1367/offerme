package pl.op.smsapi;

public enum Template {
	REGISTER("registerMsg");
	
	private final String templateName;
	
	private Template(String templateName) {
		this.templateName = templateName;
	}
	
	public TemplateMessage createMessage(String... params){
		return new TemplateMessage(this, params);
	}

	public String getTemplateName() {
		return templateName;
	}
	
}
