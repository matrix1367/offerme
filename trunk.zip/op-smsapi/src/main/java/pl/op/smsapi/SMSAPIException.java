package pl.op.smsapi;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class SMSAPIException extends Exception {

	private static final long serialVersionUID = 9159969252116440895L;
	private final static String MESSAGE_FORMAT = "[%03d] %s";
	
	private final static Map<Integer, String> codeDescriptions;
	static{
		HashMap<Integer, String> desc = new HashMap<Integer, String>(32);
		desc.put(8, "Błąd w odwołaniu (Prosimy zgłośić)");
		desc.put(11, "Zbyt długa lub brak wiadomości lub ustawiono parametr nounicode i pojawiły się znaki specjalne w wiadomości. Dla wysyłki VMS błąd oznacz brak pliku WAV lub treści TTS.");
		desc.put(12, "Wiadomość zawiera ponad 160 znaków (gdy użyty parametr &single=1)");
		desc.put(13, "Nieprawidłowy numer odbiorcy");
		desc.put(14, "Nieprawidłowe pole nadawcy");
		desc.put(17, "Nie można wysłać FLASH ze znakami specjalnymi");
		desc.put(18, "Nieprawidłowa liczba parametrów");
		desc.put(19, "Za dużo wiadomości w jednym odwołaniu");
		desc.put(20, "Nieprawidłowa liczba parametrów IDX");
		desc.put(21, "Wiadomość MMS ma za duży rozmiar (maksymalnie 100kB)");
		desc.put(22, "Błędny format SMIL");
		desc.put(23, "Błąd pobierania pliku dla wiadomości MMS lub VMS");
		desc.put(24, "Błędny format pobieranego pliku");
		desc.put(30, "Brak parametru UDH jak podany jest datacoding=bin");
		desc.put(31, "Błąd konwersji TTS");
		desc.put(32, "Nie można wysyłać wiadomości Eco, MMS i VMS na zagraniczne numery.");
		desc.put(40, "Brak grupy o podanej nazwie");
		desc.put(41, "Wybrana grupa jest pusta (brak kontaktów w grupie)");
		desc.put(101, "Niepoprawne lub brak danych autoryzacji");
		desc.put(102, "Nieprawidłowy login lub hasło");
		desc.put(103, "Brak punków dla tego użytkownika");
		desc.put(104, "Brak szablonu");
		desc.put(105, "Błędny adres IP (włączony filtr IP dla interfejsu API)");
		desc.put(200, "Nieudana próba wysłania wiadomości");
		desc.put(201, "Wewnętrzny błąd systemu (prosimy zgłosić)");
		desc.put(300, "Nieprawidłowa wartość pola points (przy użyciu pola points jest wymagana wartość 1)");
		desc.put(301, "ID wiadomości nie istnieje");
		desc.put(400, "Nieprawidłowy ID statusu wiadomości");
		desc.put(999, "Wewnętrzny błąd systemu (prosimy zgłosić)");
		
		codeDescriptions = Collections.unmodifiableMap(desc);
	}
	
	private final int errorCode;
	
	public SMSAPIException(int errorCode) {
		super(String.format(MESSAGE_FORMAT,
				errorCode,
				codeDescriptions.containsKey(errorCode)?codeDescriptions.get(errorCode):"Wystąpił niezdefiniowany błąd"));
		
		this.errorCode = Integer.valueOf(errorCode);
	}

	public int getErrorCode() {
		return errorCode;
	}
}
