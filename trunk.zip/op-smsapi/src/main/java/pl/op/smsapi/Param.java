package pl.op.smsapi;

import java.util.Collections;
import java.util.EnumSet;
import java.util.Locale;
import java.util.Set;

enum Param {
	USERNAME, PASSWORD, TO, GROUP, MESSAGE,
	TEMPLATE, PARAM1, PARAM2, PARAM3, PARAM4,
	FROM, ENCODING, FLASH, TEST, DETAILS, DATE, DATACODING, IDX, SINGLE, ECO, NOUNICODE, FAST;
	
	public static final Set<Param> params = Collections.unmodifiableSet(EnumSet.range(PARAM1, PARAM4));
	
	final private String attrName;
	
	private Param() {
		this.attrName = this.name().toLowerCase(Locale.ENGLISH);
	}
	
	String getAttrName(){
		return attrName;
	}
	
	String getQueryFragment(Object value){
		return getAttrName() + "=" + (value == null ? "" : value.toString());
	}
}
