package pl.op.smsapi;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.Map;

class Request {
	Map<Param, String> requestParams = new EnumMap<Param, String>(Param.class);
	
	public void addParam(Param param, String value){
		requestParams.put(param, value);
	}
	
	public String getParam(Param param){
		return requestParams.get(param);
	}
	
	public String getQuery(){
		StringBuilder sb = new StringBuilder();
		for(Iterator<Param> it = requestParams.keySet().iterator(); it.hasNext();){
			Param p = it.next();
			sb.append(p.getQueryFragment(requestParams.get(p)));
			if (it.hasNext()){
				sb.append('&');
			}
		}
		return sb.toString();
	}
	
	public URL getURL(String baseUrlSpec) throws MalformedURLException, URISyntaxException{
		URI uri = URI.create(baseUrlSpec);
		URI fullURI = new URI(uri.getScheme(), uri.getAuthority(), uri.getPath(), getQuery(), null);
		return fullURI.toURL();
	}
}
