package pl.op.smsapi;

class Response {
	public enum Type {OK, ERROR};
	
	public final static Response OK = new Response(Type.OK, "12345");
	
	final Type type;
	final String idcode;

	public Response(Type type, String idcode){
		this.type = type;
		this.idcode = idcode;
		
		if(type.equals(Type.ERROR)){
			Integer.valueOf(idcode);
		}
	}
	
	public Type getType() {
		return type;
	}
	
	public String getId() {
		if (Type.OK == this.type){
			return idcode;
		}
		throw new IllegalStateException("Can't obtain id from error response");
	}
	
	public int getErrorCode() {
		if (Type.ERROR == this.type){
			return Integer.valueOf(this.idcode);
		}
		throw new IllegalStateException("Can't obtain error code. No error occured");
	}
	
	public boolean isOK(){
		return Type.OK.equals(type);
	}
	
	@Override
	public String toString() {
		return type+":"+idcode;
	}
	static public Response valueOf(String s) throws SMSAPIResponseFormatException{
		String[] tokens = s.split(":");
		try {
			if (tokens.length > 1) {
				if ("OK".equals(tokens[0])) {
					return new Response(Type.OK, tokens[1]);
				}
				if ("ERROR".equals(tokens[0])) {
					return new Response(Type.ERROR, tokens[1]);
				}
			}
		} catch (NumberFormatException e) {
			//fall through
		}
		throw new SMSAPIResponseFormatException(s);
	}
}
