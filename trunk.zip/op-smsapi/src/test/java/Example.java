import pl.op.smsapi.SMSAPIException;
import pl.op.smsapi.SMSAPIGate;
import pl.op.smsapi.Template;
import pl.op.smsapi.TemplateMessage;
import pl.op.smsapi.TextMessage;


public class Example {
	public static void main(String[] args)  throws SMSAPIException {
		SMSAPIGate gate = SMSAPIGate.getDefault();
		long t = System.currentTimeMillis();
//		for(int i = 0; i<100;i++)
		//send text message
		{
			TextMessage msg = new TextMessage("test");
			System.out.println(gate.sendTextMessage("48507301166", msg));
		}
		t = System.currentTimeMillis() - t;
		System.out.println("took: "+t+" ms.");
		//send template message
//		{
//			TemplateMessage tmsg = new TemplateMessage(Template.REGISTER, "heh", "param2", "Zażółć gęślą jaźń");
//			gate.sendTemplateMessage("48123456789", tmsg);
//		}
	}
}
