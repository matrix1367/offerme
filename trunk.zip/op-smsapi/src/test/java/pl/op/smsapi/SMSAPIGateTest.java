//package pl.op.smsapi;
//
//import static org.junit.Assert.*;
//
//import org.junit.Test;
//
//import pl.op.smsapi.SMSAPIException;
//import pl.op.smsapi.SMSAPIGate;
//
//public class SMSAPIGateTest {
//
//	@Test
//	public void testGetValidNumberPlus() throws SMSAPIException {
//		String nr = SMSAPIGate.getDefault().getValidNumber("+48123456789");
//		assertEquals("123456789", nr);
//	}
//
//	@Test
//	public void testGetValidNumber48() throws SMSAPIException {
//		String nr = SMSAPIGate.getDefault().getValidNumber("48123456789");
//		assertEquals("123456789", nr);
//	}
//	
//	@Test
//	public void testGetValidNumberPure() throws SMSAPIException {
//		String nr = SMSAPIGate.getDefault().getValidNumber("123456789");
//		assertEquals("123456789", nr);
//	}
//
//	@Test
//	public void testGetValidBegins48() throws SMSAPIException {
//		String nr = SMSAPIGate.getDefault().getValidNumber("481231231");
//		assertEquals("481231231", nr);
//	}
//
//	@Test
//	public void testGetValidBeginsPlus48() throws SMSAPIException {
//		String nr = SMSAPIGate.getDefault().getValidNumber("+481231231");
//		assertEquals("481231231", nr);
//	}
//	
//	@Test(expected=SMSAPIException.class)
//	public void testGetInValidTooShort() throws SMSAPIException {
//		SMSAPIGate.getDefault().getValidNumber("12345678");
//	}
//	
//	@Test(expected=SMSAPIException.class)
//	public void testGetInValidTooLong() throws SMSAPIException {
//		SMSAPIGate.getDefault().getValidNumber("1234567891");
//	}
//	
//	@Test(expected=SMSAPIException.class)
//	public void testGetInValidText() throws SMSAPIException {
//		SMSAPIGate.getDefault().getValidNumber("1234d3123");
//	}
//	
//	@Test(expected=SMSAPIException.class)
//	public void testGetInValid() throws SMSAPIException {
//		SMSAPIGate.getDefault().getValidNumber("+49123456789");
//	}
//}
