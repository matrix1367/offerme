//package pl.op.smsapi;
//
//import static org.junit.Assert.*;
//import org.junit.Test;
//
//import pl.op.smsapi.Response;
//import pl.op.smsapi.SMSAPIResponseFormatException;
//
//
//public class ResponseParseTest {
//
//	@Test
//	public void okTest() {
//		String response = "OK:17101000090360359:0.14";
//		Response resp = Response.valueOf(response);
//		assertEquals(Response.Type.OK, resp.getType());
//		assertEquals("17101000090360359", resp.getId());
//	}
//	
//	@Test
//	public void errorTest(){
//		String response = "ERROR:102";
//		Response resp = Response.valueOf(response);
//		assertEquals(Response.Type.ERROR, resp.getType());
//		assertEquals(102, resp.getErrorCode());
//	}
//
//	@Test(expected=SMSAPIResponseFormatException.class)
//	public void emptyString(){
//		String response = "";
//		Response.valueOf(response);
//	}
//
//	@Test(expected=SMSAPIResponseFormatException.class)
//	public void invalidTest(){
//		String response = "internal server error";
//		Response.valueOf(response);
//	}
//
//	@Test(expected=SMSAPIResponseFormatException.class)
//	public void wrongTest(){
//		String response = "WRONG:12092";
//		Response.valueOf(response);
//	}
//	
//	@Test(expected=SMSAPIResponseFormatException.class)
//	public void missingId(){
//		String response = "OK:";
//		Response.valueOf(response);
//	}
//	
//	@Test
//	public void notNumberTest(){
//		String response = "OK:12x092:0.7";
//		Response resp = Response.valueOf(response);
//		assertEquals("12x092", resp.getId());
//	}
//	
//	@Test(expected=SMSAPIResponseFormatException.class)
//	public void notNumberErrorTest(){
//		String response = "ERROR:12x092:0.7";
//		Response.valueOf(response);
//	}
//}
