#!/bin/bash


file="/home/dev/workspace/trunk/op-web/src/main/resources/messages_en.properties"
file2="/home/dev/workspace/trunk/op-web/src/main/resources/messages_en.properties.tmp"
head -n -1 $file > $file2; 
echo "build.time=`date`" >> $file2 ;
rm -rf $file
mv $file2 $file


file="/home/dev/workspace/trunk/op-web/src/main/resources/messages_pl.properties"
file2="/home/dev/workspace/trunk/op-web/src/main/resources/messages_pl.properties.tmp"
head -n -1 $file > $file2;
echo "build.time=`date`" >> $file2 ;
rm -rf $file
mv $file2 $file


mvn clean install
##ssh root@192.168.1.77 /u01/apache-tomcat-7.0.34/bin/clear.sh
scp /home/dev/workspace/trunk/op-web/target/op-web-1.0-SNAPSHOT.war root@192.168.1.77:/u01/apache-tomcat-7.0.34/webapps/op-web.war

mplayer ~/smokin.wav 
