//package pl.smsapi;
//
//import org.apache.log4j.BasicConfigurator;
//import org.apache.log4j.Level;
//import org.apache.log4j.Logger;
//import org.junit.BeforeClass;
//import org.junit.Test;
//
//import pl.op.smsapi.SMSAPIException;
//import pl.op.smsapi.SMSAPIGate;
//import pl.op.smsapi.TextMessage;
//
//public class SMSAPITest {
//	Logger log = Logger.getLogger(SMSAPITest.class);
//	
//	@BeforeClass
//	static public void configure(){
//		BasicConfigurator.configure();
//		Logger.getRootLogger().setLevel(Level.INFO);
//	}
//	
//	@Test
//	public void test() throws SMSAPIException {
//		SMSAPIGate gate = SMSAPIGate.getDefault();
//		long t = System.currentTimeMillis();
////		for(int i = 0; i<100;i++)
//		//send text message
//		{
//			TextMessage msg = new TextMessage("test");
//			log.info(gate.sendTextMessage("48507301166", msg));
//		}
//		t = System.currentTimeMillis() - t;
//		log.info("took: "+t+" ms."); 
//	}
//
//}
