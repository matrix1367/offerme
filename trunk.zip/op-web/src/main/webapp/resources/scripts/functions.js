$(document).ready(function() {

	var speed = 7000;
	var run = setInterval('rotate()', speed);
	
	var item_width = $('#slides li').outerWidth(); 
	var left_value = item_width * (-1); 

	$('#slides li:first').before($('#slides li:last'));
	$('#slides ul').css({'left' : left_value});
	
	$('#slides').hover(
		function() {
			clearInterval(run);
		}, 
		function() {
			run = setInterval('rotate()', speed);	
		}
	); 
});
  
function rotate() {
	var item_width = $('#slides li').outerWidth();
	var left_value = item_width * (-1); 
	var left_indent = parseInt($('#slides ul').css('left')) - item_width;
	
	$('#slides ul').animate({'left' : left_indent}, 500, function () {
		$('#slides li:last').after($('#slides li:first'));
		$('#slides ul').css({'left' : left_value});
	});
	
	return false;
}