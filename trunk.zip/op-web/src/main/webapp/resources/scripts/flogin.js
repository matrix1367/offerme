mfsForm = null;

(function($) {
	
	$.fn.facebook_login = function(options) {
		var defaults = {
			endpoint : '/sessions/new',
			permissions : 'email,read_friendlists,publish_actions,user_birthday',
			onLoginSuccess : function(data) {
				//console.log([ 200, 'login' ]);
			},
			onSuccess : function(data) {
				//console.log([ 200, 'login' ]);
			},
			onRegisterSuccess : function(data) {
				//console.log([ 200, 'register' ]);
			},
			onError : function(data) {
				//console.log([ 500, 'Error' ]);
			},
			onInvite : function(data){}
		};

		var settings = $.extend({}, defaults, options);
		
		(function(d, s, id) {
			   var js, fjs = d.getElementsByTagName(s)[0];
			   if (d.getElementById(id)) return;
			   js = d.createElement(s); js.id = id;
			   js.src = "//connect.facebook.net/pl_PL/all.js";
			   fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));

		window.fbAsyncInit = function() {
			
			FB.init({
			    appId      : settings.appId,
			    status     : true, // check login status
			    cookie     : true, // enable cookies to allow the server to access the session
			    xfbml      : true  // parse XFBML
			});
			
			
			FB.Event.subscribe('auth.authResponseChange', function(response) {
			    // Here we specify what we do with the response anytime this event occurs. 
				console.log("auth.ResponseChange event status: " + response.status);
			    if (response.status === 'connected') {
		    	  /*FB.api('/me', function(response1) {
		    		   console.log("FB status connected");
		    		   console.log("fb login object: ");
		    		   console.log(response1);
				       settings.onLoginSuccess(response1);
				  });*/
			    	
			      //FB.ui({method: 'apprequests', message: 'Zapraszam Cię na stronę http://ogarniamprad.pl', title:"Zaproszenie znajomych do aplikacji"});
		    	  
			    } else if (response.status === 'not_authorized') {
			      console.log("FB status not_authorized");
			      //FB.login();
			    } else {
			      console.log("FB status else");
			      //FB.login();
			    }
			});
			
			
			/*FB.getLoginStatus(function(response) {
				console.log("I am in FB.getLoginStatus");
				console.log(response);
			    if (response.status === 'connected') {
			    	 FB.api('/me', function(response1) {
			    		   console.log("automatic login object: " + response1);
					       settings.onLoginSuccess(response1);
					 });
				}
			});*/
			
		};

		this.on('click', function() {
			
			FB.getLoginStatus(function(response) {
				console.log("I am in FB.getLoginStatus");
				console.log(response);
			    if (response.status === 'connected') {
			    	FB.api('/me', function(response3) {
					       console.log("automatic register object: " + response3);
					       
					       FB.ui({method: 'apprequests', message: 'Zapraszam Cię na stronę http://ogarniamprad.pl', title:"Zaproszenie znajomych do aplikacji"},function(response4) {
					    	   settings.onRegisterSuccess(response3);
					       });
					    	  /*FB.api('/me/friends', function(response1) {
					    		   var container = $(".invites").get(0);
					    		   mfsForm = document.createElement('form');
					    		   mfsForm.id = 'mfsForm';
	
					    		   // Iterate through the array of friends object and create a checkbox for each one.
					    		   for(var i = 0; i < response1.data.length; i++) {
					    		     var friendItem = document.createElement('div');
					    		     friendItem.id = 'friend_' + response1.data[i].id;
					    		     friendItem.innerHTML = '<div title="'+response1.data[i].name+'" style="float:left;background-color:#eee;margin:2px;"><label for="friends_'+i+'"><input checked="checked" id="friends_'+i+'" type="checkbox" name="friends" value="'
				    		       + response1.data[i].id
				    		       + '" /><img src="http://graph.facebook.com/'+response1.data[i].id+'/picture" title="'+response1.data[i].name+'" alt="'+response1.data[i].name+'" /></div>';
				    		       mfsForm.appendChild(friendItem);
					    		   }
					    		   container.appendChild(mfsForm);
				    		     
				    		     settings.onInvite();
				    		     //console.log($("invites").html());
					    	  }); */ 
					       
					});
				}else{
					
					FB.login(function(response2) {
						   if (response2.authResponse) {
						     FB.api('/me', function(response3) {
						       console.log("automatic register object: " + response3);
						       
						       FB.ui({method: 'apprequests', message: 'Zapraszam Cię na stronę http://ogarniamprad.pl', title:"Zaproszenie znajomych do aplikacji"},function(response4) {
						    	   settings.onRegisterSuccess(response3);
						       });
						       
						       /*FB.api('/me/friends', function(response1) {
					    		   var container = $(".invites").get(0);
					    		   mfsForm = document.createElement('form');
					    		   mfsForm.id = 'mfsForm';
	
					    		   // Iterate through the array of friends object and create a checkbox for each one.
					    		   for(var i = 0; i < response1.data.length; i++) {
					    		     var friendItem = document.createElement('div');
					    		     friendItem.id = 'friend_' + response1.data[i].id;
					    		     friendItem.innerHTML = '<div title="'+response1.data[i].name+'" style="float:left;background-color:#eee;margin:2px;"><label for="friends_'+i+'"><input checked="checked" id="friends_'+i+'" type="checkbox" name="friends" value="'
				    		       + response1.data[i].id
				    		       + '" /><img src="http://graph.facebook.com/'+response1.data[i].id+'/picture" title="'+response1.data[i].name+'" alt="'+response1.data[i].name+'" /></div>';
				    		       mfsForm.appendChild(friendItem);
					    		   }
					    		   container.appendChild(mfsForm);
				    		     
				    		     settings.onInvite();
				    		     //console.log($("invites").html());
					    	  }); */
						       
						     });
						   } else {
						     console.log('User cancelled login or did not fully authorize.');
						     settings.onError(response2);
						   }
					}, {scope: settings.permissions});
					
				}
			});

			return false;
			
		});
		
	};
})(jQuery);
	