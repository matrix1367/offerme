﻿jQuery.fn.countdown = function(userOptions) {
	var options = {
		endDate : "0"
	};

	$.extend(options, userOptions);

	var elem = this;
	setInterval(function() {

		var currentDate = new Date().getTime();
		var difference = (options.endDate - currentDate) / 1000;
		var resultText = "";
		
		days = parseInt(difference / 86400);
		difference = difference % 86400;

		hours = parseInt(difference / 3600);
		difference = difference % 3600;

		minutes = parseInt(difference / 60);
		seconds = parseInt(difference % 60);

		if (seconds < 0)
			elem.text("Aukcja zakończona");
		else {
 			
//			elem.text(days + "d " + hours + "h " + minutes + "m " + seconds
//					+ "s");
			if(days > 0) {
				resultText += days + "d ";
			}
			if(hours > 0) {
				resultText += hours + "h ";
			}
			if(minutes > 0) {
				resultText += minutes + "m ";
			}
			if(seconds > 0) {
				resultText += seconds + "s";
			} else {
				resultText += "0s";
			}
			elem.text(resultText);
		}

	}, 1000);
};

jQuery.fn.timer = function(userOptions) {
	var elem = this;

	setInterval(function() {
		var currentDate = new Date();
		currentDate.setTime(currentDate.getTime() + userOptions.endDays * 24 * 60 * 60 * 1000);
		var months = currentDate.getMonth() + 1;
		elem.text(currentDate.getDate() + "-" + months + "-"
				+ currentDate.getFullYear() + " " + currentDate.getHours()
				+ ":" + (currentDate.getMinutes() < 10 ? '0' : '')
				+ currentDate.getMinutes() + ":" + (currentDate.getSeconds() < 10 ? '0' : '') + currentDate.getSeconds());

	}, 1000);
};