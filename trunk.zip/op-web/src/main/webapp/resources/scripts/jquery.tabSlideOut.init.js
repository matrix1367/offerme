$(function() {
	$('.facebook').tabSlideOut({
		tabHandle : '.facebook-icon', //class of the element that will become your tab
		tabLocation : 'right', //side of screen where tab lives, top, right, bottom, or left
		speed : 300, //speed of animation
		action : 'click', //options: 'click' or 'hover', action to trigger animation
		topPos : '70px', //position from the top/ use if tabLocation is left or right
		leftPos : '20px', //position from left/ use if tabLocation is bottom or top
		fixedPosition : true
	});
	
	$('.facebook').delay(1).fadeIn();
});

$(function() {
	$('.ask-question').tabSlideOut({
		tabHandle : '.ask-question-icon', //class of the element that will become your tab
		tabLocation : 'right', //side of screen where tab lives, top, right, bottom, or left
		speed : 300, //speed of animation
		action : 'click', //options: 'click' or 'hover', action to trigger animation
		topPos : '261px', //position from the top/ use if tabLocation is left or right
		leftPos : '20px', //position from left/ use if tabLocation is bottom or top
		fixedPosition : true
	});
	
	$('.ask-question').delay(1).fadeIn();
});

$(function() {
	$('.add-comment').tabSlideOut({
		tabHandle : '.add-comment-icon', //class of the element that will become your tab
		tabLocation : 'right', //side of screen where tab lives, top, right, bottom, or left
		speed : 300, //speed of animation
		action : 'click', //options: 'click' or 'hover', action to trigger animation
		topPos : '120px', //position from the top/ use if tabLocation is left or right
		leftPos : '20px', //position from left/ use if tabLocation is bottom or top
		fixedPosition : true
	});
	
	$('.add-comment').delay(1).fadeIn();
});