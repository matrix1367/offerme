package pl.op.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.jboss.seam.annotations.Name;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AgreementDao;
import pl.op.dao.CloudDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.auction.AuctionStatus;
import pl.op.model.auction.ZoneType;
import pl.op.model.cloud.Cloud;
import pl.op.model.contract.Agreement;
import pl.op.model.contract.PPE;
import pl.op.model.user.UserApp;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class CloudUtil.
 */
@Name("op.CloudUtil")
public class CloudUtil {

    private Logger log = LoggerFactory.getLogger(CloudUtil.class);

    private AgreementDao agreementDao;

    private CloudDao cloudDao;

    /**
     * Instantiates a new cloud util.
     */
    public CloudUtil() {
        initialize();
    }

    /**
     * Initialize.
     */
    public void initialize() {
        agreementDao = GuiceSingleton.getInstance().getInstance(AgreementDao.class);
        cloudDao = GuiceSingleton.getInstance().getInstance(CloudDao.class);
    }

    /**
     * Calculate offers.
     *
     * @param cloud - the cloud instance
     * @return number of offers for the cloud
     */
    public Integer calculateOffers(Cloud cloud) {

        Integer totalOffers = 0;

        for (Auction auction : cloud.getAuctions()) {
            if (auction.getAuctionOffers() != null) {
                for (AuctionOffer auctionOffer : auction.getAuctionOffers()) {
                    if (auctionOffer.getStatus() != null) {
                        if (!AuctionStatus.SUSPENDED.equals(auctionOffer.getStatus())) {
                            totalOffers++;
                        }
                    }
                }
            }
        }

        log.info("#" + cloud.getCloudId() + " totfal offers: " + totalOffers);

        return totalOffers;

    }

    /**
     * Gets the year volume maps for all PPEs.
     *
     * @param ppes - list with the ppes
     * @return the year volume maps for all PPEs by zone type
     */
    public static HashMap<ZoneType, Double> getYearVolumeMapsForAllPPEs(List<PPE> ppes) {

        CloudUtil util = GuiceSingleton.getInstance().getInstance(CloudUtil.class);

        HashMap<ZoneType, Double> map = new HashMap<ZoneType, Double>();

        PpeUtil ppeUtil = null;

        for (PPE ppe : ppes) {
            ppeUtil = new PpeUtil();
            HashMap<ZoneType, Double> mapVolumes = ppeUtil.prepareYearVolumeMapsForPPE(ppe);
            for (ZoneType zoneType : mapVolumes.keySet()) {
                util.log.info("ppe #" + ppe.getPpeId() + " volume for zone: " + zoneType + " = "
                        + mapVolumes.get(zoneType));
                if (map.containsKey(zoneType)) {
                    Double actualValue = map.get(zoneType);
                    util.log.info("actualValue = " + actualValue);
                    map.put(zoneType, actualValue + mapVolumes.get(zoneType));
                } else {
                    util.log.info("firstValue = " + mapVolumes.get(zoneType));
                    map.put(zoneType, mapVolumes.get(zoneType));
                }
                util.log.info(zoneType + " value = " + map.get(zoneType));
            }
        }

        return map;

    }

    /**
     * Gets the PPEs can join to auction by cloud.
     * Obliczanie opłacalności. 
     *
     * @param cloud - the cloud instance
     * @param beginContractDate - the begin contract date
     * @return the list of PPEs can join to auction by cloud
     * @throws Exception the exception
     */
    public static List<PPE> getPPEsCanJoinToAuctionByCloud(Cloud cloud, Date beginContractDate) throws Exception {

        CloudUtil util = GuiceSingleton.getInstance().getInstance(CloudUtil.class);

        Auction auctionMock = prepareAuctionMock(beginContractDate);
        UserApp userMock = prepareUserMock(false);
        AuctionUtil auctionUtil = null;
        List<PPE> ppesCanJoinToAuction = new ArrayList<PPE>();
        List<PPE> ppes;
        //kreator chmury
        if (cloud.getStereotype() == null || cloud.getStereotype().getStereotypeId() == null) 
                ppes = util.cloudDao.getPpeByCloudIdNoStereotype(cloud); 
            else
                ppes = util.cloudDao.getPpeByCloudId(cloud);
         
       // List<PPE> ppes = util.cloudDao.getPpeByCloudId(cloud);
        //kreator chmury
        util.log.info(">>> count ppes " + ppes.size());

        for (PPE ppe : ppes) {
            Agreement agreement = util.agreementDao.getLastAgreementByPpeId(ppe.getPpeId());
            ppe.updateActualAgreement(agreement);

            auctionUtil = new AuctionUtil(userMock, auctionMock, ppe);
            if (auctionUtil.canJoinToAuction()) {
                ppesCanJoinToAuction.add(ppe);
            }
        }

        return ppesCanJoinToAuction;

    }

    /**
     * Prepare auction mock.
     *
     * @param beginContractDate - the begin contract date
     * @return the auction instance
     */
    public static Auction prepareAuctionMock(Date beginContractDate) {

        Auction auctionMock = new Auction();
        auctionMock.setBeginContractDate(beginContractDate);
        auctionMock.setFinishDate(beginContractDate);
        auctionMock.setStatus(AuctionStatus.INPROGRESS);

        return auctionMock;

    }

    /**
     * Prepare user mock.
     *
     * @param isCompany - the user is company
     * @return the user instance
     */
    public static UserApp prepareUserMock(boolean isCompany) {

        UserApp userMock = new UserApp();
        userMock.setIsCompany(isCompany);

        return userMock;

    }

    /**
     * Update cloud volume by ppe id.
     *
     * @param ppeId the ppe id
     */
    public static void updateCloudVolumeByPpeId(Integer ppeId) {
        CloudUtil util = GuiceSingleton.getInstance().getInstance(CloudUtil.class);

        try {
            List<Cloud> clouds = util.getCloudsByPpeId(ppeId);
            Double volume;
            for (Cloud cloud : clouds) {
                volume = updateCloudVolume(cloud.getCloudId());
                util.log.info("Cloud: #" + cloud.getCloudId() + "; new volume: " + volume);
            }
        } catch (Exception e) {
            util.log.error("Problem while update clouds volume by ppeId: ", e);
        }
    }

    /**
     * Gets the clouds by ppe id.
     *
     * @param ppeId the ppe id
     * @return the clouds by ppe id
     * @throws Exception the exception
     */
    private List<Cloud> getCloudsByPpeId(Integer ppeId) throws Exception {
        List<Cloud> clouds = cloudDao.getCloudsByPpeId(ppeId);
        if (!hasCloudOnList(clouds)) {
            clouds = new ArrayList<Cloud>();
        }

        return clouds;
    }

    /**
     * Checks for cloud on list.
     *
     * @param clouds the clouds
     * @return true, if successful
     */
    private boolean hasCloudOnList(List<Cloud> clouds) {
        if (null == clouds) {
            return false;
        }
        if (clouds.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Update cloud volume.
     *
     * @param cloudId the cloud id
     * @return double - cloud volume
     */
    public static Double updateCloudVolume(Integer cloudId) {        
        CloudUtil util = GuiceSingleton.getInstance().getInstance(CloudUtil.class);
        util.log.info("[updateCloudVolume]");
        
        try {
            Double newVolume = util.calculateCloudVolume(cloudId);
            util.saveCloudVolume(util.getMockCloud(cloudId, newVolume));
            return newVolume;
        } catch (Exception e) {
            util.log.error("Problem while update cloud volume: ", e);
        }

        return 0.0;
    }


    /**
     * Calculate cloud volume.
     *
     * @param cloudId the cloud id
     * @return the double
     * @throws Exception the exception
     */
    private Double calculateCloudVolume(Integer cloudId) throws Exception {
        log.info("calculateCloudVolume(" + cloudId + ")");
        List<PPE> cloudPpes = cloudDao.getPpeByCloudId(getMockCloud(cloudId));
        Double volume = 0.0;

        if (hasPpeOnList(cloudPpes)) {
            log.info("Found ppe: " + cloudPpes.size());

            for (PPE ppe : cloudPpes) {
                log.info("PPE: #" + ppe.getPpeId() + "; value: " + ppe.getValue());
                volume += ppe.getValue().doubleValue() * 1000.0;
            }
        } else {
            log.info("Ppes not found");
        }
        log.info("calculateCloudVolume - Actual cloud volume: " + volume);

        return volume;
    }
    
    public static Double updateCloudVolumeByManual(Integer cloudId) {
        CloudUtil util = GuiceSingleton.getInstance().getInstance(CloudUtil.class);
        util.log.info("[updateCloudVolumeByManual]");
        try {
            Double newVolume = util.calculateCloudVolumeByCreator(cloudId);
            util.saveCloudVolume(util.getMockCloud(cloudId, newVolume));
            return newVolume;
        } catch (Exception e) {
            util.log.error("Problem while update cloud volume: ", e);
        }

        return 0.0;
    }

    private Double calculateCloudVolumeByCreator(Integer cloudId) throws Exception {
        log.info("calculateCloudVolume(" + cloudId + ")");
        List<PPE> cloudPpes = cloudDao.getPpeByCloudIdNoStereotype(getMockCloud(cloudId));
        Double volume = 0.0;

        if (hasPpeOnList(cloudPpes)) {
            log.info("Found ppe: " + cloudPpes.size());

            for (PPE ppe : cloudPpes) {
                log.info("PPE: #" + ppe.getPpeId() + "; value: " + ppe.getValue());
                volume += ppe.getValue().doubleValue() * 1000.0;
            }
        } else {
            log.info("Ppes not found");
        }
        log.info("calculateCloudVolumeByCreator- Actual cloud volume: " + volume);

        return volume;
    }


    /**
     * Checks for ppe on list.
     *
     * @param ppeList the ppe list
     * @return true, if successful
     */
    private boolean hasPpeOnList(List<PPE> ppeList) {
        if (null == ppeList) {
            return false;
        }
        if (ppeList.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Gets the mock cloud.
     *
     * @param cloudId the cloud id
     * @return the mock cloud
     */
    private Cloud getMockCloud(Integer cloudId) {
        Cloud cloud = new Cloud();
        cloud.setCloudId(cloudId);

        return cloud;
    }

    /**
     * Gets the mock cloud.
     *
     * @param cloudId the cloud id
     * @param volume the volume
     * @return the mock cloud
     */
    private Cloud getMockCloud(Integer cloudId, Double volume) {
        Cloud cloud = getMockCloud(cloudId);
        cloud.setVolume(volume);

        return cloud;
    }

    /**
     * Save cloud volume.
     *
     * @param cloud the cloud
     * @throws Exception the exception
     */
    private void saveCloudVolume(Cloud cloud) throws Exception {
        cloudDao.updateCloudVolume(cloud);
    }

    /**
     * Check cloud auction list.
     *
     * @param cloud the cloud
     */
    public static void checkCloudAuctionList(Cloud cloud) {
        if (null == cloud.getAuctions()) {
            return;
        }
        if (cloud.getAuctions().isEmpty()) {
            return;
        }
        if (cloud.getAuctions().size() == 1) {
            if (null == cloud.getAuctions().get(0).getAuctionId()) {
                cloud.setAuctions(new ArrayList<Auction>());
            }
        }
    }
}
