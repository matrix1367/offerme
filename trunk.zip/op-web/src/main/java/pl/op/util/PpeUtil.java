package pl.op.util;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.MeasureDao;
import pl.op.dao.PPEDao;
import pl.op.model.auction.ZoneType;
import pl.op.model.cloud.VolumeEnum;
import pl.op.model.contract.Invoice;
import pl.op.model.contract.Location;
import pl.op.model.contract.Measure;
import pl.op.model.contract.MeasureFilter;
import pl.op.model.contract.PPE;
import pl.op.model.contract.PPEStatus;
import pl.op.model.contract.Priority;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class PpeUtil.
 */
public class PpeUtil {

    private Logger log = LoggerFactory.getLogger(PpeUtil.class);

    private MeasureDao measureDao;

    private PPEDao ppeDao;

    public HashMap<Integer, HashMap<ZoneType, Integer>> workDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Integer>>();
    public HashMap<Integer, HashMap<ZoneType, Integer>> saturdayDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Integer>>();
    public HashMap<Integer, HashMap<ZoneType, Integer>> sundaysDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Integer>>();
    public HashMap<Integer, HashMap<ZoneType, Double>> extraValWorkDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Double>>();
    public HashMap<Integer, HashMap<ZoneType, Double>> extraValSaturdayDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Double>>();
    public HashMap<Integer, HashMap<ZoneType, Double>> extraValSundaysDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Double>>();

    public HashMap<ZoneType, Integer> cointainesZones = new HashMap<ZoneType, Integer>();
    public HashMap<ZoneType, String> zonesColours = new HashMap<ZoneType, String>();

    private List<ZoneType> zoneTypes = new ArrayList<ZoneType>();

    private HashMap<ZoneType, Integer> zoneValue = new HashMap<ZoneType, Integer>();
    private HashMap<ZoneType, Double> zoneValueDbl = new HashMap<ZoneType, Double>();
    private HashMap<ZoneType, Double> cointainesZonesDbl = new HashMap<ZoneType, Double>();

    private HashMap<Integer, String> coloursMap;

    private Double measureValuePerDay = Double.valueOf("0.0");
    public HashMap<ZoneType, Integer> measureDayPerZone = new HashMap<ZoneType, Integer>();
    public HashMap<ZoneType, Double> measureDayValuePerZone = new HashMap<ZoneType, Double>();
    public HashMap<ZoneType, Double> extraMeasureDayValuePerZone = new HashMap<ZoneType, Double>();

    public final static Integer DAYS_TO_COMPARE = 27;

    /**
     * Instantiates a new ppe util.
     */
    public PpeUtil() {
        initialize();
    }

    /**
     * Initialize.
     */
    public void initialize() {
        measureDao = GuiceSingleton.getInstance().getInstance(MeasureDao.class);
        ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);
        generateRandomColours(10);
    }

    /**
     * Unique PPE object type.
     *
     * @param objectType - the current object type
     * @param ppeList - the list of PPEs
     * @return the string with unique object type
     */
    public static String uniquePPEObjectType(String objectType, List<PPE> ppeList) {

        String tmpObjectType = objectType;
        String tmpObjectType2 = tmpObjectType;
        int i = 1;

        for (PPE tmpPPE : ppeList) {
            while (tmpPPE.getObjectType().equals(tmpObjectType2)) {
                i++;
                tmpObjectType2 = tmpObjectType + " " + i;
            }
        }

        return tmpObjectType2;

    }

    /**
     * Calculate and sets the PPE value.
     *
     * @param ppe - the new PPE value
     * @throws Exception the exception
     */
    public static void setPPEValue(PPE ppe) throws Exception {

        PpeUtil util = GuiceSingleton.getInstance().getInstance(PpeUtil.class);

        Double sum = PpeUtil.getPPEValue(ppe);
        sum = sum / 1000.0;
        ppe.setValue(sum);
        ppe.setValueUnit(VolumeEnum.MWH);
        ppe.setValueUpdatedAt(new Date());
        util.ppeDao.updatePPEValue(ppe);

        CloudUtil.updateCloudVolumeByPpeId(ppe.getPpeId());

        //util.log.info("Set PPEValue for PPE #" + ppe.getPpeId() + ", value = " + sum + " " + VolumeEnum.MWH);
    }

    /**
     * Sets the PPE value for all PPEs by locations.
     *
     * @param locations - the list of locations
     * @throws Exception the exception
     */
    public static void setPPEValueForAllPPEsByLocations(List<Location> locations) throws Exception {

        for (Location location : locations) {
            for (PPE ppe : location.getPpes()) {
                PpeUtil.setPPEValue(ppe);
            }
        }

    }

    /**
     * Gets the PPE value.
     *
     * @param ppe - the PPE instance
     * @return the PPE value
     */
    public static Double getPPEValue(PPE ppe) {

        PpeUtil util = GuiceSingleton.getInstance().getInstance(PpeUtil.class);

        Double sum = 0.00;

        HashMap<ZoneType, Double> volumeMaps = util.prepareYearVolumeMapsForPPE(ppe);

        //util.log.info("volumeMaps: " + volumeMaps);
        for (Double value : volumeMaps.values()) {
            sum += value;
        }

        return sum;

    }

    /**
     * Sets the status for all PPEs by locations.
     *
     * @param locations - the list of locations
     * @param status - the status
     * @param additionalParams - dodatkowe parametry, pierwszy czy zmieniać
     * tylko dla tych co nie są PPEStatus.JOINED
     * @throws Exception the exception
     */
    public static void setStatusForAllPPEs(List<Location> locations, PPEStatus status, boolean... additionalParams)
            throws Exception {

        PpeUtil util = GuiceSingleton.getInstance().getInstance(PpeUtil.class);

        for (Location location : locations) {
            for (PPE ppe : location.getPpes()) {
                //util.log.info("Set PPEStatus (" + status + ") for PPE #" + ppe.getPpeId());

                if (canChangeStatus(ppe, additionalParams)) {
                    ppe.setPpeStatus(status);
                    util.ppeDao.updatePPEStatus(ppe.getPpeId(), status);
                }
            }
        }

    }

    /**
     * Can change status.
     *
     * @param ppe - the PPE isntance
     * @param additionalParams - dodatkowe parametry, pierwszy czy zmieniać
     * tylko dla tych co nie są PPEStatus.JOINED
     * @return true, if successful
     */
    public static boolean canChangeStatus(PPE ppe, boolean... additionalParams) {
        if (null == additionalParams) {
            return true;
        }
        if (additionalParams.length == 0) {
            return true;
        }
        if (false == additionalParams[0]) {
            return true;
        }
        if (additionalParams[0] == true && !PPEStatus.JOINED.equals(ppe.getPpeStatus())) {
            return true;
        }

        return false;
    }

    /**
     * Sets the status for PPE.
     *
     * @param ppe - the PPE isntance
     * @param status - the status (enum from PPEStatus)
     * @throws Exception the exception
     */
    public static void setStatusForPPE(PPE ppe, PPEStatus status) throws Exception {

        PpeUtil util = GuiceSingleton.getInstance().getInstance(PpeUtil.class);

        //util.log.info("Set PPEStatus (" + status + ") for PPE #" + ppe.getPpeId());
        ppe.setPpeStatus(status);
        util.ppeDao.updatePPEStatus(ppe.getPpeId(), status);

    }

    /**
     * Sets the status for company by invoices.
     *
     * @param invoices - the list of invoices
     * @param locations - the list of locations
     * @param additionalParams - dodatkowe parametry, pierwszy czy zmieniać
     * tylko dla tych co nie są PPEStatus.JOINED
     * @throws Exception the exception
     */
    @SuppressWarnings("deprecation")
    public static void setStatusForCompanyByInvoices(List<Invoice> invoices, List<Location> locations,
            boolean... additionalParams) throws Exception {

        PpeUtil util = GuiceSingleton.getInstance().getInstance(PpeUtil.class);

        for (Location location : locations) {
            for (PPE ppe : location.getPpes()) {
                for (Invoice invoice : invoices) {
                    if (invoice.getPpe().getPpeId().intValue() == ppe.getPpeId().intValue()) {
                        if (ppe.getInvoices() == null) {
                            ppe.setInvoices(new ArrayList<Invoice>());
                        }

                        ppe.getInvoices().add(invoice);
                    }
                }
            }
        }
        // sprawdzanie czy użytkownik dodał wystarczająco dużo faktur za cały rok.
        for (Location location : locations) {
            for (PPE ppe : location.getPpes()) {
                Date lastDate = getLastDateForInvoices(ppe.getInvoices());
                Integer days = getNumberOfDaysForLatestInvoices(lastDate, ppe.getInvoices());
                //util.log.info("PPE: " + ppe.getPpeId().toString() + " Deys" + days.toString());
                if (canChangeStatus(ppe, additionalParams)) {
                    if (days < DAYS_TO_COMPARE) {
                        util.ppeDao.updatePPEStatus(ppe.getPpeId(), PPEStatus.INVOICE_MISSING);
                    } else {
                        util.ppeDao.updatePPEStatus(ppe.getPpeId(), PPEStatus.READY_TO_JOIN);
                    }
                }
            }
        }

    }

    /**
     * Gets the last date for invoices.
     *
     * @param invoices - the list of invoices
     * @return the last date for invoices
     */
    public static Date getLastDateForInvoices(List<Invoice> invoices) {

        Date lastDate = null;

        for (Invoice invoice : invoices) {
            if (lastDate == null) {
                lastDate = invoice.getDateTo();
            }

            if (lastDate.before(invoice.getDateTo())) {
                lastDate = invoice.getDateTo();
            }
        }

        return lastDate;

    }

    /**
     * Gets the number of days for latest invoices.
     *
     * @param lastDateTo - the last date to
     * @param invoices - the list of invoices
     * @return the number of days for latest invoices
     */
    public static Integer getNumberOfDaysForLatestInvoices(Date lastDateTo, List<Invoice> invoices) {

        Integer days = 0;

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(lastDateTo);
        calendar.add(Calendar.YEAR, -1);

        Date lastDateFrom = calendar.getTime();

        for (Invoice invoice : invoices) {
            if (isDateBetweenCompareDate(lastDateTo, lastDateFrom, invoice.getDateTo(), invoice.getDateFrom())) {
                days += Days.daysBetween(new LocalDate(invoice.getDateFrom()), new LocalDate(invoice.getDateTo()))
                        .getDays();
            }
        }

        return days;

    }

    /**
     * Checks if is date between compare date.
     *
     * @param lastDateTo - the last date to
     * @param lastDateFrom -the last date from
     * @param dateTo - the date to
     * @param dateFrom - the date from
     * @return true, if is date between compare date
     */
    public static boolean isDateBetweenCompareDate(Date lastDateTo, Date lastDateFrom, Date dateTo, Date dateFrom) {

        boolean isBetween = false;

        if (dateFrom.after(lastDateFrom) && dateTo.before(lastDateTo)) {
            isBetween = true;
        }
        if (lastDateFrom.equals(dateFrom) && dateTo.before(lastDateTo)) {
            isBetween = true;
        }
        if (dateFrom.after(lastDateFrom) && lastDateTo.equals(dateTo)) {
            isBetween = true;
        }
        if (lastDateFrom.equals(dateFrom) && lastDateTo.equals(dateTo)) {
            isBetween = true;
        }

        return isBetween;

    }

    /**
     * Generate random colours.
     *
     * @param count the count
     */
    public void generateRandomColours(Integer count) {
        Random rand = new Random();
        coloursMap = new HashMap<Integer, String>();

        for (int i = 0; i < count; i++) {
            int r = rand.nextInt(255);
            int g = rand.nextInt(255);
            int b = rand.nextInt(255);

            coloursMap.put(i, String.format("#%02x%02x%02x", r, g, b));
        }
    }

    /**
     * Prepare year volume maps for ppe.
     *
     * @param ppe the ppe
     * @return the hash map
     */
    public HashMap<ZoneType, Double> prepareYearVolumeMapsForPPE(PPE ppe) {
        //log.info("[prepareYearVolumeMapsForPPE]");
        HashMap<ZoneType, Double> map = new HashMap<ZoneType, Double>();

//        Calendar cal = Calendar.getInstance();
//        cal.setTime(new Date());
//        cal.add(Calendar.YEAR, -1);
//        Date dateFrom = cal.getTime();
        Date dateFrom = new Date(new Date().getYear(), 0, 1);
        Date dateTo = new Date(new Date().getYear(), 11, 31);

        //preparePpeUsageData(ppe, dateFrom, new Date(), "month");
        preparePpeUsageData(ppe, dateFrom, dateTo, "");

        for (ZoneType zoneType : cointainesZones.keySet()) {
            Double sum = getSumValueByZone(workDaysPerMonth, extraValWorkDaysPerMonth, zoneType)
                    + getSumValueByZone(saturdayDaysPerMonth, extraValSaturdayDaysPerMonth, zoneType)
                    + getSumValueByZone(sundaysDaysPerMonth, extraValSundaysDaysPerMonth, zoneType);
            map.put(zoneType, sum);
            //log.info("[prepareYearVolumeMapsForPPE]>>>>>>dodanie mapy z ppp:" + zoneType.toString() + " wolumen  " + sum);
        }

        return map;
    }

    /**
     * Gets the sum value by zone.
     *
     * @param measurePerMonth the measure per month
     * @param extraMeasurePerMonth the extra measure per month
     * @param zoneType the zone type
     * @return the sum value by zone
     */
    public Double getSumValueByZone(HashMap<Integer, HashMap<ZoneType, Integer>> measurePerMonth,
            HashMap<Integer, HashMap<ZoneType, Double>> extraMeasurePerMonth, ZoneType zoneType) {

        double result = Double.valueOf("0.0");
        Integer dayQuantity = 0;

        for (int i = 0; i < 12; i++) {

            if (zoneType != null) {
                if (measurePerMonth.get(i).containsKey(zoneType)) {
                    dayQuantity += measurePerMonth.get(i).get(zoneType);
                } else {
                    dayQuantity = 0;
                }
            }

            if (extraMeasurePerMonth != null && !extraMeasurePerMonth.isEmpty()) {
                if (extraMeasurePerMonth.get(i).containsKey(zoneType)) {
                    result += extraMeasurePerMonth.get(i).get(zoneType).doubleValue();
                }
            }
        }

        result += dayQuantity * measureDayValuePerZone.get(zoneType);

        return result;
    }

    /**
     * Prepare ppe usage data.
     *
     * @param ppe the ppe
     * @param dateFrom the date from
     * @param dateTo the date to
     * @param durationType the duration type
     */
    @SuppressWarnings("deprecation")
    public void preparePpeUsageData(PPE ppe, Date dateFrom, Date dateTo, String durationType) {
        /*log.info("preparePpeUsageData");
         log.info("ppe: #" + ppe.getPpeId());
         log.info("dateFrom: " + dateFrom.toLocaleString());
         log.info("dateTo: " + dateTo.toLocaleString());
         log.info("durationType: " + durationType);
         */
        clearHelpers();
        Integer measureAllDay = new Integer(0);
        Double measureValue = Double.valueOf("0.0");

        try {
            if (durationType.equals("month")) {
                dateFrom.setDate(1);
                dateTo.setDate(1);
            }

            MeasureFilter filter = new MeasureFilter();
            filter.setDateFrom(dateFrom);
            filter.setDateTo(dateTo);
            filter.setPpeId(ppe.getPpeId());
            filter.setPriority(Priority.medium);

            List<Measure> measureInvoiceList = measureDao.getMeasureByFilter(filter);

            filter.setDateTo(null);
            filter.setPriority(Priority.high);
            List<Measure> measureMeterList = measureDao.getMeasureByFilter(filter);

            //log.info("measureInvoiceList.size - " + measureInvoiceList.size());
            //log.info("measureMeterList.size - " + measureMeterList.size());
            List<Integer> countedInvoices = new ArrayList<Integer>();
            HashMap<ZoneType, Integer> cointainesZonesType = new HashMap<ZoneType, Integer>();
            for (Measure measure : measureInvoiceList) {
                zoneTypes.add(measure.getZoneType());
                


                int measureDay = (int) ((measure.getDateTo().getTime() - measure.getDateFrom().getTime()) / 1000 / 3600 / 24);
                measureValue = measureValue + measure.getValue().doubleValue();

                if (!countedInvoices.contains(measure.getInvoice().getInvoiceId())) {
                    countedInvoices.add(measure.getInvoice().getInvoiceId());
                    measureAllDay += measureDay;
                    cointainesZonesType.clear();
                } else {
                    
                    if (cointainesZonesType.containsKey(measure.getZoneType())) {
                        measureDay = 0;
                    }
                }
                cointainesZonesType.put(measure.getZoneType(), 0);
                updateMeasureDayVal(measure.getZoneType(), measureDay, measure.getValue().doubleValue());
            }
            prepareCointainesZonesMaps();

            if (measureInvoiceList.size() == 0 && measureMeterList.size() == 0) {
                prepareMeasureValPerDay(filter);
                if (measureValuePerDay == 0) {
                    return;
                }
            } else {
                measureValuePerDay = (measureValue / measureAllDay) * 1000;
            }

            prepareDayCountMaps(dateFrom, dateTo);
            renderMeasureMeterList(measureMeterList);
            calculateMeasureDayValuePerZone();
           // logUsageDateResult(measureAllDay);
        } catch (Exception e) {
            log.error("Problem while prepare ppe usage chart data: ", e);
        }
    }

    /**
     * Clear helpers.
     */
    private void clearHelpers() {
        workDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Integer>>();
        saturdayDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Integer>>();
        sundaysDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Integer>>();

        extraValWorkDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Double>>();
        extraValSaturdayDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Double>>();
        extraValSundaysDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Double>>();

        cointainesZones = new HashMap<ZoneType, Integer>();
        cointainesZonesDbl = new HashMap<ZoneType, Double>();

        zonesColours = new HashMap<ZoneType, String>();
        zoneValue = new HashMap<ZoneType, Integer>();
        zoneValueDbl = new HashMap<ZoneType, Double>();
        zoneTypes = new ArrayList<ZoneType>();

        measureDayPerZone = new HashMap<ZoneType, Integer>();
        measureDayValuePerZone = new HashMap<ZoneType, Double>();
        extraMeasureDayValuePerZone = new HashMap<ZoneType, Double>();
        measureValuePerDay = 0.0;
    }

    /**
     * Update measure day val.
     *
     * @param zone the zone
     * @param days the days
     * @param value the value
     */
    private void updateMeasureDayVal(ZoneType zone, int days, Double value) {
        //log.info("updateMeasureDayVal");
        if (!measureDayPerZone.containsKey(zone)) {
            measureDayPerZone.put(zone, 0);
        }
        //wlicza wszystkie faktury a nie tylko jedna
        measureDayPerZone.put(zone, days + measureDayPerZone.get(zone));
        //measureDayPerZone.put(zone, days);

        if (!measureDayValuePerZone.containsKey(zone)) {
            measureDayValuePerZone.put(zone, 0.0);
        }
        measureDayValuePerZone.put(zone, value + measureDayValuePerZone.get(zone));
    }

    /**
     * Prepare cointaines zones maps.
     */
    private void prepareCointainesZonesMaps() {
        for (ZoneType zone : zoneTypes) {
            cointainesZones.put(zone, 0);
            cointainesZonesDbl.put(zone, 0.0);
            zonesColours.put(zone, coloursMap.get(zoneTypes.indexOf(zone)));
        }
    }

    /**
     * Prepare measure val per day.
     *
     * @param filter the filter
     * @throws Exception the exception
     */
    private void prepareMeasureValPerDay(MeasureFilter filter) throws Exception {
        filter.setDateFrom(null);
        filter.setDateTo(null);
        filter.setPriority(null);
        List<Measure> measureValList = measureDao.getMeasureByFilter(filter);

        if (measureValList.size() > 0) {
            Measure measure = measureValList.get((measureValList.size() - 1));
            if (null == measure.getDateTo()) {
                measureValuePerDay = measure.getValue().doubleValue();
                updateExtraMeasureDayValuePerZone(measure.getZoneType(), measure.getValue().doubleValue());
            } else {
                Double value = measure.getValue().doubleValue();
                long measureDays = (measure.getDateTo().getTime() - measure.getDateFrom().getTime()) / 1000 / 3600 / 24;

                measureValuePerDay = value / measureDays;
                updateMeasureDayVal(measure.getZoneType(), (int) measureDays, value.doubleValue());
            }
        } else {
            measureValuePerDay = 0.0;
        }
    }

    /**
     * Prepare day count maps.
     *
     * @param dateFrom the date from
     * @param dateTo the date to
     */
    private void prepareDayCountMaps(Date dateFrom, Date dateTo) {
        for (long start = dateFrom.getTime(); start < dateTo.getTime(); start = start + (24 * 3600 * 1000)) {
            zoneValue = new HashMap<ZoneType, Integer>();
            renderUsageDataByDayType(new Date(start));
        }
    }

    /**
     * Render usage data by day type.
     *
     * @param date the date
     */
    private void renderUsageDataByDayType(Date date) {
        int dayOfWeek = getDayOfWeek(date);
        if (1 == dayOfWeek) {
            fillDataToMap(sundaysDaysPerMonth, date);
        } else if (7 > dayOfWeek) {
            fillDataToMap(workDaysPerMonth, date);
        } else {
            fillDataToMap(saturdayDaysPerMonth, date);
        }
    }

    /**
     * Fill data to map.
     *
     * @param dataMap the data map
     * @param date the date
     */
    private void fillDataToMap(HashMap<Integer, HashMap<ZoneType, Integer>> dataMap, Date date) {
        int month = getMonth(date);

        if (!dataMap.containsKey(month)) {
            dataMap.put(month, cointainesZones);
        }
        for (ZoneType zone : zoneTypes) {
            zoneValue.put(zone, dataMap.get(month).get(zone) + 1);
        }

        dataMap.put(month, zoneValue);
    }

    /**
     * Render measure list.
     *
     * @param measureMeterList the measure meter list
     */
    private void renderMeasureMeterList(List<Measure> measureMeterList) {
        for (Measure measure : measureMeterList) {
            updateExtraMeasureDayValuePerZone(measure.getZoneType(), measure.getValue().doubleValue());
            renderMeasureByDayType(measure.getDateFrom(), measure);
        }
    }

    /**
     * Update extra measure day value per zone.
     *
     * @param zone the zone
     * @param value the value
     */
    private void updateExtraMeasureDayValuePerZone(ZoneType zone, Double value) {
        if (!extraMeasureDayValuePerZone.containsKey(zone)) {
            extraMeasureDayValuePerZone.put(zone, 0.0);
        }
        extraMeasureDayValuePerZone.put(zone, value + extraMeasureDayValuePerZone.get(zone));

        if (measureDayPerZone.containsKey(zone)) {
            measureDayPerZone.put(zone, measureDayPerZone.get(zone) - 1);
        }
    }

    /**
     * Render measure by day type.
     *
     * @param date the date
     * @param measure the measure
     */
    private void renderMeasureByDayType(Date date, Measure measure) {
        int dayOfWeek = getDayOfWeek(date);

        if (1 == dayOfWeek) {
            prepareZoneValueDbl(extraValSundaysDaysPerMonth, date, measure);
            fillMeasureDataToMap(extraValSundaysDaysPerMonth, sundaysDaysPerMonth, date, measure);
        } else if (7 > dayOfWeek) {
            prepareZoneValueDbl(extraValWorkDaysPerMonth, date, measure);
            fillMeasureDataToMap(extraValWorkDaysPerMonth, workDaysPerMonth, date, measure);
        } else {
            prepareZoneValueDbl(extraValSaturdayDaysPerMonth, date, measure);
            fillMeasureDataToMap(extraValSaturdayDaysPerMonth, saturdayDaysPerMonth, date, measure);
        }
    }

    /**
     * Prepare zone value dbl map.
     *
     * @param dataMap the data map
     * @param date the date
     * @param measure the measure
     */
    private void prepareZoneValueDbl(HashMap<Integer, HashMap<ZoneType, Double>> dataMap, Date date, Measure measure) {
        int month = getMonth(date);
        zoneValueDbl = new HashMap<ZoneType, Double>();

        for (ZoneType zone : zoneTypes) {
            zoneValueDbl.put(zone, dataMap.get(month).get(zone) + measure.getValue());
        }
    }

    /**
     * Fill measure data to map.
     *
     * @param dataMap the data map
     * @param relationMap the relation map
     * @param date the date
     * @param measure the measure
     */
    private void fillMeasureDataToMap(HashMap<Integer, HashMap<ZoneType, Double>> dataMap,
            HashMap<Integer, HashMap<ZoneType, Integer>> relationMap, Date date, Measure measure) {

        int month = getMonth(date);
        if (!dataMap.containsKey(month)) {
            dataMap.put(month, cointainesZonesDbl);
        }

        for (ZoneType zone : zoneTypes) {
            zoneValueDbl.put(zone, dataMap.get(month).get(zone) + measure.getValue());
        }
        dataMap.put(month, zoneValueDbl);

        if (relationMap.containsKey(month)) {
            for (ZoneType zone : zoneTypes) {
                Integer value = 0;
                if (relationMap.get(month).get(zone) > 0) {
                    value = relationMap.get(month).get(zone) - 1;
                } else {
                    value = relationMap.get(month).get(zone);
                }
                zoneValue.put(zone, value);
            }
            relationMap.put(month, zoneValue);
        }
    }

    /**
     * Calculate measure day value per zone.
     */
    private void calculateMeasureDayValuePerZone() {
        for (ZoneType zoneType : cointainesZones.keySet()) {
            Double value = measureDayValuePerZone.get(zoneType);
            value /= measureDayPerZone.get(zoneType);
            if (extraMeasureDayValuePerZone.containsKey(zoneType)) {
                value += extraMeasureDayValuePerZone.get(zoneType);
            }
            measureDayValuePerZone.put(zoneType, value * 1000);
        }
    }

    /**
     * Log from prepare usage data.
     *
     * @param measureAllDay the measure all day
     */
    private void logUsageDateResult(Integer measureAllDay) {
        log.info("cointainesZones " + cointainesZones);
        log.info("workDaysPerMonth " + workDaysPerMonth);
        log.info("saturdayDaysPerMonth " + saturdayDaysPerMonth);
        log.info("sundaysDaysPerMonth " + sundaysDaysPerMonth);
        log.info("extraValWorkDaysPerMonth " + extraValWorkDaysPerMonth);
        log.info("extraValSaturdayDaysPerMonth " + extraValSaturdayDaysPerMonth);
        log.info("extraValSundaysDaysPerMonth " + extraValSundaysDaysPerMonth);
        log.info("measureValuePerDay " + measureValuePerDay);
        log.info("measureAllDay " + measureAllDay);
        log.info("measureDayPerZone " + measureDayPerZone);
        log.info("measureDayValuePerZone " + measureDayValuePerZone);
        log.info("extraMeasureDayValuePerZone " + extraMeasureDayValuePerZone);
    }

    /**
     * Gets the measure value per day.
     *
     * @return the measure value per day
     */
    public Double getMeasureValuePerDay() {
        return measureValuePerDay;
    }

    /**
     * Sets the measure value per day.
     *
     * @param measureValuePerDay the new measure value per day
     */
    public void setMeasureValuePerDay(Double measureValuePerDay) {
        this.measureValuePerDay = measureValuePerDay;
    }

    /**
     * Gets the month.
     *
     * @param date the date
     * @return the month
     */
    public int getMonth(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);

        return cal.get(Calendar.MONTH);
    }

    /**
     * Gets the day.
     *
     * @param date the date
     * @return the day
     */
    public int getDayOfWeek(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);

        return cal.get(Calendar.DAY_OF_WEEK);
    }

    /**
     * Gets the measure day value per zone.
     *
     * @return the measure day value per zone
     */
    public HashMap<ZoneType, Double> getMeasureDayValuePerZone() {
        return measureDayValuePerZone;
    }

    /**
     * Gets the extra measure day value per zone.
     *
     * @return the extra measure day value per zone
     */
    public HashMap<ZoneType, Double> getExtraMeasureDayValuePerZone() {
        return extraMeasureDayValuePerZone;
    }

    public static Boolean canEditPpe(final PPE ppe) {
        if ((ppe.getPpeStatus() == PPEStatus.AIMED_TO_AGREEMENT) || (ppe.getPpeStatus() == PPEStatus.JOINED)) {
            return false;
        }

        return true;
    }
}
