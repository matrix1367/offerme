package pl.op.util;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AuctionDao;
import pl.op.dao.OperatorAgreementDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionStatus;
import pl.op.model.contract.Agreement;
import pl.op.model.contract.OperatorAgreement;
import pl.op.model.contract.PPE;
import pl.op.model.contract.PPEStatus;
import pl.op.model.user.UserApp;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class AuctionUtil.
 */
public class AuctionUtil {
    private Logger log = LoggerFactory.getLogger(AuctionUtil.class);

    private UserApp user;
    private Auction auction;
    private Agreement ppeAgreement;
    private PPE ppe;
    private String globalMessageKey;

    /**
     * Instantiates a new auction util.
     */
    public AuctionUtil() {
        setDefaultValuesToVars();
    }

    /**
     * Instantiates a new auction util.
     * 
     * @param auctionToCheck
     *            the auction to check
     */
    public AuctionUtil(Auction auctionToCheck) {
        auction = auctionToCheck;
    }

    /**
     * Instantiates a new auction util.
     * 
     * @param userInstance
     *            the user instance
     * @param selectedPpe
     *            the ppe instance to operation
     */
    public AuctionUtil(UserApp userInstance, PPE selectedPpe) {
        user = userInstance;
        ppe = selectedPpe;
        ppeAgreement = ppe.getActualAgreement();
    }

    /**
     * Instantiates a new auction util.
     * 
     * @param userInstance
     *            the user instance
     * @param auctionToJoin
     *            the auction to join
     * @param selectedPpe
     *            the ppe instance to operation
     */
    public AuctionUtil(UserApp userInstance, Auction auctionToJoin, PPE selectedPpe) {
        this(userInstance, selectedPpe);

        auction = auctionToJoin;
    }

    /**
     * Sets the default values to vars.
     */
    private void setDefaultValuesToVars() {
        log.info("setDefaultValuesToVars");

        if(null == user) {
            user = UserUtil.getLoggedUserInstance();
        }
        if(null == auction) {
            auction = new Auction();
        }
        if(null == ppeAgreement) {
            ppeAgreement = new Agreement();
        }
    }

    /**
     * Can join to auction.
     * 
     * @return true, if successful
     */
    public boolean canJoinToAuction() {
        try {
            return checkCanJoinToAuction();
        } catch (Exception e) {
            log.error("Problem while check can join to auction: ", e);
            e.printStackTrace();
        }

        return true;
    }

    /**
     * Check can join to auction.
     * 
     * @return true, if successful
     * @throws Exception
     *             the exception
     */
    private boolean checkCanJoinToAuction() throws Exception {
        log.info("checkCanJoinToAuction");

        if(!isAuctionValid()) {
            return false;
        }
        if(!canSignNewAgreement()) {
            return false;
        }
        if(isInAuction()) {
            return false;
        }
        
        if (isMiedAgreement()) {
            log.info("isMiedAgreement : uzytkownik oczekuje na umowe");
            return false;
        }

        if(!hasInvoices()) {
            return false;
        }

        if(isRefusedAgreement()) {
            return false;
        }
        if(isCompany()) {
            if(!hasSignedAgreement()) {
                return false;
            }
        }

        PpeUtil.setStatusForPPE(ppe, PPEStatus.READY_TO_JOIN);
        log.info("canJoinToAuction: " + auction.getAuctionId());
        return true;
    }
    
    
    public boolean isMiedAgreement() {
        log.info("isMiedAgreement");
        return ppe.getPpeStatus() == PPEStatus.AIMED_TO_AGREEMENT;        
    }

    /**
     * Checks if is auction valid.
     * 
     * @param auction
     *            the auction
     * @return true, if is auction valid
     */
    public static boolean isAuctionValid(Auction auction) {
        AuctionUtil util = new AuctionUtil(auction);

        return util.isAuctionValid();
    }

    /**
     * Checks if is auction valid.
     * 
     * @return true, if is auction valid
     */
    private boolean isAuctionValid() {
        log.info("isAuctionValid");

        if(null == auction) {
            log.info("auction is null");
            return false;
        }
        if(null == auction.getFinishDate()) {
            log.info("auction.finishDate is null");
            return false;
        }
        if(!auction.getStatus().equals(AuctionStatus.INPROGRESS)) {
            log.info("auction.getStatus().equals(AuctionStatus.INPROGRESS) => false");
            return false;
        }

        return true;
    }

    /**
     * Can sign new agreement.
     * 
     * @return true, if successful
     */
    private boolean canSignNewAgreement() {
        log.info("canSignNewAgreement");

        if(null != ppeAgreement.getDateTo()) {
            log.info("ppeAgreement.getDateTo() is not null");
            if(!isEnoughtTimeBeforeEndAgreement()) {
                return false;
            }

        }

        return true;
    }

    /**
     * Checks if is enought time before end agreement.
     * 
     * @return true, if is enought time before end agreement
     */
    private boolean isEnoughtTimeBeforeEndAgreement() {
        log.info("isEnoughtTimeBeforeEndAgreement");        
        if(getAcceptedBeignContractDate().compareTo(ppeAgreement.getDateTo()) >= 0) {
            log.info(">>>>>>> OK >>> data rozpoczecia aukcji jest wieksza od "+ ppeAgreement.getDateTo().toString() );
            return true;
        }
        log.info(">>>>>>> data rozpoczecia jest mniejsza od "+ ppeAgreement.getDateTo().toString() );
        return false;
    }

    /**
     * Gets the accepted beign contract date.
     * 
     * @return the accepted beign contract date
     */
    private Date getAcceptedBeignContractDate() {
        DictionaryBean dictionaryBean = ComponentLookup.lookupComponent("op.dictionaryBean");
        dictionaryBean.refreshNextAuctionMonthsThreshold();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(auction.getBeginContractDate());
        log.info(">>>>>>>>data rozpoczecia umowy z aukcji " + auction.getBeginContractDate().toString());
        calendar.add(Calendar.MONTH, -(dictionaryBean.getNextAuctionMonthsThreshold()));
        log.info(">>>>>>>>data rozpoczecia umowy z aukcji - ("+(dictionaryBean.getNextAuctionMonthsThreshold())+ ") " + calendar.getTime().toString());
        return calendar.getTime();
    }

    /**
     * Checks if is in auction.
     * 
     * @return true, if is in auction
     * @throws Exception
     *             the exception
     */
    private boolean isInAuction() throws Exception {
        log.info("[isInAuction] isInOtherAuction");

//        if (isJoined()) {
//            log.info("isInAuction : status ppe : joined");
//            return true;
//        } else {
//            log.info(ppe.getPpeStatus().toString());
//        }
        
        List<Auction> userAuction = getFoundUserAuction();

        if(isFoundUserAuction(userAuction)) {
            log.info("FoundUserAuction");
            return true;
        } else {
            log.info("notFoundUserAuction");
        } 
        return false;
    }

    /**
     * Checks if is found user auction.
     * 
     * @param auctionList
     *            the auction list
     * @return true, if is found user auction
     */
    private boolean isFoundUserAuction(List<Auction> auctionList) {
        if(null == auctionList) {
            return false;
        }
        if(auctionList.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Gets the found user auction.
     * 
     * @return the found user auction
     * @throws Exception
     *             the exception
     */
    private List<Auction> getFoundUserAuction() throws Exception {
        AuctionDao auctionDao = GuiceSingleton.getInstance().getInstance(AuctionDao.class);
        return auctionDao.getJoinedAuctionByPpe(ppe);
    }

    /**
     * Checks if is company.
     * 
     * @return true, if is company
     */
    private boolean isCompany() {
        return user.getIsCompany();
    }

    /**
     * Checks for invoices.
     * 
     * @return true, if successful
     */
    private boolean hasInvoices() {
        log.info("hasInvoices");

        if(PPEStatus.INVOICE_MISSING.equals(ppe.getPpeStatus())) {
            return false;
        }

        return true;
    }

    /**
     * Checks if is refused agreement.
     * 
     * @return true, if is refused agreement
     */
    private boolean isRefusedAgreement() {
        log.info("isRefusedAgreement");

        if(PPEStatus.REFUSED_AGREEMENT.equals(ppe.getPpeStatus())) {
            return true;
        }

        return false;
    }
    
    private boolean isJoined() {
        log.info("isRefusedAgreement");
        if(PPEStatus.JOINED.equals(ppe.getPpeStatus())) {
            return true;
        }

        return false;
    }

    /**
     * Checks for signed agreement.
     * 
     * @return true, if successful
     * @throws Exception
     *             the exception
     */
    private boolean hasSignedAgreement() throws Exception {
        log.info("hasSignedAgreement");

        OperatorAgreement agreement = getOperatorAgreement();
        return isSignedOperatorAgreement(agreement);
    }

    /**
     * Gets the operator agreement.
     * 
     * @return the operator agreement
     * @throws Exception
     *             the exception
     */
    private OperatorAgreement getOperatorAgreement() throws Exception {
        OperatorAgreementDao operatorAgreementDao = GuiceSingleton.getInstance()
                .getInstance(OperatorAgreementDao.class);

        return operatorAgreementDao.getOperatorAgreement(new OperatorAgreement(user));
    }

    /**
     * Checks if is signed operator agreement.
     * 
     * @param agreement
     *            the agreement
     * @return true, if is signed operator agreement
     */
    private boolean isSignedOperatorAgreement(OperatorAgreement agreement) {
        if(null == agreement) {
            return false;
        }

        return agreement.getAgreementSigned();
    }

    /**
     * Prepare global message.
     */
    public void prepareGlobalMessage() {
        log.info("prepareGlobalMessage");
        try {
            if(isCompany()) {
                if(isCompanyUserGlobalMessageToGenerate()) {
                    globalMessageKey = "auction.message.company.agreementNotSigned";
                    generateUserGlobaMessage();
                    return;
                }
            }

            if(isUserGlobalMessageToGenerate()) {
                generateUserGlobaMessage();
                return;
            }
        } catch (Exception e) {
            log.info("Problem while generateGlobalMessage: ", e);
        }
    }

    /**
     * Checks if is company user global message to generate.
     * 
     * @return true, if is company user global message to generate
     * @throws Exception
     *             the exception
     */
    private boolean isCompanyUserGlobalMessageToGenerate() throws Exception {
        if(!hasSignedAgreement()) {
            return true;
        }

        return false;
    }

    /**
     * Checks if is user global message to generate.
     * 
     * @return true, if is user global message to generate
     * @throws Exception
     *             the exception
     */
    private boolean isUserGlobalMessageToGenerate() throws Exception {
        if(isPpeGiven()) {
            if(!hasInvoices()) {
                globalMessageKey = "auction.message.invoiceMissing";
                return true;
            }
            if(isRefusedAgreement()) {
                globalMessageKey = "auction.message.ppeRefusedAgreement";
                return true;
            }
            if(isInAuction()) {
                globalMessageKey = "auction.message.ppeIsInAuction";
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if is ppe given.
     * 
     * @return true, if is ppe given
     */
    private boolean isPpeGiven() {
        if(null == ppe) {
            return false;
        }
        if(null == ppe.getPpeId()) {
            return false;
        }

        return true;
    }

    /**
     * Generate user globa message.
     */
    private void generateUserGlobaMessage() {
        MessageUtil.displayMessageWarn(globalMessageKey);
    }
}
