package pl.op.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.slf4j.LoggerFactory;

import pl.op.model.cloud.VolumeEnum;
import pl.op.model.stereotype.Sector;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;

/**
 * The Class DictUtil.
 */
public class DictUtil {

    private List<Sector> allSectorList;

    private boolean isCompany;

    /**
     * Instantiates a new dict util.
     */
    public DictUtil() {
        DictionaryBean dictionaryBean = ComponentLookup.lookupComponent("op.dictionaryBean");
        allSectorList = dictionaryBean.getSectorList();
    }

    /**
     * Gets the sector list by type.
     * 
     * @param isCompany
     *            the is company
     * @return the sector list by type
     */
    public static List<Sector> getSectorListByType(Boolean isCompany) {
        DictUtil dictUtil = new DictUtil();
        if(null == isCompany) {
            isCompany = false;
        }
        dictUtil.isCompany = isCompany;

        return dictUtil.getSectorList();
    }

    /**
     * Gets the sector list.
     * 
     * @return the sector list
     */
    public List<Sector> getSectorList() {
        List<Sector> list = new ArrayList<Sector>();
        if(isEmptySectorList()) {
            return list;
        }

        try {
            for(Sector sector : allSectorList) {
                if(canAddSectorToList(sector)) {
                    list.add(sector);
//                    LoggerFactory.getLogger(DictUtil.class).info(
//                            "Add sector: " + sector.getSectorId() + " - isCompany: " + isCompany);
                } else {
//                    LoggerFactory.getLogger(DictUtil.class).info(
//                            "Not add sector: " + sector.getSectorId() + " - isCompany: " + isCompany + "; isHidden: "
//                                    + sector.getIsHidden());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Checks if is empty sector list.
     * 
     * @return true, if is empty sector list
     */
    private boolean isEmptySectorList() {
        if(null == allSectorList) {
            return true;
        }
        if(allSectorList.isEmpty()) {
            return true;
        }

        return false;
    }

    /**
     * Can add sector to list.
     * 
     * @param sector
     *            the sector
     * @return true, if successful
     */
    private boolean canAddSectorToList(Sector sector) {
        if(isCompany == true) {
            if(!sector.getIsHidden().booleanValue()) {
                return true;
            }
        } else {
            if(sector.getIsHidden().booleanValue() == true) {
                return true;
            }
        }

        return false;
    }

    /**
     * Gets the volumes.
     * 
     * @return the volumes
     */
    public static List<VolumeEnum> getVolumes() {
        List<VolumeEnum> volumes = new ArrayList<VolumeEnum>();

        for(VolumeEnum a : VolumeEnum.values()) {
            a.setLabel(BundlesUtils.getMessageResourceString("messages", "cloud.volume." + a, null, Locale.getDefault()));

            volumes.add(a);
        }

        return volumes;
    }
}
