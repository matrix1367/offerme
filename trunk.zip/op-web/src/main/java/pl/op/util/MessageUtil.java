package pl.op.util;

import java.util.Locale;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.jboss.seam.faces.FacesMessages;

import pl.op.web.common.BundlesUtils;
import pl.op.web.listener.GuiceSingleton;

// TODO: Auto-generated Javadoc
/**
 * The Class MessageUtil.
 */
public class MessageUtil {

    private static ExternalContext ectx;

    /**
     * Initialize.
     */
    private void initialize() {
        if(null == ectx) {
            FacesContext facesContext = FacesContext.getCurrentInstance();
            ectx = facesContext.getExternalContext();
        }
    }

    /**
     * Display message.
     * 
     * @param id
     *            the id
     * @param key
     *            the key
     */
    public static void displayMessage(String id, String key) {
        String message = BundlesUtils.getMessageResourceString("messages", key, null, Locale.getDefault());
        FacesContext context = FacesContext.getCurrentInstance();
        FacesMessage facesMessage = new FacesMessage(message);
        context.addMessage(id, facesMessage);
    }

    /**
     * Display message info.
     * 
     * @param key
     *            the key
     */
    public static void displayMessageInfo(String key) {
        MessageUtil messageUtil = GuiceSingleton.getInstance().getInstance(MessageUtil.class);
        messageUtil.initialize();

        FacesMessages.instance().add(FacesMessage.SEVERITY_INFO,
                BundlesUtils.getMessageResourceString("messages", key, null, messageUtil.ectx.getRequestLocale()));
    }

    /**
     * Display message info.
     * 
     * @param id
     *            the id
     * @param key
     *            the key
     */
    public static void displayMessageInfo(String id, String key) {
        String message = BundlesUtils.getMessageResourceString("messages", key, null, Locale.getDefault());
        FacesContext context = FacesContext.getCurrentInstance();
        FacesMessage facesMessage = new FacesMessage(message);
        facesMessage.setSeverity(FacesMessage.SEVERITY_INFO);
        context.addMessage(id, facesMessage);
    }

    /**
     * Display message warn.
     * 
     * @param key
     *            the key
     */
    public static void displayMessageWarn(String key) {
        MessageUtil messageUtil = GuiceSingleton.getInstance().getInstance(MessageUtil.class);
        messageUtil.initialize();

        FacesMessages.instance().add(FacesMessage.SEVERITY_WARN,
                BundlesUtils.getMessageResourceString("messages", key, null, messageUtil.ectx.getRequestLocale()));
    }

    /**
     * Display message warn.
     * 
     * @param id
     *            the id
     * @param key
     *            the key
     */
    public static void displayMessageWarn(String id, String key) {
        String message = BundlesUtils.getMessageResourceString("messages", key, null, Locale.getDefault());
        FacesContext context = FacesContext.getCurrentInstance();
        FacesMessage facesMessage = new FacesMessage(message);
        facesMessage.setSeverity(FacesMessage.SEVERITY_WARN);
        context.addMessage(id, facesMessage);
    }

}
