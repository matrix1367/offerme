package pl.op.util;

import javax.faces.context.FacesContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.SectorDao;
import pl.op.dao.StereotypeDao;
import pl.op.model.stereotype.Sector;
import pl.op.model.user.UserApp;
import pl.op.web.beans.AdminBean;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class UserUtil.
 */
public class UserUtil {

    private Logger log = LoggerFactory.getLogger(UserUtil.class);
    private UserApp userApp;

    private StereotypeDao stereotypeDao;
    private SectorDao sectorDao;

    /**
     * Instantiates a new user util.
     */
    public UserUtil() {
        initializeDao();
    }

    /**
     * Initialize dao.
     */
    private void initializeDao() {
        stereotypeDao = GuiceSingleton.getInstance().getInstance(StereotypeDao.class);
        sectorDao = GuiceSingleton.getInstance().getInstance(SectorDao.class);
    }

    /**
     * Gets the logged user instance.
     * 
     * @return the logged user instance
     */
    public static UserApp getLoggedUserInstance() {
        UserUtil userUtil = GuiceSingleton.getInstance().getInstance(UserUtil.class);

        userUtil.updateLoggedUserApp();

        return userUtil.userApp;
    }

    /**
     * Update logged user instance.
     */
    private void updateLoggedUserApp() {
        log.info("setLoggedUserApp");

        FacesContext ctx = FacesContext.getCurrentInstance();
        AdminBean adminBean = (AdminBean) ctx.getApplication().getELResolver()
                .getValue(ctx.getELContext(), null, "op.adminBean");

        try {
            userApp = adminBean.getUserLog();
            log.info("userId: " + userApp.getUserId());
            setUserStereotype();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Sets the user stereotype.
     * 
     * @throws Exception
     *             the exception
     */
    private void setUserStereotype() throws Exception {
        log.info("setUserStereotype");

        if(!hasUserStereotypeData()) {
            userApp.getSector().setStereotype(stereotypeDao.getStereotypeBySector(userApp.getSector()));
        }

        userApp.setSectorId(userApp.getSector().getSectorId());
    }

    /**
     * Sets the user sector.
     * 
     * @throws Exception
     *             the exception
     */
    private void setUserSector() throws Exception {
        log.info("setUserSector");

        Sector sector = sectorDao.getSectorByUser(userApp);
        userApp.setSector(sector);
    }

    /**
     * Checks for user stereotype data.
     * 
     * @return true, if successful
     * @throws Exception
     *             the exception
     */
    private boolean hasUserStereotypeData() throws Exception {
        log.info("hasUserStereotypeData");

        if(null == userApp.getSector()) {
            setUserSector();
        }
        if(null == userApp.getSector().getStereotype()) {
            return false;
        }

        if(null == userApp.getSector().getStereotype().getStereotypeId()) {
            return false;
        }

        return true;
    }
}
