package pl.op.util;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.CityDao;
import pl.op.dao.StreetDao;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Street;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class LocationUtil.
 */
public class LocationUtil {

    private Logger log = LoggerFactory.getLogger(LocationUtil.class);

    private CityDao cityDao;
    private StreetDao streetDao;

    /**
     * Instantiates a new location util.
     */
    public LocationUtil() {
        initializeDao();
    }

    /**
     * Initialize dao.
     */
    private void initializeDao() {
        cityDao = GuiceSingleton.getInstance().getInstance(CityDao.class);
        streetDao = GuiceSingleton.getInstance().getInstance(StreetDao.class);
    }

    /**
     * Auto complete city.
     * 
     * @param query
     *            the query
     * @return the list
     */
    public static List<String> autoCompleteCity(String query) {
        LocationUtil util = GuiceSingleton.getInstance().getInstance(LocationUtil.class);

        return util.getAutoCompleteCity(query, null, null);
    }

    /**
     * Auto complete city.
     * 
     * @param query
     *            the query
     * @param areaId
     *            the area id
     * @return the list
     */
    public static List<String> autoCompleteCity(String query, Integer areaId) {
        LocationUtil util = GuiceSingleton.getInstance().getInstance(LocationUtil.class);

        return util.getAutoCompleteCity(query, areaId, null);
    }

    /**
     * Auto complete city.
     * 
     * @param query
     *            the query
     * @param areaId
     *            the area id
     * @param hasStatus
     *            the has status
     * @return the list
     */
    public static List<String> autoCompleteCity(String query, Integer areaId, Boolean hasStatus) {
        LocationUtil util = GuiceSingleton.getInstance().getInstance(LocationUtil.class);

        return util.getAutoCompleteCity(query, areaId, hasStatus);
    }

    /**
     * Gets the auto complete city.
     * 
     * @param query
     *            the query
     * @param areaId
     *            the area id
     * @param hasStatus
     *            the has status
     * @return the auto complete city
     */
    private List<String> getAutoCompleteCity(String query, Integer areaId, Boolean hasStatus) {
        log.info("getAutoCompleteCity(" + query + ", " + areaId + ", " + hasStatus + ")");
        List<String> suggestions = new ArrayList<String>();

        query = query.toLowerCase();
        log.info("autocompleteCity query: " + query);

        try {
            City tmpCity = prepareTmpCity(areaId, hasStatus);
            tmpCity.setCityName(query);

            List<City> searchCities = cityDao.searchCities(tmpCity);
            if(isCitiesOnList(searchCities)) {
                suggestions = prepareSuggestionsCityList(searchCities);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return suggestions;
    }

    /**
     * Auto complete street.
     * 
     * @param query
     *            the query
     * @return the list
     */
    public static List<String> autoCompleteStreet(String query) {
        LocationUtil util = GuiceSingleton.getInstance().getInstance(LocationUtil.class);

        return util.getAutoCompleteStreet(query, null);
    }

    /**
     * Auto complete street.
     * 
     * @param query
     *            the query
     * @param cityId
     *            the city id
     * @return the list
     */
    public static List<String> autoCompleteStreet(String query, Integer cityId) {
        LocationUtil util = GuiceSingleton.getInstance().getInstance(LocationUtil.class);

        return util.getAutoCompleteStreet(query, cityId);
    }

    /**
     * Gets the city.
     * 
     * @param name
     *            the name
     * @param area
     *            the area
     * @return the city
     */
    public static City getCity(String name, Area area) {
        LocationUtil util = GuiceSingleton.getInstance().getInstance(LocationUtil.class);

        Integer areaId = (area != null) ? area.getAreaId() : null;
        City filterCity = util.prepareTmpCity(areaId, null);
        filterCity.setCityName(name);

        City selectedCity = null;
        try {
            selectedCity = util.cityDao.getCity(filterCity);
            util.log.info("Search city by name: " + name + "; Result: " + selectedCity);
        } catch (Exception e) {
            util.log.error("Problem while search selected city: ", e);
        }

        return selectedCity;
    }

    /**
     * Gets the street.
     * 
     * @param name
     *            the name
     * @param city
     *            the city
     * @param area
     *            the area
     * @return the street
     */
    public static Street getStreet(String name, City city, Area area) {
        LocationUtil util = GuiceSingleton.getInstance().getInstance(LocationUtil.class);

        Street filterStreet = util.prepareTmpStreet(city, area);
        filterStreet.setStreetName(name);

        Street selectedStreet = null;
        try {
            selectedStreet = util.streetDao.getStreet(filterStreet);
            util.log.info("Search street by name: " + name + "; Result: " + selectedStreet);
        } catch (Exception e) {
            util.log.error("Problem while search selected street: ", e);
        }

        return selectedStreet;
    }

    /**
     * Gets the auto complete street.
     * 
     * @param query
     *            the query
     * @param cityId
     *            the city id
     * @return the auto complete street
     */
    private List<String> getAutoCompleteStreet(String query, Integer cityId) {
        log.info("getAutoCompleteStreet(" + query + ", " + cityId + ")");
        List<String> suggestions = new ArrayList<String>();

        query = query.toLowerCase();
        log.info("autocompleteCity query: " + query);

        try {
            Street tmpStreet = prepareTmpStreet(cityId);
            tmpStreet.setStreetName(query);

            List<Street> searchStreets = streetDao.searchStreets(tmpStreet);
            if(isStreetsOnList(searchStreets)) {
                suggestions = prepareSuggestionsStreetList(searchStreets);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return suggestions;
    }

    /**
     * Prepare tmp street.
     * 
     * @param cityId
     *            the city id
     * @return the street
     */
    private Street prepareTmpStreet(Integer cityId) {
        Street street = new Street();

        City city = new City();
        city.setCityId(cityId);

        street.setCity(city);
        street.setCityId(cityId);
        street.setLimit(30);

        return street;
    }

    /**
     * Prepare tmp street.
     * 
     * @param city
     *            the city
     * @param area
     *            the area
     * @return the street
     */
    private Street prepareTmpStreet(City city, Area area) {
        Integer cityId = (city != null) ? city.getCityId() : null;
        Integer areaId = (area != null) ? area.getAreaId() : null;

        Street street = prepareTmpStreet(cityId);
        street.getCity().setArea(new Area());
        street.getCity().getArea().setAreaId(areaId);

        return street;
    }

    /**
     * Prepare tmp city.
     * 
     * @param areaId
     *            the area id
     * @param hasStatus
     *            the has status
     * @return the city
     */
    private City prepareTmpCity(Integer areaId, Boolean hasStatus) {
        City city = new City();
        if(null != areaId) {
            city.setArea(new Area());
            city.getArea().setAreaId(areaId);
            city.setAreaId(areaId);
            log.info("autocompleteCity areaId: " + areaId);
        }

        if(null != hasStatus) {
            city.setHasStatus(hasStatus);
        }
        city.setLimit(30);

        return city;
    }

    /**
     * Checks if is cities on list.
     * 
     * @param cities
     *            the cities
     * @return true, if is cities on list
     */
    private boolean isCitiesOnList(List<City> cities) {
        if(null == cities) {
            return false;
        }
        if(cities.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Checks if is streets on list.
     * 
     * @param streets
     *            the streets
     * @return true, if is streets on list
     */
    private boolean isStreetsOnList(List<Street> streets) {
        if(null == streets) {
            return false;
        }
        if(streets.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Prepare suggestions city list.
     * 
     * @param cities
     *            the cities
     * @return the list
     */
    private List<String> prepareSuggestionsCityList(List<City> cities) {
        log.info("cities.size(): " + cities.size());
        List<String> suggestions = new ArrayList<String>();

        for(City tmpFindCity : cities) {
            log.info("tmpFindCity: " + tmpFindCity.getCityName());
            suggestions.add(tmpFindCity.getCityName());
        }

        return suggestions;
    }

    /**
     * Prepare suggestions street list.
     * 
     * @param streets
     *            the streets
     * @return the list
     */
    private List<String> prepareSuggestionsStreetList(List<Street> streets) {
        log.info("streets.size(): " + streets.size());
        List<String> suggestions = new ArrayList<String>();

        for(Street tmpFindStreet : streets) {
            log.info("tmpFindStreet: " + tmpFindStreet.getStreetName());
            suggestions.add(tmpFindStreet.getStreetName());
        }

        return suggestions;
    }
}
