package pl.op.web.beans.log;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Serializable;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.OperatorAgreementDao;
import pl.op.model.contract.OperatorAgreement;
import pl.op.web.beans.AdminBean;
import pl.op.web.beans.CustomerBean;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;
import pl.op.web.service.BonusService;

@Name("op.operatorAgreementBean")
@Scope(ScopeType.SESSION)
public class OperatorAgreementBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private Logger log = LoggerFactory.getLogger(OperatorAgreementBean.class);

    private SalesmanBean salesmanBean;
    private CustomerBean customerBean;

    private OperatorAgreement operatorAgreement;
    private OperatorAgreement operatorAgreementNew;
    private OperatorAgreementDao operatorAgreementDao;

    private UploadedFile agreementFile;

    private Boolean salesmanAgreement;

    @In(value = "#{op.adminBean}", scope = ScopeType.SESSION, required = true)
    private AdminBean adminBean;

    public OperatorAgreementBean() {
        log.info("OperatorAgreementBean constructor");
        initialize();
    }

    private void initialize() {
        operatorAgreementDao = GuiceSingleton.getInstance().getInstance(OperatorAgreementDao.class);
        salesmanBean = ComponentLookup.lookupComponent("op.salesmanBean");
        customerBean = ComponentLookup.lookupComponent("op.customerBean");
    }

    public StreamedContent downloadAgreement() {
        InputStream is = new ByteArrayInputStream(operatorAgreement.getFile());
        StreamedContent file = new DefaultStreamedContent(is);

        return file;
    }

    public void initializeAgreement(Boolean salesmanAgreement) {
        this.salesmanAgreement = salesmanAgreement;

        OperatorAgreement filter = new OperatorAgreement();

        if (salesmanAgreement)
            filter.setSalesman(salesmanBean.getSalesman());
        else
            filter.setUser(customerBean.getCustomer());

        try {
            operatorAgreement = operatorAgreementDao.getOperatorAgreement(filter);
        } catch (Exception e) {
            log.error("There has been an error while initializing agreement: " + e);
        }

        if (operatorAgreement == null) {
            operatorAgreement = new OperatorAgreement();
            operatorAgreement.setAgreementSigned(false);
        }
    }

    public void addAgreement() {
        operatorAgreementNew.setOperatorAgreementId(operatorAgreement.getOperatorAgreementId());
        operatorAgreementNew.setFile(agreementFile.getContents());
        operatorAgreementNew.setRemoved(false);
        operatorAgreementNew.setAgreementSigned(operatorAgreement.getAgreementSigned());

        if (salesmanAgreement)
            operatorAgreementNew.setSalesman(salesmanBean.getSalesman());
        else
            operatorAgreementNew.setUser(customerBean.getCustomer());

        try {
            if (operatorAgreementNew.getOperatorAgreementId() == null)
                operatorAgreementDao.saveOperatorAgreement(operatorAgreementNew);
            else
                operatorAgreementDao.updateOperatorAgreement(operatorAgreementNew);
        } catch (Exception e) {
            log.error("There has been an error while adding agreement: " + e);
        }

        clearAgreementNew();
        initializeAgreement(salesmanAgreement);
    }

    public void updateAgreement() {
        if (salesmanAgreement)
            operatorAgreement.setSalesman(salesmanBean.getSalesman());
        else
            operatorAgreement.setUser(customerBean.getCustomer());

        try {
            if (operatorAgreement.getAgreementSigned()) {
                if (salesmanAgreement) {
                    BonusService.run("signingContract", adminBean.getUserLog());
                } else {
                    BonusService.run("signingContract", customerBean.getCustomer());
                }
            }
            operatorAgreementDao.updateOperatorAgreement(operatorAgreement);
        } catch (Exception e) {
            log.error("There has been an error while updating agreement: " + e);
        }
    }

    public void clearAgreementNew() {
        operatorAgreementNew = new OperatorAgreement();
    }

    public Boolean getSalesmanAgreement() {
        return salesmanAgreement;
    }

    public void setSalesmanAgreement(Boolean salesmanAgreement) {
        this.salesmanAgreement = salesmanAgreement;
    }

    public OperatorAgreement getOperatorAgreement() {
        return operatorAgreement;
    }

    public void setOperatorAgreement(OperatorAgreement operatorAgreement) {
        this.operatorAgreement = operatorAgreement;
    }

    public OperatorAgreement getOperatorAgreementNew() {
        return operatorAgreementNew;
    }

    public void setOperatorAgreementNew(OperatorAgreement operatorAgreementNew) {
        this.operatorAgreementNew = operatorAgreementNew;
    }

    public UploadedFile getAgreementFile() {
        return agreementFile;
    }

    public void setAgreementFile(UploadedFile agreementFile) {
        this.agreementFile = agreementFile;
    }

}
