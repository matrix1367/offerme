package pl.op.web.beans.auction;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.TabChangeEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AuctionDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionAttributesEnum;
import pl.op.model.auction.AuctionEndEnum;
import pl.op.model.auction.AuctionFilter;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.auction.AuctionStatus;
import pl.op.model.auction.AuctionUser;
import pl.op.model.auction.PriceComponent;
import pl.op.model.auction.PriceComponentValue;
import pl.op.model.cloud.Cloud;
import pl.op.model.cloud.VolumeEnum;
import pl.op.model.contract.PPE;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Tariff;
import pl.op.model.stereotype.Stereotype;
import pl.op.model.user.UserApp;
import pl.op.util.DictUtil;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;
import pl.op.web.service.BonusService;

/**
 * The Class AuctionBean.
 */
@Name("op.auctionBean")
@Scope(ScopeType.SESSION)
public class AuctionBean {

    private Logger log = LoggerFactory.getLogger(AuctionBean.class);
    public static final long HOUR = 3600 * 1000;

    private Auction auction;
    private Auction auctionDetails; //auctionEconomy
    //private Integer ppeIdEconomy;
    private AuctionOffer auctionOffer;

    private List<Area> areas;
    private List<City> cities;
    private List<AuctionEndEnum> auctionEnd;
    private List<AuctionAttributesEnum> auctionAttributes;
    private List<Tariff> tariffs;
    private List<Stereotype> stereotypes;
    private List<VolumeEnum> volumes;

    private AuctionDao auctionDao;

    private DictionaryBean dictionaryBean;

    private boolean auctionOfferButtons = true;
    private String actualTab;

    /**
     * Instantiates a new auction bean.
     */
    public AuctionBean() {
        log.info("AuctionBean contructor");
        initializeDao();
        initializeVars();
    }

    /**
     * Initialize dao.
     */
    private void initializeDao() {
        log.info("initializeDao");

        auctionDao = GuiceSingleton.getInstance().getInstance(AuctionDao.class);
    }

    /**
     * Initialize vars.
     */
    private void initializeVars() {
        log.info("initializeVars");

        dictionaryBean = ComponentLookup.lookupComponent("op.dictrionaryBean");

        auction = new Auction();
        auction.setCloud(new Cloud());
    }

    /**
     * Initialize on load.
     */
    public void initializeOnLoad() {
        try {
            if(!isInitializedDicts()) {
                initializeDicts();
            }

            tariffs = dictionaryBean.getTariffsList();
            stereotypes = dictionaryBean.getStereotypesList();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Initialize dicts.
     */
    public void initializeDicts() {
        areas = dictionaryBean.getAreasList();
        cities = new ArrayList<City>();
    }

    /**
     * Checks if is initialized dicts.
     * 
     * @return true, if is initialized dicts
     */
    private boolean isInitializedDicts() {
        if(null == areas || null == cities) {
            return false;
        }
        if(areas.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Checks if is initialized.
     * 
     * @return true, if is initialized
     */
    private boolean isInitialized() {
        if(!isInitializedDicts()) {
            return false;
        }
        if(null == tariffs || null == stereotypes) {
            return false;
        }
        if(tariffs.isEmpty() || stereotypes.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Search auctions.
     * 
     * @param auctionFilter
     *            the auction filter
     * @return the list
     */
    public List<Auction> searchAuctions(AuctionFilter auctionFilter) {
        log.info("[searchAuctions]");
        List<Auction> auctions = new ArrayList<Auction>();
        if(auctionFilter.getEndTime() != null) {
            Date finishDate = new Date();
            auctionFilter.getAuction().setFinishDate(
                    new Date((long) (finishDate.getTime() + auctionFilter.getEndTime() * HOUR)));
        }

        try {
           //log.info("searchAuctions :\n"+ auctionFilter.toString());
            auctions = auctionDao.getAuctions(auctionFilter);
        } catch (Exception e) {
            log.error("Problem while searchAuction: ", e);
        }

        return auctions;
    }
    
        /**
     * Search auctions.
     * 
     * @param auctionFilter
     *            the auction filter
     * @return the list
     */
    public List<Auction> searchAuctionsForUser(AuctionFilter auctionFilter) {
        log.info("[searchAuctionsForUser]");
        List<Auction> auctions = new ArrayList<Auction>();
        if(auctionFilter.getEndTime() != null) {
            Date finishDate = new Date();
            auctionFilter.getAuction().setFinishDate(
                    new Date((long) (finishDate.getTime() + auctionFilter.getEndTime() * HOUR)));
        }

        try {
           //log.info("searchAuctions :\n"+ auctionFilter.toString());
            auctions = auctionDao.getAuctionsForUsers(auctionFilter);
        } catch (Exception e) {
            log.error("Problem while searchAuction: ", e);
        }

        return auctions;
    } 

    /**
     * Not constant prices.
     * 
     * @param auctionOfferId
     *            the auction offer id
     * @return the double
     */
    public Double notConstantPrices(Integer auctionOfferId) {
        Double price = null;
        PriceComponentValue priceComponentValue = initializePriceComponentValue();
        priceComponentValue.getAuctionOffer().setAuctionOfferId(auctionOfferId);
        priceComponentValue.getPriceComponent().setConstant(false);

        try {
            price = auctionDao.getPriceComponentValuesByConstant(priceComponentValue);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return price;
    }

    /**
     * Initialize price component value.
     * 
     * @return the price component value
     */
    private PriceComponentValue initializePriceComponentValue() {
        PriceComponentValue priceComponentValue = new PriceComponentValue();
        priceComponentValue.setAuctionOffer(new AuctionOffer());
        priceComponentValue.setPriceComponent(new PriceComponent());

        return priceComponentValue;
    }

    /**
     * Constant prices.
     * 
     * @param auctionOfferId
     *            the auction offer id
     * @return the double
     */
    public Double constantPrices(Integer auctionOfferId) {
        Double price = null;
        PriceComponentValue priceComponentValue = initializePriceComponentValue();
        priceComponentValue.getAuctionOffer().setAuctionOfferId(auctionOfferId);
        priceComponentValue.getPriceComponent().setConstant(true);

        try {
            price = auctionDao.getPriceComponentValuesByConstant(priceComponentValue);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return price;
    }

    /**
     * Contract date.
     * 
     * @return the string
     */
    public String contractDate() {
        return BundlesUtils.getMessageResourceString("messages", "from", null, Locale.getDefault()) + " "
                + auction.getBeginContractDate() + " "
                + BundlesUtils.getMessageResourceString("messages", "to", null, Locale.getDefault()) + " "
                + auction.getEndContractDate();
    }

    /**
     * Auction status.
     * 
     * @return the string
     */
    public String auctionStatus() {
        if(auction.getStatus() != null)
            return BundlesUtils.getMessageResourceString("messages", "auction.status." + auction.getStatus(), null,
                    Locale.getDefault());
        else
            return "";
    }

    /**
     * Change auction offer status.
     */
    public void changeAuctionOfferStatus() {
        if(auctionOffer.getStatus() == AuctionStatus.INPROGRESS)
            auctionOffer.setStatus(AuctionStatus.SUSPENDED);
        else
            auctionOffer.setStatus(AuctionStatus.INPROGRESS);
    }

    /**
     * Edits the auction action.
     * 
     * @return the string
     */
    public String editAuctionAction() {
        return "auctionEdit";
    }

    /**
     * Sets the auction components.
     * 
     * @param auction
     *            the new auction components
     */
    public void setAuctionComponents(Auction auction) {
        this.auction = auction;

        try {
            this.auction.setAuctionOffers(auctionDao.getAuctionOffers(auction));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * Assign user to auction.
     * 
     * @param auction
     *            the auction
     * @param user
     *            the user
     * @param ppe
     *            the ppe
     */
    public void assignUserToAuction(Auction auction, UserApp user, PPE ppe) {
        AuctionUser auctionUser = new AuctionUser();

        auctionUser.setAuction(auction);
        auctionUser.setUserApp(user);
        auctionUser.setPpe(ppe);
        auctionUser.setJoinedAt(new Date());

        if(user.getIsCompany() == false) {
            BonusService.run("offerAuction", user);
        }

        try {
            auctionDao.assignUserToAuction(auctionUser);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Lock message.
     * 
     * @return the string
     */
    public String lockMessage() {
        if(auctionOffer != null) {
            Object[] param = new Object[1];
            param[0] = auctionOffer.getAuctionOfferId();

            if(auctionOffer.getStatus() == AuctionStatus.INPROGRESS)
                return BundlesUtils.getMessageResourceString("messages", "label.offer.block", param,
                        Locale.getDefault());
            else
                return BundlesUtils.getMessageResourceString("messages", "label.offer.unblock", param,
                        Locale.getDefault());
        } else
            return "";
    }

    /**
     * Auction offer tariff.
     */
    public void auctionOfferTariff() {
        auctionOffer.setAuction(auction);
        try {
            auctionOffer.setPriceComponentValues(auctionDao.getAuctionOfferTariff(auctionOffer));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * On auction offer select.
     * 
     * @param event
     *            the event
     */
    public void onAuctionOfferSelect(SelectEvent event) {
        auctionOfferButtons = false;
    }

    /**
     * Change auction status.
     */
    public void changeAuctionStatus() {
        if(auction.getStatus() == AuctionStatus.INPROGRESS) {
            auction.setStatus(AuctionStatus.SUSPENDED);

            try {
                auctionDao.updateAuction(auction);
            } catch (Exception e1) {
                e1.printStackTrace();
            }

            for(int i = 0; i < auction.getAuctionOffers().size(); i++) {
                auction.getAuctionOffers().get(i).setStatus(AuctionStatus.SUSPENDED);

                try {
                    auctionDao.updateAuctionOffer(auction.getAuctionOffers().get(i));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else
            auction.setStatus(AuctionStatus.INPROGRESS);
    }

    /**
     * Send email.
     * 
     * @param auctionOffer
     *            the auction offer
     */
    private void sendEmail(AuctionOffer auctionOffer) {
    }

    /**
     * Auction ends.
     * 
     * @param endDate
     *            the end date
     * @return the string
     */
    public String auctionEnds(Date endDate) {
        String result = "";
        long diffrence = endDate.getTime() - System.currentTimeMillis();
        if(diffrence / 1000 % 60 > 1)
            result = diffrence / 1000 % 60 + "s";

        if(diffrence / 1000 / 60 % 60 > 1)
            result = diffrence / 1000 / 60 % 60 + "m " + result;

        if(diffrence / 1000 / 60 / 60 % 60 > 1)
            result = diffrence / 1000 / 60 / 60 % 24 + "h " + result;

        if(diffrence / 1000 / 60 / 60 / 24 % 24 > 1)
            result = diffrence / 1000 / 60 / 60 / 24 + "d " + result;

        return result;
    }

    /**
     * Price component const.
     * 
     * @param isConst
     *            the is const
     * @param value
     *            the value
     * @param pConst
     *            the const
     * @return the string
     */
    public String priceComponentConst(boolean isConst, Double value, boolean pConst) {
        if(isConst == pConst)
            return value.toString();
        else
            return "-";
    }

    /**
     * Cloud data.
     * 
     * @return the string
     */
    public String cloudData() {
        String result = "";
        if(auction.getCloud().getCities() != null) {
            for(int i = 0; i < auction.getCloud().getCities().size(); i++) {
                result += auction.getCloud().getCities().get(i).getCityName();
                if((i + 1) < auction.getCloud().getCities().size())
                    result += ", ";
            }
        }

        if(auction.getCloud().getStreets() != null) {
            result += " ";
            for(int i = 0; i < auction.getCloud().getStreets().size(); i++) {
                result += auction.getCloud().getStreets().get(i).getStreetName();
                if((i + 1) < auction.getCloud().getStreets().size())
                    result += ", ";
            }
        }

        result += " " + auction.getCloud().getTariff().getTariffName();
        if(auction.getCloud().getStereotype() != null)
            result += " " + auction.getCloud().getStereotype().getStereotypeName();

        return result;
    }

    /**
     * Best auction offer score.
     * 
     * @param auction
     *            the auction
     * @return the double
     */
    public Double bestAuctionOfferScore(Auction auction) {

        Double bestScore = 0.00;

        try {
            bestScore = auctionDao.getBestAuctionOfferScore(auction);
        } catch (Exception e) {
            log.error("Problem while get best Auction offer score: ", e);
        }

        return bestScore;

    }

    /**
     * Gets the areas.
     * 
     * @return the areas
     */
    public List<Area> getAreas() {
        if(!isInitialized()) {
            initializeOnLoad();
        }
        return areas;
    }

    /**
     * Sets the areas.
     * 
     * @param areas
     *            the new areas
     */
    public void setAreas(List<Area> areas) {
        this.areas = areas;
    }

    /**
     * Gets the cities.
     * 
     * @return the cities
     */
    public List<City> getCities() {
        if(!isInitialized()) {
            initializeOnLoad();
        }
        return cities;
    }

    /**
     * Sets the cities.
     * 
     * @param cities
     *            the new cities
     */
    public void setCities(List<City> cities) {
        this.cities = cities;
    }

    /**
     * Gets the tariffs.
     * 
     * @return the tariffs
     */
    public List<Tariff> getTariffs() {
        if(!isInitialized()) {
            initializeOnLoad();
        }
        return tariffs;
    }

    /**
     * Sets the tariffs.
     * 
     * @param tariffs
     *            the new tariffs
     */
    public void setTariffs(List<Tariff> tariffs) {
        this.tariffs = tariffs;
    }

    /**
     * Gets the stereotypes.
     * 
     * @return the stereotypes
     */
    public List<Stereotype> getStereotypes() {
        if(!isInitialized()) {
            initializeOnLoad();
        }
        return stereotypes;
    }

    /**
     * Sets the stereotypes.
     * 
     * @param stereotypes
     *            the new stereotypes
     */
    public void setStereotypes(List<Stereotype> stereotypes) {
        this.stereotypes = stereotypes;
    }

    /**
     * Gets the auction attributes.
     * 
     * @return the auction attributes
     */
    public List<AuctionAttributesEnum> getAuctionAttributes() {
        auctionAttributes = new ArrayList<AuctionAttributesEnum>();

        for(AuctionAttributesEnum a : AuctionAttributesEnum.values()) {
            a.setLabel(BundlesUtils.getMessageResourceString("messages", "auction.attribute." + a, null,
                    Locale.getDefault()));

            auctionAttributes.add(a);
        }

        return auctionAttributes;
    }

    /**
     * Sets the auction attributes.
     * 
     * @param auctionAttributes
     *            the new auction attributes
     */
    public void setAuctionAttributes(List<AuctionAttributesEnum> auctionAttributes) {
        this.auctionAttributes = auctionAttributes;
    }

    /**
     * Gets the auction end.
     * 
     * @return the auction end
     */
    public List<AuctionEndEnum> getAuctionEnd() {
        auctionEnd = new ArrayList<AuctionEndEnum>();

        for(AuctionEndEnum a : AuctionEndEnum.values()) {
            a.setLabel(BundlesUtils.getMessageResourceString("messages", "auction.end." + a, null, Locale.getDefault()));

            auctionEnd.add(a);
        }

        return auctionEnd;
    }

    /**
     * Sets the auction end.
     * 
     * @param auctionEnd
     *            the new auction end
     */
    public void setAuctionEnd(List<AuctionEndEnum> auctionEnd) {
        this.auctionEnd = auctionEnd;
    }

    /**
     * Gets the auction.
     * 
     * @return the auction
     */
    public Auction getAuction() {
        return auction;
    }

    /**
     * Sets the auction.
     * 
     * @param auction
     *            the new auction
     */
    public void setAuction(Auction auction) {
        this.auction = auction;
    }

    /**
     * Gets the auction offer.
     * 
     * @return the auction offer
     */
    public AuctionOffer getAuctionOffer() {
        return auctionOffer;
    }

    /**
     * Sets the auction offer.
     * 
     * @param auctionOffer
     *            the new auction offer
     */
    public void setAuctionOffer(AuctionOffer auctionOffer) {
        this.auctionOffer = auctionOffer;
    }

    /**
     * Checks if is auction offer buttons.
     * 
     * @return true, if is auction offer buttons
     */
    public boolean isAuctionOfferButtons() {
        return auctionOfferButtons;
    }

    /**
     * Sets the auction offer buttons.
     * 
     * @param auctionOfferButtons
     *            the new auction offer buttons
     */
    public void setAuctionOfferButtons(boolean auctionOfferButtons) {
        this.auctionOfferButtons = auctionOfferButtons;
    }

    /**
     * Gets the auctions count.
     * 
     * @return the auctions count
     */
    public int getAuctionsCount() {
        try {
            log.info("getAuctionsCount");
            AuctionFilter auctionFilter = new AuctionFilter();
            Integer result = auctionDao.getAuctionCount(auctionFilter);

            log.info("result = " + result);
            if(result == null)
                return 0;

            return result;
        } catch (Exception e) {
            log.error("Problem while get auctions Count: ", e);
        }

        return 0;
    }

    /**
     * Gets the closed auctions count.
     * 
     * @return the closed auctions count
     */
    public int getClosedAuctionsCount() {
        try {
            log.info("getClosedAuctionsCount");
            AuctionFilter auctionFilter = new AuctionFilter();
            auctionFilter.getAuction().setStatus(AuctionStatus.FINISHED);
            Integer result = auctionDao.getAuctionCount(auctionFilter);

            log.info("result = " + result);
            if(result == null)
                return 0;

            return result;
        } catch (Exception e) {
            log.error("Problem while get cloused auctions count: ", e);
        }

        return 0;
    }

    /**
     * Gets the open auctions count.
     * 
     * @return the open auctions count
     */
    public int getOpenAuctionsCount() {
        try {
            log.info("getOpenAuctionsCount");
            AuctionFilter auctionFilter = new AuctionFilter();
            auctionFilter.getAuction().setStatus(AuctionStatus.INPROGRESS);
            Integer result = auctionDao.getAuctionCount(auctionFilter);

            log.info("result = " + result);
            if(result == null)
                return 0;

            return result;
        } catch (Exception e) {
            log.error("Problem while get open auctions count: ", e);
        }

        return 0;
    }

    /**
     * Gets the blocked auctions count.
     * 
     * @return the blocked auctions count
     */
    public int getBlockedAuctionsCount() {
        try {
            log.info("getBlockedAuctionsCount");
            AuctionFilter auctionFilter = new AuctionFilter();
            auctionFilter.getAuction().setStatus(AuctionStatus.SUSPENDED);
            Integer result = auctionDao.getAuctionCount(auctionFilter);

            log.info("result = " + result);
            if(result == null)
                return 0;

            return result;
        } catch (Exception e) {
            log.error("Problem while get blocked auctions count: ", e);
        }

        return 0;
    }

    /**
     * Gets the volumes.
     * 
     * @return the volumes
     */
    public List<VolumeEnum> getVolumes() {
        volumes = DictUtil.getVolumes();
        return volumes;
    }

    /**
     * On tab change user auction.
     * 
     * @param event
     *            the event
     */
    public void onTabChangeUserAuction(TabChangeEvent event) {
        log.info("change to tab: " + event.getTab().getId());
        actualTab = event.getTab().getId();
        setPPEIdEconomy();
    }

    public String getActualTab() {
        return actualTab;
    }

    /**
     * Gets the auction details.
     * 
     * @return the auction details
     */
    public Auction getAuctionDetails() {
        if(null == actualTab || "inProgressAuctionBox".equals(actualTab)) {
            AuctionInProgressBean bean = ComponentLookup.lookupComponent("op.auctionInProgressBean");
            auctionDetails = bean.getSelectedAuction();
        } else {
            AuctionArchiveBean bean = ComponentLookup.lookupComponent("op.auctionArchiveBean");
            auctionDetails = bean.getSelectedAuction();
        }

        return auctionDetails;
    }
    
    /**
     * Gets the ppe economy.     
     */
    public void setPPEIdEconomy() {    
        
        if(null == actualTab || "inProgressAuctionBox".equals(actualTab)) {
            AuctionInProgressBean bean = ComponentLookup.lookupComponent("op.auctionInProgressBean");
            Integer ppeIdEconomy = bean.getUserPpeId();
            bean.updateAuctionLocation(ppeIdEconomy);
             
        } else {
            AuctionArchiveBean bean = ComponentLookup.lookupComponent("op.auctionArchiveBean");
            Integer ppeIdEconomy = bean.getUserPpeId();
            
            AuctionInProgressBean beanInProgres = ComponentLookup.lookupComponent("op.auctionInProgressBean");
            beanInProgres.updateAuctionLocation(ppeIdEconomy);
             
        }
        //return ppeIdEconomy;
    }

    /**
     * Update auction instance finish date.
     * 
     * @param auction
     *            the auction
     */
    public void updateAuctionInstanceFinishDate(Auction auction) {
       // log.info("updateAuctionInstanceFinishDate");
        if(isAuctionValid(auction)) {
          //  log.info("actual finishDate in auction(#" + auction.getAuctionId() + "): "
          //          + auction.getFinishDate().toString());
            try {
                Auction freshInstance = auctionDao.getAuctionAndOffers(auction.getAuctionId());

                if(isAuctionValid(freshInstance)) {
                    auction.setFinishDate(freshInstance.getFinishDate());
                    auction.setAuctionOffers(freshInstance.getAuctionOffers());

                    if(freshInstance.getFinishDate().compareTo(new Date()) <= 0
                            && AuctionStatus.INPROGRESS.equals(freshInstance.getStatus())) {
                        auction.setStatus(AuctionStatus.FINISHED);
                    } else {
                        auction.setStatus(freshInstance.getStatus());
                    }

                  //  log.info("fresh finishDate in auction(#" + freshInstance.getAuctionId() + "): "
                  //          + freshInstance.getFinishDate().toString());
                }
            } catch (Exception e) {
                log.error("Problem while update auction finish date: ", e);
            }
        }
    }

    /**
     * Checks if is auction valid.
     * 
     * @param auction
     *            the auction
     * @return true, if is auction valid
     */
    private boolean isAuctionValid(Auction auction) {
        if(null == auction) {
            return false;
        }
        if(null == auction.getFinishDate()) {
            return false;
        }

        return true;
    }
    
    public int getAuctionUserCount(Auction auction) throws Exception {
       log.info(">>>getAuctionUserCout");
        if (auction != null) {
            int tmp= auctionDao.getAuctionUsers(auction).size();
            log.info("auction id : " + auction.getAuctionId() + " user size:" + tmp);
            return tmp;
        }
        return 0;
    }
}