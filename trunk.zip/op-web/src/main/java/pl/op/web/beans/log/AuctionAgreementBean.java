package pl.op.web.beans.log;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import jxl.CellView;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.write.Label;
import jxl.write.Number;
import jxl.write.WritableCellFeatures;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AgreementDao;
import pl.op.dao.AuctionDao;
import pl.op.dao.PPEDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionAgreement;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.auction.AuctionStatus;
import pl.op.model.cloud.Cloud;
import pl.op.model.contract.Agreement;
import pl.op.model.contract.AgreementType;
import pl.op.model.contract.DurationType;
import pl.op.model.contract.PPE;
import pl.op.model.contract.PPEStatus;
import pl.op.model.dict.Tariff;
import pl.op.model.salesman.Salesman;
import pl.op.web.beans.AdminBean;
import pl.op.web.beans.auction.operator.AuctionBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.common.Consts;
import pl.op.web.listener.GuiceSingleton;

@Name("op.auctionAgreementBean")
@Scope(ScopeType.SESSION)
public class AuctionAgreementBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private Logger log = LoggerFactory.getLogger(AuctionAgreementBean.class);

    private List<AuctionAgreement> auctionAgreements;

    private AuctionAgreement auctionAgreement;
    private WritableCellFormat timesBoldUnderline;
    private WritableCellFormat times;
    private AuctionOffer auctionAgreementFilter;
    private UploadedFile uploadedFile;

    private AuctionDao auctionDao;
    private PPEDao ppeDao;
    private SalesmanBean salesmanBean;
    private AgreementDao agreementDao;
    private AdminBean adminBean;

    private Boolean buttonDisabled;

    public AuctionAgreementBean() {
        log.info("SalesmanBean constructor");
        initialize();
    }

    private void initialize() {
        auctionDao = GuiceSingleton.getInstance().getInstance(AuctionDao.class);
        adminBean = ComponentLookup.lookupComponent("op.adminBean");
        salesmanBean = ComponentLookup.lookupComponent("op.salesmanBean");
        ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);
        agreementDao = GuiceSingleton.getInstance().getInstance(AgreementDao.class);
        clearAgreementFilter();
    }

    public void clearAgreementFilter() {
        auctionAgreementFilter = new AuctionOffer();

        auctionAgreementFilter.setSalesman(salesmanBean.getSalesman());

        Auction a = new Auction();
        Cloud c = new Cloud();
        c.setTariff(new Tariff());
        a.setCloud(c);

        auctionAgreementFilter.setAuction(a);
    }

    public void searchAgreements() {
        log.info("searchAgreements");
        try {
            auctionAgreements = auctionDao.getGroupedAuctionAgreements(auctionAgreementFilter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public AuctionOffer getAuctionAgreementFilter() {
        return auctionAgreementFilter;
    }

    public void setAuctionAgreementFilter(AuctionOffer auctionAgreementFilter) {
        this.auctionAgreementFilter = auctionAgreementFilter;
    }

    public List<AuctionAgreement> getAuctionAgreements() {
        return auctionAgreements;
    }

    public void setAuctionAgreements(List<AuctionAgreement> auctionAgreements) {
        this.auctionAgreements = auctionAgreements;
    }

    public Boolean getButtonDisabled() {
        return buttonDisabled;
    }

    public void setButtonDisabled(Boolean buttonDisabled) {
        this.buttonDisabled = buttonDisabled;
    }

    public AuctionAgreement getAuctionAgreement() {
        return auctionAgreement;
    }

    public void setAuctionAgreement(AuctionAgreement auctionAgreement) {
        this.auctionAgreement = auctionAgreement;
    }

    public UploadedFile getUploadedFile() {
        return uploadedFile;
    }

    public void setUploadedFile(UploadedFile uploadedFile) {
        this.uploadedFile = uploadedFile;
    }

    public StreamedContent generateReport(Integer auctionId) throws IOException, WriteException {
        OutputStream os = new ByteArrayOutputStream();
        WorkbookSettings wbSettings = new WorkbookSettings();

        wbSettings.setLocale(new Locale("en", "EN"));

        WritableWorkbook workbook = Workbook.createWorkbook(os, wbSettings);
        workbook.createSheet("Report", 0);
        WritableSheet excelSheet = workbook.getSheet(0);
        createLabel(excelSheet);
        createContent(excelSheet, auctionId);

        workbook.write();
        workbook.close();

        InputStream is = new ByteArrayInputStream(((ByteArrayOutputStream) os).toByteArray());
        StreamedContent file = new DefaultStreamedContent(is, "application/xls", "raport.xls");

        return file;

    }

    private void createLabel(WritableSheet sheet) throws WriteException {
        WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
        times = new WritableCellFormat(times10pt);
        times.setWrap(true);

        WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10);
        timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);

        CellView cv = new CellView();
        cv.setFormat(times);
        cv.setFormat(timesBoldUnderline);
        cv.setAutosize(true);

        addCaption(sheet, 0, 0, new Date().toLocaleString());
        addCaption(sheet, 1, 0, auctionAgreements.get(0).getAuctionId().toString());
        addCaption(sheet, 2, 0, auctionAgreements.get(0).getTariffName());

        addCaption(sheet, 0, 1,
                BundlesUtils.getMessageResourceString("messages", "column.header.num", null, Locale.getDefault()));
        addCaption(
                sheet,
                1,
                1,
                BundlesUtils.getMessageResourceString("messages", "column.header.auction.user", null,
                        Locale.getDefault()));
        addCaption(sheet, 2, 1,
                BundlesUtils.getMessageResourceString("messages", "column.header.ppe.id", null, Locale.getDefault()));
        addCaption(sheet, 3, 1,
                BundlesUtils.getMessageResourceString("messages", "column.header.email", null, Locale.getDefault()));
        addCaption(sheet, 4, 1,
                BundlesUtils.getMessageResourceString("messages", "column.header.phone", null, Locale.getDefault()));
        addCaption(sheet, 5, 1,
                BundlesUtils.getMessageResourceString("messages", "column.header.area", null, Locale.getDefault()));
        addCaption(sheet, 6, 1,
                BundlesUtils.getMessageResourceString("messages", "column.header.city", null, Locale.getDefault()));
        addCaption(sheet, 7, 1,
                BundlesUtils.getMessageResourceString("messages", "column.header.zipcode", null, Locale.getDefault()));
        addCaption(
                sheet,
                8,
                1,
                BundlesUtils.getMessageResourceString("messages", "column.header.street.mail", null,
                        Locale.getDefault()));
        addCaption(
                sheet,
                9,
                1,
                BundlesUtils.getMessageResourceString("messages", "column.header.number.short", null,
                        Locale.getDefault()));
        addCaption(
                sheet,
                10,
                1,
                BundlesUtils.getMessageResourceString("messages", "column.header.year.volume", null,
                        Locale.getDefault()));
        addCaption(
                sheet,
                11,
                1,
                BundlesUtils.getMessageResourceString("messages", "column.header.signed.agreement", null,
                        Locale.getDefault()));

    }

    public void auctionDetails() {
        Auction auction = new Auction();
        auction.setAuctionId(auctionAgreement.getAuctionId());

        try {
            auction = auctionDao.getAuction(auction);
        } catch (Exception e) {
            e.printStackTrace();
        }

        AuctionBean auctionBean = ComponentLookup.lookupComponent("op.operatorAuctionBean");
        auctionBean.setAuctionComponents(auction);
    }

    private void createContent(WritableSheet sheet, Integer auctionId) throws WriteException, RowsExceededException {
        List<AuctionAgreement> excelData = null;

        AuctionOffer filter = new AuctionOffer();
        Auction a = new Auction();
        a.setAuctionId(auctionId);
        filter.setAuction(a);

        try {
            excelData = auctionDao.getAuctionAgreements(filter);
        } catch (Exception e) {
            e.printStackTrace();
        }

        for (int i = 0; i < excelData.size(); i++) {
            addNumber(sheet, 0, i + 2, i + 1);
            addLabel(sheet, 1, i + 2, excelData.get(i).getFirstname() + " " + excelData.get(i).getSurname());
            addNumber(sheet, 2, i + 2, excelData.get(i).getPpeId());
            addLabel(sheet, 3, i + 2, excelData.get(i).getLogin());
            addLabel(sheet, 4, i + 2, excelData.get(i).getPhone());
            addLabel(sheet, 5, i + 2, excelData.get(i).getAreaName());
            addLabel(sheet, 6, i + 2, excelData.get(i).getCityName());
            addLabel(sheet, 7, i + 2, excelData.get(i).getZipCode());
            addLabel(sheet, 8, i + 2, excelData.get(i).getStreetName());
            addLabel(sheet, 9, i + 2, excelData.get(i).getFlatNo());
            addLabel(sheet, 10, i + 2, excelData.get(i).getValue() != null ? excelData.get(i).getValue().toString()
                    : "");

            WritableCellFeatures cellFeatures = new WritableCellFeatures();
            ArrayList al = new ArrayList();
            al.add(Consts.YES);
            al.add(Consts.NO);
            cellFeatures.setDataValidationList(al);
            Label checkLabel = new Label(11, i + 2, (String) al.get(1));
            checkLabel.setCellFeatures(cellFeatures);
            sheet.addCell(checkLabel);

        }

    }

    private void addCaption(WritableSheet sheet, int column, int row, String s) throws RowsExceededException,
            WriteException {
        Label label;
        label = new Label(column, row, s, timesBoldUnderline);
        sheet.addCell(label);
    }

    private void addNumber(WritableSheet sheet, int column, int row, Integer integer) throws WriteException,
            RowsExceededException {
        Number number;
        number = new Number(column, row, integer, times);
        sheet.addCell(number);
    }

    private void addLabel(WritableSheet sheet, int column, int row, String s) throws WriteException,
            RowsExceededException {
        Label label;
        label = new Label(column, row, s, times);
        sheet.addCell(label);
    }

    public void importReport() {
        Workbook w;

        try {
            w = Workbook.getWorkbook(uploadedFile.getInputstream());
            Sheet sheet = w.getSheet(0);

            Auction auction = new Auction();
            auction.setAuctionId(Integer.parseInt(sheet.getCell(1, 0).getContents()));

            auction = auctionDao.getAuction(auction);

            AuctionOffer auctionOffer = new AuctionOffer();
            auctionOffer.setAuction(auction);
            auctionOffer.setStatus(AuctionStatus.FINISHED);

            Salesman salesman = salesmanBean.getSalesman();// auctionDao.getLastAuctionOffer(auctionOffer).getSalesman();

            for (int i = 2; i < sheet.getRows(); i++) {

                log.info("importing EXCEL line: ");

                if (sheet.getCell(0, i).getContents().length() == 0)
                    break;

                PPE ppe = null;

                log.info("getPPEById line: " + Long.parseLong((sheet.getCell(2, i).getContents())));
                ppe = ppeDao.getPPEById(Long.parseLong((sheet.getCell(2, i).getContents())));

                log.info("ppe id" + ppe.getPpeId());

                String signedAgreement = sheet.getCell(11, i).getContents();
                log.info("signedAgreement: " + signedAgreement);
                if (signedAgreement.equals(Consts.YES)) {
                    // Agreement agreement =
                    // agreementDao.getLastAgreementByPpeId(ppe.getPpeId());
                    Agreement agreement = new Agreement();

                    log.info("agreement: " + agreement.getAgreementId());
                    agreement.setPpeId(ppe.getPpeId());
                    // agreement.setActive(true);
                    agreement.setAgreementType(AgreementType.master);
                    // agreement.getAgreementType(AgreementType.master);
                    agreement.setDateFrom(auction.getBeginContractDate());
                    agreement.setDateTo(auction.getEndContractDate());
                    agreement.setSalesman(salesman);

                    agreement.setDurationType(DurationType.fixed);
                    // agreement.setPower(power);
                    agreementDao.saveAgreement(agreement);
                    ppe.setPpeStatus(PPEStatus.READY_TO_JOIN);

                    ppeDao.updatePPE(ppe);

                    // agreementDao.updateAgreement(agreement);

                } else if (signedAgreement.equals(Consts.NO)) {
                    log.info("signedAgreement");
                    ppe.setPpeStatus(PPEStatus.REFUSED_AGREEMENT);
                    log.info("setPpeStatus");

                    ppeDao.updatePPE(ppe);
                    log.info("updatePPE");
                }
            }
        } catch (Exception e) {
            log.error("import error: ", e);
        }
    }

    public void onAuctionAgreementSelect(SelectEvent event) {
        buttonDisabled = false;
    }

    public void onAgreementUnselect(UnselectEvent event) {
        buttonDisabled = true;
        auctionAgreement = new AuctionAgreement();
    }

}
