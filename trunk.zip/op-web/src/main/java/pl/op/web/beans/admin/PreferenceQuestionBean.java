package pl.op.web.beans.admin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang.SerializationUtils;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.PrefQuestDao;
import pl.op.dao.QuestItemDao;
import pl.op.model.question.PreferenceQuestion;
import pl.op.model.question.QuestionItem;
import pl.op.model.question.ValueType;
import pl.op.model.stereotype.Stereotype;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

@Name("op.preferenceQuestionBean")
@Scope(ScopeType.SESSION)
public class PreferenceQuestionBean {

	private Logger log = LoggerFactory.getLogger(PreferenceQuestionBean.class);

	private PreferenceQuestion preferenceQuestion;
	private PreferenceQuestion preferenceQuestionOld;
	private List<PreferenceQuestion> preferenceQuestionList;
	private PrefQuestDao prefQuestDao;
	private QuestItemDao questItemDao;
	@SuppressWarnings("unused")
	private List<Stereotype> stereotypeList;
	private List<ValueType> attributeTypes = new ArrayList<ValueType>();
	private List<QuestionItem> questItemDelete;

	private DictionaryBean dictionaryBean;

	// disable buttons
	private boolean disableShow;
	private boolean disableEdit;
	private boolean disableRemove;
	private boolean showType;
	private boolean enableAttributeItemButtons;
	private boolean showAttributePanel;
	private boolean disableItemListButtons;
	private QuestionItem selectedQuestionItem;

	public PreferenceQuestionBean() {
		initialize();
		dictionaryBean = ComponentLookup.lookupComponent("op.dictionaryBean");

		prefQuestDao = GuiceSingleton.getInstance().getInstance(
				PrefQuestDao.class);
		questItemDao = GuiceSingleton.getInstance().getInstance(
				QuestItemDao.class);
	}

	public void initialize() {
		preferenceQuestion = new PreferenceQuestion();
		preferenceQuestion.setStereotype(new Stereotype());
	}

	public String listPreferenceQuestion() {
		notAvailableAction();
		preferenceQuestion = new PreferenceQuestion();

		try {
			PreferenceQuestion filterpreferenceQuestion = new PreferenceQuestion();
			filterpreferenceQuestion.setStereotype(new Stereotype());
			preferenceQuestionList = prefQuestDao
					.getPreferenceQuestionList(filterpreferenceQuestion);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "preferenceQuestionList";
	}

	public String cancel() {
		preferenceQuestion = (PreferenceQuestion) SerializationUtils
				.clone(preferenceQuestionOld);

		return "preferenceQuestionList";
	}

	public String addPrefQuestion() {
		preferenceQuestion = new PreferenceQuestion();
		preferenceQuestion.setStereotype(new Stereotype());
		preferenceQuestion.setRemoved(false);

		showType = false;
		enableAttributeItemButtons = true;
		showAttributePanel = false;
		return "preferenceQuestion";
	}

	public String editPrefQuestion() {
		questItemDelete = new ArrayList<QuestionItem>();
		disableItemListButtons = true;

		try {
			preferenceQuestionOld = prefQuestDao
					.getPreference(preferenceQuestion);
		} catch (Exception e) {
			e.printStackTrace();
		}

		switch (preferenceQuestionOld.getValueType()) {
		case ListValues:
			showAttributePanel = true;
			enableAttributeItemButtons = true;
			break;
		case BooleanValue:
			showAttributePanel = true;
			enableAttributeItemButtons = false;
			break;
		case OneValue:
			showAttributePanel = false;
			enableAttributeItemButtons = false;
			break;
		}

		if (preferenceQuestionOld.getValueType() == preferenceQuestion
				.getValueType())
			preferenceQuestion.setQuestionItems(preferenceQuestionOld
					.getQuestionItems());

		return "preferenceQuestion";
	}

	public String deletePrefQuestion() {
		if (preferenceQuestion != null) {
			try {
				for (int i = 0; i < preferenceQuestion.getQuestionItems()
						.size(); i++) {
					questItemDao.deleteQuestionIten(preferenceQuestion
							.getQuestionItems().get(i));
				}

				prefQuestDao.deletePreferenceQuestion(preferenceQuestion);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		listPreferenceQuestion();

		return "preferenceQuestionList";
	}

	public String showPrefQuestion() {

		return "";
	}

	public void onRowSelectAuditList(SelectEvent event) {
		availableAction();
	}

	public void onRowUnselectAuditList(UnselectEvent event) {
		notAvailableAction();
	}

	public void availableAction() {
		disableShow = false;
		disableEdit = false;
		disableRemove = false;
	}

	public void notAvailableAction() {
		disableShow = true;
		disableEdit = true;
		disableRemove = true;
	}

	public PreferenceQuestion getPreferenceQuestion() {
		return preferenceQuestion;
	}

	public void setPreferenceQuestion(PreferenceQuestion preferenceQuestion) {
		this.preferenceQuestion = preferenceQuestion;
	}

	public List<PreferenceQuestion> getPreferenceQuestionList() {
		return preferenceQuestionList;
	}

	public void setPreferenceQuestionList(
			List<PreferenceQuestion> preferenceQuestionList) {
		this.preferenceQuestionList = preferenceQuestionList;
	}

	public boolean isDisableShow() {
		return disableShow;
	}

	public void setDisableShow(boolean disableShow) {
		this.disableShow = disableShow;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}

	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}

	public List<Stereotype> getStereotypeList() {
		List<Stereotype> stereotypes = new ArrayList<Stereotype>();
		stereotypes = dictionaryBean.getStereotypesList();
		return stereotypes;
	}

	public void setStereotypeList(List<Stereotype> stereotypeList) {
		this.stereotypeList = stereotypeList;
	}

	public boolean isShowType() {
		return showType;
	}

	public void setShowType(boolean showType) {
		this.showType = showType;
	}

	public List<ValueType> getAttributeTypes() {
		attributeTypes = new ArrayList<ValueType>();

		for (ValueType t : ValueType.values()) {
			t.setLabel(BundlesUtils.getMessageResourceString("messages",
					"attribute.type." + t, null, Locale.getDefault()));

			attributeTypes.add(t);
		}

		return attributeTypes;
	}

	public String changeAttributeType() {

		if (preferenceQuestion != null) {
			if (preferenceQuestion.getValueType() == ValueType.ListValues
					|| preferenceQuestion.getValueType() == ValueType.BooleanValue) {

				preferenceQuestion
						.setQuestionItems(new ArrayList<QuestionItem>());

				if (preferenceQuestion.getValueType() == ValueType.BooleanValue) {
					QuestionItem item1 = new QuestionItem();
					item1.setQuestionItemName(BundlesUtils
							.getMessageResourceString("messages", "yes", null,
									Locale.getDefault()));
					item1.setQuestionItemValue("true");

					QuestionItem item2 = new QuestionItem();
					item2.setQuestionItemName(BundlesUtils
							.getMessageResourceString("messages", "no", null,
									Locale.getDefault()));
					item2.setQuestionItemValue("false");

					preferenceQuestion.getQuestionItems().add(item1);
					preferenceQuestion.getQuestionItems().add(item2);

					enableAttributeItemButtons = false;
				} else {
					enableAttributeItemButtons = true;
				}

				showAttributePanel = true;
			} else {
				preferenceQuestion
						.setQuestionItems(new ArrayList<QuestionItem>());
				showAttributePanel = false;
				enableAttributeItemButtons = true;
			}
		}

		return "";
	}

	public String addAttributeItem() {
		if (preferenceQuestion != null) {
			if (preferenceQuestion.getQuestionItems() == null) {
				preferenceQuestion
						.setQuestionItems(new ArrayList<QuestionItem>());
			}

			preferenceQuestion.getQuestionItems().add(new QuestionItem());
		}

		showAttributePanel = true;

		return "";
	}

	public String removeAttributeItem() {
		if (preferenceQuestion != null
				&& preferenceQuestion.getQuestionItems() != null
				&& selectedQuestionItem != null) {
			questItemDelete.add(selectedQuestionItem);
			preferenceQuestion.getQuestionItems().remove(selectedQuestionItem);
		}

		disableItemListButtons = true;

		return "";
	}

	public String submit() {
		try {
			if (preferenceQuestion.getPreferenceQuestionId() == null) {
				// Adds new preference question with question items
				prefQuestDao.savePreferenceQuestion(preferenceQuestion);

				for (int i = 0; i < preferenceQuestion.getQuestionItems()
						.size(); i++) {
					QuestionItem item = preferenceQuestion.getQuestionItems()
							.get(i);
					item.setPreferenceQuestion(preferenceQuestion);
					questItemDao.saveQuestionItem(item);
				}
			} else {
				// Edits preference question with question items
				boolean prefQuestTypeNew = false;
				prefQuestDao.updatePreferenceQuestion(preferenceQuestion);

				// Checks if there is new question item type
				if (preferenceQuestion.getValueType() != preferenceQuestionOld
						.getValueType()) {
					prefQuestTypeNew = true;
					log.info("weszlo");
				}

				log.info("old value type = "
						+ preferenceQuestionOld.getValueType());
				log.info("new value type = "
						+ preferenceQuestion.getValueType());

				// Updates/Adds question items
				for (int i = 0; i < preferenceQuestion.getQuestionItems()
						.size(); i++) {
					QuestionItem item = preferenceQuestion.getQuestionItems()
							.get(i);
					if (item.getQuestionItemId() == null || prefQuestTypeNew) {
						item.setPreferenceQuestion(preferenceQuestion);
						questItemDao.saveQuestionItem(item);
					} else {
						questItemDao.updateQuestionItem(item);
					}
				}

				// Deletes all question items
				if (prefQuestTypeNew) {
					for (int i = 0; i < preferenceQuestionOld
							.getQuestionItems().size(); i++) {
						log.info("Usuwam ="
								+ preferenceQuestionOld.getQuestionItems()
										.get(i).getQuestionItemId());
						questItemDao.deleteQuestionIten(preferenceQuestionOld
								.getQuestionItems().get(i));
					}
				}

				// Deletes deleted questionItems
				for (int i = 0; i < questItemDelete.size(); i++) {
					questItemDao.deleteQuestionIten(questItemDelete.get(i));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		listPreferenceQuestion();

		preferenceQuestionOld = null;

		return "preferenceQuestionList";
	}

	public void onItemRowSelect(SelectEvent event) {
		disableItemListButtons = false;
	}

	public void onItemRowUnselect(UnselectEvent event) {
		disableItemListButtons = true;
	}

	public void setAttributeTypes(List<ValueType> attributeTypes) {
		this.attributeTypes = attributeTypes;
	}

	public boolean isEnableAttributeItemButtons() {
		return enableAttributeItemButtons;
	}

	public void setEnableAttributeItemButtons(boolean enableAttributeItemButtons) {
		this.enableAttributeItemButtons = enableAttributeItemButtons;
	}

	public boolean isShowAttributePanel() {
		return showAttributePanel;
	}

	public void setShowAttributePanel(boolean showAttributePanel) {
		this.showAttributePanel = showAttributePanel;
	}

	public QuestionItem getSelectedQuestionItem() {
		return selectedQuestionItem;
	}

	public void setSelectedQuestionItem(QuestionItem selectedQuestionItem) {
		this.selectedQuestionItem = selectedQuestionItem;
	}

	public boolean isDisableItemListButtons() {
		return disableItemListButtons;
	}

	public void setDisableItemListButtons(boolean disableItemListButtons) {
		this.disableItemListButtons = disableItemListButtons;
	}
}