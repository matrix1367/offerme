package pl.op.web.beans.wizard;

import java.io.Serializable;
import java.util.List;

import javax.faces.event.AjaxBehaviorEvent;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.StereotypeDao;
import pl.op.dao.UserDao;
import pl.op.model.stereotype.Sector;
import pl.op.model.stereotype.Stereotype;
import pl.op.model.stereotype.StereotypeType;
import pl.op.model.user.UserApp;
import pl.op.util.UserUtil;
import pl.op.web.listener.GuiceSingleton;

@Name("op.wizardUserBean")
@Scope(ScopeType.SESSION)
public class WizardUserBean implements Serializable {

    private static final long serialVersionUID = 7657279753756327544L;

    public WizardUserBean() {
        log.info("WizardUserBean constructor");
        initialize();
    }

    private Logger log = LoggerFactory.getLogger(WizardUserBean.class);

    private UserApp userApp;
    private UserDao dao;
    private StereotypeDao stereotypeDao;

    private Sector sector;
    private Sector sectorUser;
    private Sector sectorCompany;
    private Stereotype stereotype;
    private Stereotype stereotypeUser;
    private Stereotype stereotypeCompany;
    private StereotypeType stereotypeType;

    private List<Stereotype> stereotypeList;
    private List<Sector> sectors;

    private Double mediumYearConsumption;
    private Integer sectorId;

    private void initialize() {
        dao = GuiceSingleton.getInstance().getInstance(UserDao.class);
        stereotypeDao = GuiceSingleton.getInstance().getInstance(StereotypeDao.class);

        stereotype = new Stereotype();

        try {
            Sector s = new Sector();
            s.setIsHidden(false);
            sectors = stereotypeDao.getSectors(s);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // userApp = getLoggedUser();
        userApp = UserUtil.getLoggedUserInstance();
        userApp.setFirstLogin(false);
        userApp.setIsCompany(false);
    }

    public UserApp getLoggedUser() {
        UserApp userLogged = UserUtil.getLoggedUserInstance();

        return userLogged;
    }

    public UserApp getUserApp() {
        return userApp;
    }

    public void setUserApp(UserApp userApp) {
        this.userApp = userApp;
    }

    public List<Stereotype> getStereotypeList() {
        if(!userApp.getIsCompany()) {
            try {
                Stereotype stereotype = new Stereotype();
                stereotype.setStereotypeType(stereotypeType);

                Sector sector = new Sector();
                sector.setIsHidden(!userApp.getIsCompany());
                sector.setStereotype(stereotype);

                stereotypeList = stereotypeDao.getStereotypes(sector);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return stereotypeList;
    }

    public void setStereotypeList(List<Stereotype> stereotypeList) {
        this.stereotypeList = stereotypeList;
    }

    public void onStereotypeSelect(Integer stereotypeId) {
        try {
            sector = stereotypeDao.getSectorByStereotypeId(stereotypeId);
            stereotype = sector.getStereotype();
            stereotypeUser = stereotype;
            sectorUser = sector;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onIsCompanySelect() {

        if(userApp.getIsCompany()) {
            stereotype = stereotypeCompany;
            sector = sectorCompany;
        } else {
            stereotype = stereotypeUser;
            sector = sectorUser;
        }

    }

    public String stereotypeClass(Integer stereotypeId) {
        try {
            if(sector != null && stereotypeId == sector.getStereotype().getStereotypeId()) {
                return "ui-button-selected";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "";
    }

    public void onSectorSelect(AjaxBehaviorEvent ev) {
        log.info("onSectorSelect");

        if(sectorId != null) {
            log.info("onSectorSelect sector id :"  + sectorId.toString());
            try {
                sector = new Sector();
                sector.setSectorId(sectorId);
                stereotype = stereotypeDao.getStereotypeBySectorId(sectorId);
               // log.info("[onSectorSelect] getStereotypeBySectorId" + sectorId.toString() );
                sector = stereotypeDao.getSectorByStereotypeId(stereotype.getStereotypeId());
                //log.info("[onSectorSelect]getSectorByStereotypeId " + stereotype.getStereotypeId().toString());
                stereotypeCompany = stereotype;
                sectorUser = sector;

                sectorCompany = sector;
               // sector.setStereotype(stereotype);
            } catch (Exception e) {
                log.info("Problem while get stereotype by sector on sector select: ", e);
            }
        } else {
            stereotype = new Stereotype();
             log.info(">>>>>>> onSectorSelect :  stereotype = new Stereotype();");
        }
        
        if (sector != null) {
            if (sector.getStereotype() != null) {
                log.info("[onSectorSelect] stereotypename:" + sector.getStereotype().getStereotypeName());
            } else {
            log.info("[onSectorSelect] sector.getStereotype() is null");    
            }
        } else {
            log.info("[onSectorSelect] sector is null");
        }
    }

    public Double getMediumYearConsumption() {
        return mediumYearConsumption;
    }

    public void setMediumYearConsumption(Double mediumYearConsumption) {
        this.mediumYearConsumption = mediumYearConsumption;
    }

    public Stereotype getStereotype() {
        return stereotype;
    }

    public void setStereotype(Stereotype stereotype) {
        this.stereotype = stereotype;
    }

    public Sector getSector() {
        return sector;
    }

    public void setSector(Sector sector) {
        this.sector = sector;
    }

    public StereotypeType getStereotypeType() {
        return stereotypeType;
    }

    public void setStereotypeType(StereotypeType stereotypeType) {
        this.stereotypeType = stereotypeType;
    }

    public List<Sector> getSectors() {
        return sectors;
    }

    public void setSectors(List<Sector> sectors) {
        this.sectors = sectors;
    }

    public Integer getSectorId() {
        return sectorId;
    }

    public void setSectorId(Integer sectorId) {
        this.sectorId = sectorId;
    }

    public Stereotype getStereotypeUser() {
        return stereotypeUser;
    }

    public void setStereotypeUser(Stereotype stereotypeUser) {
        this.stereotypeUser = stereotypeUser;
    }

    public Stereotype getStereotypeCompany() {
        return stereotypeCompany;
    }

    public void setStereotypeCompany(Stereotype stereotypeCompany) {
        this.stereotypeCompany = stereotypeCompany;
    }

    public Sector getSectorUser() {
        return sectorUser;
    }

    public void setSectorUser(Sector sectorUser) {
        this.sectorUser = sectorUser;
    }

    public Sector getSectorCompany() {
        return sectorCompany;
    }

    public void setSectorCompany(Sector sectorCompany) {
        this.sectorCompany = sectorCompany;
    }

}