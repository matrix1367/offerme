package pl.op.web.beans.user;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;

import pl.op.dao.UserDao;
import pl.op.model.user.UserApp;
import pl.op.web.beans.AdminBean;
import pl.op.web.beans.MenuBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.LoginUtil;
import pl.op.web.listener.GuiceSingleton;

@Name("op.changePasswordBean")
@Scope(ScopeType.SESSION)
public class ChangePasswordBean {

	private UserApp userLocal;
	private UserApp userAppLog;
	private UserDao dao;
	private FacesContext facesContext;
	private ExternalContext ectx;
	private Logger log = LoggerFactory.getLogger(ChangePasswordBean.class);
	
	public ChangePasswordBean() {
		log.info("ChangePasswordBean constructor");
		initialize();
	}
	
	public UserApp getUserLocal() {
		return userLocal;
	}

	public void setUserLocal(UserApp userLocal) {
		this.userLocal = userLocal;
	}

	private void initialize() {
		facesContext  = FacesContext.getCurrentInstance();
		ectx = facesContext.getExternalContext();
		userLocal = new UserApp();     
		dao = GuiceSingleton.getInstance().getInstance(UserDao.class);
	}

	public String startChgPasswordAction(){
		
		initialize();
		
		//get current user login
		FacesContext ctx = FacesContext.getCurrentInstance();
		AdminBean adminBean = (AdminBean) ctx.getApplication().getELResolver()
		.getValue(ctx.getELContext(), null, "op.adminBean");
		
		userAppLog = adminBean.getUserLog();
		
		userLocal.setUserId(userAppLog.getUserId());
		userLocal.setLogin(userAppLog.getLogin());
		
		return "change_password";
	}
	
	public String execute(){

		if(validateForm()){

			//update password
			userLocal.setPassword(LoginUtil.generatePasswordHash(
			userLocal.getPassword(), userLocal.getLogin()));
			log.info("New passworg generated: "+userLocal.getPassword());
			
			try {
				dao.updatePassword(userLocal);
			} catch (Exception e) {
	        	log.error(e.getMessage(), e);
				String message = BundlesUtils.getMessageResourceString(
				"messages", "change.password.error", null, ectx.getRequestLocale());
				FacesMessages.instance().add(message);
	        	return "";
			}

			String message = BundlesUtils.getMessageResourceString(
			"messages", "change.password.succes", null, ectx.getRequestLocale());
			FacesMessages.instance().add(message);
			
			initializeView();
			return "view_user";
		}
		
		return "change_password";
	}
	

	public String cancel(){
		
		initializeView();
		
		return "view_user";
	}
	
	public Boolean validateForm(){
	 
		boolean formValidate = false;
		
		
		//validate new password
		boolean passwordValidate = true;
		if(!userLocal.getPassword().equals(userLocal.getPassword2())){		
			
			String message = BundlesUtils.getMessageResourceString(
			"messages", "password_error", null, ectx.getRequestLocale());
			FacesMessages.instance().add(FacesMessage.SEVERITY_ERROR, message);
			
			passwordValidate = false;
		}
		
		
		//validate old password
		log.info("Old password: "+userAppLog.getPassword());
		log.info("Generate and check: "+LoginUtil.generatePasswordHash(
		userLocal.getOldPassword(), userLocal.getLogin()));
		
		
		boolean oldPasswordValidate = true;
		if(!userAppLog.getPassword().equals(LoginUtil.generatePasswordHash(
		userLocal.getOldPassword(), userLocal.getLogin()))){
			
			String message = BundlesUtils.getMessageResourceString(
			"messages", "old_password_error", null, ectx.getRequestLocale());
			FacesMessages.instance().add(FacesMessage.SEVERITY_ERROR, message);
			oldPasswordValidate = false;
		}		
		
		if(passwordValidate && oldPasswordValidate){
			formValidate = true;
		}
		
		return formValidate;
	}
	
	public void initializeView(){
		
		FacesContext ctx = FacesContext.getCurrentInstance();
		MenuBean menuBean = (MenuBean) ctx.getApplication().getELResolver()
		.getValue(ctx.getELContext(), null, "op.menuBean");
		
		menuBean.setEditTopMenuItemSelected("topMenuBasicData");
				
		EditDataBean editDataBean = (EditDataBean) ctx.getApplication().getELResolver()
		.getValue(ctx.getELContext(), null, "op.editDataBean");
		
		editDataBean.startEditAction();
	}
}