package pl.op.web.beans.auction.operator;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Locale;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.op.dao.PPEDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionFilter;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.auction.AuctionStatus;
import pl.op.model.auction.AuctionUser;
import pl.op.model.auction.PriceComponentValue;
import pl.op.model.contract.Location;
import pl.op.model.contract.PPE;
import pl.op.model.dict.City;
import pl.op.model.user.UserApp;
import pl.op.util.LocationUtil;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class AuctionFinishedBean.
 */
@Name("op.operatorAuctionFinishedBean")
@Scope(ScopeType.SESSION)
public class AuctionFinishedBean {

    private Logger log = LoggerFactory.getLogger(AuctionFinishedBean.class);
    public static final long HOUR = 3600 * 1000;

    private List<Auction> auctions;
    private Auction auction;

    private AuctionBean auctionBean;

    // Filters
    private AuctionFilter auctionFilter;
    private String cityName;

    private boolean buttonsDisabled = true;
    private boolean galleryView = false;
    
  
     private PPEDao ppeDo;
     

    /**
     * Instantiates a new auction finished bean.
     */
    public AuctionFinishedBean() {
        log.info("AuctionFinishedBean constructor");
        initializeVars();
        initializeFilter();
    }

    /**
     * Initialize vars.
     */
    public void initializeVars() {
        auctionBean = ComponentLookup.lookupComponent("op.operatorAuctionBean");
        ppeDo = GuiceSingleton.getInstance().getInstance(PPEDao.class);
    }

    /**
     * Initialize filter.
     */
    public void initializeFilter() {
        clearFilter();
        searchAuctions();
    }

    /**
     * Clear filter.
     */
    public void clearFilter() {
        auctionFilter = new AuctionFilter();
        cityName = "";
    }

    /**
     * Search auctions.
     */
    public void searchAuctions() {
        clearSelectedAuction();
        if(!"".equals(cityName) && null != cityName) {
            log.info("cityName: " + cityName);
            auctionFilter.setCity(LocationUtil.getCity(cityName, auctionFilter.getArea()));

            if(null == auctionFilter.getCity()) {
                auctionFilter.setCity(new City());
                auctionFilter.getCity().setCityId(0);
            }
        } else {
            auctionFilter.setCity(new City());
        }

        auctionFilter.getAuction().setStatus(AuctionStatus.FINISHED);
        auctions = auctionBean.searchAuctions(auctionFilter);
    }

    /**
     * Clear selected auction.
     */
    private void clearSelectedAuction() {
        auction = null;
        buttonsDisabled = true;
    }

    /**
     * Initialize auction.
     */
    public void initializeAuction() {
        auctionBean.setAuctionComponents(auction);
    }


    /**
     * On auction select.
     * 
     * @param event
     *            the event
     */
    public void onAuctionSelect(SelectEvent event) throws WriteException, Exception {
        buttonsDisabled = false;
 
    }
    
    private void prepareContentPaport(final Auction auction, WritableSheet excelSheet) throws WriteException, Exception {
         int row = 0;
        Label idAuctionLabel = new Label(0, row, "ID Aukcji");
        Label DataStartAuctionLabel = new Label(1, row, "Data rozpoczęcia aukcji");
        Label DataStopAuctionLabel = new Label(2, row, "Data zakończenia aukcji");
        Label DataStartUAuctionLabel = new Label(3, row, "Data rozpoczęcia umowy");
        Label DataStopUAuctionLabel = new Label(4, row, "Data zakończenia umowy");
        Label idCloudLabel = new Label(5, row, "ID chmury");
        Label NameCloudLabel = new Label(6, row, "Nazwa chmury");
        Label DescriptionCloudLabel = new Label(7, row, "Opis chmury ");
        Label ValueCloudLabel = new Label(8, row, "Wolumen chmury ");
        Label TarifeCloudLabel = new Label(9, row, "Taryfa chmury ");
        Label isCompanyCloudLabel = new Label(10, row, "Typ firmowy ");
        Label isManualCloudLabel = new Label(11, row, "Typ tworzenia ręcznego ");

        excelSheet.addCell(idAuctionLabel);
        excelSheet.addCell(DataStartAuctionLabel);
        excelSheet.addCell(DataStopAuctionLabel);
        excelSheet.addCell(DataStartUAuctionLabel);
        excelSheet.addCell(DataStopUAuctionLabel);
        excelSheet.addCell(idCloudLabel);
        excelSheet.addCell(NameCloudLabel);
        excelSheet.addCell(DescriptionCloudLabel);
        excelSheet.addCell(ValueCloudLabel);
        excelSheet.addCell(TarifeCloudLabel);
        excelSheet.addCell(isCompanyCloudLabel);
        excelSheet.addCell(isManualCloudLabel);
            
        row = 1;
        jxl.write.Number idAuctionValue = new jxl.write.Number(0, row, auction.getAuctionId());
        Label DataStartAuctionValue = new Label(1, row, auction.getStartDate().toString());
        Label DataStopAuctionValue = new Label(2, row, auction.getFinishDate().toString());
        Label DataStartUAuctionValue = new Label(3, row, auction.getBeginContractDate().toString());
        Label DataStopUAuctionValue = new Label(4, row, auction.getEndContractDate().toString());
        jxl.write.Number idCloudValue = new jxl.write.Number(5, row, auction.getCloud().getCloudId());
        Label NameCloudValue = new Label(6, row, auction.getCloud().getName());
        Label DescriptionCloudValue = new Label(7, row, auction.getCloud().getDescription());
        jxl.write.Number ValueCloudValue = new jxl.write.Number(8, row, auction.getCloud().getVolume());
        Label TarifeCloudValue = new Label(9, row, auction.getCloud().getTariff().getTariffName());
        Label isCompanyCloudValue = new Label(10, row, auction.getCloud().getIsCompany().toString());
        Label isManualCloudValue = new Label(11, row, auction.getCloud().getIsManual().toString());

        excelSheet.addCell(idAuctionValue);
        excelSheet.addCell(DataStartAuctionValue);
        excelSheet.addCell(DataStopAuctionValue);
        excelSheet.addCell(DataStartUAuctionValue);
        excelSheet.addCell(DataStopUAuctionValue);
        excelSheet.addCell(idCloudValue);
        excelSheet.addCell(NameCloudValue);
        excelSheet.addCell(DescriptionCloudValue);
        excelSheet.addCell(ValueCloudValue);
        excelSheet.addCell(TarifeCloudValue);
        excelSheet.addCell(isCompanyCloudValue);
        excelSheet.addCell(isManualCloudValue);

        row = 3;
        Label SelNameLabel = new Label(0, row, "Sprzedawca");
        excelSheet.addCell(SelNameLabel);

        AuctionOffer auctionOffer = auction.getLastOfferForEmail();
        Label SelNameValue = new Label(0, row+1, auctionOffer.getSalesman().getSalesmanName());
        excelSheet.addCell(SelNameValue);

        List<PriceComponentValue> princeComponentValues = auctionOffer.getPriceComponentValues();
        int i = 1;
        for (PriceComponentValue princeComponentValue : princeComponentValues) {
            Label princeName = new Label(i, row, princeComponentValue.getPriceComponent().getName());
            excelSheet.addCell(princeName);

            jxl.write.Number prinveValue = new jxl.write.Number(i, row+1, princeComponentValue.getValue());
            excelSheet.addCell(prinveValue);

            i++;
        }

        row = 6;
        Label LabelLogin = new Label(0, row, "Login");
        Label LabelNazwaFirmy = new Label(1, row, "Nazwa firmy");
        Label LabelNip = new Label(2, row, "Nip");
        Label LabelRegon = new Label(3, row, "Regon");
        Label LabelPesel = new Label(4, row, "PESEL");

        Label LabelPPEId = new Label(5, row, "PPE ID");
        Label LabelNazwaPPe = new Label(6, row, "Nazwa");
        Label LabelWolumen = new Label(7, row, "Wolumen");

        Label LabelArea = new Label(8, row, "Województwo");
        Label LabelCity = new Label(9, row, "Miasto");
        Label Labelstreat = new Label(10, row, "Ulica");
        Label LabelnrHome = new Label(11, row, "Nr Mieszkania");
        Label LabelCode = new Label(12, row, "Kod");

        excelSheet.addCell(LabelLogin);
        excelSheet.addCell(LabelNazwaFirmy);
        excelSheet.addCell(LabelNip);
        excelSheet.addCell(LabelRegon);
        excelSheet.addCell(LabelPesel);

        excelSheet.addCell(LabelPPEId);
        excelSheet.addCell(LabelNazwaPPe);
        excelSheet.addCell(LabelWolumen);

        excelSheet.addCell(LabelArea);
        excelSheet.addCell(LabelCity);
        excelSheet.addCell(Labelstreat);
        excelSheet.addCell(LabelnrHome);
        excelSheet.addCell(LabelCode);

        List<AuctionUser> usersAuction = auction.getAuctionUsers();
        int countUsers = 7;
        for (AuctionUser userAuction : usersAuction) {
            if (userAuction.getAuctionUserId() != null) {
                UserApp user = userAuction.getUserApp();
                Label ValueLogin = new Label(0, countUsers, user.getLogin());
                Label ValueNazwaFirmy = new Label(1, countUsers, user.getCompanyName());
                Label ValueNip = new Label(2, countUsers, user.getNip());
                Label ValueRegion = new Label(3, countUsers, user.getRegon());
                Label ValuePesel = new Label(4, countUsers, user.getPesel());

                excelSheet.addCell(ValueLogin);
                excelSheet.addCell(ValueNazwaFirmy);
                excelSheet.addCell(ValueNip);
                excelSheet.addCell(ValueRegion);
                excelSheet.addCell(ValuePesel);
            }

            if (userAuction.getPpe() != null && userAuction.getPpe().getPpeId() != null) 
            {
                
            
            PPE ppe = ppeDo.getPPEById(userAuction.getPpe().getPpeId().longValue());

            if (ppe != null) {
                jxl.write.Number ValuePPEID = new jxl.write.Number(5, countUsers, ppe.getPpeId());
                Label ValueNamePPe = new Label(6, countUsers, ppe.getObjectType());
                jxl.write.Number ValueWolumen = new jxl.write.Number(7, countUsers, ppe.getValue());

                excelSheet.addCell(ValuePPEID);
                excelSheet.addCell(ValueNamePPe);
                excelSheet.addCell(ValueWolumen);
            }

            Location location = ppe.getLocation();
            if (location != null) {
                Label ValueArea = new Label(8, countUsers, location.getStreet().getCity().getArea().getAreaName());
                Label ValueCity = new Label(9, countUsers, location.getStreet().getCity().getCityName());
                Label ValuStreet = new Label(10, countUsers, location.getStreet().getStreetName());
                Label ValueHomeNo = new Label(11, countUsers, location.getHomeNo());
                Label ValueZipCode = new Label(12, countUsers, location.getZipCode());

                excelSheet.addCell(ValueArea);
                excelSheet.addCell(ValueCity);
                excelSheet.addCell(ValuStreet);
                excelSheet.addCell(ValueHomeNo);
                excelSheet.addCell(ValueZipCode);

            }
            }
            countUsers++;
        }
    }
    
 
    /**
     * Autocomplete city.
     * 
     * @param query
     *            the query
     * @return the list
     */
    public List<String> autocompleteCity(String query) {
        return LocationUtil.autoCompleteCity(query, auctionFilter.getArea().getAreaId());
    }

    /**
     * Gets the auctions.
     * 
     * @return the auctions
     */
    public List<Auction> getAuctions() {
        return auctions;
    }

    /**
     * Sets the auctions.
     * 
     * @param auctions
     *            the new auctions
     */
    public void setAuctions(List<Auction> auctions) {
        this.auctions = auctions;
    }

    /**
     * Gets the auction.
     * 
     * @return the auction
     */
    public Auction getAuction() {
        return auction;
    }

    /**
     * Sets the auction.
     * 
     * @param auction
     *            the new auction
     */
    public void setAuction(Auction auction) {
        this.auction = auction;
    }

    /**
     * Gets the auction filter.
     * 
     * @return the auction filter
     */
    public AuctionFilter getAuctionFilter() {
        return auctionFilter;
    }

    /**
     * Sets the auction filter.
     * 
     * @param auctionFilter
     *            the new auction filter
     */
    public void setAuctionFilter(AuctionFilter auctionFilter) {
        this.auctionFilter = auctionFilter;
    }

    /**
     * Checks if is buttons disabled.
     * 
     * @return true, if is buttons disabled
     */
    public boolean isButtonsDisabled() {
        return buttonsDisabled;
    }

    /**
     * Sets the buttons disabled.
     * 
     * @param buttonsDisabled
     *            the new buttons disabled
     */
    public void setButtonsDisabled(boolean buttonsDisabled) {
        this.buttonsDisabled = buttonsDisabled;
    }

    /**
     * Checks if is gallery view.
     * 
     * @return true, if is gallery view
     */
    public boolean isGalleryView() {
        return galleryView;
    }

    /**
     * Sets the gallery view.
     * 
     * @param galleryView
     *            the new gallery view
     */
    public void setGalleryView(boolean galleryView) {
        this.galleryView = galleryView;
    }

    /**
     * Change view.
     */
    public void changeView() {
        galleryView = !galleryView;
        if (galleryView) {
            buttonsDisabled = true;
        }
    }

    /**
     * Gets the city name.
     * 
     * @return the city name
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * Sets the city name.
     * 
     * @param cityName
     *            the new city name
     */
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }
    
    public StreamedContent GenerateRaport() throws FileNotFoundException, IOException, Exception {
   
        OutputStream os = new ByteArrayOutputStream();
        WorkbookSettings wbSettings = new WorkbookSettings();

        wbSettings.setLocale(new Locale("en", "EN"));

        WritableWorkbook workbook = Workbook.createWorkbook(os, wbSettings);
        workbook.createSheet("Report", 0);
        WritableSheet excelSheet = workbook.getSheet(0);
        prepareContentPaport(auction, excelSheet);
        

        workbook.write();
        workbook.close();

        InputStream is = new ByteArrayInputStream(
                        ((ByteArrayOutputStream) os).toByteArray());
        StreamedContent file = new DefaultStreamedContent(is,
                        "application/xls", auction.getAuctionId().toString()+ "_" + auction.getCloud().getName() +"_raport.xls");

        return file;
    }
}