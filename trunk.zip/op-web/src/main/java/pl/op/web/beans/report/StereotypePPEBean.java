package pl.op.web.beans.report;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Locale;

import jxl.CellView;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.format.Colour;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.StereotypeDao;
import pl.op.model.stereotype.StereotypePPEReport;
import pl.op.web.common.BundlesUtils;
import pl.op.web.listener.GuiceSingleton;

@Name("op.stereotypePPEBean")
@Scope(ScopeType.SESSION)
public class StereotypePPEBean {

	private Logger log = LoggerFactory.getLogger(StereotypePPEBean.class);

	private StereotypeDao stereotypeDao;
	private WritableCellFormat timesBoldUnderline;
	private WritableCellFormat times10ptRed;
	private WritableCellFormat times;

	public StereotypePPEBean() {
		log.info("StereotypePPEBean constructor");

		initialize();
	}

	public void initialize() {
		stereotypeDao = GuiceSingleton.getInstance().getInstance(
				StereotypeDao.class);
	}

	public StreamedContent generateReport() throws IOException, WriteException {
		OutputStream os = new ByteArrayOutputStream();
		WorkbookSettings wbSettings = new WorkbookSettings();

		wbSettings.setLocale(new Locale("en", "EN"));

		WritableWorkbook workbook = Workbook.createWorkbook(os, wbSettings);
		workbook.createSheet("Report", 0);
		WritableSheet excelSheet = workbook.getSheet(0);
		createLabel(excelSheet);
		createContent(excelSheet);

		workbook.write();
		workbook.close();

		InputStream is = new ByteArrayInputStream(
				((ByteArrayOutputStream) os).toByteArray());
		StreamedContent file = new DefaultStreamedContent(is,
				"application/xls", "raport.xls");

		return file;

	}

	private void createLabel(WritableSheet sheet) throws WriteException {
		WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
		times = new WritableCellFormat(times10pt);
		times.setWrap(true);

		WritableFont times10ptBoldUnderline = new WritableFont(
				WritableFont.TIMES, 10);
		timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);

		CellView cv = new CellView();
		cv.setFormat(times);
		cv.setFormat(timesBoldUnderline);
		cv.setAutosize(true);
		
		 times10ptRed = new WritableCellFormat(times10ptBoldUnderline);
		times10ptRed.setBackground(Colour.RED);
		
		CellView cvRed = new CellView();
		cvRed.setFormat(times);
		cvRed.setFormat(times10ptRed);
		cvRed.setAutosize(true);
				
		addCaption(sheet, 0, 0, BundlesUtils.getMessageResourceString(
				"messages", "concat_name", null, Locale.getDefault()));
		addCaption(sheet, 1, 0, BundlesUtils.getMessageResourceString(
				"messages", "user_login", null, Locale.getDefault()));
		addCaption(sheet, 2, 0, BundlesUtils.getMessageResourceString(
				"messages", "ppe.value", null, Locale.getDefault()));
		addCaption(sheet, 3, 0, BundlesUtils.getMessageResourceString(
				"messages", "stereotype.value", null, Locale.getDefault()));
		addCaption(sheet, 4, 0, BundlesUtils.getMessageResourceString(
				"messages", "stereotype.aberration", null, Locale.getDefault()));
	}

	private void createContent(WritableSheet sheet) throws WriteException,
			RowsExceededException {
		List<StereotypePPEReport> reportData = null;

		try {
			reportData = stereotypeDao.getStereotypePPEReport();
		} catch (Exception e) {
			e.printStackTrace();
		}

		for (int i = 0; i < reportData.size(); i++) {
			Double ppeValue = 0.00;
			if(reportData.get(i).getPpeValue() != null){
				ppeValue = reportData.get(i).getPpeValue();
				//Z MWH na KWH
				ppeValue = ppeValue*1000;
			}
			Double stereotypeValue = 0.00;
			if(reportData.get(i).getStereotypeValue() != null){
				stereotypeValue = reportData.get(i).getStereotypeValue();
				//Z MWH na KWH
				stereotypeValue = stereotypeValue*1000;
			}
			addLabel(sheet, 0, i + 1, reportData.get(i).getFirstname() + " "
					+ reportData.get(i).getSurname());
			addLabel(sheet, 1, i + 1, reportData.get(i).getLogin());
			addLabel(sheet, 2, i + 1,
					reportData.get(i).getPpeValue() == null ? "" : ppeValue.toString());
			addLabel(sheet, 3, i + 1,
					reportData.get(i).getStereotypeValue() == null ? ""	: stereotypeValue.toString());
			if (reportData.get(i).getPpeValue() == null || reportData.get(i).getStereotypeValue() == null)
				addLabel(sheet, 4, i + 1, "");
			else {
				Double aberration = 100 - (reportData.get(i).getPpeValue() / reportData
						.get(i).getStereotypeValue()) * 100;
				Integer abInteger = aberration.intValue();
				
				if (aberration <0)
					sheet.addCell(new Label(4, i+1, abInteger.toString() + "%", times10ptRed));
				else
					addLabel(sheet, 4, i+1, abInteger.toString() + "%");
			}
		}

	}


	private void addCaption(WritableSheet sheet, int column, int row, String s)
			throws RowsExceededException, WriteException {
		Label label;
		label = new Label(column, row, s, timesBoldUnderline);
		sheet.addCell(label);
		if(column == 1){
			sheet.setColumnView(column, 40);
		} else {
			sheet.setColumnView(column, 20);
		}
	}

	private void addLabel(WritableSheet sheet, int column, int row, String s)
			throws WriteException, RowsExceededException {
		Label label;
		label = new Label(column, row, s, times);
		sheet.addCell(label);
	}
}