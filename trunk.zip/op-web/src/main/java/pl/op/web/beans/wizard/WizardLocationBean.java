package pl.op.web.beans.wizard;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AreaDao;
import pl.op.dao.CityDao;
import pl.op.dao.DistributorDao;
import pl.op.dao.MeterModelDao;
import pl.op.dao.SalesmanDao;
import pl.op.dao.StreetDao;
import pl.op.dao.TariffDao;
import pl.op.model.contract.Agreement;
import pl.op.model.contract.AgreementType;
import pl.op.model.contract.DurationType;
import pl.op.model.contract.Invoice;
import pl.op.model.contract.Location;
import pl.op.model.contract.PPE;
import pl.op.model.device.Device;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Distributor;
import pl.op.model.dict.MeterModel;
import pl.op.model.dict.Street;
import pl.op.model.dict.Tariff;
import pl.op.model.salesman.Salesman;
import pl.op.model.stereotype.Building;
import pl.op.util.LocationUtil;
import pl.op.util.PpeUtil;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

@Name("op.wizardLocationBean")
@Scope(ScopeType.SESSION)
public class WizardLocationBean implements Serializable {

    private static final long serialVersionUID = 7657279753756327544L;

    public WizardLocationBean() {
        log.info("WizardLocationBean constructor");
        initialize();
    }

    private Logger log = LoggerFactory.getLogger(WizardLocationBean.class);

    private Location location;
    private PPE ppe;
    private Agreement agreement;

    private List<PPE> ppeList;
    private List<Location> locationList;
    private List<City> cities;
    private List<Area> areas;
    private List<Street> streets;
    private List<Tariff> tariffs;
    private List<Salesman> salesmans;
    private List<Distributor> distributors;
    private List<AgreementType> agreementTypes;
    private List<DurationType> durationTypes;
    private List<MeterModel> meterModels;

    private String streetName;
    private String salesman;
    private String distributor;
    private String villageName;

    private Integer cityId;
    private Integer tariffId;
    private Integer areaId;
    private Integer locationId;
    private Integer meterModelId;

    private Integer locationIdFake;
    private Integer ppeIdFake;
    private boolean locationPpeAdd = false;
    private boolean hasStatus;
    private boolean disabledCity = false;
    private boolean newLocation = true;

    private AreaDao areaDao;
    private TariffDao tariffDao;
    private DistributorDao distributorDao;
    private MeterModelDao meterModelDao;
    private CityDao cityDao;
    private StreetDao streetDao;
    private SalesmanDao salesmanDao;

    private DictionaryBean dictionaryBean;

    // buttons
    private boolean ppeButtons = true;

    private FacesContext facesContext;
    private ExternalContext ectx;

    private void initialize() {
        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();

        dictionaryBean = ComponentLookup.lookupComponent("op.dictionaryBean");

        areaDao = GuiceSingleton.getInstance().getInstance(AreaDao.class);
        tariffDao = GuiceSingleton.getInstance().getInstance(TariffDao.class);
        distributorDao = GuiceSingleton.getInstance().getInstance(DistributorDao.class);
        meterModelDao = GuiceSingleton.getInstance().getInstance(MeterModelDao.class);
        cityDao = GuiceSingleton.getInstance().getInstance(CityDao.class);
        streetDao = GuiceSingleton.getInstance().getInstance(StreetDao.class);
        salesmanDao = GuiceSingleton.getInstance().getInstance(SalesmanDao.class);

        try {
            cities = new ArrayList<City>();
            areas = areaDao.getAreas(new Area());
            Tariff tariffFilter = new Tariff();
            tariffFilter.setTariffName("%");
            tariffFilter.setTariffNameFilter("%");
            tariffs = tariffDao.getTariffs(tariffFilter);
            distributors = distributorDao.getDistributors();
            salesmans = salesmanDao.getAllSalesmans();
            meterModels = meterModelDao.getMeterModels();
        } catch (Exception e) {
            e.printStackTrace();
            log.info("error:: " + e.getMessage());
        }

        clearLocationPPE();

        locationList = new ArrayList<Location>();
        ppeList = new ArrayList<PPE>();

        locationIdFake = 1;
        ppeIdFake = 1;
    }

    public List<City> getCities() {
        if(areaId != null && areaId > 0) {
            Area area = new Area();
            area.setAreaId(areaId);

            if(hasStatus) {
                cities = dictionaryBean.getCitiesMap().get(areaId);
            } else {
                cities = dictionaryBean.getVillagesMap().get(areaId);
            }

            setDisabledCity(true);
            if(!cities.isEmpty()) {
                setDisabledCity(false);
            }
        } else {
            setDisabledCity(true);
        }

        return cities;
    }

    public void setCities(List<City> cities) {
        this.cities = cities;
    }

    public List<Tariff> getTariffs() {
        return tariffs;
    }

    public void setTariffs(List<Tariff> tariffs) {
        this.tariffs = tariffs;
    }

    public void saveLocationPPE() {
        if(agreement.getDateFrom() != null && agreement.getDateTo() != null
                && agreement.getDateFrom().after(agreement.getDateTo())) {
            warning("warning.two.dates.invalid");
            return;
        }

        if(ppe.getContractualPower() != null && ppe.getContractualPower() <= 0) {
            warning("warning.power.min");
            return;
        }

        log.info("<< saveLocationPPE start >>");

        try {
            Street s = new Street();
            City city = new City();
            if(hasStatus) {
                city.setCityId(cityId);
                city = cityDao.getCity(city);
            } else {
                city = village();
            }
            city.setArea(areaDao.getAreaById(areaId));

            s.setStreetName(streetName);
            s.setCity(city);

            Street street = streetDao.getStreet(s);

            if(street == null)
                street = s;

            street.setCity(city);
            location.setStreet(street);

            log.info("start locationIdFake: " + locationIdFake);

            if(location.getLocationId() == null) {
                location.setLocationId(locationIdFake);
                location.setDevices(new ArrayList<Device>());
                location.setInvoices(new ArrayList<Invoice>());
                Building building = new Building();
		building.setProperty(true);
                location.setBuilding(building);
                location.setPpes(new ArrayList<PPE>());
                locationList.add(location);
                locationIdFake++;
            }

            log.info("end locationIdFake: " + locationIdFake);

            Salesman sales = null;
            log.info("salesmans size: " + salesmans.size());

            for(int i = 0; i < salesmans.size(); i++) {
                if(salesmans.get(i).getSalesmanName().equals(salesman)) {
                    sales = salesmans.get(i);
                    log.info("sales: " + sales.getSalesmanName());
                    break;
                }
            }

            if(sales == null) {
                log.info("sales is null");
                sales = new Salesman();
                sales.setSalesmanName(salesman);
                sales.setRemoved(false);
                salesmans.add(sales);
            }

            Distributor dis = null;
            log.info("distributors size: " + distributors.size());

            for(int i = 0; i < distributors.size(); i++) {
                log.info("distributor: " + distributor);
                log.info("distributors: " + distributors.toString());
                log.info("distributors " + i + ": " + distributors.get(i).toString());
                log.info("distributors " + i + " name: " + distributors.get(i).getName());
                if(distributor != null && distributor.equals(distributors.get(i).getName())) {
                    dis = distributors.get(i);
                    log.info("dis: " + dis.getName());
                    break;
                }
            }

            log.info("dis: " + dis);
            log.info("distributor: " + distributor);
            if(dis == null && "".equals(distributor) == false) {
                log.info("dis is null");
                dis = new Distributor();
                dis.setName(distributor);
                if(distributor != null && distributor.length() > 0)
                    distributors.add(dis);
            }

            log.info("create agreement list");
            List<Agreement> agreementList = new ArrayList<Agreement>();
            agreement.setSalesman(sales);
            agreementList.add(agreement);
            log.info("add agreement to list");

            log.info("tariffId: " + tariffId);

            Tariff newTariff = tariffDao.getTariffById(tariffId);
            Tariff oldTariff = null;
            if(ppe.getPpeId() != null) {
                oldTariff = ppe.getTariff();
            }

            ppe.setAgreements(agreementList);
            ppe.setTariff(newTariff);
            ppe.setCurrentDistributor(dis);
            ppe.setLocation(location);
            ppe.setMeterModel(meterModelDao.getMeterModelById(meterModelId));

            if(compareTariff(newTariff, oldTariff) == false) {
                removeAllInvoicesForPPE(ppe);
            }

            log.info("tariff toString: " + newTariff.toString());
        } catch (Exception e) {
            e.printStackTrace();
            log.info("Exception: ", e);
        }

        log.info("start ppeIdFake: " + ppeIdFake);

        if(ppe.getPpeId() == null) {
            ppe.setPpeId(ppeIdFake);

            String objectType = PpeUtil.uniquePPEObjectType(ppe.getObjectType(), ppeList);
            ppe.setObjectType(objectType);

            location.getPpes().add(ppe);
            ppeList.add(ppe);

            ppeIdFake++;
        }

        log.info("end ppeIdFake: " + ppeIdFake);

        clearLocationPPE();
        locationPpeAdd = false;
        ppeButtons = true;

        log.info("<< saveLocationPPE end >>");
    }

    /**
     * Compare tariff.
     * 
     * @param newTariff
     *            - the new tariff instance
     * @param oldTariff
     *            - the old tariff instance
     * @return true, if they are same
     */
    public boolean compareTariff(Tariff newTariff, Tariff oldTariff) {

        boolean test = true;

        if(newTariff != null && oldTariff != null) {
            test = newTariff.getTariffId().equals(oldTariff.getTariffId());
            log.info("compareTariff: " + test);
        }

        return test;

    }

    /**
     * Removes the all invoices for PPE.
     * 
     * @param ppe
     *            - the PPE instance
     */
    public void removeAllInvoicesForPPE(PPE ppe) {

        if(ppe.getPpeId() != null) {
            WizardInvoiceBean wizardInvoiceBean = ComponentLookup.lookupComponent("op.wizardInvoiceBean");
            List<Invoice> allInvoices = wizardInvoiceBean.getInvoices();
            Iterator<Invoice> invoiceIterator = allInvoices.iterator();
            while(invoiceIterator.hasNext()) {
                Invoice invoice = invoiceIterator.next();
                if(invoice != null) {
                    log.info("invoice ppeId from invoice: " + invoice.getPpe().getPpeId());
                    log.info("invoice ppeId from args: " + ppe.getPpeId());
                    if(invoice.getPpe().getPpeId().intValue() == ppe.getPpeId().intValue()) {
                        log.info("remove invoice for ppeId: " + ppe.getPpeId());
                        invoiceIterator.remove();
                    }
                }
            }
        }

    }

    public City village() {

        Area area = new Area();
        area.setAreaId(areaId);

        City village = new City();

        City tmpCity = new City();
        tmpCity.setCityName(villageName);
        tmpCity.setArea(area);
        try {
            tmpCity = cityDao.getCity(tmpCity);
            if(tmpCity == null) {
                tmpCity = new City();
                tmpCity.setCityName(villageName);
                tmpCity.setArea(area);
                tmpCity.setHasStatus(false);
                cityDao.saveCity(tmpCity);
                village = tmpCity;
            } else {
                village = tmpCity;
                cityId = village.getCityId();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return village;
    }

    public void deletePPE() {
        if(ppe != null) {
            location = ppe.getLocation();
            location.getPpes().remove(ppe);
            ppeList.remove(ppe);
            if(location.getPpes().size() == 0)
                locationList.remove(location);
            removeAllInvoicesForPPE(ppe);
            clearLocationPPE();
            ppeButtons = true;
        }
    }

    public void onLocationSelect(AjaxBehaviorEvent ev) {
        if(locationId == 0) {
            location = new Location();
            Building building = new Building();
	    building.setProperty(true);
            location.setBuilding(building);
            setNewLocation(true);
        } else {
            for(int i = 0; i < locationList.size(); i++) {
                if(locationList.get(i).getLocationId().intValue() == locationId.intValue()) {
                    this.location = locationList.get(i);
                    setNewLocation(false);

                    log.info("this.location.getStreet(): " + this.location.getStreet().getStreetName());
                    log.info("this.location.getStreet().getCity(): "
                            + this.location.getStreet().getCity().getCityName());
                    log.info("this.location.getStreet().getCity().getArea(): "
                            + this.location.getStreet().getCity().getArea().getAreaName());

                    areaId = this.location.getStreet().getCity().getArea().getAreaId();
                    cityId = this.location.getStreet().getCity().getCityId();
                    hasStatus = this.location.getStreet().getCity().getHasStatus();
                    streetName = this.location.getStreet().getStreetName();
                    break;
                }
            }
        }
        if(location.getPpes() == null)
            location.setPpes(new ArrayList<PPE>());
    }

    public void cancelLocationPPE() {
        locationPpeAdd = false;
        ppeButtons = true;
        clearLocationPPE();
    }

    public void addLocationPPE() {
        locationPpeAdd = false;
        setNewLocation(true);
        clearLocationPPE();
    }

    public void addLocationPPEAction() {
        clearLocationPPE();
        locationPpeAdd = true;
    }

    public void editLocationPPEAction() {
        location = ppe.getLocation();
        tariffId = ppe.getTariff().getTariffId();
        salesman = ppe.getAgreements().get(0).getSalesman().getSalesmanName();
        if(ppe.getCurrentDistributor() != null)
            distributor = ppe.getCurrentDistributor().getName();
        streetName = location.getStreet().getStreetName();
        cityId = location.getStreet().getCity().getCityId();
        areaId = location.getStreet().getCity().getArea().getAreaId();
        locationId = location.getLocationId();

        setHasStatus(location.getStreet().getCity().getHasStatus());

        if(hasStatus == false) {
            villageName = location.getStreet().getCity().getCityName();
        }

        if(ppe.getMeterModel() != null)
            meterModelId = ppe.getMeterModel().getMeterModelId();

        locationPpeAdd = true;
    }

    public void clearLocationPPE() {
        location = new Location();
        location.setStreet(new Street());

        ppe = new PPE();
        ppe.setLocation(location);
        ppe.setTariff(new Tariff());

        agreement = new Agreement();

        tariffId = null;
        salesman = "";
        distributor = "";
        streetName = "";
        cityId = null;
        areaId = null;
        locationId = null;
        meterModelId = null;
        hasStatus = true;
    }

    public void onPPESelect(SelectEvent event) {
        tariffId = ppe.getTariff().getTariffId();
        salesman = ppe.getAgreements().get(0).getSalesman().getSalesmanName();
        if(ppe.getCurrentDistributor() != null)
            distributor = ppe.getCurrentDistributor().getName();
        ppeButtons = false;
        agreement = ppe.getAgreements().get(0);
    }

    public void onPPEUnselect(UnselectEvent event) {
        clearLocationPPE();
    }

    public List<String> autocompleteStreet(String query) {
        List<String> suggestions = new ArrayList<String>();

        query = query.toLowerCase();

        if(cityId != null) {
            suggestions = LocationUtil.autoCompleteStreet(query, cityId);
        } else {
            suggestions = LocationUtil.autoCompleteStreet(query);
        }

        return suggestions;
    }

    public List<String> autocompleteVillage(String query) {
        List<String> suggestions = new ArrayList<String>();

        query = query.toLowerCase();

        suggestions = LocationUtil.autoCompleteCity(query, areaId, false);

        return suggestions;
    }

    public void onCitySelect() {
        City city = new City();
        city.setCityId(cityId);
        try {
            Street street = new Street();
            street.setCity(city);
            streets = streetDao.getStreets(street);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Integer getCityId() {
        return cityId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public Integer getTariffId() {
        return tariffId;
    }

    public void setTariffId(Integer tariffId) {
        this.tariffId = tariffId;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public PPE getPpe() {
        return ppe;
    }

    public void setPpe(PPE ppe) {
        this.ppe = ppe;
    }

    public List<Distributor> getDistributors() {
        return distributors;
    }

    public void setDistributors(List<Distributor> distributors) {
        this.distributors = distributors;
    }

    public boolean isPpeButtons() {
        return ppeButtons;
    }

    public void setPpeButtons(boolean ppeButtons) {
        this.ppeButtons = ppeButtons;
    }

    public List<Area> getAreas() {
        return areas;
    }

    public void setAreas(List<Area> areas) {
        this.areas = areas;
    }

    public Integer getAreaId() {
        return areaId;
    }

    public void setAreaId(Integer areaId) {
        if(hasStatus == false) {
            villageName = "";
            disabledCity = false;
        }
        this.areaId = areaId;
    }

    public List<AgreementType> getAgreementTypes() {
        agreementTypes = new ArrayList<AgreementType>();

        for(AgreementType t : AgreementType.values()) {
            t.setLabel(BundlesUtils.getMessageResourceString("messages", "agreement.type." + t, null,
                    Locale.getDefault()));

            agreementTypes.add(t);
        }
        return agreementTypes;
    }

    public void setAgreementTypes(List<AgreementType> agreementTypes) {
        this.agreementTypes = agreementTypes;
    }

    public List<PPE> getPpeList() {
        return ppeList;
    }

    public void setPpeList(List<PPE> ppeList) {
        this.ppeList = ppeList;
    }

    public List<Location> getLocationList() {
        return locationList;
    }

    public void setLocationList(List<Location> locationList) {
        this.locationList = locationList;
    }

    public boolean isLocationPpeAdd() {
        return locationPpeAdd;
    }

    public void setLocationPpeAdd(boolean locationPpeAdd) {
        this.locationPpeAdd = locationPpeAdd;
    }

    public Integer getLocationId() {
        return locationId;
    }

    public void setLocationId(Integer locationId) {
        this.locationId = locationId;
    }

    public List<DurationType> getDurationTypes() {
        durationTypes = new ArrayList<DurationType>();

        for(DurationType t : DurationType.values()) {
            t.setLabel(BundlesUtils.getMessageResourceString("messages", "duration.type." + t, null,
                    Locale.getDefault()));

            durationTypes.add(t);
        }
        return durationTypes;
    }

    public void setDurationTypes(List<DurationType> durationTypes) {
        this.durationTypes = durationTypes;
    }

    public List<MeterModel> getMeterModels() {
        return meterModels;
    }

    public void setMeterModels(List<MeterModel> meterModels) {
        this.meterModels = meterModels;
    }

    public Integer getMeterModelId() {
        return meterModelId;
    }

    public void setMeterModelId(Integer meterModelId) {
        this.meterModelId = meterModelId;
    }

    public Agreement getAgreement() {
        return agreement;
    }

    public void setAgreement(Agreement agreement) {
        this.agreement = agreement;
    }

    public List<Salesman> getSalesmans() {
        return salesmans;
    }

    public void setSalesmans(List<Salesman> salesmans) {
        this.salesmans = salesmans;
    }

    public List<Street> getStreets() {
        return streets;
    }

    public void setStreets(List<Street> streets) {
        this.streets = streets;
    }

    public boolean isHasStatus() {
        return hasStatus;
    }

    public void setHasStatus(boolean hasStatus) {
        this.hasStatus = hasStatus;
    }

    public String getSalesman() {
        return salesman;
    }

    public void setSalesman(String salesman) {
        this.salesman = salesman;
    }

    public String getDistributor() {
        return distributor;
    }

    public void setDistributor(String distributor) {
        this.distributor = distributor;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    @SuppressWarnings({ "deprecation" })
    private void warning(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_WARN,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    public boolean isDisabledCity() {
        return disabledCity;
    }

    public void setDisabledCity(boolean disabledCity) {
        this.disabledCity = disabledCity;
    }

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }

    public boolean isNewLocation() {
        return newLocation;
    }

    public void setNewLocation(boolean newLocation) {
        this.newLocation = newLocation;
    }

}