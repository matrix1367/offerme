package pl.op.web.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.CommentDao;
import pl.op.model.comment.Comment;
import pl.op.model.comment.File;
import pl.op.model.comment.News;
import pl.op.model.user.UserApp;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class CommentBean.
 */
@Name("op.commentBean")
@Scope(ScopeType.SESSION)
public class CommentBean implements Serializable {

    private Logger log = LoggerFactory.getLogger(CommentBean.class);

    private static final long serialVersionUID = -8387717131750606039L;

    private CommentDao commentDao;

    private MessageActualBean messageActualBean;

    private List<Comment> comments;
    private List<News> news;
    private Comment selectedComment;
    private News selectedNews;
    private Comment comment;
    private News newsItem;
    private UserApp userLogged;

    private List<File> files;

    private String isCommentActivateVisible = "false";
    private String isCommentRemoveVisible = "false";
    private String isCommentEditVisible = "false";

    private String isNewsActivateVisible = "false";
    private String isNewsRemoveVisible = "false";
    private String isNewsEditVisible = "false";

    private Integer messagesCommentType = 0;
    private Integer messagesNewsType = 0;

    /**
     * Instantiates a new comment bean.
     */
    public CommentBean() {

        commentDao = GuiceSingleton.getInstance().getInstance(CommentDao.class);
        messageActualBean = ComponentLookup.lookupComponent("op.messageActualBean");
    }

    /**
     * Gets the news.
     * 
     * @return the news
     */
    public List<News> getNews() {
        return news;
    }

    /**
     * Sets the news.
     * 
     * @param news
     *            the new news
     */
    public void setNews(List<News> news) {
        this.news = news;
    }

    /**
     * Refreshed displayed comments.
     */
    public void refreshedDisplayedComments() {
        log.info("refreshing displayed comments...");
        messageActualBean.getActualCommentsList();
    }

    /**
     * Refreshed displayed news.
     */
    public void refreshedDisplayedNews() {
        log.info("refreshing displayed news...");
        messageActualBean.getActualNewsList();
    }

    /**
     * Adds the comment.
     * 
     * @return the string
     */
    public String addComment() {
        log.info("comment add action...");
        try {
            comment = new Comment();
            comment.setDateComment(new Date());
            files = new ArrayList<File>();
        } catch (Exception e) {
            log.error("Problem while add comment: ", e);
        }

        return "comment";
    }

    /**
     * Edits the comment.
     * 
     * @return the string
     */
    public String editComment() {
        log.info("edit comment action...");

        try {
            comment = commentDao.getComment(selectedComment.getIdComment());
        } catch (Exception e) {
            log.error("Problem while edit comment: ", e);
        }

        return "comment";
    }

    /**
     * Cancel comment.
     * 
     * @return the string
     */
    public String cancelComment() {
        log.info("cancel comment action...");

        try {
            comments = commentDao.getComments(new Comment());
            isCommentEditVisible = "false";
        } catch (Exception e) {
            log.error("Problem while cancel comment: ", e);
        }

        return "comments";
    }

    /**
     * Cancel news item.
     * 
     * @return the string
     */
    public String cancelNewsItem() {
        log.info("cancel news item action...");

        try {
            news = commentDao.getNews(new News());
            isNewsEditVisible = "false";
        } catch (Exception e) {
            log.error("Problem while cancel news item: ", e);
        }

        return "news";
    }

    /**
     * Adds the news item.
     * 
     * @return the string
     */
    public String addNewsItem() {
        log.info("add news item action...");

        try {
            newsItem = new News();
            newsItem.setDateNews(new Date());
        } catch (Exception e) {
            log.error("Problem while add news item: ", e);
        }

        return "newsItem";
    }

    /**
     * Edits the news item.
     * 
     * @return the string
     */
    public String editNewsItem() {
        log.info("edit news item action...");

        try {
            newsItem = selectedNews;
        } catch (Exception e) {
            log.error("Problem while edit news item: ", e);
        }

        return "newsItem";
    }

    /**
     * Action comments.
     * 
     * @return the string
     */
    public String actionComments() {
        log.info("commments administration console...");
        try {
            comments = commentDao.getComments(new Comment());
            AdminBean admin = ComponentLookup.lookupComponent("op.adminBean");
            userLogged = admin.getUserLog();
            log.info("user logged: " + userLogged.getLogin());
            isCommentEditVisible = "false";
        } catch (Exception e) {
            log.error("Problem while comment administration console: ", e);
        }

        return "comments";
    }

    /**
     * Action news.
     * 
     * @return the string
     */
    public String actionNews() {
        log.info("news administration console...");
        try {
            news = commentDao.getNews(new News());
            AdminBean admin = ComponentLookup.lookupComponent("op.adminBean");
            userLogged = admin.getUserLog();
            log.info("user logged: " + userLogged.getLogin());
            isNewsEditVisible = "false";
        } catch (Exception e) {
            log.error("Problem while news administation console: ", e);
        }

        return "news";
    }

    /**
     * Gets the comments.
     * 
     * @return the comments
     */
    public List<Comment> getComments() {
        return comments;
    }

    /**
     * Sets the comments.
     * 
     * @param comments
     *            the new comments
     */
    public void setComments(List<Comment> comments) {
        this.comments = comments;
    }

    /**
     * Save comment.
     * 
     * @return the string
     */
    public String saveComment() {
        log.info("save/add comment...");

        try {
            if(comment.getIdComment() == null) {
                comment.setRemoved(false);
                if(comment.getActive() == null) {
                    comment.setActive(false);
                }
                comment.setAuthor(userLogged.getLogin());

                commentDao.addComment(comment);

                log.info("commentId: " + comment.getIdComment());

                if(files != null && files.size() > 0) {
                    for(Iterator<File> iterator = files.iterator(); iterator.hasNext();) {
                        File fileItem = iterator.next();
                        fileItem.setComment(comment);
                        commentDao.addFile(fileItem);
                        fileItem.setUrl(comment.getIdComment() + "_" + fileItem.getFileId() + "_" + fileItem.getName());
                        commentDao.updateFileUrl(fileItem);
                    }
                }

            } else {
                commentDao.updateComment(comment);
            }
        } catch (Exception e) {
            log.error("Problem while save comment: ", e);
        }

        try {
            comments = commentDao.getComments(new Comment());
        } catch (Exception e) {
            log.error("Problem while get comments: ", e);
        }

        return "comments";
    }

    /**
     * Save news item.
     * 
     * @return the string
     */
    public String saveNewsItem() {

        log.info("save/add newsItem...");

        try {
            if(newsItem.getIdNews() == null) {
                newsItem.setRemoved(false);
                if(newsItem.getActive() == null)
                    newsItem.setActive(false);
                newsItem.setAuthor(userLogged.getLogin());
                commentDao.addNews(newsItem);
            } else
                commentDao.updateNews(newsItem);
        } catch (Exception e) {
            // TODO: handle exception
        }

        try {
            news = commentDao.getNews(new News());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return "news";
    }

    /**
     * Gets the selected comment.
     * 
     * @return the selected comment
     */
    public Comment getSelectedComment() {
        return selectedComment;
    }

    /**
     * Sets the selected comment.
     * 
     * @param selectedComment
     *            the new selected comment
     */
    public void setSelectedComment(Comment selectedComment) {
        this.selectedComment = selectedComment;
    }

    /**
     * Gets the selected news.
     * 
     * @return the selected news
     */
    public News getSelectedNews() {
        return selectedNews;
    }

    /**
     * Sets the selected news.
     * 
     * @param selectedNews
     *            the new selected news
     */
    public void setSelectedNews(News selectedNews) {
        this.selectedNews = selectedNews;
    }

    /**
     * Activate comment.
     * 
     * @return the string
     */
    public String activateComment() {

        if(selectedComment == null)
            return "";

        log.info("activateComment..." + selectedComment.getIdComment());
        try {
            commentDao.activateComment(selectedComment.getIdComment());
            isCommentActivateVisible = "false";
        } catch (Exception e) {
            e.printStackTrace();
        }

        log.info("refreshing comments list...");

        try {
            comments = commentDao.getComments(new Comment());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "";
    }

    /**
     * Removes the comment.
     * 
     * @return the string
     */
    public String removeComment() {

        if(selectedComment == null)
            return "";

        log.info("removeComment..." + selectedComment.getIdComment());
        try {
            commentDao.removeComment(selectedComment.getIdComment());
            isCommentRemoveVisible = "false";
        } catch (Exception e) {
            e.printStackTrace();
        }

        log.info("refreshing comments list...");

        try {
            comments = commentDao.getComments(new Comment());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * Activate news.
     * 
     * @return the string
     */
    public String activateNews() {

        if(selectedNews == null)
            return "";

        log.info("activateNews..." + selectedNews.getIdNews());
        try {
            commentDao.activateNews(selectedNews.getIdNews());
            isNewsActivateVisible = "false";
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        log.info("refreshing news list...");

        try {
            news = commentDao.getNews(new News());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return "";
    }

    /**
     * Removes the news.
     * 
     * @return the string
     */
    public String removeNews() {

        if(selectedNews == null)
            return "";

        log.info("removeNews..." + selectedNews.getIdNews());
        try {
            commentDao.removeNews(selectedNews.getIdNews());
            isNewsRemoveVisible = "false";
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        log.info("refreshing news list...");

        try {
            news = commentDao.getNews(new News());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return "";
    }

    /**
     * Gets the comment.
     * 
     * @return the comment
     */
    public Comment getComment() {
        return comment;
    }

    /**
     * Sets the comment.
     * 
     * @param comment
     *            the new comment
     */
    public void setComment(Comment comment) {
        this.comment = comment;
    }

    /**
     * Gets the news item.
     * 
     * @return the news item
     */
    public News getNewsItem() {
        return newsItem;
    }

    /**
     * Sets the news item.
     * 
     * @param newsItem
     *            the new news item
     */
    public void setNewsItem(News newsItem) {
        this.newsItem = newsItem;
    }

    /**
     * On row comment select.
     * 
     * @param event
     *            the event
     */
    public void onRowCommentSelect(SelectEvent event) {
        if(event != null) {
            selectedComment = (Comment) event.getObject();
        }

        log.info("->>>>>>>>>>>>>>>>>>>>>>>> SELECT ");

        refreshCommentButtonsPanel();
    }

    /**
     * On row comment unselect.
     * 
     * @param event
     *            the event
     */
    public void onRowCommentUnselect(UnselectEvent event) {
        if(event != null) {
            selectedComment = (Comment) event.getObject();
        }

        log.info("->>>>>>>>>>>>>>>>>>>>>>>> UNSELECT ");

        refreshCommentButtonsPanel();
    }

    /**
     * Refresh comment buttons panel.
     */
    public void refreshCommentButtonsPanel() {

        log.info("refreshCommentButtonsPanel...");

        if(selectedComment != null) {

            isCommentEditVisible = "true";

            if(!selectedComment.getActive().booleanValue())
                isCommentActivateVisible = "true";
            else
                isCommentActivateVisible = "false";

            if(!selectedComment.getRemoved().booleanValue())
                isCommentRemoveVisible = "true";
            else
                isCommentRemoveVisible = "false";
        } else
            isCommentEditVisible = "false";

    }

    /**
     * On row news select.
     * 
     * @param event
     *            the event
     */
    public void onRowNewsSelect(SelectEvent event) {
        if(event != null) {
            selectedNews = (News) event.getObject();
        }

        log.info("->>>>>>>>>>>>>>>>>>>>>>>> SELECT ");

        refreshNewsButtonsPanel();
    }

    /**
     * On row news unselect.
     * 
     * @param event
     *            the event
     */
    public void onRowNewsUnselect(UnselectEvent event) {
        if(event != null) {
            selectedNews = (News) event.getObject();
        }

        log.info("->>>>>>>>>>>>>>>>>>>>>>>> UNSELECT ");

        refreshNewsButtonsPanel();
    }

    /**
     * Refresh news buttons panel.
     */
    public void refreshNewsButtonsPanel() {

        if(selectedNews != null) {

            isNewsEditVisible = "true";

            if(!selectedNews.getActive().booleanValue())
                isNewsActivateVisible = "true";
            else
                isNewsActivateVisible = "false";

            if(!selectedNews.getRemoved().booleanValue())
                isNewsRemoveVisible = "true";
            else
                isNewsRemoveVisible = "false";
        } else
            isNewsEditVisible = "false";

        log.info("refreshNewsButtonsPanel...");

    }

    /**
     * Gets the checks if is comment activate visible.
     * 
     * @return the checks if is comment activate visible
     */
    public String getIsCommentActivateVisible() {
        return isCommentActivateVisible;
    }

    /**
     * Sets the checks if is comment activate visible.
     * 
     * @param isCommentActivateVisible
     *            the new checks if is comment activate visible
     */
    public void setIsCommentActivateVisible(String isCommentActivateVisible) {
        this.isCommentActivateVisible = isCommentActivateVisible;
    }

    /**
     * Gets the checks if is comment remove visible.
     * 
     * @return the checks if is comment remove visible
     */
    public String getIsCommentRemoveVisible() {
        return isCommentRemoveVisible;
    }

    /**
     * Sets the checks if is comment remove visible.
     * 
     * @param isCommentRemoveVisible
     *            the new checks if is comment remove visible
     */
    public void setIsCommentRemoveVisible(String isCommentRemoveVisible) {
        this.isCommentRemoveVisible = isCommentRemoveVisible;
    }

    /**
     * Gets the checks if is comment edit visible.
     * 
     * @return the checks if is comment edit visible
     */
    public String getIsCommentEditVisible() {
        return isCommentEditVisible;
    }

    /**
     * Sets the checks if is comment edit visible.
     * 
     * @param isCommentEditVisible
     *            the new checks if is comment edit visible
     */
    public void setIsCommentEditVisible(String isCommentEditVisible) {
        this.isCommentEditVisible = isCommentEditVisible;
    }

    /**
     * Gets the checks if is news activate visible.
     * 
     * @return the checks if is news activate visible
     */
    public String getIsNewsActivateVisible() {
        return isNewsActivateVisible;
    }

    /**
     * Sets the checks if is news activate visible.
     * 
     * @param isNewsActivateVisible
     *            the new checks if is news activate visible
     */
    public void setIsNewsActivateVisible(String isNewsActivateVisible) {
        this.isNewsActivateVisible = isNewsActivateVisible;
    }

    /**
     * Gets the checks if is news remove visible.
     * 
     * @return the checks if is news remove visible
     */
    public String getIsNewsRemoveVisible() {
        return isNewsRemoveVisible;
    }

    /**
     * Sets the checks if is news remove visible.
     * 
     * @param isNewsRemoveVisible
     *            the new checks if is news remove visible
     */
    public void setIsNewsRemoveVisible(String isNewsRemoveVisible) {
        this.isNewsRemoveVisible = isNewsRemoveVisible;
    }

    /**
     * Gets the checks if is news edit visible.
     * 
     * @return the checks if is news edit visible
     */
    public String getIsNewsEditVisible() {
        return isNewsEditVisible;
    }

    /**
     * Sets the checks if is news edit visible.
     * 
     * @param isNewsEditVisible
     *            the new checks if is news edit visible
     */
    public void setIsNewsEditVisible(String isNewsEditVisible) {
        this.isNewsEditVisible = isNewsEditVisible;
    }

    /**
     * Gets the messages comment type.
     * 
     * @return the messages comment type
     */
    public Integer getMessagesCommentType() {
        return messagesCommentType;
    }

    /**
     * Sets the messages comment type.
     * 
     * @param messagesCommentType
     *            the new messages comment type
     */
    public void setMessagesCommentType(Integer messagesCommentType) {
        this.messagesCommentType = messagesCommentType;
    }

    /**
     * Gets the messages news type.
     * 
     * @return the messages news type
     */
    public Integer getMessagesNewsType() {
        return messagesNewsType;
    }

    /**
     * Sets the messages news type.
     * 
     * @param messagesNewsType
     *            the new messages news type
     */
    public void setMessagesNewsType(Integer messagesNewsType) {
        this.messagesNewsType = messagesNewsType;
    }

    /**
     * Handle file upload.
     * 
     * @param event
     *            the event
     */
    public void handleFileUpload(FileUploadEvent event) {
        FacesMessage msg = new FacesMessage("Succesful", event.getFile().getFileName() + " is uploaded.");

        File image = new File();
        image.setImage(event.getFile().getContents());
        image.setName(event.getFile().getFileName());

        files.add(image);

        FacesContext.getCurrentInstance().addMessage(null, msg);
    }

    /**
     * Value change show comment type.
     * 
     * @param event
     *            the event
     */
    public void valueChangeShowCommentType(ValueChangeEvent event) {

        if(event.getNewValue() != null && !event.getNewValue().equals("")) {

            Integer showID = Integer.parseInt(event.getNewValue().toString());

            switch (showID) {

                case 0:
                    try {
                        log.info("show all comments...");
                        comments = commentDao.getComments(new Comment());
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    break;

                case 1:
                    log.info("show displayed comments...");
                    comments = messageActualBean.getActualComments();
                    break;

                case 2:
                    try {
                        log.info("show current comments...");
                        comments = commentDao.getActualComments();
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                    break;

                default:
                    break;

            }
        }
    }

    /**
     * Value change show news type.
     * 
     * @param event
     *            the event
     */
    public void valueChangeShowNewsType(ValueChangeEvent event) {

        if(event.getNewValue() != null && !event.getNewValue().equals("")) {

            Integer showID = Integer.parseInt(event.getNewValue().toString());

            switch (showID) {

                case 0:
                    try {
                        log.info("show all news...");
                        news = commentDao.getNews(new News());
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    break;

                case 1:
                    log.info("show displayed news...");
                    news = messageActualBean.getActualNews();
                    break;

                case 2:
                    try {
                        log.info("show current news...");
                        news = commentDao.getActualNews();
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                    break;

                default:
                    break;

            }
        }
    }

}
