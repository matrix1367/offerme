package pl.op.web.beans;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.SalesmanDao;
import pl.op.dao.UserDao;
import pl.op.model.salesman.Salesman;
import pl.op.model.user.UserApp;
import pl.op.model.user.UserRole;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.common.LoginUtil;
import pl.op.web.listener.GuiceSingleton;

import com.lowagie.text.BadElementException;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;

@Name("op.adminBean")
@Scope(ScopeType.SESSION)
public class AdminBean implements Serializable {

    private static final long serialVersionUID = 7657279753756327544L;

    public AdminBean() {
        log.info("AdminBean constructor");
        initialize();

    }

    private UserDao userDao;
    private SalesmanDao salesmanDao;
    private UserApp user;
    private UserApp userFilter;
    private UserApp userLog;
    private List<UserApp> users;
    private UserApp userSelected;
    private List<Integer> operatorsIdList;
    @SuppressWarnings("unused")
    private List<UserRole> userRoles;

    private List<Salesman> salesmanList;
    private Integer salesmanId;

    private String isActivateVisible = "false";
    private String isRemoveVisible = "false";
    private String isEditVisible = "false";
    private String isLockVisible = "false";
    private String isShowVisible = "false";

    private ExternalContext ectx;
    private FacesContext facesContext;

    private boolean salesmanAddMode = false;

    private Integer pageUserSearch = 0;

    String passwordCode = null;

    private Logger log = LoggerFactory.getLogger(AdminBean.class);

    private void initialize() {
        userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);
        salesmanDao = GuiceSingleton.getInstance().getInstance(SalesmanDao.class);
        users = new ArrayList<UserApp>();

        user = new UserApp();
        userFilter = new UserApp();

        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();

        try {
            salesmanList = salesmanDao.getAllSalesmans();
        } catch (Exception e) {
            log.error("There was a problem while retrieving salesmen: ", e);
        }

    }

    public List<Salesman> getSalesmanList() {
        return salesmanList;
    }

    public UserApp getUser() {
        return user;
    }

    public void setUser(UserApp user) {
        this.user = user;
    }

    public UserApp getUserLog() {
        return userLog;
    }

    public void setUserLog(UserApp userLog) {
        this.userLog = userLog;
    }

    public List<UserApp> getUsers() {
        return users;
    }

    public void setUsers(List<UserApp> users) {
        this.users = users;
    }

    public String backToUserList() {

        user = new UserApp();
        log.info("back to user list...");

        return "listUsers";
    }

    public void refreshSalesmanMode() {
        log.info("user role: " + user.getUserRole());
        if (user.getUserRole().equals(UserRole.salesman))
            salesmanAddMode = true;
        else
            salesmanAddMode = false;
        log.info("salesmanAddMode: " + salesmanAddMode);
    }

    public String listUsers() {

        try {

            isActivateVisible = "false";
            isLockVisible = "false";
            isEditVisible = "false";

            user = new UserApp();
            userFilter = new UserApp();
            userSelected = new UserApp();
            users = userDao.getUsersList();
            if (users != null)
                log.info("users size: " + users.size());
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
        }
        return "listUsers";

    }
    
    public void refreshUsersList() {
    	try {
			users = userDao.getUsersList();
		} catch (Exception e) {
			log.error("EXCEPTION:", e);
		}
    }

    private void blockOperatorsEdit() {
        if (userLog.getUserRole().name().equals("operator")
                && (userSelected.getUserRole().name().equals("operator") || userSelected.getUserRole().name()
                        .equals("admin"))) {
            isLockVisible = "false";
            isEditVisible = "false";
        } 
    }

    public List<Integer> listOperators() {
        try {
            operatorsIdList = userDao.getOperatorsIdList(operatorsIdList);
        } catch (Exception e) {
            log.error("error while getOperatorsIdList : ", e);
        }

        return operatorsIdList;
    }

    public void searchUsers() {
        try {
            users = userDao.filterUsers(userFilter);
        } catch (Exception e) {
            e.printStackTrace();
        }
        refreshButtonsPanel();
    }

    public void clearSearchUsers() {
        userFilter = new UserApp();

        try {
            user.setRemoved(false);
            users = userDao.getUsersList();
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
        }

        refreshButtonsPanel();

    }

    public String lockUser() {
        log.info("lock user...");

        user = userSelected;
        try {
            user.setActive(false);
            userDao.updateUser(user);
            users = userDao.getUsers(new UserApp());
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
        }

        refreshButtonsPanel();

        return "";
    }
    
    public String LoginName(){
        if (userLog != null) {
            if (userLog.getIsCompany()) {
                return userLog.getCompanyName();
            } else {
                return userLog.getFirstName() + " " + userLog.getSurname();
            }
        } else {
            return "";
        }
    }

    public String activateUser() {
        log.info("activate user...");

        user = userSelected;
        try {
            user.setActive(true);
            userDao.updateUser(user);
            users = userDao.getUsers(new UserApp());
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
        }

        refreshButtonsPanel();

        return "";
    }

    public String editUser() {

        log.info("edit user...");

        user = userSelected;

        return "admin_user_edit";
    }

    public String showDetailUser() {

        log.info("show Detail user...");
        user = userSelected;

        refreshButtonsPanel();

        return "admin_user_detail";
    }

    /*
     * public boolean checkLoginValidate() { boolean loginValidate = true; if
     * (!user.getLogin().equals(user.getLogin2())) {
     * 
     * String message = BundlesUtils.getMessageResourceString("messages",
     * "email_error", null, ectx.getRequestLocale());
     * FacesMessages.instance().add(message); loginValidate = false; }
     * 
     * log.info("loginValidate: " + loginValidate);
     * 
     * return loginValidate; }
     */

    public String saveUser() {

        log.info("User role: " + user.getUserRole());

        log.info("User FirstLogin #1: " + user.getFirstLogin());

        if (user.getUserId() == null) {

            user.setIsCompany(false);
            user.setFirstLogin(false);
            user.setRemoved(false);
            user.setActive(true);
            try {
				user.setSalesman(salesmanDao.getSalesmanById(salesmanId));
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
            // user.setCreationDate(new Date());

            // boolean login = checkLoginValidate();
            // if (!login)
            // return "admin_user_add";

            log.info("User FirstLogin #2: " + user.getFirstLogin());

            boolean unique = uniqueName();
            if (!unique)
                return "admin_user_add";

            String password;

            if (user.getUserRole().equals(UserRole.user) || user.getUserRole().equals(UserRole.user_blocked)
                    || user.getUserRole().equals(UserRole.user_junior)
                    || user.getUserRole().equals(UserRole.user_premium)) {
                user.setFirstLogin(true);
                log.info("wizzard enable");
            }

            log.info("User FirstLogin #3: " + user.getFirstLogin());

            try {

                MailBean mailBean = ComponentLookup.lookupComponent("op.mailBean");

                passwordCode = UUID.randomUUID().toString().substring(0, 8);
                password = LoginUtil.generatePasswordHash(passwordCode, user.getLogin());
                user.setPassword(password);

                userDao.saveUser(user);
                log.info("user.login=" + user.getLogin());

                mailBean.sendNotificationEmail(user, passwordCode);
                passwordCode = null;

            } catch (Exception e) {
                log.error("EXCEPTION:", e);
            }
        } else {

            try {

                log.info("User FirstLogin #1: " + user.getFirstLogin());

                if (user.getUserRole().equals(UserRole.admin) || user.getUserRole().equals(UserRole.operator)
                        || user.getUserRole().equals(UserRole.salesman)) {
                    user.setFirstLogin(false);
                    log.info("wizzard disabled");
                }

                log.info("User FirstLogin #2: " + user.getFirstLogin());

                userDao.updateUser(user);
            } catch (Exception e) {
                log.error("EXCEPTION:", e);
            }
        }

        log.info("saveUser...");

        try {
            users = userDao.getUsers(new UserApp());
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
        }

        refreshButtonsPanel();

        clearSearchUsers();
        return "listUsers";
    }

    public void removeUser() {

        if (userSelected != null && userSelected.getUserId() != null) {
            try {
                userDao.deleteUser(userSelected);
            } catch (Exception e) {
                log.error("EXCEPTION:", e);
            }

            try {
                users = userDao.getUsers(new UserApp());
            } catch (Exception e) {
                log.error("EXCEPTION:", e);
            }

            log.info("delete user action");
        }

        try {

            isActivateVisible = "false";
            isLockVisible = "false";
            isEditVisible = "false";

            user = new UserApp();
            userFilter = new UserApp();
            userSelected = new UserApp();
            users = userDao.getUsersList();
            if (users != null)
                log.info("users size: " + users.size());
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
        }

        clearSearchUsers();
        refreshButtonsPanel();
    }

    public String cancelAddIncomeAction() {

        log.info("cancel add income action...");

        return "admin_user_transactions";
    }

    public String cancelAddUserAction() {

        user = new UserApp();
        log.info("cancel add user action...");

        return "listUsers";
    }

    public String cancelEditUserAction() {

        user = new UserApp();
        log.info("cancel edit user action...");

        clearSearchUsers();
        blockOperatorsEdit();
        return "listUsers";
    }

    private boolean uniqueName() {

        boolean userExist = false;

        try {
            userExist = userDao.checkLocalUserExist(user.getLogin());

        } catch (Exception e) {
            return false;
        }

        if (userExist) {
            String message = BundlesUtils.getMessageResourceString("messages", "login_exist", null,
                    ectx.getRequestLocale());
            FacesMessages.instance().add(message);
            return false;
        } else
            return true;

    }

    public String addUser() {

        log.info("add new user...");
        salesmanAddMode = false;
        user = null;
        user = new UserApp();

        user.setUserRole(UserRole.user);

        refreshButtonsPanel();

        return "admin_user_add";
    }

    public UserApp getUserSelected() {
        return userSelected;
    }

    public void setUserSelected(UserApp userSelected) {
        this.userSelected = userSelected;
    }

    public void onRowSelect(SelectEvent event) {
        if (event != null) {
            userSelected = (UserApp) event.getObject();
        }

        log.info("->>>>>>>>>>>>>>>>>>>>>>>> SELECT ");

        refreshButtonsPanel();
        isShowVisible = "true";
        blockOperatorsEdit();
    }

    public void onRowUnselect(UnselectEvent event) {
        if (event != null) {
            userSelected = (UserApp) event.getObject();
        }

        log.info("->>>>>>>>>>>>>>>>>>>>>>>> UNSELECT ");

        refreshButtonsPanel();
        isShowVisible = "false";
    }

    public void refreshButtonsPanel() {

        log.info("refreshButtonsPanel...");

        if (userSelected != null) {

            isEditVisible = "true";

            if (!userSelected.getActive().booleanValue()) {
                isActivateVisible = "true";
                isLockVisible = "false";
            } else {
                isActivateVisible = "false";
                isLockVisible = "true";
            }

            if (userSelected.getActive().booleanValue()) {
                isLockVisible = "true";
                isActivateVisible = "false";
            } else {
                isLockVisible = "false";
                isActivateVisible = "true";
            }

            if (userSelected.getRemoved() != null && !userSelected.getRemoved().booleanValue())
                isRemoveVisible = "true";
            else
                isRemoveVisible = "false";
        } else
            isEditVisible = "false";

    }

    @SuppressWarnings("deprecation")
    public void preProcessPDF(Object document) throws IOException, BadElementException, DocumentException {
        Document pdf = (Document) document;
        pdf.open();
        pdf.setPageSize(PageSize.A4);

        ServletContext servletContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext()
                .getContext();
        String logo = servletContext.getRealPath("") + File.separator + "images" + File.separator + "logo_op.png";

        pdf.add(Paragraph.getInstance(new Date().toLocaleString()));
        pdf.add(Image.getInstance(logo));
    }

    public String getIsActivateVisible() {
        return isActivateVisible;
    }

    public void setIsActivateVisible(String isActivateVisible) {
        this.isActivateVisible = isActivateVisible;
    }

    public String getIsRemoveVisible() {
        return isRemoveVisible;
    }

    public void setIsRemoveVisible(String isRemoveVisible) {
        this.isRemoveVisible = isRemoveVisible;
    }

    public String getIsEditVisible() {
        return isEditVisible;
    }

    public void setIsEditVisible(String isEditVisible) {
        this.isEditVisible = isEditVisible;
    }

    public String getIsLockVisible() {
        return isLockVisible;
    }

    public void setIsLockVisible(String isLockVisible) {
        this.isLockVisible = isLockVisible;
    }

    public List<UserRole> getUserRoles() {

        List<UserRole> list = new ArrayList<UserRole>();

        for (UserRole e : UserRole.values()) {
            if (e.ordinal() > 0)
                list.add(e);
        }

        return list;
    }

    public void setUserRoles(List<UserRole> userRoles) {
        this.userRoles = userRoles;
    }

    public List<Integer> getOperatorsIdList() {
        return operatorsIdList;
    }

    public void setOperatorsIdList(List<Integer> operatorsIdList) {
        this.operatorsIdList = operatorsIdList;
    }

    public String getPasswordCode() {
        return passwordCode;
    }

    public void setPasswordCode(String passwordCode) {
        this.passwordCode = passwordCode;
    }

    public UserApp getUserFilter() {
        return userFilter;
    }

    public void setUserFilter(UserApp userFilter) {
        this.userFilter = userFilter;
    }

    public Integer getPageUserSearch() {
        return pageUserSearch;
    }

    public void setPageUserSearch(Integer pageUserSearch) {
        this.pageUserSearch = pageUserSearch;
    }

    public boolean getSalesmanAddMode() {
        return salesmanAddMode;
    }

    public void setSalesmanAddMode(boolean salesmanAddMode) {
        this.salesmanAddMode = salesmanAddMode;
    }

	public Integer getSalesmanId() {
		return salesmanId;
	}

	public void setSalesmanId(Integer salesmanId) {
		this.salesmanId = salesmanId;
	}

	public String getIsShowVisible() {
		return isShowVisible;
	}

	public void setIsShowVisible(String isShowVisible) {
		this.isShowVisible = isShowVisible;
	}
}