/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pl.op.web.beans;

import java.util.ArrayList;
import java.util.List;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import pl.op.dao.DynamicTextDao;
import pl.op.dao.SettingsDao;
import pl.op.dynamicText.DynamicText;
import pl.op.settings.Settings;
import pl.op.web.beans.cloud.CloudBean;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;
import sun.security.pkcs11.wrapper.Functions;

/**
 *
 * @author dev
 */
@Name("op.homePageTools")
@Scope(ScopeType.SESSION)
public class HomePageTools {
      
    /** The log. */
    private Logger log = LoggerFactory.getLogger(HomeBean.class);

    
    /** The cloud bean. */
    @In(value = "#{op.cloudBean}", scope = ScopeType.SESSION, required = true)
    private CloudBean cloudBean;
    private SettingsDao settingsDao;
    private DynamicTextDao dynamicTextDao;
    
    private String banerText;
    private String cloudVolumen;

    public String getCloudVolumen() {
        return cloudVolumen;
    }

    public void setCloudVolumen(String cloudVolumen) {
        this.cloudVolumen = cloudVolumen;
    }        
 
    public void setBanerText(String banerText) {
        this.banerText = banerText;
    }

    public String getBanerText() {
        return banerText;
    }
    
    
    /** The clouds count. */
    private int cloudsCount = 0;   
    private int countRefreshPage = 0;
    private Boolean firstVisit = true;
        /**
     * Instantiates a new dashboard bean.
     */
    public HomePageTools() {
        preinitialize();
        initialize();
    }
    
    /**
     * Preinitialize.
     */
    private void preinitialize() {
          cloudBean = ComponentLookup.lookupComponent("op.cloudBean");
          settingsDao = GuiceSingleton.getInstance().getInstance(
				SettingsDao.class);
         dynamicTextDao = GuiceSingleton.getInstance().getInstance(
                DynamicTextDao.class);
    }
    /**
     * Initialize.
     */
    private void initialize() {
          try {
               cloudsCount = cloudBean.cloudsCount();
               Settings setting = settingsDao.getSettingByType("countRefreshPage");
               DynamicText dynamicTextBaner = dynamicTextDao.getDynamicTextByType("banerHomePage");
               if (null != dynamicTextBaner) {
                   banerText = dynamicTextBaner.getDynamicTextValue();
               } else banerText = "";
                 if (null == setting) {
                     countRefreshPage  = setting.getSettingValue();
                 } else {
                     
                 }
                 
                 DynamicText dynamicTextCludValue = dynamicTextDao.getDynamicTextByType("cloudVolumen");
                 if (null != dynamicTextCludValue) {
                     cloudVolumen = dynamicTextCludValue.getDynamicTextValue();
                 }
                 else {
                     cloudVolumen = "60 GWh";
                 }
          }
          catch (Exception e) {
            log.error("Problem while retrieving data: ", e);
        }
    }
    
    public int getCountRefreshPage()
    {
        return countRefreshPage;   
    }
    
    public int updateCountRefreshPage()
    {
         try {
         
                Settings setting = settingsDao.getSettingByType("countRefreshPage");
                    
                 if (null == setting) {
                     countRefreshPage  = 0;
                 } else {
                    countRefreshPage  = setting.getSettingValue();
                 }
                 
                // String ipAddr = ((ServletRequestAttributes)RequestContextHolder.currentRequestAttributes()).getRequest().getRemoteAddr();
                 
                 if(firstVisit) {
                     countRefreshPage++;
                     firstVisit = false;
                 }
                 
                 //todo remove log
               //  log.info("update licznika :" + countRefreshPage + " " +ipAddr);
                 if (setting != null) setting.setSettingValue(countRefreshPage);
                 settingsDao.updateSetting(setting);
                 return countRefreshPage;
          }
          catch (Exception e) {
            log.error("Problem while updateCountRefreshPage data: ", e);
        }
        return 0;
    }
    
     /**
     * Gets the clouds count.
     * 
     * @return the clouds count
     */
    public int getCloudsCount() {
        return cloudsCount;
    }
}
