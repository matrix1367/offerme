package pl.op.web.beans.auction;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.DateSelectEvent;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AgreementDao;
import pl.op.dao.InvoiceDao;
import pl.op.dao.PPEDao;
import pl.op.dao.StereotypeDao;
import pl.op.dao.UserDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionFilter;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.auction.AuctionStatus;
import pl.op.model.auction.AuctionUser;
import pl.op.model.cloud.Cloud;
import pl.op.model.contract.Agreement;
import pl.op.model.contract.Invoice;
import pl.op.model.contract.PPE;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Tariff;
import pl.op.model.stereotype.Stereotype;
import pl.op.model.user.UserApp;
import pl.op.util.UserUtil;
import pl.op.web.common.ComponentLookup;
import pl.op.web.comparator.AuctionByOfferPriceComparator;
import pl.op.web.comparator.AuctionByScoreComparator;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class AuctionArchiveBean.
 */
@Name("op.auctionArchiveBean")
@Scope(ScopeType.SESSION)
public class AuctionArchiveBean {

    private Logger log = LoggerFactory.getLogger(AuctionArchiveBean.class);

    private List<Auction> auctions;
    private Auction selectedAuction;
    private UserApp userApp;
    private Invoice lastInvoiceForPpe;
    private Agreement lastAgreementForPpe;

    private AuctionBean auctionBean;

    private PPEDao ppeDao;
    private UserDao userDao;
    private StereotypeDao stereotypeDao;
    private InvoiceDao invoiceDao;
    private AgreementDao agreementDao;

    private AuctionFilter auctionFilter;
    private List<PPE> userPpes;

    private Integer userPpeId;
    private Date calendarMinDate;

    private boolean buttonsDisabled = true;
    private boolean galleryView = true;

    /**
     * Instantiates a new auction archive bean.
     */
    @SuppressWarnings("deprecation")
    public AuctionArchiveBean() {
        auctionBean = ComponentLookup.lookupComponent("op.auctionBean");

        initializeDao();
        initializeVars();
        initializeFilter();
    }

    /**
     * Initialize dao.
     */
    public void initializeDao() {
        ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);
        userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);
        stereotypeDao = GuiceSingleton.getInstance().getInstance(StereotypeDao.class);
        invoiceDao = GuiceSingleton.getInstance().getInstance(InvoiceDao.class);
        agreementDao = GuiceSingleton.getInstance().getInstance(AgreementDao.class);
    }

    /**
     * Initialize vars.
     */
    public void initializeVars() {
        userPpes = new ArrayList<PPE>();
        userPpeId = null;

        calendarMinDate = new Date();
        calendarMinDate.setMonth(0);
        calendarMinDate.setDate(1);

        userApp = UserUtil.getLoggedUserInstance();
    }

    /**
     * Initialize on load.
     */
    public void initializeOnLoad() {
        try {
            userPpes = ppeDao.getPPEsByUser(userApp);
            setDefaultUserPpeId();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Checks if is initialized.
     *
     * @return true, if is initialized
     */
    private boolean isInitialized() {
        if (null == userPpes) {
            return false;
        }
        if (userPpes.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Sets the default user ppe id.
     */
    private void setDefaultUserPpeId() {
        if (!userPpes.isEmpty()) {
            userPpeId = userPpes.get(0).getPpeId();
            log.info("find user ppes => " + userPpes.size());
        }
    }

    /**
     * Initialize filter.
     */
    public void initializeFilter() {
        clearFilter();

        auctionFilter.getAuction().getCloud().addUser(userApp);
        auctionFilter.getAuction().getCloud().setStereotype(userApp.getSector().getStereotype());
        auctionFilter.setOrderBy("price-ASC");

        selectedAuction = new Auction();
    }

    /**
     * Clear selected auction.
     */
    public void clearSelectedAuction() {
        selectedAuction = new Auction();
        selectedAuction.setAuctionOffers(new ArrayList<AuctionOffer>());

        Cloud cloud = new Cloud();
        cloud.setTariff(new Tariff());
        cloud.setStereotype(new Stereotype());
        cloud.setAreas(new ArrayList<Area>());
        cloud.setCities(new ArrayList<City>());
        selectedAuction.setCloud(cloud);
        if (userApp != null) {
            AuctionUser au = new AuctionUser();
            au.setAuction(selectedAuction);
            au.setUserApp(userApp);
            selectedAuction.addAuctionUser(au);
        }
    }

    /**
     * Clear filter.
     */
    public void clearFilter() {
        clearSelectedAuction();

        auctionFilter = new AuctionFilter();
        auctionFilter.setAuction(selectedAuction);
        auctionFilter.setAuctionAttribute(null);
        auctionFilter.setEndTime(null);
        auctionFilter.setSeller(false);
    }

    /**
     * Update auction location.
     * onchange ppe - archiwalne aukcjie
     * @param ppeId the ppe id
     */
    public void updateAuctionLocation(Integer ppeId) {
        log.info("[AuctionArchiveBean]update auctions list");
        if (ppeId > 0) {
            userPpeId = ppeId;
        }
        if (userPpeId != null) {
            if (userPpeId > 0) {
                for (PPE ppe : userPpes) {
                    if (ppe.getPpeId().equals(userPpeId)) {
                        if (ppe.getTariff() == null) {
                            try {
                                ppe.setTariff(ppeDao.getActualTariff(ppe));
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }

                        auctionFilter.updateLocationDataInCloud(ppe, true, true);

                        updateLastInvoiceForPpe(userPpeId);
                        updateLastAgreementForPpe(userPpeId);

                        searchAuctions();
                    }
                }

            }
        }

        //aktualizacja ppe przy zmianie ppe w widoku archiwalnym
        AuctionInProgressBean bean = ComponentLookup.lookupComponent("op.auctionInProgressBean");
        bean.updateAuctionLocation(ppeId);
    }

    /**
     * Update order.
     *
     * @param order the order
     */
    public void updateOrder(String order) {
        auctionFilter.setOrderBy(order);

        searchAuctions();
    }

    /**
     * On start date change.
     *
     * @param event the event
     */
    public void onStartDateChange(DateSelectEvent event) {
        auctionFilter.setStartDate(event.getDate());

        if (auctionFilter.getFinishDate() != null && auctionFilter.getFinishDate().before(auctionFilter.getStartDate())) {
            auctionFilter.setFinishDate(auctionFilter.getStartDate());
        }

        searchAuctions();
    }

    /**
     * On finish date change.
     *
     * @param event the event
     */
    public void onFinishDateChange(DateSelectEvent event) {
        auctionFilter.setFinishDate(event.getDate());

        searchAuctions();
    }

    /**
     * Search auctions.
     */
    public void searchAuctions() {
        log.info("Searching archive auctions...");

        auctionFilter.getAuction().setStatus(AuctionStatus.FINISHED);
        auctions = auctionBean.searchAuctions(auctionFilter);
        if (auctions != null) {
            if (!auctions.isEmpty()) {
                for (Auction auction : auctions) {
                    if (lastInvoiceForPpe != null) {
                        auction.setActualUserInvoice(lastInvoiceForPpe);
                    }
                }
                log.info("find " + auctions.size() + " auctions");
                sortAuctions();
            } else {
                log.info("auctions not found");
            }
        } else {
            log.info("auctions not found");
        }
    }

    /**
     * Sort auctions.
     */
    public void sortAuctions() {
        if (auctionFilter.getOrderColumn().equals("price")) {
            log.info("sort auction by price - " + auctionFilter.getOrderType());
            Collections.sort(auctions, new AuctionByOfferPriceComparator(auctionFilter.getOrderType()));
        } else {
            log.info("sort auction by score - " + auctionFilter.getOrderType());
            Collections.sort(auctions, new AuctionByScoreComparator(auctionFilter.getOrderType()));
        }
    }

    /**
     * Gets the auctions.
     *
     * @return the auctions
     */
    public List<Auction> getAuctions() {
        return auctions;
    }

    /**
     * Sets the auctions.
     *
     * @param auctions the new auctions
     */
    public void setAuctions(List<Auction> auctions) {
        this.auctions = auctions;
    }

    /**
     * Gets the selected auction.
     *
     * @return the selected auction
     */
    public Auction getSelectedAuction() {
        return selectedAuction;
    }

    /**
     * Sets the selected auction.
     *
     * @param selectedAuction the new selected auction
     */
    public void setSelectedAuction(Auction selectedAuction) {
        this.selectedAuction = selectedAuction;
    }

    /**
     * Update selected auction.
     *
     * @param selectedAuction the selected auction
     */
    public void updateSelectedAuction(Auction selectedAuction) {
        log.info("update selected auction #" + selectedAuction.getAuctionId());
        this.selectedAuction = selectedAuction;
    }

    /**
     * Gets the user app.
     *
     * @return the user app
     */
    public UserApp getUserApp() {
        return userApp;
    }

    /**
     * Sets the user app.
     *
     * @param userApp the new user app
     */
    public void setUserApp(UserApp userApp) {
        this.userApp = userApp;
    }

    /**
     * Gets the last invoice for ppe.
     *
     * @return the last invoice for ppe
     */
    public Invoice getLastInvoiceForPpe() {
        return lastInvoiceForPpe;
    }

    /**
     * Sets the last invoice for ppe.
     *
     * @param lastInvoiceForPpe the new last invoice for ppe
     */
    public void setLastInvoiceForPpe(Invoice lastInvoiceForPpe) {
        this.lastInvoiceForPpe = lastInvoiceForPpe;
    }

    /**
     * Update last invoice for ppe.
     *
     * @param id the id
     */
    public void updateLastInvoiceForPpe(Integer id) {
        try {
            log.info("update lastInvoceByPpeId to ppe #" + id);
            lastInvoiceForPpe = invoiceDao.getLastInvoiceByPpeId(id);
            if (lastInvoiceForPpe != null) {
                log.info("lastInvoceByPpeId #" + lastInvoiceForPpe.getInvoiceId());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Gets the last agreement for ppe.
     *
     * @return the last agreement for ppe
     */
    public Agreement getLastAgreementForPpe() {
        return lastAgreementForPpe;
    }

    /**
     * Sets the last agreement for ppe.
     *
     * @param lastAgreementForPpe the new last agreement for ppe
     */
    public void setLastAgreementForPpe(Agreement lastAgreementForPpe) {
        this.lastAgreementForPpe = lastAgreementForPpe;
    }

    /**
     * Update last agreement for ppe.
     *
     * @param id the id
     */
    public void updateLastAgreementForPpe(Integer id) {
        try {
            log.info("update lastAgreementByPpeId to ppe #" + id);
            lastAgreementForPpe = agreementDao.getLastAgreementByPpeId(id);

            if (lastAgreementForPpe != null) {
                log.info("lastAgreementByPpeId #" + lastAgreementForPpe.getAgreementId());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Gets the user ppe id.
     *
     * @return the user ppe id
     */
    public Integer getUserPpeId() {
        if (!isInitialized()) {
            initializeOnLoad();
        }
        return userPpeId;
    }

    /**
     * Sets the user ppe id.
     *
     * @param userPpeId the new user ppe id
     */
    public void setUserPpeId(Integer userPpeId) {
        this.userPpeId = userPpeId;
    }

    /**
     * Checks if is buttons disabled.
     *
     * @return true, if is buttons disabled
     */
    public boolean isButtonsDisabled() {
        return buttonsDisabled;
    }

    /**
     * Sets the buttons disabled.
     *
     * @param buttonsDisabled the new buttons disabled
     */
    public void setButtonsDisabled(boolean buttonsDisabled) {
        this.buttonsDisabled = buttonsDisabled;
    }

    /**
     * Checks if is gallery view.
     *
     * @return true, if is gallery view
     */
    public boolean isGalleryView() {
        return galleryView;
    }

    /**
     * Sets the gallery view.
     *
     * @param galleryView the new gallery view
     */
    public void setGalleryView(boolean galleryView) {
        this.galleryView = galleryView;
    }

    /**
     * Change gallery view.
     */
    public void changeGalleryView() {
        clearSelectedAuction();

        buttonsDisabled = true;
        if (galleryView == true) {
            galleryView = false;
        } else {
            galleryView = true;
        }
    }

    /**
     * On auction select.
     *
     * @param event the event
     */
    public void onAuctionSelect(SelectEvent event) {
        buttonsDisabled = false;
    }

    /**
     * Gets the auction filter.
     *
     * @return the auction filter
     */
    public AuctionFilter getAuctionFilter() {
        return auctionFilter;
    }

    /**
     * Sets the auction filter.
     *
     * @param auctionFilter the new auction filter
     */
    public void setAuctionFilter(AuctionFilter auctionFilter) {
        this.auctionFilter = auctionFilter;
    }

    /**
     * Gets the user ppes.
     *
     * @return the user ppes
     */
    public List<PPE> getUserPpes() {
        if (!isInitialized()) {
            initializeOnLoad();
        }
        return userPpes;
    }

    /**
     * Sets the user ppes.
     *
     * @param userPpes the new user ppes
     */
    public void setUserPpes(List<PPE> userPpes) {
        this.userPpes = userPpes;
    }

    /**
     * Gets the calendar min date.
     *
     * @return the calendar min date
     */
    public Date getCalendarMinDate() {
        return calendarMinDate;
    }

    /**
     * Sets the calendar min date.
     *
     * @param calendarMinDate the new calendar min date
     */
    public void setCalendarMinDate(Date calendarMinDate) {
        this.calendarMinDate = calendarMinDate;
    }
}
