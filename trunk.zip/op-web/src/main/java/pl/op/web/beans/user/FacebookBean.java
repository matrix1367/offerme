package pl.op.web.beans.user;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.security.Identity;
import org.primefaces.context.RequestContext;
import org.primefaces.json.JSONException;
import org.primefaces.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.UserDao;
import pl.op.model.user.UserApp;
import pl.op.model.user.UserRole;
import pl.op.web.common.LoginUtil;
import pl.op.web.listener.GuiceSingleton;

@Name("op.facebookBean")
@Scope(ScopeType.SESSION)
public class FacebookBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Logger log = LoggerFactory.getLogger(FacebookBean.class);
	
	@In
	Identity identity;

	private UserApp facebookUser;
	private UserDao bdUser;

	private boolean isAuthorized;

	public UserApp getFacebookUser() {
		return facebookUser;
	}

	public void setFacebookUser(UserApp facebookUser) {
		this.facebookUser = facebookUser;
	}

	public FacebookBean() {
		initialize();
	}

	private void initialize() {
		bdUser = GuiceSingleton.getInstance().getInstance(UserDao.class);
		facebookUser = new UserApp();
	}

	public boolean authenticateUser(final String data) {
		log.info("trying to register user: " + data);
		JSONObject obj = parseJSON(data);

		try {

			facebookUser.setLogin(obj.getString("email"));
			if (!userExists()) {
				facebookUser.setActive(true);
				facebookUser.setFirstName(obj.getString("first_name"));
				facebookUser.setSurname(obj.getString("last_name"));
				facebookUser.setCreationDate(new Date());
				facebookUser.setFacebookUserId(obj.getString("id"));
				facebookUser.setFacebookUsername(obj.getString("username"));
				facebookUser.setFromFacebook(true);
				facebookUser.setRemoved(false);
				facebookUser.setIsCompany(false);
				facebookUser.setFirstLogin(true);
				facebookUser.setUserRole(UserRole.user);
				facebookUser.setPassword(LoginUtil.generatePasswordHash(
						randomString(10), facebookUser.getLogin()));
				if (obj.getString("birthday") != null) {
					DateFormat df = new SimpleDateFormat("mm/dd/yyyy",
							Locale.ENGLISH);
					Date result = df.parse(obj.getString("birthday"));
					facebookUser.setBirthDate(result);
				}
				bdUser.saveUser(facebookUser);
				facebookUser.setActivateKey(null);
			}

			isAuthorized = true;
			
			Identity.instance().login();

		} catch (Exception e) {
			log.error("Error while authenticating user: ", e);
		}

		return false;

	}

	String randomString(final int length) {
		Random r = new Random(); // perhaps make it a class variable so you
									// don't make a new one every time
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < length; i++) {
			char c = (char) (r.nextInt((int) (Character.MAX_VALUE)));
			sb.append(c);
		}
		return sb.toString();
	}

	public Boolean userExists() {

		boolean userExist = false;

		try {
			userExist = bdUser.checkLocalUserExist(facebookUser.getLogin());
		} catch (Exception e) {
			log.error(
					"There was a problem while checking user in the database: ",
					e);
		}

		return userExist;

	}

	private JSONObject parseJSON(String data) {
		JSONObject fieldsJson;
		try {
			fieldsJson = new JSONObject(data);
			log.info("json parameters length: " + fieldsJson.length());

			String[] fieldNames = JSONObject.getNames(fieldsJson);

			for (String name : fieldNames) {
				log.info(name + " : " + fieldsJson.getString(name));
			}

			return fieldsJson;
		} catch (JSONException e) {
			log.error("There was a problem while parsing JSON: ", e);
		}
		return null;
	}

	public boolean getIsAuthorized() {
		return isAuthorized;
	}

	public void setIsAuthorized(boolean isAuthorized) {
		this.isAuthorized = isAuthorized;
	}

}
