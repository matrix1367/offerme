package pl.op.web.beans.bill;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AgreementDao;
import pl.op.dao.InvoiceDao;
import pl.op.dao.LocationDao;
import pl.op.dao.MeasureDao;
import pl.op.dao.PPEDao;
import pl.op.dao.PriceComponentDao;
import pl.op.dao.TariffDao;
import pl.op.model.auction.PriceComponent;
import pl.op.model.cloud.VolumeEnum;
import pl.op.model.contract.Agreement;
import pl.op.model.contract.Invoice;
import pl.op.model.contract.InvoicePriceComponentValue;
import pl.op.model.contract.Location;
import pl.op.model.contract.Measure;
import pl.op.model.contract.PPE;
import pl.op.model.contract.PPEStatus;
import pl.op.model.contract.Priority;
import pl.op.model.dict.Obis;
import pl.op.model.dict.Tariff;
import pl.op.model.user.UserApp;
import pl.op.util.PpeUtil;
import pl.op.web.beans.AdminBean;
import pl.op.web.beans.log.PPEBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.common.DateUtil;
import pl.op.web.comparator.InvoicePriceComponentComparator;
import pl.op.web.listener.GuiceSingleton;
import pl.op.web.service.BonusService;
import pl.op.web.service.InvoiceService;

/**
 * The Class BillInvoiceBean.
 */
@Name("op.billInvoiceBean")
@Scope(ScopeType.SESSION)
public class BillInvoiceBean implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 7657279753756327544L;

    /**
     * Instantiates a new bill invoice bean.
     */
    public BillInvoiceBean() {
        log.info("BillInvoiceBean constructor");
        initialize();
    }

    /** The log. */
    private Logger log = LoggerFactory.getLogger(BillInvoiceBean.class);

    /** The ppe bean. */
    private PPEBean ppeBean;

    /** The invoice. */
    private Invoice invoice;

    /** The invoice fake id. */
    private Integer invoiceFakeId;

    // Filters
    /** The invoice filter. */
    private Invoice invoiceFilter;

    /** The volumes. */
    private List<VolumeEnum> volumes;

    /** The ppe list. */
    private List<PPE> ppeList;

    /** The invoices. */
    private List<Invoice> invoices;

    /** The price component values. */
    private List<InvoicePriceComponentValue> priceComponentValues;

    /** The admin bean. */
    @In(value = "#{op.adminBean}", scope = ScopeType.SESSION, required = true)
    private AdminBean adminBean;

    /** The location dao. */
    private LocationDao locationDao;

    /** The invoice buttons. */
    private boolean invoiceButtons = true;

    /** The invoice add. */
    private boolean invoiceAdd = false;

    /** The is edit. */
    private boolean isEdit = false;

    /** The today. */
    private Date today = new Date();

    /** The today as string. */
    private String todayAsString;

    /** The user. */
    private UserApp user;

    /**
     * Gets the user.
     * 
     * @return the user
     */
    public UserApp getUser() {
        return user;
    }

    /** The invoice dao. */
    private InvoiceDao invoiceDao;

    /** The ppe dao. */
    private PPEDao ppeDao;

    /** The agreement dao. */
    private AgreementDao agreementDao;

    /** The price component dao. */
    private PriceComponentDao priceComponentDao;

    /** The measure dao. */
    private MeasureDao measureDao;

    /** The ppe id. */
    private Integer ppeId;

    /** The volume enum. */
    private VolumeEnum volumeEnum;

    /** The faces context. */
    private FacesContext facesContext;

    /** The ectx. */
    private ExternalContext ectx;

    /** The sample. */
    private String sample;

    /**
     * Initialize.
     */
    private void initialize() {
        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();

        invoice = new Invoice();
        invoice.setPpe(new PPE());
        invoice.getPpe().setLocation(new Location());

        invoiceFilter = new Invoice();

        invoiceFakeId = 1;

        invoices = new ArrayList<Invoice>();

        adminBean = ComponentLookup.lookupComponent("op.adminBean");
        invoiceDao = GuiceSingleton.getInstance().getInstance(InvoiceDao.class);
        locationDao = GuiceSingleton.getInstance().getInstance(LocationDao.class);
        agreementDao = GuiceSingleton.getInstance().getInstance(AgreementDao.class);

        priceComponentDao = GuiceSingleton.getInstance().getInstance(PriceComponentDao.class);

        ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);
        measureDao = GuiceSingleton.getInstance().getInstance(MeasureDao.class);

        InicializePPE();

    }
    
    public void InicializePPE() {            
        try {

            user = adminBean.getUserLog();

            ppeList = ppeDao.getPPEsByUser(user);

            invoiceDao = GuiceSingleton.getInstance().getInstance(InvoiceDao.class);
            invoices = new ArrayList<Invoice>();

            prepareInvoice();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * Prepare invoice.
     * 
     * @throws Exception
     *             the exception
     */
    public void prepareInvoice() throws Exception {       
        invoices = new ArrayList<Invoice>();
        List<Invoice> invoicesFromDB;
        
        for(PPE ppe : ppeList) {
            if(ppe.getRemoved() == null || !ppe.getRemoved()) {               
                invoicesFromDB = invoiceDao.getInvoicesByPpeId(ppe.getPpeId());
                for(Invoice invoiceFromDB : invoicesFromDB) {                 
                    invoiceFromDB.setPpe(ppe);
                    invoiceFromDB.setVolumeEnum(VolumeEnum.MWH);
                    invoices.add(invoiceFromDB);
                }
            }
        }

    }

    /**
     * Invoice search.
     * 
     * @throws Exception
     *             the exception
     */
    public void invoiceSearch() throws Exception {

        invoices = new ArrayList<Invoice>();
        List<Invoice> invoicesFromDB;

        for(PPE ppe : ppeList) {
            if(ppe.getRemoved() == null || !ppe.getRemoved()) {
                invoiceFilter.setPpeId(ppe.getPpeId());
                invoicesFromDB = invoiceDao.searchInvoices(invoiceFilter);
                for(Invoice invoiceFromDB : invoicesFromDB) {
                    invoiceFromDB.setPpe(ppe);
                    invoiceFromDB.setVolumeEnum(VolumeEnum.MWH);
                    invoices.add(invoiceFromDB);
                }
            }
        }

    }

    /**
     * Invoice search clean.
     */
    public void invoiceSearchClean() {
        invoiceFilter = new Invoice();
        try {
            prepareInvoice();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Gets the invoice.
     * 
     * @return the invoice
     */
    public Invoice getInvoice() {
        return invoice;
    }

    /**
     * Sets the invoice.
     * 
     * @param invoice
     *            the new invoice
     */
    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }

    /**
     * Adds the invoice.
     */
    public void addInvoice() {
        if(!validInvoiceDate()) {
            log.info("validInvoiceDate: false");
            return;
        }

        if(invoice.getInvoiceId() == null) {
            log.info("[addInvoice] : invoice.getInvoiceId() == null");
            invoice.setInvoiceId(invoiceFakeId);
            // invoice.setVolumeEnum(volumeEnum.KWH);
            invoice.setInvoicePriceComponentValue(priceComponentValues);
            // invoices.add(invoice);

            try {

                List<Location> locations = locationDao.getLocationByUserApp(user);

                invoiceDao.saveInvoice(invoice);

                for(InvoicePriceComponentValue priceValue : invoice.getInvoicePriceComponentValue()) {
                    priceValue.setInvoice(invoice);

                    Double priceComponentValue = priceValue.getValue();
                    Double priceComponentAmount = priceValue.getAmount();
                    Double tempPriceComponentAmount = priceComponentAmount;
                    if(!priceValue.getPriceComponent().isConstant()) {
                        if(invoice.getVolumeEnum().equals(VolumeEnum.KWH)) {
                            priceComponentValue = priceComponentValue * 1000.0;
                            priceComponentAmount = priceComponentAmount / 1000.0;
                            priceValue.setAmount(priceComponentAmount);
                            priceValue.setValue(priceComponentValue);
                        }
                    }

                    invoiceDao.savePriceComponentValue(priceValue);

                    if(!priceValue.getPriceComponent().isConstant()) {
                        // Obis dla measure ma zawsze byc OBIS id: 1
                        Obis obis = new Obis();
                        obis.setObisId(1);
                        Double measureValue = tempPriceComponentAmount;
                        if(invoice.getVolumeEnum().equals(VolumeEnum.KWH)) {
                            measureValue = measureValue / 1000.0;
                        }
                        Measure measure = new Measure();
                        measure.setInvoice(invoice);
                        measure.setDateFrom(invoice.getDateFrom());
                        measure.setDateTo(invoice.getDateTo());
                        measure.setPpe(invoice.getPpe());
                        measure.setMeasureDate(new Date());
                        measure.setValue(measureValue);
                        measure.setZoneType(priceValue.getPriceComponent().getZoneType());
                        measure.setObis(obis);
                        measure.setPriority(Priority.medium);
                        measureDao.saveMeasure(measure);

                        BonusService.run("addMeasure", user);
                    }
                }

                PpeUtil.setPPEValue(invoice.getPpe());

                if(user.getIsCompany()) {
                    invoices.add(invoice);
                    log.info("invoices size: " + invoices.size());
                    log.info("locations size: " + locations.size());
                    PpeUtil.setStatusForCompanyByInvoices(invoices, locations, true);
                } else {
                    PpeUtil.setStatusForAllPPEs(locations, PPEStatus.READY_TO_JOIN, true);
                }

            } catch (Exception e) {
                log.error("There was a problem while saving invoice: ", e);
            }

            invoiceFakeId++;
        } else {
            log.info("[addInvoice] : invoice.getInvoiceId() != null");
            try {

                List<Location> locations = locationDao.getLocationByUserApp(user);

                invoiceDao.updateInvoice(invoice);

                measureDao.removeMeasureByInvoiceId(invoice.getInvoiceId());

                for(InvoicePriceComponentValue priceValue : invoice.getInvoicePriceComponentValue()) {
                    priceValue.setInvoice(invoice);

                    // if (!priceValue.getPriceComponent().isConstant() &&
                    // invoice.getVolumeEnum().equals(VolumeEnum.KWH)) {
                    // priceValue.setAmount(priceValue.getAmount() / 1000.0);
                    // }

                    Double priceComponentValue = priceValue.getValue();
                    log.info("[addInvoice] : priceComponentValue" + priceComponentValue);
                    Double priceComponentAmount = priceValue.getAmount();
                    log.info("[addInvoice] : priceComponentAmount" + priceComponentAmount);
                    if(!priceValue.getPriceComponent().isConstant()) {
                         log.info("[addInvoice] : !invoice.isConstant()");
                        if(invoice.getVolumeEnum().equals(VolumeEnum.KWH)) {
                            log.info("[addInvoice] :  invoice.getVolumeEnum().equals(VolumeEnum.KWH");
                            priceComponentValue = priceComponentValue * 1000.0;
                            priceComponentAmount = priceComponentAmount / 1000.0;
                            
                            log.info("[addInvoice] : priceComponentValue" + priceComponentValue);
                            log.info("[addInvoice] : priceComponentAmount" + priceComponentAmount);
                            priceValue.setAmount(priceComponentAmount);
                            priceValue.setValue(priceComponentValue);
                        }
                    }

                    invoiceDao.updateInvoicePriceComponentValue(priceValue);

                    if(!priceValue.getPriceComponent().isConstant()) {
                        // Obis dla measure ma zawsze byc OBIS id: 1
                        Obis obis = new Obis();
                        obis.setObisId(1);
                        Double measureValue = priceValue.getAmount() ; 
                      //invoice nadal jest na KWH a priceValue juz na MHW.
                       // if(invoice.getVolumeEnum().equals(VolumeEnum.KWH)) {
                       //        log.info("[addInvoice] : measureValue" + measureValue);
                            //measureValue = measureValue; /// 1000.0; 
                        //}
                        Measure measure = new Measure();
                        measure.setInvoice(invoice);
                        measure.setDateFrom(invoice.getDateFrom());
                        measure.setDateTo(invoice.getDateTo());
                        measure.setPpe(invoice.getPpe());
                        measure.setMeasureDate(new Date());
                        measure.setValue(measureValue);
                        measure.setZoneType(priceValue.getPriceComponent().getZoneType());
                        measure.setObis(obis);
                        measure.setPriority(Priority.medium);
                        measureDao.saveMeasure(measure);

                        BonusService.run("addMeasure", user);
                    }
                }

                PpeUtil.setPPEValue(invoice.getPpe());

                if(user.getIsCompany()) {
                    invoices.add(invoice);
                    PpeUtil.setStatusForCompanyByInvoices(invoices, locations, true);
                } else {
                    PpeUtil.setStatusForAllPPEs(locations, PPEStatus.READY_TO_JOIN, true);
                }

            } catch (Exception e) {
                // TODO Auto-generated catch block
                log.error("There was a problem while updating invoice: ", e);
            }

        }

        try {
            Agreement lastAgreement = agreementDao.getLastAgreementByPpeId(invoice.getPpe().getPpeId());
//            log.info(">>>>>>>>>.<<<<<<< PPE id:" + invoice.getPpe().getPpeId());
//            if (lastAgreement != null) {
//                log.info(">>>>>>>>>.<<<<<<<lastAgreement id:" + lastAgreement.getAgreementId());
//                log.info(">>>>>>>>>.<<<<<<<lastAgreement power:" +lastAgreement.getPower() );
//                log.info(">>>>>>>>>.<<<<<<<invoice.getUsagePower():" +invoice.getUsagePower() );
//            } else log.info(">>>>>>>>>.<<<<<<<lastAgreement is null");

            if(user.getIsCompany() && lastAgreement.getPower() != null) {
                if(lastAgreement.getPower() != invoice.getUsagePower())
                {
                    invoice.setUsagePower(0);
                    info("usagepower.warning", new String[] { String.valueOf(invoice.getUsagePower() - lastAgreement.getPower()) });
                }
            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        unselectInvoice();
        invoiceAdd = false;
        invoiceButtons = true;
        isEdit = false;

        ppeId = null;

        initialize();
    }

    /**
     * Update amount.
     * 
     * @param ipcv
     *            the ipcv
     */
    public void updateAmount(InvoicePriceComponentValue ipcv) {

        for(InvoicePriceComponentValue ipcv1 : invoice.getInvoicePriceComponentValue()) {
            if(!ipcv1.getPriceComponent().isConstant()) {
                if(invoice.getVolumeEnum().equals(VolumeEnum.KWH)) {
                    if(ipcv1.getAmount() != null) {
                        ipcv1.setAmount(ipcv1.getAmount() * 1000);
                    }
                    if(ipcv1.getValue() != null) {
                        ipcv1.setValue(ipcv1.getValue() / 1000.0);
                    }
                } else {
                    if(ipcv1.getAmount() != null) {
                        ipcv1.setAmount(ipcv1.getAmount() / 1000.0);
                    }
                    if(ipcv1.getValue() != null) {
                        ipcv1.setValue(ipcv1.getValue() * 1000);
                    }
                }
            }
        }

    }

    /**
     * Valid invoice date.
     * 
     * @return true, if successful
     */
    private boolean validInvoiceDate() {
        if(invoice.getDateFrom() != null && invoice.getDateTo() != null
                && invoice.getDateFrom().after(invoice.getDateTo())) {
            warning("warning.two.dates.invalid");
            return false;
        }

        if(invoice.getDateFrom().after(new Date())) {
            warning("warning.dates.future.invalid");
            return false;
        }

        if(invoice.getDateTo().after(new Date())) {
            warning("warning.dates.future.invalid");
            return false;
        }

        log.info("invoice.getDateFrom(): " + invoice.getDateFrom());
        log.info("invoice.getDateTo(): " + invoice.getDateTo());

        for(Invoice inv : invoices) {
            if(inv.getInvoiceId().equals(invoice.getInvoiceId()))
                continue;

            if(inv.getPpe().getPpeId().intValue() == invoice.getPpe().getPpeId().intValue()) {
                log.info("inv.getDateFrom(): " + inv.getDateFrom());
                log.info("inv.getDateTo(): " + inv.getDateTo());
                if(invoice.getDateFrom().after(inv.getDateFrom()) && invoice.getDateFrom().before(inv.getDateTo())) {
                    warning("warning.dates.overlap");
                    return false;
                }
                if(invoice.getDateTo().after(inv.getDateFrom()) && invoice.getDateTo().before(inv.getDateTo())) {
                    warning("warning.dates.overlap");
                    return false;
                }

                if(invoice.getDateTo().equals(inv.getDateTo())) {
                    warning("warning.dates.overlap");
                    return false;
                }

                if(invoice.getDateFrom().equals(inv.getDateFrom())) {
                    warning("warning.dates.overlap");
                    return false;
                }

                if(invoice.getDateFrom().equals(inv.getDateFrom()) && invoice.getDateTo().equals(inv.getDateTo())) {
                    warning("warning.dates.overlap");
                    return false;
                }

                if(invoice.getDateFrom().before(inv.getDateFrom()) && invoice.getDateTo().after(inv.getDateTo())) {
                    warning("warning.dates.overlap");
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * On invoice select.
     * 
     * @param event
     *            the event
     */
    public void onInvoiceSelect(SelectEvent event) {
        invoiceButtons = false;
        priceComponentValues = invoice.getInvoicePriceComponentValue();
        Collections.sort(priceComponentValues, new InvoicePriceComponentComparator());

        ppeId = invoice.getPpe().getPpeId();
    }

    /**
     * Delete invoice.
     */
    public void deleteInvoice() {
        log.info("removing invoice");
        if(invoice != null) {
            List<Invoice> ppeInvoices;
            try {
                ppeInvoices = invoiceDao.getInvoicesByPpeId(invoice.getPpe().getPpeId());
                if(ppeInvoices.size() > 1) {
                    log.info("removing invoice");
                    measureDao.removeMeasureByInvoiceId(invoice.getInvoiceId());
                    invoiceDao.removeInvoicePriceComponentValues(invoice);
                    invoices.remove(invoice);
                    PpeUtil.setPPEValue(invoice.getPpe());
                    invoiceDao.removeInvoice(invoice);
                } else {
                    warning("warning.at.least.one.invoice.per.ppe");
                }
            } catch (Exception e1) {
                log.error("There was a problem while removing invoice: ", e1);
            }

            unselectInvoice();
        }
        invoiceButtons = true;
    }

    /**
     * Unselect invoice.
     */
    public void unselectInvoice() {
        invoice = new Invoice();
        invoice.setPpe(new PPE());
        invoice.getPpe().setLocation(new Location());
        invoice.setVolumeEnum(VolumeEnum.KWH);

        invoiceButtons = true;
        priceComponentValues = new ArrayList<InvoicePriceComponentValue>();
    }

    /**
     * On ppe select.
     * 
     * @param ev
     *            the ev
     */
    public void onPPESelect(AjaxBehaviorEvent ev) {
        unselectInvoice();

        for(int i = 0; i < ppeList.size(); i++) {
            if(ppeList.get(i).getPpeId().intValue() == ppeId.intValue()) {
                invoice.setPpe(ppeList.get(i));
                try {

                    ppeList.get(i).setTariff(ppeDao.getActualTariff(ppeList.get(i)));

                    priceComponentValues = new ArrayList<InvoicePriceComponentValue>();

                    List<PriceComponent> priceComponents = invoiceDao.getPPEPriceComponents(ppeList.get(i));
                    if(priceComponents != null)
                        for(PriceComponent pC : priceComponents) {
                            InvoicePriceComponentValue pCv = new InvoicePriceComponentValue();
                            pCv.setPriceComponent(pC);
                            if(pC.isConstant()) {
                                pCv.setAmount(0.0000);
                                pCv.setValue(0.0000);
                            }
                            priceComponentValues.add(pCv);
                        }

                    if(invoice.getVolumeEnum() == null)
                        invoice.setVolumeEnum(VolumeEnum.KWH);

                } catch (Exception e) {
                    e.printStackTrace();
                }
                try {         
                    sample = InvoiceService.getFile(ppeList.get(i).getTariff());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
        }
    }

    /**
     * Invoice add action.
     */
    public void invoiceAddAction() {
        unselectInvoice();
        ppeId = 0;
        invoiceAdd = true;
        isEdit = false;
    }

    /**
     * Invoice add action.
     * 
     * @param ppe
     *            the ppe
     */
    public void invoiceAddAction(PPE ppe) {
        unselectInvoice();
        ppeId = ppe.getPpeId();
        invoiceAdd = true;
        isEdit = false;
        onPPESelect(null);
    }

    /**
     * Invoice edit action.
     */
    public void invoiceEditAction() {
        invoiceAdd = true;
        isEdit = true;
        priceComponentValues = invoice.getInvoicePriceComponentValue();
    }

    /**
     * Checks if is invoice buttons.
     * 
     * @return true, if is invoice buttons
     */
    public boolean isInvoiceButtons() {
        return invoiceButtons;
    }

    /**
     * Sets the invoice buttons.
     * 
     * @param invoiceButtons
     *            the new invoice buttons
     */
    public void setInvoiceButtons(boolean invoiceButtons) {
        this.invoiceButtons = invoiceButtons;
    }

    /**
     * Checks if is invoice add.
     * 
     * @return true, if is invoice add
     */
    public boolean isInvoiceAdd() {
        return invoiceAdd;
    }

    /**
     * Sets the invoice add.
     * 
     * @param invoiceAdd
     *            the new invoice add
     */
    public void setInvoiceAdd(boolean invoiceAdd) {
        this.invoiceAdd = invoiceAdd;
        if(invoiceAdd == false)
            unselectInvoice();
    }

    /**
     * Gets the ppe list.
     * 
     * @return the ppe list
     */
    public List<PPE> getPpeList() {
        return ppeList;
    }

    /**
     * Sets the ppe list.
     * 
     * @param ppeList
     *            the new ppe list
     */
    public void setPpeList(List<PPE> ppeList) {
        this.ppeList = ppeList;
    }

    /**
     * Gets the invoices.
     * 
     * @return the invoices
     */
    public List<Invoice> getInvoices() {
        return invoices;
    }

    /**
     * Sets the invoices.
     * 
     * @param invoices
     *            the new invoices
     */
    public void setInvoices(List<Invoice> invoices) {
        this.invoices = invoices;
    }

    /**
     * Gets the price component values.
     * 
     * @return the price component values
     */
    public List<InvoicePriceComponentValue> getPriceComponentValues() {
        return priceComponentValues;
    }

    /**
     * Sets the price component values.
     * 
     * @param priceComponentValues
     *            the new price component values
     */
    public void setPriceComponentValues(List<InvoicePriceComponentValue> priceComponentValues) {
        this.priceComponentValues = priceComponentValues;
    }

    /**
     * Gets the ppe id.
     * 
     * @return the ppe id
     */
    public Integer getPpeId() {
        return ppeId;
    }

    /**
     * Sets the ppe id.
     * 
     * @param ppeId
     *            the new ppe id
     */
    public void setPpeId(Integer ppeId) {
        this.ppeId = ppeId;
    }

    /**
     * Gets the volumes.
     * 
     * @return the volumes
     */
    public List<VolumeEnum> getVolumes() {
        volumes = new ArrayList<VolumeEnum>();

        for(VolumeEnum a : VolumeEnum.values()) {
            if(a == VolumeEnum.KWH || a == VolumeEnum.MWH) {
                a.setLabel(BundlesUtils.getMessageResourceString("messages", "cloud.volume." + a, null,
                        Locale.getDefault()));
                volumes.add(a);
            }
        }

        return volumes;
    }

    /**
     * Sets the volumes.
     * 
     * @param volumes
     *            the new volumes
     */
    public void setVolumes(List<VolumeEnum> volumes) {
        this.volumes = volumes;
    }

    /**
     * Gets the volume enum.
     * 
     * @return the volume enum
     */
    public VolumeEnum getVolumeEnum() {
        return volumeEnum;
    }

    /**
     * Sets the volume enum.
     * 
     * @param volumeEnum
     *            the new volume enum
     */
    public void setVolumeEnum(VolumeEnum volumeEnum) {
        this.volumeEnum = volumeEnum;
    }

    /**
     * Count price.
     * 
     * @param invoice
     *            the invoice
     * @return the double
     */
    public Double countPrice(Invoice invoice) {
        Double value = 0.0;

        for(InvoicePriceComponentValue iPcV : invoice.getInvoicePriceComponentValue()) {
            // if(iPcV.getAmount() != null)
            value += iPcV.getAmount() * iPcV.getValue();
            // value += iPcV.getValue();
        }

        return value;
    }

    /**
     * Count amount.
     * 
     * @param invoice
     *            the invoice
     * @return the double
     */
    public Double countAmount(Invoice invoice) {
        Double value = 0.0;

        for(InvoicePriceComponentValue iPcV : invoice.getInvoicePriceComponentValue()) {
            // if(iPcV.getAmount() != null)
            if(!iPcV.getPriceComponent().isConstant())
                value += iPcV.getAmount();
            // value += iPcV.getValue();
        }

        return value;
    }

    /**
     * Count amount in kwh.
     * 
     * @param invoice
     *            the invoice
     * @return the double
     */
    public Double countAmountInKwh(Invoice invoice) {
        return countAmount(invoice);
    }

    /**
     * Warning.
     * 
     * @param message_code
     *            the message_code
     * @param args
     *            the args
     */
    @SuppressWarnings({ "deprecation" })
    private void warning(String message_code, String... args) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_WARN,
                BundlesUtils.getMessageResourceString("messages", message_code, args, ectx.getRequestLocale()));
    }

    /**
     * Info.
     * 
     * @param message_code
     *            the message_code
     * @param args
     *            the args
     */
    @SuppressWarnings({ "deprecation" })
    private void info(String message_code, String... args) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_INFO,
                BundlesUtils.getMessageResourceString("messages", message_code, args, ectx.getRequestLocale()));
    }

    /**
     * Gets the sample.
     * 
     * @return the sample
     */
    public String getSample() {
        return sample;
    }

    /**
     * Sets the sample.
     * 
     * @param sample
     *            the new sample
     */
    public void setSample(String sample) {
        this.sample = sample;
    }

    /**
     * Gets the invoice filter.
     * 
     * @return the invoice filter
     */
    public Invoice getInvoiceFilter() {
        return invoiceFilter;
    }

    /**
     * Sets the invoice filter.
     * 
     * @param invoiceFilter
     *            the new invoice filter
     */
    public void setInvoiceFilter(Invoice invoiceFilter) {
        this.invoiceFilter = invoiceFilter;
    }

    /**
     * Gets the today as string.
     * 
     * @return the today as string
     */
    public String getTodayAsString() {
        return DateUtil.outputDate(today, "dd-MM-yyyy");
    }
}