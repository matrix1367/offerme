package pl.op.web.common;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

@Name("op.exceptionBean")
@Scope(ScopeType.SESSION)
public class ExceptionPrinter {
	
	private Date exceptionDate;
	private String message;
	
	
	public Date currentExceptionDate()
	{
		return new Date();
	}
	
	public String printStackTraceException(Throwable e)
	{
	
		StringWriter writer = new StringWriter();
		e.printStackTrace(new PrintWriter(writer));
		message = writer.getBuffer().toString(); 
		
		return message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getExceptionDate() {
		return exceptionDate;
	}

	public void setExceptionDate(Date exceptionDate) {
		this.exceptionDate = exceptionDate;
	}
	
	
}
