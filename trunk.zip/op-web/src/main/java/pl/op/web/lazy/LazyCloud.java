package pl.op.web.lazy;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

import pl.op.dao.CloudDao;
import pl.op.model.cloud.Cloud;
import pl.op.model.cloud.CloudFilter;

public class LazyCloud extends LazyDataModel<Cloud> {

    /**
	 * 
	 */
    private static final long serialVersionUID = -1148534885257596229L;

    private CloudDao cloudDao;
    private CloudFilter cloudFilter;

    public LazyCloud(CloudDao cloudDao, CloudFilter cloudFilter) {
        this.cloudDao = cloudDao;
        this.cloudFilter = cloudFilter;
    }

    @Override
    public List<Cloud> load(int first, int pageSize, String sortField, SortOrder sortOrder, Map<String, String> filters) {
        List<Cloud> clouds = new ArrayList<Cloud>();

        cloudFilter.setFirst(first);
        cloudFilter.setPageSize(pageSize);

        try {
            clouds = cloudDao.getClouds(cloudFilter);

            this.setRowCount(cloudDao.getCloudsCount(cloudFilter));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return clouds;
    }

}
