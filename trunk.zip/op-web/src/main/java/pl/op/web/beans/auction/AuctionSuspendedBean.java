package pl.op.web.beans.auction;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionFilter;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.auction.AuctionStatus;
import pl.op.model.cloud.Cloud;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Tariff;
import pl.op.model.stereotype.Stereotype;
import pl.op.web.common.ComponentLookup;

/**
 * The Class AuctionSuspendedBean.
 */
@Name("op.auctionSuspendedBean")
@Scope(ScopeType.SESSION)
public class AuctionSuspendedBean {

    private Logger log = LoggerFactory.getLogger(AuctionSuspendedBean.class);
    public static final long HOUR = 3600 * 1000;

    private List<Auction> auctions;
    private Auction auction;

    private AuctionBean auctionBean;

    // Filters
    private AuctionFilter auctionFilter;

    private boolean buttonsDisabled = true;

    /**
     * Instantiates a new auction suspended bean.
     */
    public AuctionSuspendedBean() {
        initializeVars();
        initializeFilter();
    }

    /**
     * Initialize vars.
     */
    public void initializeVars() {
        auctionBean = ComponentLookup.lookupComponent("op.auctionBean");
    }

    /**
     * Initialize filter.
     */
    public void initializeFilter() {
        clearFilter();
    }

    /**
     * Clear filter.
     */
    public void clearFilter() {
        auction = new Auction();
        auction.setAuctionOffers(new ArrayList<AuctionOffer>());

        Cloud cloud = new Cloud();
        cloud.setTariff(new Tariff());
        cloud.setStereotype(new Stereotype());
        cloud.setAreas(new ArrayList<Area>());
        cloud.setCities(new ArrayList<City>());
        auction.setCloud(cloud);

        auctionFilter = new AuctionFilter();
        auctionFilter.setAuction(auction);
        auctionFilter.setAuctionAttribute(null);
        auctionFilter.setEndTime(null);
        auctionFilter.setSeller(false);
    }

    /**
     * Search auctions.
     */
    public void searchAuctions() {
        auctionFilter.getAuction().setStatus(AuctionStatus.SUSPENDED);
        auctions = auctionBean.searchAuctions(auctionFilter);
    }

    /**
     * On auction select.
     * 
     * @param event
     *            the event
     */
    public void onAuctionSelect(SelectEvent event) {
        auctionBean.setAuctionComponents(auction);
        buttonsDisabled = false;
    }

    /**
     * Gets the auctions.
     * 
     * @return the auctions
     */
    public List<Auction> getAuctions() {
        return auctions;
    }

    /**
     * Sets the auctions.
     * 
     * @param auctions
     *            the new auctions
     */
    public void setAuctions(List<Auction> auctions) {
        this.auctions = auctions;
    }

    /**
     * Gets the auction.
     * 
     * @return the auction
     */
    public Auction getAuction() {
        return auction;
    }

    /**
     * Sets the auction.
     * 
     * @param auction
     *            the new auction
     */
    public void setAuction(Auction auction) {
        this.auction = auction;
    }

    /**
     * Gets the auction filter.
     * 
     * @return the auction filter
     */
    public AuctionFilter getAuctionFilter() {
        return auctionFilter;
    }

    /**
     * Sets the auction filter.
     * 
     * @param auctionFilter
     *            the new auction filter
     */
    public void setAuctionFilter(AuctionFilter auctionFilter) {
        this.auctionFilter = auctionFilter;
    }

    /**
     * Checks if is buttons disabled.
     * 
     * @return true, if is buttons disabled
     */
    public boolean isButtonsDisabled() {
        return buttonsDisabled;
    }

    /**
     * Sets the buttons disabled.
     * 
     * @param buttonsDisabled
     *            the new buttons disabled
     */
    public void setButtonsDisabled(boolean buttonsDisabled) {
        this.buttonsDisabled = buttonsDisabled;
    }

}