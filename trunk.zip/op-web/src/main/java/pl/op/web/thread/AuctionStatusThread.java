package pl.op.web.thread;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletContext;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.write.Label;
import jxl.write.Number;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import org.apache.velocity.app.VelocityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.ui.velocity.VelocityEngineUtils;
import pl.op.dao.AuctionDao;
import pl.op.dao.CityDao;
import pl.op.dao.PPEDao;
import pl.op.dao.SalesmanDao;
import pl.op.dao.StreetDao;
import pl.op.dao.UserDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionFilter;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.auction.AuctionStatus;
import pl.op.model.auction.AuctionUser;
import pl.op.model.auction.PriceComponentValue;
import pl.op.model.contract.Location;
import pl.op.model.contract.PPE;
import pl.op.model.contract.PPEStatus;
import pl.op.model.salesman.Salesman;
import pl.op.model.user.UserApp;
import pl.op.model.user.UserRole;
import pl.op.rating.SalesmanRating;
import pl.op.web.common.ApplicationContextProvider;
import pl.op.web.common.BundlesUtils;
import pl.op.web.listener.GuiceSingleton;

// TODO: Auto-generated Javadoc
/**
 * The Class AuctionStatusThread.
 */
public class AuctionStatusThread extends Thread {

    /**
     * The log.
     */
    private Logger log = LoggerFactory.getLogger(AuctionStatusThread.class);

    /**
     * The Constant USER_SENDER_NAME.
     */
    private static final String USER_SENDER_NAME = "ogarniamprad";

    /**
     * The sleep.
     */
    private int sleep = 30000;

    /**
     * The auction dao.
     */
    private AuctionDao auctionDao;

    /**
     * The salesmn dao.
     */
    private SalesmanDao salesmanDao;

    /**
     * The user dao.
     */
    private UserDao userDao;

    private PPEDao ppeDo;

    /**
     * The server url.
     */
    public final String SERVER_URL = "serverURL";

    /**
     * The mail sender.
     */
    private JavaMailSenderImpl mailSender;

    /**
     * The velocity engine.
     */
    private VelocityEngine velocityEngine;

    /**
     * The simple message.
     */
    private SimpleMailMessage simpleMessage;

    /**
     * The ectx.
     */
    private ExternalContext ectx;

    /**
     * The faces context.
     */
    private FacesContext facesContext;

    private ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
    private String deploymentDirectoryPath = ctx.getRealPath("/");

    private StreetDao streetDao;

    private CityDao cityDao;

    /**
     * Instantiates a new auction status thread.
     */
    public AuctionStatusThread() {
        auctionDao = GuiceSingleton.getInstance().getInstance(AuctionDao.class);
        salesmanDao = GuiceSingleton.getInstance().getInstance(SalesmanDao.class);
        userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);
        ppeDo = GuiceSingleton.getInstance().getInstance(PPEDao.class);
        streetDao = GuiceSingleton.getInstance().getInstance(StreetDao.class);
        cityDao = GuiceSingleton.getInstance().getInstance(CityDao.class);

        ApplicationContext ctx = ApplicationContextProvider.getApplicationContext();
        mailSender = (JavaMailSenderImpl) ctx.getBean("mailSender");
        velocityEngine = (VelocityEngine) ctx.getBean("velocityEngine");
        simpleMessage = (SimpleMailMessage) ctx.getBean("templateMessage");

        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();

    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Thread#run()
     */
    public void run() {

        while (true) {
            try {
                Thread.sleep(sleep);
                //log.info(">>>>>>> CLOSING AUCTIONS THREAD EXECUTION <<<<<<<");

                AuctionFilter af = new AuctionFilter();
                af.getAuction().setStatus(AuctionStatus.INPROGRESS);
                af.getAuction().setFinishDate(new Date());

                List<Auction> auctions = auctionDao.getAuctionsFull(af);

               // log.info(">>>>>>> AUCTIONS TO BE CLOSED: " + auctions.size());
                for (Auction auction : auctions) {

                    //auction.getAuctionUsers(); - zwraca bledne dane dotyczace ppe uzytkownika // juz nie
                    List<AuctionUser> usersAuction = auction.getAuctionUsers();//  auctionDao.getAuctionUsers(auction); //; //
                    

                   

                    AuctionOffer auctionOffer = auction.getLastOfferForEmail();
                    log.info(">>>>>>> AUCTIONS: " + auction.getAuctionId() + " TO BE CLOSED Last auction offert: " + auctionOffer.getAuctionOfferId());

                    Salesman salesman = auctionOffer.getSalesman();

                    for (AuctionUser userAuction : usersAuction) {
                        if (userAuction.getAuctionUserId() != null) {
                            if (userAuction.getPpe() != null) {
                                log.info("update status ppeid:" + userAuction.getPpe().getPpeId() + " to aimed to agreement");
                                ppeDo.updatePPEStatus(userAuction.getPpe().getPpeId(), PPEStatus.AIMED_TO_AGREEMENT);
                            }

                            String salameName = "Dane niejawne";
                            if (salesman != null) {
                                salameName = salesman.getSalesmanName();
                            }
                            if (userAuction.getUserApp() != null && userAuction.getUserApp().getUserId() != null) {
                                UserApp user = userDao.getUserAppbyId(userAuction.getUserApp().getUserId());

                                if (user.getLogin() != null) {
                                    sendAuctionFinishEmailUsers(userAuction.getUserApp(), auction, salameName);
                                } else {
                                    log.info("ERROR >>>>> sendAuctionFinishEmailUsers login is NULL");
                                }
                            } else {
                                log.info("ERROR >>>>> userAuction.getUserApp().getUserId()  is NULL");
                            }
                        }
                    }

                    List<AuctionOffer> offerts = auction.getAuctionOffers();

                    for (AuctionOffer auctionOffert_it : offerts) {
                        auctionOffert_it.setStatus(AuctionStatus.FINISHED);
                        auctionDao.updateAuctionOffer(auctionOffert_it);
                    }

                    /*
                     INFO: Illegal access: this web application instance has been stopped 
                     already.  Could not load pl/op/web/template/auction_finish_pl.vm.  
                     The eventual following stack trace is caused by an error thrown for 
                     debugging purposes as well as to attempt to terminate the thread which 
                     caused the illegal access, and has no functional impact.

                     WYCZYSC CACHE TOMCATA !!!!
                     */
                    if (salesman != null) {

                        // log.info(">>>>>>>test auctionOffert salesman != null");
//                        if (salesman.getEmail() != null) {
//                            log.info("sending email to salesman: " + salesman.getEmail());
//                            sendAuctionFinishEmail(salesman, auction);
//                        }
                        List<UserApp> users = userDao.getUsersBySalesman(salesman);

                        for (UserApp user : users) {
                            log.info("sending email to user: " + user.getLogin());
                            if (user.getLogin() != null) {
                                sendAuctionFinishEmail(user, auction);
                            } else {
                                log.info("ERROR >>>>> sendAuctionFinishEmail login is NULL");
                            }
                        }
                    }

                    try {
                        UserApp filter = new UserApp();
                        filter.setUserRole(UserRole.operator);
                        filter.setRemoved(Boolean.FALSE);
                        List<UserApp> operatorsList = userDao.getUsers(filter);

                        String raport = prepareRaportForOperator(auction);

                        for (UserApp user : operatorsList) {
                            if (user != null) {
                                //log.info("user is o, id:" + user.getUserId());
                                // log.info("send email to operators " + user.getLogin() );
                                if (user.getLogin() != null) {
                                    sendAuctionFinishEmailOperators(user, auction, raport);
                                } else {
                                    log.info("ERROR >>>>> sendAuctionFinishEmailOperators login is NULL");
                                }
                            } else {
                                log.info("user is null ");
                            }

                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    // wysyłanie email do użytkownikow??? cz aby napewno zdazymy wszystkie wysłać?
                    //może nowy watek??

                }

                auctionDao.closeAuctions();

                SalesmanRating sr = new SalesmanRating(auctionDao, salesmanDao);
                sr.ratingAction();

            } catch (InterruptedException e) {
                log.error("CLOSING AUCTIONS THREAD EXECUTION INTERRUPTED: ", e);
            } catch (Exception e) {
                log.error("CLOSING AUCTIONS THREAD EXECUTION ERROR: ", e);
            } finally {
                try {
                    Thread.sleep(sleep);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    log.error("CLOSING AUCTIONS THREAD SLEEP ERROR: ", e);
                }
            }
        }
    }

    private String prepareRaportForOperator(final Auction auction) throws IOException, WriteException, Exception {
        String raport = "Aukcja : <br><table>";
        raport += "<tr><td></td><td></td></tr>";
        raport += "<tr><td style='width:220px;' >Nazwa</td><td>Wartość</td></tr>";
        raport += "<tr><td>Id aukcji</td><td>" + auction.getAuctionId() + "</td></tr>";
        raport += "<tr><td>Data rozpoczęcia aukcji</td><td>" + auction.getStartDate() + "</td></tr>";
        raport += "<tr><td>Data zakończenia aukcji</td><td>" + auction.getFinishDate() + "</td></tr>";
        raport += "<tr><td>Data rozpoczęcia umowy</td><td>" + auction.getBeginContractDate() + "</td></tr>";
        raport += "<tr><td>Data zakończenia umowy</td><td>" + auction.getEndContractDate() + "</td></tr>";
        raport += "<tr><td></td><td></td></tr>";
        raport += "<tr><td>ID chmury </td><td>" + auction.getCloud().getCloudId() + "</td></tr>";
        raport += "<tr><td>Nazwa chmury </td><td>" + auction.getCloud().getName() + "</td></tr>";
        if (auction.getCloud().getDescription() == null) {
            raport += "<tr><td>Opis chmury </td><td> Brak </td></tr>";
        } else {
            raport += "<tr><td>Opis chmury </td><td>" + auction.getCloud().getDescription() + "</td></tr>";
        }
        raport += "<tr><td>Wolumen chmury </td><td>" + auction.getCloud().getVolume() + "</td></tr>";
        raport += "<tr><td>Taryfa chmury </td><td>" + auction.getCloud().getTariff().getTariffName() + "</td></tr>";

        raport += "<tr><td>Typ firmowy </td><td>" + auction.getCloud().getIsCompany() + "</td></tr>";
        raport += "<tr><td>Typ tworzenia ręcznego </td><td>" + auction.getCloud().getIsManual() + "</td></tr>";
        raport += "</table>";

        AuctionOffer auctionOffer = auction.getLastOfferForEmail();
        List<PriceComponentValue> princeComponentValues = auctionOffer.getPriceComponentValues();
        String tablePrinceComponnent = "<table>";
        for (PriceComponentValue princeComponentValue : princeComponentValues) {
            tablePrinceComponnent += "<tr><td style='width:150px'>" + princeComponentValue.getPriceComponent().getName() + "</td><td style='width:250px'>" + princeComponentValue.getValue() + " PLN</td></tr>";
        }
        tablePrinceComponnent += "</table>";

        raport += "</br></br>Oferta:";
        raport += "<table>";
        raport += "<tr><td>Sprzedawca</td><td>" + auctionOffer.getSalesman().getSalesmanName() + "</td></tr>";
        raport += "<tr><td>Cena</td><td>" + tablePrinceComponnent + "</td></tr>";
        raport += "</table></br></br>";

        boolean noUsers = false;
        raport += "Użytkownicy:";

        List<AuctionUser> usersAuction = auction.getAuctionUsers();
        //List<AuctionUser> usersAuction = auctionDao.getAuctionUsersFull(auction); 
        for (AuctionUser userAuction : usersAuction) {
            if (userAuction.getAuctionUserId() != null && userAuction.getUserApp() != null) {

                //UserApp user = userDao.getUserAppbyId(userAuction.getAuctionUserId());
                UserApp user = userAuction.getUserApp();
                raport += "<table>";
                if (user != null) {
                    if (user.getIsCompany()) {
                        raport += "<tr><td>Login</td><td>" + user.getLogin() + "</td></tr>";
                        raport += "<tr><td>Nazwa</td><td>" + user.getCompanyName() + "</td></tr>";
                        raport += "<tr><td>NIP</td><td>" + user.getNip() + "</td></tr>";
                        raport += "<tr><td>REGON</td><td> " + user.getRegon() + "</td></tr>";
                    } else {
                        raport += "<tr><td>Login</td><td>" + user.getLogin() + "</td></tr>";
                        raport += "<tr><td>PESEL</td><td>" + user.getPesel() + "</td></tr>";
                    }
                }
                if (userAuction.getPpe() != null) {
                    PPE ppe = ppeDo.getPPEById(userAuction.getPpe().getPpeId().longValue());
                    if (ppe != null) {
                        raport += "<tr><td></td><td></td></tr>";
                        raport += "<tr><td>PPE id</td><td>" + ppe.getPpeId() + "</td></tr>";
                        raport += "<tr><td>Nazwa</td><td>" + ppe.getObjectType() + "</td></tr>";
                        raport += "<tr><td>Wolumen</td><td>" + ppe.getValue() + "</td></tr>";
                    }
                    Location location = ppe.getLocation();
                    if (location != null) {
                        raport += "<tr><td>Województwo</td><td>" + location.getStreet().getCity().getArea().getAreaName() + "</td></tr>";
                        raport += "<tr><td>Miasto</td><td>" + location.getStreet().getCity().getCityName() + "</td></tr>";
                        raport += "<tr><td>Ulica</td><td>" + location.getStreet().getStreetName() + "</td></tr>";
                        raport += "<tr><td>Nr mieszkania</td><td>" + location.getHomeNo() + "</td></tr>";
                        raport += "<tr><td>Kod</td><td>" + location.getZipCode() + "</td></tr>";
                    } 
                }
                raport += "</table></br></br>";
            } else {
                noUsers = true;
            }

        }

        if (noUsers) {
            raport += "<table><tr><td>Brak</td></tr>";
        } else {
            raport += "<table><tr><td>Login,PESEL,Nazwa,NIP,REGON,PPE_id,Nazwa,Wolumen,Województwo,Miasto,Ulica,Nr_mieszkania,Kod</td></tr>";
        }
        for (AuctionUser userAuction : usersAuction) {
            if (userAuction.getAuctionUserId() != null) {
                UserApp user = userAuction.getUserApp();
                PPE ppe = ppeDo.getPPEById(userAuction.getPpe().getPpeId().longValue());
                Location location = ppe.getLocation();
                raport += "<tr><td>";
                if (user != null && ppe != null && location != null) {

                    if (user.getIsCompany()) {
                        raport += user.getLogin() + ",brak," + user.getCompanyName() + "," + user.getNip() + "," + user.getRegon() + "," + ppe.getPpeId() + "," + ppe.getObjectType() + "," + ppe.getValue() + "," + location.getStreet().getCity().getArea().getAreaName() + "," + location.getStreet().getCity().getCityName() + "," + location.getStreet().getStreetName() + "," + location.getHomeNo() + "," + location.getZipCode();

                    } else {
                        raport += user.getLogin() + ", " + user.getPesel() + ", brak ,brak,brak," + ppe.getPpeId() + "," + ppe.getObjectType() + "," + ppe.getValue() + "," + location.getStreet().getCity().getArea().getAreaName() + "," + location.getStreet().getCity().getCityName() + "," + location.getStreet().getStreetName() + "," + location.getHomeNo() + "," + location.getZipCode();

                    }
                }
                raport += "</td></tr>";
            }
        }
        raport += "</table>";

//        raport+="<table>";
//        raport +="</table>";
        return raport;
    }

    private void prepareXLSRaportForOperator(final Auction auction) throws IOException, WriteException, Exception {
        File file = new File(deploymentDirectoryPath + "resources/files/raport.xls");

        //OutputStream os = new ByteArrayOutputStream();
        WorkbookSettings wbSettings = new WorkbookSettings();

        wbSettings.setLocale(new Locale("en", "EN"));

        WritableWorkbook workbook = Workbook.createWorkbook(file, wbSettings);
        workbook.createSheet("Report", 0);
        WritableSheet excelSheet = workbook.getSheet(0);
        int row = 0;
        Label idAuctionLabel = new Label(0, row, "ID Aukcji");
        Label DataStartAuctionLabel = new Label(1, row, "Data rozpoczęcia aukcji");
        Label DataStopAuctionLabel = new Label(2, row, "Data zakończenia aukcji");
        Label DataStartUAuctionLabel = new Label(3, row, "Data rozpoczęcia umowy");
        Label DataStopUAuctionLabel = new Label(4, row, "Data zakończenia umowy");
        Label idCloudLabel = new Label(5, row, "ID chmury");
        Label NameCloudLabel = new Label(6, row, "Nazwa chmury");
        Label DescriptionCloudLabel = new Label(7, row, "Opis chmury ");
        Label ValueCloudLabel = new Label(8, row, "Wolumen chmury ");
        Label TarifeCloudLabel = new Label(9, row, "Taryfa chmury ");
        Label isCompanyCloudLabel = new Label(10, row, "Typ firmowy ");
        Label isManualCloudLabel = new Label(11, row, "Typ tworzenia ręcznego ");

        excelSheet.addCell(idAuctionLabel);
        excelSheet.addCell(DataStartAuctionLabel);
        excelSheet.addCell(DataStopAuctionLabel);
        excelSheet.addCell(DataStartUAuctionLabel);
        excelSheet.addCell(DataStopUAuctionLabel);
        excelSheet.addCell(idCloudLabel);
        excelSheet.addCell(NameCloudLabel);
        excelSheet.addCell(DescriptionCloudLabel);
        excelSheet.addCell(ValueCloudLabel);
        excelSheet.addCell(TarifeCloudLabel);
        excelSheet.addCell(isCompanyCloudLabel);
        excelSheet.addCell(isManualCloudLabel);

        row = 1;
        Number idAuctionValue = new Number(0, row, auction.getAuctionId());
        Label DataStartAuctionValue = new Label(1, row, auction.getStartDate().toString());
        Label DataStopAuctionValue = new Label(2, row, auction.getFinishDate().toString());
        Label DataStartUAuctionValue = new Label(3, row, auction.getBeginContractDate().toString());
        Label DataStopUAuctionValue = new Label(4, row, auction.getEndContractDate().toString());
        Number idCloudValue = new Number(5, row, auction.getCloud().getCloudId());
        Label NameCloudValue = new Label(6, row, auction.getCloud().getName());
        Label DescriptionCloudValue = new Label(7, row, auction.getCloud().getDescription());
        Number ValueCloudValue = new Number(8, row, auction.getCloud().getVolume());
        Label TarifeCloudValue = new Label(9, row, auction.getCloud().getTariff().getTariffName());
        Label isCompanyCloudValue = new Label(10, row, auction.getCloud().getIsCompany().toString());
        Label isManualCloudValue = new Label(11, row, auction.getCloud().getIsManual().toString());

        excelSheet.addCell(idAuctionValue);
        excelSheet.addCell(DataStartAuctionValue);
        excelSheet.addCell(DataStopAuctionValue);
        excelSheet.addCell(DataStartUAuctionValue);
        excelSheet.addCell(DataStopUAuctionValue);
        excelSheet.addCell(idCloudValue);
        excelSheet.addCell(NameCloudValue);
        excelSheet.addCell(DescriptionCloudValue);
        excelSheet.addCell(ValueCloudValue);
        excelSheet.addCell(TarifeCloudValue);
        excelSheet.addCell(isCompanyCloudValue);
        excelSheet.addCell(isManualCloudValue);

        row = 3;
        Label SelNameLabel = new Label(0, row, "Sprzedawca");
        excelSheet.addCell(SelNameLabel);

        AuctionOffer auctionOffer = auction.getLastOfferForEmail();
        Label SelNameValue = new Label(0, row + 1, auctionOffer.getSalesman().getSalesmanName());
        excelSheet.addCell(SelNameValue);

        List<PriceComponentValue> princeComponentValues = auctionOffer.getPriceComponentValues();
        int i = 1;
        for (PriceComponentValue princeComponentValue : princeComponentValues) {
            Label princeName = new Label(i, row, princeComponentValue.getPriceComponent().getName());
            excelSheet.addCell(princeName);

            Number prinveValue = new Number(i, row + 1, princeComponentValue.getValue());
            excelSheet.addCell(prinveValue);

            i++;
        }

        row = 6;
        Label LabelLogin = new Label(0, row, "Login");
        Label LabelNazwaFirmy = new Label(1, row, "Nazwa firmy");
        Label LabelNip = new Label(2, row, "Nip");
        Label LabelRegon = new Label(3, row, "Regon");
        Label LabelPesel = new Label(4, row, "PESEL");

        Label LabelPPEId = new Label(5, row, "PPE ID");
        Label LabelNazwaPPe = new Label(6, row, "Nazwa");
        Label LabelWolumen = new Label(7, row, "Wolumen");

        Label LabelArea = new Label(8, row, "Województwo");
        Label LabelCity = new Label(9, row, "Miasto");
        Label Labelstreat = new Label(10, row, "Ulica");
        Label LabelnrHome = new Label(11, row, "Nr Mieszkania");
        Label LabelCode = new Label(12, row, "Kod");

        excelSheet.addCell(LabelLogin);
        excelSheet.addCell(LabelNazwaFirmy);
        excelSheet.addCell(LabelNip);
        excelSheet.addCell(LabelRegon);
        excelSheet.addCell(LabelPesel);

        excelSheet.addCell(LabelPPEId);
        excelSheet.addCell(LabelNazwaPPe);
        excelSheet.addCell(LabelWolumen);

        excelSheet.addCell(LabelArea);
        excelSheet.addCell(LabelCity);
        excelSheet.addCell(Labelstreat);
        excelSheet.addCell(LabelnrHome);
        excelSheet.addCell(LabelCode);

        List<AuctionUser> usersAuction = auction.getAuctionUsers();
        //List<AuctionUser> usersAuction =  auctionDao.getAuctionUsersFull(auction); 
        int countUsers = 7;
        for (AuctionUser userAuction : usersAuction) {
            if (userAuction.getAuctionUserId() != null) {
                UserApp user = userAuction.getUserApp();
                Label ValueLogin = new Label(0, countUsers, user.getLogin());
                Label ValueNazwaFirmy = new Label(1, countUsers, user.getCompanyName());
                Label ValueNip = new Label(2, countUsers, user.getNip());
                Label ValueRegion = new Label(3, countUsers, user.getRegon());
                Label ValuePesel = new Label(4, countUsers, user.getPesel());

                excelSheet.addCell(ValueLogin);
                excelSheet.addCell(ValueNazwaFirmy);
                excelSheet.addCell(ValueNip);
                excelSheet.addCell(ValueRegion);
                excelSheet.addCell(ValuePesel);
            }

            if (userAuction.getPpe() != null) {
            PPE ppe = ppeDo.getPPEById(userAuction.getPpe().getPpeId().longValue());

            if (ppe != null) {
                Number ValuePPEID = new Number(5, countUsers, ppe.getPpeId());
                Label ValueNamePPe = new Label(6, countUsers, ppe.getObjectType());
                Number ValueWolumen = new Number(7, countUsers, ppe.getValue());

                excelSheet.addCell(ValuePPEID);
                excelSheet.addCell(ValueNamePPe);
                excelSheet.addCell(ValueWolumen);
            }

            Location location = ppe.getLocation();
            if (location != null) {
                Label ValueArea = new Label(8, countUsers, location.getStreet().getCity().getArea().getAreaName());
                Label ValueCity = new Label(9, countUsers, location.getStreet().getCity().getCityName());
                Label ValuStreet = new Label(10, countUsers, location.getStreet().getStreetName());
                Label ValueHomeNo = new Label(11, countUsers, location.getHomeNo());
                Label ValueZipCode = new Label(12, countUsers, location.getZipCode());

                excelSheet.addCell(ValueArea);
                excelSheet.addCell(ValueCity);
                excelSheet.addCell(ValuStreet);
                excelSheet.addCell(ValueHomeNo);
                excelSheet.addCell(ValueZipCode);

            }
            } else log.info("excelSheet error, PPE is null");
            countUsers++;
        }

        // createLabel(excelSheet);
        // createContent(excelSheet, auctionId);
        workbook.write();
        workbook.close();

        // InputStream is = new ByteArrayInputStream(((ByteArrayOutputStream) os).toByteArray());
        //StreamedContent file = new DefaultStreamedContent(is, "application/xls", deploymentDirectoryPath + "resources/files/raport.xls");
    }

    public void sendAuctionFinishEmailOperators(final UserApp userApp, final Auction auction, final String raport) {
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {
                MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true);

                message.setFrom(simpleMessage.getFrom(), USER_SENDER_NAME);
                message.setTo(userApp.getLogin());

                Object[] params = new Object[3];
                params[0] = auction.getAuctionId();
                params[1] = System.getProperty(SERVER_URL) + "/op-web";
                params[2] = raport;

                String subject = "Potwierdzenie zakończenia aukcji";

                message.setSubject(subject);

                Map<String, Object> model = new HashMap<String, Object>();
                model.put("auction", auction);
                model.put("url", System.getProperty(SERVER_URL) + "/op-web");
                model.put("raport", raport);

                String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine,
                        "pl/op/web/template/auction_finish_pl_operators.vm", "UTF-8", model);

                prepareXLSRaportForOperator(auction);

                message.addAttachment("raport.xls", new File(deploymentDirectoryPath + "resources/files/raport.xls"));

                message.setText(text, true);
            }
        };
        this.mailSender.send(preparator);
    }

    public void sendAuctionFinishEmailUsers(final UserApp userApp, final Auction auction, final String nameSalame) {
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {
                MimeMessageHelper message = new MimeMessageHelper(mimeMessage);

                message.setFrom(simpleMessage.getFrom(), USER_SENDER_NAME);
                message.setTo(userApp.getLogin());

                AuctionOffer offert = auction.getLastOfferForEmail();

                List<PriceComponentValue> princeComponentValues = offert.getPriceComponentValues();
                String tablePrinceComponnent = "<table>";
                for (PriceComponentValue princeComponentValue : princeComponentValues) {
                    tablePrinceComponnent += "<tr><td style='padding-right:50px'>" + princeComponentValue.getPriceComponent().getName() + "</td><td>" + princeComponentValue.getValue() + "</td></tr>";
                    //log.info (">>>>>>> "+ princeComponentValue.getPriceComponent().getName() + " : " +princeComponentValue.getValue() );

                }
                tablePrinceComponnent += "</table>";

                Object[] params = new Object[4];
                params[0] = auction.getAuctionId();
                params[1] = System.getProperty(SERVER_URL) + "/op-web";
                params[2] = tablePrinceComponnent;
                params[3] = nameSalame;

                String subject = "Potwierdzenie zakończenia aukcji";

                message.setSubject(subject);

                Map<String, Object> model = new HashMap<String, Object>();
                model.put("auction", auction);
                model.put("url", System.getProperty(SERVER_URL) + "/op-web");
                model.put("tablePrinceComponentValues", tablePrinceComponnent);
                model.put("nameSalame", nameSalame);

                String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine,
                        "pl/op/web/template/auction_finish_pl_users.vm", "UTF-8", model);
                message.setText(text, true);
            }
        };
        this.mailSender.send(preparator);
    }

    /**
     * Send auction finish email.
     *
     * @param userApp the user app
     * @param auction the auction
     */
    public void sendAuctionFinishEmail(final UserApp userApp, final Auction auction) {
        try {
            MimeMessagePreparator preparator = new MimeMessagePreparator() {
                public void prepare(MimeMessage mimeMessage) throws Exception {

                    MimeMessageHelper message = new MimeMessageHelper(mimeMessage);

                    message.setFrom(simpleMessage.getFrom(), USER_SENDER_NAME);

                    message.setTo(userApp.getLogin());

                    Object[] params = new Object[2];
                    params[0] = auction.getAuctionId();
                    params[1] = System.getProperty(SERVER_URL) + "/op-web";

                    String subject = "Potwierdzenie zakończenia aukcji";

                    message.setSubject(subject);

                    Map<String, Object> model = new HashMap<String, Object>();

                    model.put("auction", auction);

                    model.put("url", System.getProperty(SERVER_URL) + "/op-web");

                    String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine,
                            "pl/op/web/template/auction_finish_pl.vm", "UTF-8", model);

                    message.setText(text, true);

                }
            };
            this.mailSender.send(preparator);
        } catch (Exception e) {
            log.error("sendAuctionFinishEmail ERROR: ", e);
        }

    }

    /**
     * Send auction finish email.
     *
     * @param salesman the salesman
     * @param auction the auction
     */
    public void sendAuctionFinishEmail(final Salesman salesman, final Auction auction) {
        UserApp user = new UserApp();
        user.setLogin(salesman.getEmail());
        sendAuctionFinishEmail(user, auction);
    }
}
