package pl.op.web.comparator;

import java.util.Comparator;

import pl.op.model.auction.Auction;

public class AuctionByOfferPriceComparator implements Comparator<Auction> {

	private String direction;
	
	public AuctionByOfferPriceComparator(String direction) {
		this.direction = direction;
	}
	
	@Override
	public int compare(Auction auction, Auction auction2) {
		if(direction.equals("ASC")) {
			return compareAsc(auction, auction2);
		}
		
		return compareDesc(auction, auction2);
	}
	
	public int compareAsc(Auction auction, Auction auction2) {
		return getOfferPrice(auction).compareTo(getOfferPrice(auction2));
	}
	
	public int compareDesc(Auction auction, Auction auction2) {
		return getOfferPrice(auction2).compareTo(getOfferPrice(auction));
	}
	
	public Double getOfferPrice(Auction auction) {
		if(auction.isAuctionOffersNotNull()) {
			return auction.getLastOffer().getOfferValue();
		}
		
		return 0.0;
	}
}
