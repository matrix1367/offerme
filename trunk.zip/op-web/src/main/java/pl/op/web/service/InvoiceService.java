package pl.op.web.service;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.model.dict.Tariff;
import pl.op.model.salesman.Salesman;

import pl.op.session.GlobalConstants;

/**
 * The Class InvoiceService.
 */
public class InvoiceService {

    private static Logger log = LoggerFactory.getLogger(InvoiceService.class);

    public final static String UPLOAD_DIR = "../webapps/upload/";

    public final static String INVOICE_DIR = "invoice/";

    /**
     * Gets the file.
     * 
     * @param tariff
     *            - the tariff instance
    
     * @return the file path
     */
    public static String getFile(Tariff tariff) {
        
        String result = "../../images/default.png";
        //String path =  UPLOAD_DIR + INVOICE_DIR;
        
        String path =  "../webapps/op-web/images/upload/invoice/";
        String pathWeb = "../../images/upload/invoice/";
        
        File dir = new File(path);
        dir.mkdir();

        if(tariff == null ||  tariff.getTariffName() == null) {
            log.warn("Tariff not exist: ");
            return result;
        }      
        
        log.info("[InvoiceService::getFile] Taryfa:" + tariff.getTariffName());
        File invoiceFile = new File(path + tariff.getTariffName() + ".png");
        if(invoiceFile.exists()) {          
            return pathWeb + tariff.getTariffName() + ".png";
        } else
        {
            log.warn("file not exist: " + invoiceFile.getAbsolutePath());
        }
         
        invoiceFile = new File(path + tariff.getTariffName() + ".jpg");
        if(invoiceFile.exists()) {
            return pathWeb + tariff.getTariffName() + ".jpg";
        }
        else
        {
            log.warn("file not exist: " + invoiceFile.getAbsolutePath());
        }
        invoiceFile = new File(path + tariff.getTariffName() + ".pdf");
        if(invoiceFile.exists()) {
            return pathWeb + tariff.getTariffName() + ".pdf";
        }
        else
        {
            log.warn("file not exist: " + invoiceFile.getAbsolutePath());
        }

        return result;

    }

}
