package pl.op.web.beans.auction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.PriceComponentDao;
import pl.op.model.auction.PriceComponent;
import pl.op.model.auction.ZoneType;
import pl.op.web.common.BundlesUtils;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class PriceComponentBean.
 */
@Name("op.priceComponentBean")
@Scope(ScopeType.SESSION)
public class PriceComponentBean {

    private Logger log = LoggerFactory.getLogger(PriceComponentBean.class);

    private List<PriceComponent> priceComponentList;
    private List<ZoneType> zoneTypeEnum;
    private String selectedZoneType;
    private Map<String, ZoneType> enumMap;
    private PriceComponent selectedPriceComponent;
    private PriceComponent newPriceComponent;

    private boolean edit;

    private boolean disableShow = true;
    private boolean disableEdit = true;
    private boolean disableRemove = true;

    private PriceComponentDao priceComponentDao;

    /**
     * Instantiates a new price component bean.
     */
    public PriceComponentBean() {
        log.info("PriceComponentBean constructor");
        initialize();
    }

    /**
     * Initialize.
     */
    private void initialize() {
        notAvailableAction();
        priceComponentDao = GuiceSingleton.getInstance().getInstance(PriceComponentDao.class);

        priceComponentList = new ArrayList<PriceComponent>();

        zoneTypeEnum = new ArrayList<ZoneType>();

        enumMap = new HashMap<String, ZoneType>();

        for(ZoneType p : ZoneType.values()) {
            zoneTypeEnum.add(p);

            enumMap.put(p.name(), p);

            log.info("Name : " + p.name());
        }
    }

    // Dictionary PriceComponent
    /**
     * Prepare price component list.
     */
    private void preparePriceComponentList() {
        try {
            priceComponentList = priceComponentDao.getPriceComponent();
        } catch (Exception e) {
            log.error("error while getting priceComponent: ", e);
        }
    }

    /**
     * Refresh price component list.
     */
    public void refreshPriceComponentList() {
        preparePriceComponentList();
    }

    /**
     * Adds the price component.
     * 
     * @return the string
     */
    public String addPriceComponent() {
        edit = false;
        selectedPriceComponent = new PriceComponent();
        newPriceComponent = new PriceComponent();
        selectedZoneType = "";
        return "priceComponent";
    }

    /**
     * Cancel add price component.
     * 
     * @return the string
     */
    public String cancelAddPriceComponent() {
        notAvailableAction();
        return "dictionaries";
    }

    /**
     * Save price component.
     * 
     * @return the string
     */
    public String savePriceComponent() {
        newPriceComponent.setZoneType(enumMap.get(selectedZoneType));

        try {
            if(edit) {
                priceComponentDao.updatePriceComponent(selectedPriceComponent);
            } else {
                /*
                	private Integer priceComponentId;
	private String currency;
	private String description;
	private boolean isConstant;
	private String name;
	private ZoneType zoneType;
	private Boolean removed;
                */
                log.info("name" + newPriceComponent.getName());
                log.info("desc" + newPriceComponent.getDescription());
                log.info("currenty" + newPriceComponent.getCurrency());
                log.info("cost" + newPriceComponent.isConstant());
                log.info("zonetype" + newPriceComponent.getZoneType());
                priceComponentDao.savePriceComponent(newPriceComponent);
            }
        } catch (Exception e) {
            log.error("Error while savePriceComponent: ", e);
        }
        preparePriceComponentList();
        return "dictionaries";
    }

    /**
     * Delete price component.
     */
    public void deletePriceComponent() {
        try {
            priceComponentDao.deletePriceComponent(selectedPriceComponent);
        } catch (Exception e) {
            log.error("Error while deletePriceComponent: ", e);
        }
        preparePriceComponentList();
        notAvailableAction();
    }

    /**
     * Edits the pricecomponent.
     * 
     * @return the string
     */
    public String editPricecomponent() {
        edit = true;
        newPriceComponent = selectedPriceComponent;

        selectedZoneType = BundlesUtils.getMessageResourceString("messages", "dictionaries.zone.type."
                + selectedPriceComponent.getZoneType().name(), null, Locale.getDefault());

        log.info("Selected PriceComponent Type : " + selectedZoneType);

        return "priceComponent";
    }

    /**
     * On row select dictionaries list.
     * 
     * @param event
     *            the event
     */
    public void onRowSelectDictionariesList(SelectEvent event) {
        availableAction();
    }

    /**
     * On row unselect dictionaries list.
     * 
     * @param event
     *            the event
     */
    public void onRowUnselectDictionariesList(UnselectEvent event) {
        notAvailableAction();
    }

    /**
     * Available action.
     */
    public void availableAction() {
        disableShow = false;
        disableEdit = false;
        disableRemove = false;
    }

    /**
     * Not available action.
     */
    public void notAvailableAction() {
        selectedPriceComponent = new PriceComponent();

        disableShow = true;
        disableEdit = true;
        disableRemove = true;
    }

    /**
     * Gets the new price component.
     * 
     * @return the new price component
     */
    public PriceComponent getNewPriceComponent() {
        return newPriceComponent;
    }

    /**
     * Sets the new price component.
     * 
     * @param newPriceComponent
     *            the new new price component
     */
    public void setNewPriceComponent(PriceComponent newPriceComponent) {
        this.newPriceComponent = newPriceComponent;
    }

    /**
     * Gets the selected price component.
     * 
     * @return the selected price component
     */
    public PriceComponent getSelectedPriceComponent() {
        return selectedPriceComponent;
    }

    /**
     * Sets the selected price component.
     * 
     * @param selectedPriceComponent
     *            the new selected price component
     */
    public void setSelectedPriceComponent(PriceComponent selectedPriceComponent) {
        this.selectedPriceComponent = selectedPriceComponent;
    }

    /**
     * Gets the price component list.
     * 
     * @return the price component list
     */
    public List<PriceComponent> getPriceComponentList() {
        return priceComponentList;
    }

    /**
     * Sets the price component list.
     * 
     * @param priceComponentList
     *            the new price component list
     */
    public void setPriceComponentList(List<PriceComponent> priceComponentList) {
        this.priceComponentList = priceComponentList;
    }

    /**
     * Checks if is disable show.
     * 
     * @return true, if is disable show
     */
    public boolean isDisableShow() {
        return disableShow;
    }

    /**
     * Sets the disable show.
     * 
     * @param disableShow
     *            the new disable show
     */
    public void setDisableShow(boolean disableShow) {
        this.disableShow = disableShow;
    }

    /**
     * Checks if is disable edit.
     * 
     * @return true, if is disable edit
     */
    public boolean isDisableEdit() {
        return disableEdit;
    }

    /**
     * Sets the disable edit.
     * 
     * @param disableEdit
     *            the new disable edit
     */
    public void setDisableEdit(boolean disableEdit) {
        this.disableEdit = disableEdit;
    }

    /**
     * Checks if is disable remove.
     * 
     * @return true, if is disable remove
     */
    public boolean isDisableRemove() {
        return disableRemove;
    }

    /**
     * Sets the disable remove.
     * 
     * @param disableRemove
     *            the new disable remove
     */
    public void setDisableRemove(boolean disableRemove) {
        this.disableRemove = disableRemove;
    }

    /**
     * Gets the selected zone type.
     * 
     * @return the selected zone type
     */
    public String getSelectedZoneType() {
        return selectedZoneType;
    }

    /**
     * Sets the selected zone type.
     * 
     * @param selectedZoneType
     *            the new selected zone type
     */
    public void setSelectedZoneType(String selectedZoneType) {
        this.selectedZoneType = selectedZoneType;
    }

    /**
     * Gets the zone type enum.
     * 
     * @return the zone type enum
     */
    public List<ZoneType> getZoneTypeEnum() {
        return zoneTypeEnum;
    }

    /**
     * Sets the zone type enum.
     * 
     * @param zoneTypeEnum
     *            the new zone type enum
     */
    public void setZoneTypeEnum(List<ZoneType> zoneTypeEnum) {
        this.zoneTypeEnum = zoneTypeEnum;
    }

    /**
     * Gets the enum map.
     * 
     * @return the enum map
     */
    public Map<String, ZoneType> getEnumMap() {
        return enumMap;
    }

    /**
     * Sets the enum map.
     * 
     * @param enumMap
     *            the enum map
     */
    public void setEnumMap(Map<String, ZoneType> enumMap) {
        this.enumMap = enumMap;
    }

}
