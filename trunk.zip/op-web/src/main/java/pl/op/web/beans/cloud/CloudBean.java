package pl.op.web.beans.cloud;

import com.sun.org.apache.bcel.internal.generic.L2D;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.primefaces.model.DualListModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AreaDao;
import pl.op.dao.CityDao;
import pl.op.dao.CloudDao;
import pl.op.dao.PPEDao;
import pl.op.dao.SalesmanDao;
import pl.op.dao.SectorDao;
import pl.op.dao.StereotypeDao;
import pl.op.dao.StreetDao;
import pl.op.dao.UserDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.ZoneType;
import pl.op.model.cloud.Cloud;
import pl.op.model.cloud.CloudFilter;
import pl.op.model.cloud.CloudVolume;
import pl.op.model.cloud.VolumeEnum;
import pl.op.model.contract.Location;
import pl.op.model.contract.PPE;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Street;
import pl.op.model.dict.Tariff;
import pl.op.model.salesman.Salesman;
import pl.op.model.stereotype.Sector;
import pl.op.model.stereotype.Stereotype;
import pl.op.model.user.UserApp;
import pl.op.util.CloudUtil;
import pl.op.util.DictUtil;
import pl.op.util.LocationUtil;
import pl.op.util.PpeUtil;
import pl.op.web.beans.AdminBean;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.beans.log.SalesmanBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;
import pl.op.web.service.BonusService;

/**
 * The Class CloudBean.
 */
@Name("op.cloudBean")
@Scope(ScopeType.SESSION)
public class CloudBean implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private Logger log = LoggerFactory.getLogger(CloudBean.class);

    private FacesContext facesContext;
    private ExternalContext ectx;

    private boolean buttonDisabled = true;
    private boolean buttonMultiDisabled = true;
    private boolean buttonDeleteUsers = true;
    private boolean streetDisabled = true;
    private boolean userButtons = true;
    private boolean cloudCompare = false;
    private boolean locationSaved = false;
    private boolean galleryView = false;

    private Cloud cloud;
    private Cloud selectedCloud;
    private UserApp user;

    private List<Cloud> clouds;
    private List<City> cities;
    private List<Area> areas;
    private List<Street> streets;
    private List<Tariff> tariffs;
    private List<Stereotype> stereotypes;
    private List<Salesman> salesmans;
    private List<VolumeEnum> volumes;
    private List<PPE> ppeList = new ArrayList<PPE>();
    private DualListModel<City> dualCities = new DualListModel<City>();
    private DualListModel<Area> dualAreas = new DualListModel<Area>();
    private List<Area> cloudAreas = new ArrayList<Area>();
    private DualListModel<UserApp> dualUsers = new DualListModel<UserApp>();
    //kreator chmury
    private DualListModel<UserApp> dualUsersCloudCreator = new DualListModel<UserApp>();
    private List<UserApp> usersCloudCreator = new ArrayList<UserApp>();
    //kreator chmury
    private List<String> cloudStreets;
    private List<Sector> sectors;
    private List<ZoneType> zoneType;
    private Sector sector;
    private List<UserApp> potentialUsers;
    private Map<ZoneType, Double> detailsMap;
    private CloudDao cloudDao;
    private StereotypeDao stereotypeDao;
    private SalesmanDao salesmanDao;
    private UserDao userDao;
    private SectorDao sectorDao;
    private CityDao cityDao;
    private StreetDao streetDao;
    private AreaDao areaDao;

    private Cloud[] cloudsMulti;
    private UserApp[] selectedUsers;

    // Filters
    private CloudFilter cloudFilter = new CloudFilter();

    Integer areasSize = 0;
    Integer citiesSize = 0;
    private String streetName;
    private String cityName;
    private String cityAreaName;

    // cloud creator location vars
    private String locationCreatorCloudType = "many_area";
    private boolean locationCreatorType1Rendered = true;
    private boolean locationCreatorType2Rendered = false;
    private boolean locationCreatorType3Rendered = false;
    private Integer locationCreatorAreaId;
    private Integer locationCreatorCityId;
    private String locationCreatorStreetName;

    @In(value = "#{op.adminBean}", scope = ScopeType.SESSION, required = true)
    private AdminBean adminBean;

    private DictionaryBean dictionaryBean;

    /**
     * Instantiates a new cloud bean.
     */
    public CloudBean() {
        log.info("CloudBean constructor");
        initializeDao();
        initializeVars();
    }

    /**
     * Initialize dao.
     */
    private void initializeDao() {
        log.info("initializeDao");

        cityDao = GuiceSingleton.getInstance().getInstance(CityDao.class);
        streetDao = GuiceSingleton.getInstance().getInstance(StreetDao.class);
        cloudDao = GuiceSingleton.getInstance().getInstance(CloudDao.class);
        stereotypeDao = GuiceSingleton.getInstance().getInstance(StereotypeDao.class);
        salesmanDao = GuiceSingleton.getInstance().getInstance(SalesmanDao.class);
        userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);
        sectorDao = GuiceSingleton.getInstance().getInstance(SectorDao.class);
        areaDao = GuiceSingleton.getInstance().getInstance(AreaDao.class);
    }

    /**
     * Initialize vars.
     */
    private void initializeVars() {
        log.info("initializeVars");

        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();

        dictionaryBean = ComponentLookup.lookupComponent("op.dictionaryBean");
        cloudFilter = new CloudFilter();
    }

    /**
     * Initialize on load.
     */
    public void initializeOnLoad() {
        log.info("initializeOnLoad");

        try {
            if (!isInitializedDicts()) {
                initializeDicts();
            }

            tariffs = dictionaryBean.getTariffsList();
            salesmans = salesmanDao.getAllSalesmans();
            sectors = sectorDao.getSector();
            stereotypes = stereotypeDao.getStereotypes(new Sector());

            clearFilter();
            clearCloud();
            clearSelectedCloud();

            searchClouds();
        } catch (Exception e) {
            log.info("Problem while initilialice cloudBean on load: ", e);
        }
    }

    /**
     * Checks if is initialized dicts.
     *
     * @return true, if is initialized dicts
     */
    public boolean isInitializedDicts() {
        log.info("isInitializedDicts");
        if (areas == null || cities == null || streets == null) {
            return false;
        }

        if (areas.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Initialize dicts.
     *
     * @throws Exception the exception
     */
    private void initializeDicts() throws Exception {
        log.info("initializeDicts");

        areas = dictionaryBean.getAreasList();
        cities = new ArrayList<City>();
        streets = new ArrayList<Street>();
    }

    /**
     * Clear filter.
     */
    public void clearFilter() {
        cloudFilter = new CloudFilter();

        Cloud tempCloud = new Cloud();
        tempCloud.setStereotype(new Stereotype());
        tempCloud.setTariff(new Tariff());
        tempCloud.setAreas(new ArrayList<Area>());
        tempCloud.setCities(new ArrayList<City>());
        tempCloud.setStreets(new ArrayList<Street>());
        tempCloud.setSalesman(new Salesman());

        cityName = "";
        streetName = "";

        cloudFilter.setCloud(tempCloud);

    }

    /**
     * Clear cloud.
     */
    public void clearCloud() {
        cloud = new Cloud();
        cloud.setStereotype(new Stereotype());
        cloud.setTariff(new Tariff());
        cloud.setAreas(new ArrayList<Area>());
        cloud.setCities(new ArrayList<City>());
        cloud.setStreets(new ArrayList<Street>());
        cloud.setSalesman(new Salesman());
        cloud.setIsCompany(false);
        cloud.setUsers(new ArrayList<UserApp>());
        user = new UserApp();

        dualAreas = new DualListModel<Area>(areas, new ArrayList<Area>());
        cloudAreas = new ArrayList<Area>();
        dualCities = new DualListModel<City>(cities, new ArrayList<City>());
        cloudStreets = new ArrayList<String>();
        streetName = "";
        cityName = "";

        sector = new Sector();

        dualUsersCloudCreator = new DualListModel<UserApp>();
        usersCloudCreator = new ArrayList<UserApp>();
    }

    /**
     * Clear selected cloud.
     */
    public void clearSelectedCloud() {
        selectedCloud = new Cloud();
        selectedCloud.setStereotype(new Stereotype());
        selectedCloud.setTariff(new Tariff());
        selectedCloud.setAreas(new ArrayList<Area>());
        selectedCloud.setCities(new ArrayList<City>());
        selectedCloud.setStreets(new ArrayList<Street>());
        selectedCloud.setSalesman(new Salesman());
        selectedCloud.setIsCompany(false);
        selectedCloud.setUsers(new ArrayList<UserApp>());

        cloudCompare = false;
    }

    /**
     * Clear clouds multi.
     */
    public void clearCloudsMulti() {
        cloudsMulti = new Cloud[0];
    }

    /**
     * Search clouds.
     */
    public void searchClouds() {
        clearSelectedCloud();
        clearCloudsMulti();
        prepareCloudButtons();
        try {
            if (null == cloudFilter) {
                clearFilter();
            }

            if (!"".equals(cityName) && null != cityName) {
                if (null == cloudFilter.getCity()) {
                    cloudFilter.setCity(new City());
                    cloudFilter.getCity().setCityId(0);
                }
            } else {
                cloudFilter.setCity(new City());
            }

            if (!"".equals(streetName) && null != streetName) {
                cloudFilter.setStreet(LocationUtil.getStreet(streetName, cloudFilter.getCity(), cloudFilter.getArea()));

                if (null == cloudFilter.getStreet()) {
                    cloudFilter.setStreet(new Street());
                    cloudFilter.getStreet().setStreetId(0);
                }
            } else {
                cloudFilter.setStreet(new Street());
            }

            clouds = cloudDao.getClouds(cloudFilter);
            if (isCloudsInList(clouds)) {
                log.info("find " + clouds.size() + " clouds");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Checks if is clouds in list.
     *
     * @param clouds the clouds
     * @return true, if is clouds in list
     */
    private boolean isCloudsInList(List<Cloud> clouds) {
        if (clouds == null) {
            return false;
        }

        if (clouds.isEmpty()) {
            return false;
        }

        if (clouds.size() == 1) {
            if (clouds.get(0).getCloudId() == null) {
                return false;
            }
        }

        return true;
    }

    public void saveUsersCloud() {
        usersCloudCreator.clear();
        usersCloudCreator.addAll(dualUsersCloudCreator.getSource());
        //    cloud.setUsers(dualUsersCloudCreator.getSource());
    }

    public String FindUserForCloud() {
        log.info("[TestCloud]");
        RequestContext context = RequestContext.getCurrentInstance();
        try {
            if (cloudAreas.size() == 0) {
                info("warning.area.required");
                return "";
            }
            //location
            cloud.setAreas(cloudAreas);

//            CloudFilter cF = new CloudFilter();
//            cF.setCloud(cloud);
//            log.info("cloudTariff: " + cF.getCloud().getTariff());
//            log.info("cloudStereotype: " + cF.getCloud().getStereotype());
//            List<Cloud> similarCloud = cloudDao.getClouds(cF);
//            if(similarCloud != null) {
//                if(similarCloud.size() > 0) {
//                    context.execute("cloudExistsDlg.show()");
//                    return "";
//                }
//            }
            cloud.setCreationDate(new Date());
            cloud.setIsManual(true);
          

            List<UserApp> matchedUsers = userDao.getUsersMatchToCloud(cloud);
            log.info("Find :" + matchedUsers.size() + " users");

            dualUsersCloudCreator.setSource(matchedUsers);
            dualUsersCloudCreator.setTarget(new ArrayList<UserApp>());

            usersCloudCreator.clear();
            usersCloudCreator.addAll(matchedUsers);

           //  log.info("Find :"+ matchedUsers.size() + " users");
            //  cloud.setUsers(matchedUsers);
            //cloudDao.saveCloud(cloud);
            //cloud.genereateName();
            // cloudDao.updateCloud(cloud);
          //  BonusService.run("createCloud", adminBean.getUserLog());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public void TestCreateCloud() {
        log.info(">>>>>><<<<<<<TestCreateCloud>>>>>><<<<<<<<<<<");
        List<Area> areasTest = dualAreas.getTarget();
        for (Area area : areasTest) {
            log.info(">>>>>><<<<<<<>>>>>><<<<<<<<<<<");
            log.info("TestArea name:" + area.getAreaName());
            log.info("TestArea id:" + area.getAreaId());
        }
        for (Area area : cloudAreas) {
            log.info(">>>>>><<<<<<<>>>>>><<<<<<<<<<<");
            log.info("TestArea cloudAreas name:" + area.getAreaName());
            log.info("TestArea  cloudAreas id:" + area.getAreaId());
        }
    }

    /**
     * Save cloud.
     *
     * @return the string
     */
    public String saveCloud() {
        log.info("[saveCloud]");
        RequestContext context = RequestContext.getCurrentInstance();
        try {
            if (cloudAreas.isEmpty()) {
                info("warning.area.required");   //Województwo jest wymagane\!
                return "";
            }

//            List<Street> streetsSave = new ArrayList<Street>();
//            for(String s : cloudStreets) {
//                City city = new City();
//                city.setCloudId(locationCreatorCityId);
//                Street street = new Street();
//                street.setStreetName(s);
//                street.setCity(city);
//                Street checkStreet = streetDao.getStreet(street);
//                if(checkStreet == null) {
//                    streetDao.saveStreet(street);
//                    streetsSave.add(street);
//                } else {
//                    streetsSave.add(checkStreet);
//                }
//            }
            cloud.setAreas(cloudAreas);
//            cloud.setCities(dualCities.getTarget());
//            cloud.setStreets(streetsSave);
            
            //wyłączenie sprawdzania chmury
            /*
            CloudFilter cF = new CloudFilter();
            cF.setCloud(cloud);
            log.info("cloudTariff: " + cF.getCloud().getTariff());
            log.info("cloudStereotype: " + cF.getCloud().getStereotype());
            List<Cloud> similarCloud = cloudDao.getClouds(cF);
            if (similarCloud != null) {
                if (similarCloud.size() > 0) {
                    context.execute("cloudExistsDlg.show()");
                    return "";
                }
            }
            */
            cloud.setCreationDate(new Date());
            cloud.setIsManual(true);
            cloud.setVolume(0.0);
            cloudDao.saveCloud(cloud); //jeżeli area w chmurzej jest ustawoiona to arrea zostana zapisane

            //generowanie nazwy chmur i zapis nazwy
            cloud.genereateName();
            cloudDao.updateCloud(cloud);

            cloud.setUsers(new ArrayList<UserApp>()); //czyszczenie chmury z mozliwych uzytkownikow

            for (UserApp userFor : usersCloudCreator) {
                assignUserToCloud(cloud, userFor);
            }

            //wyliczenie wolumenu                        
            // assignUsers();
            cloud.setUsers(usersCloudCreator);

            for (UserApp user : cloud.getUsers()) {
                //user.setCloudId(cloud.getCloudId());
                //cloudDao.saveUserCloud(user);
                log.info("Add user(#" + user.getUserId() + ") to cloud #" + cloud.getCloudId());
            }
              log.info(cloud.toString());
              
            if (cloud.getStereotype() == null || cloud.getStereotype().getStereotypeId() == null)             
            CloudUtil.updateCloudVolumeByManual(cloud.getCloudId());
            else
            CloudUtil.updateCloudVolume(cloud.getCloudId());

            BonusService.run("createCloud", adminBean.getUserLog());

        } catch (Exception e) {
            e.printStackTrace();
        }

        //context.execute("cloudSaveDlg.show()");
        info("message.cloud.added");

        return "";
    }

    /**
     * Cloud save message.
     *
     * @return the string
     */
    public String cloudSaveMessage() {
        Object[] param = new Object[1];
        param[0] = cloud.getName();

        return BundlesUtils.getMessageResourceString("messages", "cloud.save.message", param, Locale.getDefault());
    }

    /**
     * Clouds count.
     *
     * @return the integer
     */
    public Integer cloudsCount() {
        Integer cloudsCount = null;

        try {
            cloudsCount = cloudDao.getCloudsCount();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return cloudsCount;
    }

    /**
     * Change street state.
     */
    public void changeStreetState() {
        if (cloud.getCities() != null) {
            streetDisabled = false;
        } else {
            streetDisabled = true;
        }
    }

    /**
     * Adds the street.
     */
    public void addStreet() {
        if (locationCreatorStreetName != null) {
            cloudStreets.add(locationCreatorStreetName);
            locationCreatorStreetName = "";
        }
    }

    /**
     * Cloud exists action.
     *
     * @return the string
     */
    public String cloudExistsAction() {
        cloudFilter.setCloud(cloud);
        return "clouds";
    }

    /**
     * Assign users.
     */
    public void assignUsers() {
        log.info("assignUsers");

        try {
            Integer cloudUserCount = 0;
            if (cloud.getUsers() != null) {
                cloudUserCount = cloud.getUsers().size();
            }

            log.info("Search matched user to cloud # " + cloud.getCloudId());
            List<UserApp> matchedUsers = userDao.getUsersMatchToCloud(cloud);

            if (!matchedUsers.isEmpty()) {
                log.info("Find " + matchedUsers.size() + " matched user to cloud # " + cloud.getCloudId());
                cloudUserCount += matchedUsers.size();

                cloud.setUsers(matchedUsers);

                for (UserApp user : cloud.getUsers()) {
                    user.setCloudId(cloud.getCloudId());
                    cloudDao.saveUserCloud(user);
                    log.info("Add user(#" + user.getUserId() + ") to cloud #" + cloud.getCloudId());
                }

                CloudUtil.updateCloudVolumeByManual(cloud.getCloudId());

            } else {
                log.info("Find 0 matched user to cloud # " + cloud.getCloudId());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Assign user to cloud.
     *
     * @param cloud the cloud
     * @param user the user
     */
    public void assignUserToCloud(Cloud cloud, UserApp user) {
        log.info("[assignUserToCloud]");
        try {
            Integer cloudUserCount = 0;
            if (cloud.getUsers() != null) {
                if (!cloud.getUsers().isEmpty()) {
                    cloudUserCount = cloud.getUsers().size();
                    if (isUserInCloud(cloud, user)) {
                        log.info("user is in cloud");
                        return;
                    }
                }
            }

            log.info("actual cloud #" + cloud.getCloudId() + " memnerNo: " + cloudUserCount);

            cloudUserCount++;

            user.setCloudId(cloud.getCloudId());
            log.info("Add user(#" + user.getUserId() + ") to cloud #" + cloud.getCloudId());
            cloudDao.saveUserCloud(user);
            log.info("User added");

            log.info("Update cloud #" + cloud.getCloudId() + " number user to " + cloudUserCount);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Checks if is user in cloud.
     *
     * @param cloud the cloud
     * @param user the user
     * @return true, if is user in cloud
     */
    private boolean isUserInCloud(Cloud cloud, UserApp user) {
        for (UserApp cloudUser : cloud.getUsers()) {
            if (cloudUser.getUserId().intValue() == user.getUserId().intValue()) {
                return true;
            }
        }

        return false;
    }

    /**
     * User assign message.
     *
     * @return the string
     */
    public String userAssignMessage() {
        Object[] param = new Object[1];
        param[0] = cloud.getUsers().size();

        return BundlesUtils.getMessageResourceString("messages", "cloud.users.message", param, Locale.getDefault());
    }

    /**
     * On cloud select.
     *
     * @param event the event
     */
    public void onCloudSelect(SelectEvent event) {
        clearSelectedCloud();

        prepareCloudButtons();
    }

    /**
     * On cloud unselect.
     *
     * @param event the event
     */
    public void onCloudUnselect(UnselectEvent event) {
        prepareCloudButtons();
    }

    /**
     * Prepare cloud buttons.
     */
    private void prepareCloudButtons() {
        switch (cloudsMulti.length) {
            case 1:
                buttonDisabled = false;
                buttonMultiDisabled = true;
                selectedCloud = cloudsMulti[0];
                break;
            case 2:
                buttonDisabled = true;
                buttonMultiDisabled = false;
                break;
            default:
                buttonDisabled = true;
                buttonMultiDisabled = true;
                break;
        }
    }

    /**
     * On user select.
     *
     * @param event the event
     */
    public void onUserSelect(SelectEvent event) {
        if (selectedUsers.length >= 1) {
            buttonDeleteUsers = false;
        }
    }

    /**
     * On user unselect.
     *
     * @param event the event
     */
    public void onUserUnselect(UnselectEvent event) {
        if (selectedUsers.length == 0) {
            buttonDeleteUsers = true;
        }
    }

    public void refresDualAreas() {
        log.info(">>>>> refresDualAreas <<<<<<<<");
        dualAreas.setTarget(cloudAreas);
    }

    /**
     * Save cloud location.
     */
    public void saveCloudLocation() {
        locationSaved = true;
        cloudAreas.clear();
        cloudAreas.addAll(dualAreas.getTarget());
        addLocation();
        setLocationCreatorCloudType("many_area");
    }

    /**
     * Back to clouds.
     *
     * @return the string
     */
    public String backToClouds() {
        searchClouds();

        return "clouds";
    }

    /**
     * Delete users from cloud.
     *
     * @return the string
     */
    public String deleteUsersFromCloud() {

        List<UserApp> list = new ArrayList<UserApp>();

        for (int i = 0; i < selectedUsers.length; i++) {
            list.add(selectedUsers[i]);
        }

        try {
            cloudDao.deleteCloudUsersBatch(selectedCloud, list);
            selectedCloud.setUsers(cloudDao.getUsersForCloud(selectedCloud));
        } catch (Exception e) {
            log.error("Problem while delete user from cloud: ", e);
        }

        return "";
    }

    /**
     * Metoda zwraca aktualną instancje salesmanBean. Metoda używana do
     * zawężenia podpowiadania nazw ulic
     *
     * @return SalesmanBean|null
     */
    public SalesmanBean getActualSalesmanBean() {
        FacesContext ctx = FacesContext.getCurrentInstance();
        return (SalesmanBean) ctx.getApplication().getELResolver()
                .getValue(ctx.getELContext(), null, "op.salesmanBean");
    }

    /**
     * Autocomplete city.
     *
     * @param query the query
     * @return the list
     */
    public List<String> autocompleteCity(String query) {
        SalesmanBean salesmanBean = getActualSalesmanBean();
        return LocationUtil.autoCompleteCity(query, salesmanBean.getAreaId());
    }

    /**
     * Autocomplete street.
     *
     * @param query the query
     * @return the list
     */
    public List<String> autocompleteStreet(String query) {
        return LocationUtil.autoCompleteStreet(query, locationCreatorCityId);
    }

    /**
     * Checks if is button disabled.
     *
     * @return true, if is button disabled
     */
    public boolean isButtonDisabled() {
        return buttonDisabled;
    }

    /**
     * Sets the button disabled.
     *
     * @param buttonDisabled the new button disabled
     */
    public void setButtonDisabled(boolean buttonDisabled) {
        this.buttonDisabled = buttonDisabled;
    }

    /**
     * Gets the clouds.
     *
     * @return the clouds
     */
    public List<Cloud> getClouds() {
        return clouds;
    }

    /**
     * Sets the clouds.
     *
     * @param clouds the new clouds
     */
    public void setClouds(List<Cloud> clouds) {
        this.clouds = clouds;
    }

    /**
     * Gets the cloud.
     *
     * @return the cloud
     */
    public Cloud getCloud() {
        return cloud;
    }

    /**
     * Sets the cloud.
     *
     * @param cloud the new cloud
     */
    public void setCloud(Cloud cloud) {
        this.cloud = cloud;
    }

    /**
     * Gets the cities.
     *
     * @return the cities
     */
    public List<City> getCities() {
        log.info("[getCities]");
        if (cloudFilter.getCloud().getAreas() != null) {
            try {
                // TODO: trzeba zmienić pod większą ilość area
                // cities = dictionaryDao.getCitiesByArea(cloudFilter.getCloud()
                // .getArea());

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (selectedCloud.getAreas() != null) {
            try {
                // TODO: trzeba zmienić pod większą ilość area
                // cities = dictionaryDao.getCitiesByArea(cloud.getArea());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (locationCreatorAreaId != null) {
            log.info("locationCreatorAreaId: " + locationCreatorAreaId);
            cities = new ArrayList<City>();
            City city = new City();
            city.setHasStatus(true);
            city.setAreaId(locationCreatorAreaId);
            try {
                cities = cityDao.searchCities(city);
            } catch (Exception e) {
                e.printStackTrace();
            }
            log.info("cities size: " + cities.size());
        }

        return cities;
    }

    /**
     * Sets the cities.
     *
     * @param cities the new cities
     */
    public void setCities(List<City> cities) {
        this.cities = cities;
    }

    /**
     * Gets the areas.
     *
     * @return the areas
     */
    public List<Area> getAreas() {
        return areas;
    }

    /**
     * Sets the areas.
     *
     * @param areas the new areas
     */
    public void setAreas(List<Area> areas) {
        this.areas = areas;
    }

    /**
     * Gets the cloud filter.
     *
     * @return the cloud filter
     */
    public CloudFilter getCloudFilter() {
        return cloudFilter;
    }

    /**
     * Sets the cloud filter.
     *
     * @param cloudFilter the new cloud filter
     */
    public void setCloudFilter(CloudFilter cloudFilter) {
        this.cloudFilter = cloudFilter;
    }

    /**
     * Gets the streets.
     *
     * @return the streets
     */
    public List<Street> getStreets() {
        // TODO: czy na pewno chcemy aby uzupełniać this.streets?
        if (cloudFilter.getCloud().getCities() != null) {
            try {
                for (int i = 0; i < cloudFilter.getCloud().getCities().size(); i++) {
                    City city = cloudFilter.getCloud().getCities().get(i);
                    Street street = new Street();
                    street.setCity(city);
                    streets.addAll(streetDao.getStreets(street));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return streets;
    }

    /**
     * Sets the streets.
     *
     * @param streets the new streets
     */
    public void setStreets(List<Street> streets) {
        this.streets = streets;
    }

    /**
     * Gets the tariffs.
     *
     * @return the tariffs
     */
    public List<Tariff> getTariffs() {
        return tariffs;
    }

    /**
     * Sets the tariffs.
     *
     * @param tariffs the new tariffs
     */
    public void setTariffs(List<Tariff> tariffs) {
        this.tariffs = tariffs;
    }

    /**
     * Gets the stereotypes.
     *
     * @return the stereotypes
     */
    public List<Stereotype> getStereotypes() {
        try {
            if (sector.getSectorId() != null) {
                cloud.setStereotype(stereotypeDao.getStereotypeBySector(sector));
            }

            Sector s = new Sector();
            if (cloud.getIsCompany()) {

                s.setIsHidden(false);

                stereotypes = stereotypeDao.getStereotypes(s);
            } else {
                s.setIsHidden(true);
                stereotypes = stereotypeDao.getStereotypes(s);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return stereotypes;
    }

    /**
     * Sets the stereotypes.
     *
     * @param stereotypes the new stereotypes
     */
    public void setStereotypes(List<Stereotype> stereotypes) {
        this.stereotypes = stereotypes;
    }

    /**
     * Gets the salesmans.
     *
     * @return the salesmans
     */
    public List<Salesman> getSalesmans() {
        return salesmans;
    }

    /**
     * Sets the salesmans.
     *
     * @param salesmans the new salesmans
     */
    public void setSalesmans(List<Salesman> salesmans) {
        this.salesmans = salesmans;
    }

    /**
     * Checks if is street disabled.
     *
     * @return true, if is street disabled
     */
    public boolean isStreetDisabled() {
        return streetDisabled;
    }

    /**
     * Sets the street disabled.
     *
     * @param streetDisabled the new street disabled
     */
    public void setStreetDisabled(boolean streetDisabled) {
        this.streetDisabled = streetDisabled;
    }

    /**
     * Gets the volumes.
     *
     * @return the volumes
     */
    public List<VolumeEnum> getVolumes() {
        return DictUtil.getVolumes();
    }

    /**
     * Compare clouds.
     */
    public void compareClouds() {
        cloudCompare = true;

        cloudsMulti[0].setOffersNumber(0);
        cloudsMulti[1].setOffersNumber(0);

        for (Auction auction : cloudsMulti[0].getAuctions()) {
            try {
                cloudsMulti[0].setOffersNumber(cloudsMulti[0].getOffersNumber()
                        + cloudDao.getAuctionOffersForAuctionsCount(auction));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        for (Auction auction : cloudsMulti[1].getAuctions()) {
            try {
                cloudsMulti[1].setOffersNumber(cloudsMulti[1].getOffersNumber()
                        + cloudDao.getAuctionOffersForAuctionsCount(auction));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Sets the volumes.
     *
     * @param volumes the new volumes
     */
    public void setVolumes(List<VolumeEnum> volumes) {
        this.volumes = volumes;
    }

    /**
     * Gets the user.
     *
     * @return the user
     */
    public UserApp getUser() {
        return user;
    }

    /**
     * Sets the user.
     *
     * @param userId the new user
     */
    public void setUser(Integer userId) {
        try {
            this.user = userDao.getUserAppbyId(userId);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Checks if is user buttons.
     *
     * @return true, if is user buttons
     */
    public boolean isUserButtons() {
        return userButtons;
    }

    /**
     * Sets the user buttons.
     *
     * @param userButtons the new user buttons
     */
    public void setUserButtons(boolean userButtons) {
        this.userButtons = userButtons;
    }

    /**
     * Gets the dual cities.
     *
     * @return the dual cities
     */
    public DualListModel<City> getDualCities() {
        log.info("[getDualCities]");
        if (locationCreatorType2Rendered) {
            log.info("locationCreatorAreaId: " + locationCreatorAreaId);
            if (locationCreatorAreaId != null) {
                City city = new City();
                city.setHasStatus(true);
                city.setAreaId(locationCreatorAreaId);
                try {
                    cities = cityDao.searchCities(city);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                log.info("cities size: " + cities.size());
            }
            dualCities = new DualListModel<City>(cities, new ArrayList<City>());
        }
        return dualCities;
    }

    public DualListModel<UserApp> getDualUsersCloudCreator() {
        return dualUsersCloudCreator;
    }

    public void setDualUsersCloudCreator(DualListModel<UserApp> users) {
        dualUsersCloudCreator = users;
    }

    /**
     * Sets the dual cities.
     *
     * @param dualCities the new dual cities
     */
    public void setDualCities(DualListModel<City> dualCities) {
        this.dualCities = dualCities;
    }

    /**
     * Gets the dual areas.
     *
     * @return the dual areas
     */
    public DualListModel<Area> getDualAreas() {
        return dualAreas;
    }

    /**
     * Sets the dual areas.
     *
     * @param dualAreas the new dual areas
     */
    public void setDualAreas(DualListModel<Area> dualAreas) {
        this.dualAreas = dualAreas;
    }

    /**
     * Gets the street name.
     *
     * @return the street name
     */
    public String getStreetName() {
        return streetName;
    }

    /**
     * Sets the street name.
     *
     * @param streetName the new street name
     */
    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    /**
     * Gets the sectors.
     *
     * @return the sectors
     */
    public List<Sector> getSectors() {
        return sectors;
    }

    /**
     * Sets the sectors.
     *
     * @param sectors the new sectors
     */
    public void setSectors(List<Sector> sectors) {
        this.sectors = sectors;
    }

    /**
     * Checks if is button multi disabled.
     *
     * @return true, if is button multi disabled
     */
    public boolean isButtonMultiDisabled() {
        return buttonMultiDisabled;
    }

    /**
     * Sets the button multi disabled.
     *
     * @param buttonMultiDisabled the new button multi disabled
     */
    public void setButtonMultiDisabled(boolean buttonMultiDisabled) {
        this.buttonMultiDisabled = buttonMultiDisabled;
    }

    /**
     * Gets the clouds multi.
     *
     * @return the clouds multi
     */
    public Cloud[] getCloudsMulti() {
        return cloudsMulti;
    }

    /**
     * Sets the clouds multi.
     *
     * @param cloudsMulti the new clouds multi
     */
    public void setCloudsMulti(Cloud[] cloudsMulti) {
        this.cloudsMulti = cloudsMulti;
    }

    /**
     * Checks if is cloud compare.
     *
     * @return true, if is cloud compare
     */
    public boolean isCloudCompare() {
        return cloudCompare;
    }

    /**
     * Sets the cloud compare.
     *
     * @param cloudCompare the new cloud compare
     */
    public void setCloudCompare(boolean cloudCompare) {
        this.cloudCompare = cloudCompare;
    }

    /**
     * Gets the cloud streets.
     *
     * @return the cloud streets
     */
    public List<String> getCloudStreets() {
        return cloudStreets;
    }

    /**
     * Sets the cloud streets.
     *
     * @param cloudStreets the new cloud streets
     */
    public void setCloudStreets(List<String> cloudStreets) {
        this.cloudStreets = cloudStreets;
    }

    /**
     * Checks if is location saved.
     *
     * @return true, if is location saved
     */
    public boolean isLocationSaved() {
        return locationSaved;
    }

    /**
     * Sets the location saved.
     *
     * @param locationSaved the new location saved
     */
    public void setLocationSaved(boolean locationSaved) {
        this.locationSaved = locationSaved;
    }

    private String ConvertNameAreaToCondeArea(String nameArea) {
        if ("dolnośląskie".equals(nameArea.toLowerCase())) {
            return "DS";
        }
        if ("kujawsko-pomorskie".equals(nameArea.toLowerCase())) {
            return "KP";
        }
        if ("lubelskie".equals(nameArea.toLowerCase())) {
            return "LU";
        }
        if ("lubuskie".equals(nameArea.toLowerCase())) {
            return "LB";
        }
        if ("łódzkie".equals(nameArea.toLowerCase())) {
            return "LD";
        }
        if ("małopolskie".equals(nameArea.toLowerCase())) {
            return "MA";
        }
        if ("mazowieckie".equals(nameArea.toLowerCase())) {
            return "MZ";
        }
        if ("opolskie".equals(nameArea.toLowerCase())) {
            return "OP";
        }
        if ("podkarpackie".equals(nameArea.toLowerCase())) {
            return "PK";
        }
        if ("podlaskie".equals(nameArea.toLowerCase())) {
            return "PD";
        }
        if ("pomorskie".equals(nameArea.toLowerCase())) {
            return "PM";
        }
        if ("śląskie".equals(nameArea.toLowerCase())) {
            return "SL";
        }
        if ("świętokrzyskie".equals(nameArea.toLowerCase())) {
            return "SK";
        }
        if ("warmińsko-mazurskie".equals(nameArea.toLowerCase())) {
            return "WN";
        }
        if ("wielkopolskie".equals(nameArea.toLowerCase())) {
            return "WP";
        }
        if ("zachodniopomorskie".equals(nameArea.toLowerCase())) {
            return "ZP";
        }
        return "not support iso 3166";
    }

    public String dualAreasMessageCode() {
        if (cloudAreas.isEmpty()) {
            return "";
        }
        if (cloudAreas.size() == 1) {
            return cloudAreas.get(0).getAreaName();
        } else if (cloudAreas.size() == 2) {
            return cloudAreas.get(0).getAreaName() + ", \n" + cloudAreas.get(1).getAreaName();
        } else if (cloudAreas.size() == 3) {
            return cloudAreas.get(0).getAreaName() + ", \n" + cloudAreas.get(1).getAreaName() + ",\n" + cloudAreas.get(2).getAreaName();
        } else {
            String namesAreas = ConvertNameAreaToCondeArea(cloudAreas.get(0).getAreaName());;
            for (int i = 1; i < cloudAreas.size(); i++) {
                namesAreas += ", \n" + ConvertNameAreaToCondeArea(cloudAreas.get(i).getAreaName());
            }
            return namesAreas;
        }
    }

    /**
     * Dual areas message.
     *
     * @return the string
     */
    public String dualAreasMessage() {
        log.info("cloudAreas.size(): " + cloudAreas.size());
        if (cloudAreas.size() == 1) {
            return cloudAreas.get(0).getAreaName();
        } else if (cloudAreas.size() > 1) {
            Object[] params = new Object[2];
            params[0] = cloudAreas.get(0).getAreaName();
            params[1] = cloudAreas.size() - 1;
            return BundlesUtils.getMessageResourceString("messages", "message.and.more", params, Locale.getDefault());
        } else {
            return "";
        }
    }

    /**
     * Dual cities message.
     *
     * @return the string
     */
    public String dualCitiesMessage() {
        log.info("dualCities.getTarget().size(): " + dualCities.getTarget().size());
        try {
            if (dualCities.getTarget().size() == 1) {
                log.info("only one city: " + dualCities.getTarget().get(0).getCityName());
                return dualCities.getTarget().get(0).getCityName();
            } else if (dualCities.getTarget().size() > 1) {
                Object[] params = new Object[2];
                params[0] = dualCities.getTarget().get(0).getCityName();
                params[1] = dualCities.getTarget().size() - 1;
                log.info("more city, one city: " + params[0] + " and more: " + params[1]);
                return BundlesUtils.getMessageResourceString("messages", "message.and.more", params,
                        Locale.getDefault());
            } else {
                log.info("return empty string");
                return "";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * Dual streets message.
     *
     * @return the string
     */
    public String dualStreetsMessage() {
        log.info("cloudStreets.size(): " + cloudStreets.size());
        if (cloudStreets.size() == 1) {
            return cloudStreets.get(0);
        }

        if (cloudStreets.size() > 1) {
            Object[] params = new Object[2];
            params[0] = cloudStreets.get(0);
            params[1] = cloudStreets.size() - 1;
            return BundlesUtils.getMessageResourceString("messages", "message.and.more", params, Locale.getDefault());
        }
        return "";
    }

    public String areasMessageCode() {
        if (selectedCloud.getAreas().isEmpty()) {
            return "";
        }
        if (selectedCloud.getAreas().size() == 1) {
            return selectedCloud.getAreas().get(0).getAreaName();
        } else if (selectedCloud.getAreas().size() == 2) {
            return selectedCloud.getAreas().get(0).getAreaName() + ", \n" + selectedCloud.getAreas().get(1).getAreaName();
        } else if (selectedCloud.getAreas().size() == 3) {
            return selectedCloud.getAreas().get(0).getAreaName() + ", \n" + selectedCloud.getAreas().get(1).getAreaName() + ",\n" + selectedCloud.getAreas().get(2).getAreaName();
        } else {
            String namesAreas = ConvertNameAreaToCondeArea(selectedCloud.getAreas().get(0).getAreaName());;
            for (int i = 1; i < selectedCloud.getAreas().size(); i++) {
                namesAreas += ", \n" + ConvertNameAreaToCondeArea(selectedCloud.getAreas().get(i).getAreaName());
            }
            return namesAreas;
        }
    }

    /**
     * Areas message.
     *
     * @return the string
     */
    public String areasMessage() {
        if (selectedCloud.getAreas().size() == 1) {
            return selectedCloud.getAreas().get(0).getAreaName();
        }
        if (selectedCloud.getAreas().size() > 1) {
            Object[] params = new Object[2];
            params[0] = selectedCloud.getAreas().get(0).getAreaName();
            params[1] = selectedCloud.getAreas().size() - 1;
            return BundlesUtils.getMessageResourceString("messages", "message.and.more", params, Locale.getDefault());
        }

        return "";
    }

    /**
     * Cities message.
     *
     * @return the string
     */
    public String citiesMessage() {
        if (selectedCloud.getCities().size() == 1) {
            return selectedCloud.getCities().get(0).getCityName();
        }

        if (selectedCloud.getCities().size() > 1) {
            Object[] params = new Object[2];
            params[0] = selectedCloud.getCities().get(0).getCityName();
            params[1] = selectedCloud.getCities().size() - 1;
            return BundlesUtils.getMessageResourceString("messages", "message.and.more", params, Locale.getDefault());
        }
        return "";
    }

    /**
     * City area.
     */
    public void cityArea() {
        Area area = new Area();

        try {
            if (hasCloudCities(selectedCloud)) {
                area = areaDao.getAreaByCityId(selectedCloud.getCities().get(0).getCityId());
            }
        } catch (Exception e) {
            log.error("Error while getting Auction city area: ", e);
            e.printStackTrace();
        }

        cityAreaName = area.getAreaName();
    }

    /**
     * Checks for cloud cities.
     *
     * @param cloud the cloud
     * @return true, if successful
     */
    private boolean hasCloudCities(Cloud cloud) {
        if (null == cloud) {
            return false;
        }
        if (null == cloud.getCities()) {
            return false;
        }
        if (cloud.getCities().isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Streets message.
     *
     * @return the string
     */
    public String streetsMessage() {
        if (selectedCloud.getStreets().size() == 1) {
            return selectedCloud.getStreets().get(0).getStreetName();
        }

        if (selectedCloud.getStreets().size() > 1) {
            Object[] params = new Object[2];
            params[0] = selectedCloud.getStreets().get(0).getStreetName();
            params[1] = selectedCloud.getStreets().size() - 1;
            return BundlesUtils.getMessageResourceString("messages", "message.and.more", params, Locale.getDefault());
        }

        return "";
    }

    /**
     * Info.
     *
     * @param message_code the message_code
     */
    @SuppressWarnings({"deprecation"})
    private void info(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_INFO,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    /**
     * Warning.
     *
     * @param message_code the message_code
     */
    @SuppressWarnings({"unused", "deprecation"})
    private void warning(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_WARN,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    /**
     * Gets the zone type.
     *
     * @return the zone type
     */
    public List<ZoneType> getZoneType() {
        zoneType = new ArrayList<ZoneType>();

        for (ZoneType a : ZoneType.values()) {
            a.setLabel(BundlesUtils.getMessageResourceString("messages", a.toString(), null, Locale.getDefault()));

            zoneType.add(a);
        }

        return zoneType;
    }

    /**
     * Sets the zone type.
     *
     * @param zoneType the new zone type
     */
    public void setZoneType(List<ZoneType> zoneType) {
        this.zoneType = zoneType;
    }

    /**
     * Cloud volume.
     *
     * @param cloud the cloud
     * @return the string
     */
    public String cloudVolume(Cloud cloud) {
        log.info("cloudVolume");
        Double vol = 0.0;

        if (null == cloud) {
            log.info("cloud == null, WTF");
            return vol  + " "
                + BundlesUtils.getMessageResourceString("messages", "cloud.volume.KWH", null,
                        ectx.getRequestLocale());
        }
        if (cloud.getStereotype() == null || cloud.getStereotype().getStereotypeId() == null)
            vol = CloudUtil.updateCloudVolumeByManual(cloud.getCloudId());
        else
            vol = CloudUtil.updateCloudVolume(cloud.getCloudId());
        log.info("id: " + cloud.getCloudId().toString() + "valume :" + vol.toString());
        DecimalFormat decimalFormat = new DecimalFormat("#0.0000");

        if (vol > 10000) {
            return decimalFormat.format(vol / 1000.0)
                    + " "
                    + BundlesUtils.getMessageResourceString("messages", "cloud.volume.MWH", null,
                            ectx.getRequestLocale());
        } else {
            return decimalFormat.format(vol)
                    + " "
                    + BundlesUtils.getMessageResourceString("messages", "cloud.volume.KWH", null,
                            ectx.getRequestLocale());
        }
    }

    /**
     * Cloud volume for compare.
     *
     * @param arg the arg
     * @return the string
     */
    public String cloudVolumeForCompare(Integer arg) {
        log.info("cloudVolumeForCompare: " + arg);
        if (haveCloudToCompare(arg)) {
            DecimalFormat decimalFormat = new DecimalFormat("#0.0000");
            Double cloudVolume = cloudsMulti[arg].getVolume();
            cloudVolume *= 1000;

            String result = decimalFormat.format(cloudVolume);
            result += " "
                    + BundlesUtils.getMessageResourceString("messages", "cloud.volume.KWH", null,
                            ectx.getRequestLocale());
            return result;
        }

        return "0.0000";
    }

    /**
     * Have cloud to compare.
     *
     * @param index the index
     * @return true, if successful
     */
    private boolean haveCloudToCompare(Integer index) {
        if (null == index) {
            return false;
        }
        if (null == cloudsMulti) {
            return false;
        }
        if (cloudsMulti.length <= index) {
            return false;
        }
        if (null == cloudsMulti[index].getVolume()) {
            return false;
        }

        return true;
    }

    /**
     * Cloud volume by type.
     *
     * @param cloud the cloud
     * @param pcType the pc type
     * @return the string
     */
    public String cloudVolumeByType(Cloud cloud, String pcType) {

        for (CloudVolume cV : cloud.getCloudVolume()) {
            if (cV.getZoneType() == ZoneType.valueOf(pcType)) {
                return cV.getVolume().toString();
            }
        }

        return "-";
    }

    /**
     * Ppe count.
     *
     * @param cloud the cloud
     * @return the integer
     */
    public Integer ppeCount(Cloud cloud) {
        Integer ppeCount = 0;

        try {
            ppeCount = cloudDao.getPPECount(cloud);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ppeCount;
    }

    /**
     * Prepare ppe volume.
     *
     * @param cloud the cloud
     * @return the map
     */
    public Map<ZoneType, Double> preparePpeVolume(Cloud cloud) {
        log.info("[preparePpeVolume]");
        List<PPE> list = new ArrayList<PPE>();
        Map<ZoneType, Double> map = new HashMap<ZoneType, Double>();

        try {
            if (cloud.getStereotype() == null || cloud.getStereotype().getStereotypeId() == null) {
                list = cloudDao.getPpeByCloudIdNoStereotype(cloud); 
                 log.info("[preparePpeVolume] cloud.getStereotype() == null || cloud.getStereotype().getStereotypeId() == nul");
            }
            else
                list = cloudDao.getPpeByCloudId(cloud);

            log.info("size list : " + list.size());
            for (PPE ppe : list) {
                log.info("[preparePpeVolume] ppe ID: " + ppe.getPpeId());
                PpeUtil ppeUtil = new PpeUtil();

                Map<ZoneType, Double> tmpMap = ppeUtil.prepareYearVolumeMapsForPPE(ppe);
                Double value_get = ppeUtil.getPPEValue(ppe);
                log.info("[preparePpeVolume] 2.0  value.getValue()" + value_get);

                for (Map.Entry<ZoneType, Double> entry : tmpMap.entrySet()) {

                    ZoneType key = entry.getKey();
                    log.info("[preparePpeVolume] 4 key: " + key.toString());
                    Double value = entry.getValue();
                    log.info("[preparePpeVolume] 5 value: " + value.toString());
                    Double old_value = 0.0;
                    log.info("[preparePpeVolume] 5.1 map size: " + map.size());
                    if (map.containsKey(key)) {
                        log.info("[preparePpeVolume] 5.2 map has key: " + key.toString());
                        old_value = map.get(key);
                    } else {
                        log.info("key not exist:" + key.toString());
                    }

                    log.info("[preparePpeVolume] 6 old_value:  " + old_value.toString());
                    map.put(key, old_value + value);
                    log.info("[preparePpeVolume] 7 new value: " + map.get(key));
                }

                log.info("map ppe::" + map.size());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return map;
    }

    public Map<ZoneType, Double> preparePpeVolumeForUser(Cloud cloud) {
        log.info("[preparePpeVolumeForUser]");
        List<PPE> list = new ArrayList<PPE>();
        Map<ZoneType, Double> map = new HashMap<ZoneType, Double>();
        PPEDao ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);

        try {
            list = cloudDao.getPpeByCloudId(cloud);
            List<PPE> listForUser = new ArrayList<PPE>();

            for (PPE ppe : list) {
                ppe = ppeDao.getPPEById((long) ppe.getPpeId());
                for (UserApp user_ : cloud.getUsers()) {
                    if (user_.getUserId() == ppe.getLocation().getUserApp().getUserId()) {
                        log.info("user_ getUserId: " + user_.getUserId());
                        listForUser.add(ppe);
                    }
                }
            }

            log.info("size list : " + listForUser.size());
            for (PPE ppe : listForUser) {
                log.info("[preparePpeVolumeForUser] ppe ID: " + ppe.getPpeId());
                PpeUtil ppeUtil = new PpeUtil();

                Map<ZoneType, Double> tmpMap = ppeUtil.prepareYearVolumeMapsForPPE(ppe);
                Double value_get = ppeUtil.getPPEValue(ppe);
                log.info("[preparePpeVolumeForUser] 2.0  value.getValue()" + value_get);

                for (Map.Entry<ZoneType, Double> entry : tmpMap.entrySet()) {

                    ZoneType key = entry.getKey();
                    log.info("[preparePpeVolumeForUser] 4 key: " + key.toString());
                    Double value = entry.getValue();
                    log.info("[preparePpeVolumeForUser] 5 value: " + value.toString());
                    Double old_value = 0.0;
                    log.info("[preparePpeVolumeForUser] 5.1 map size: " + map.size());
                    if (map.containsKey(key)) {
                        log.info("[preparePpeVolumeForUser] 5.2 map has key: " + key.toString());
                        old_value = map.get(key);
                    } else {
                        log.info("key not exist:" + key.toString());
                    }

                    log.info("[preparePpeVolumeForUser] 6 old_value:  " + old_value.toString());
                    map.put(key, old_value + value);
                    log.info("[preparePpeVolumeForUser] 7 new value: " + map.get(key));
                }

                log.info("preparePpeVolumeForUser map ppe::" + map.size());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return map;
    }

    /**
     * Initialize cloud details.
     *
     * @param cloud the cloud
     * @return the string
     */
    public String initializeCloudDetails(Cloud cloud) {
        this.selectedCloud = cloud;
        prepareVolumeAndDetails();
        updateCloudVolumePerZone(cloud);
        return "cloudDetails";
    }

    public String initializeCloudDetailsForUser(Cloud cloud) {
        this.selectedCloud = cloud;
        prepareVolumeAndDetailsForUser();
        // updateCloudVolumePerZone(cloud);
        return "cloudDetails";
    }

    private void updateCloudVolumePerZone(Cloud cloud) {
        SalesmanCloudBean salesmanCloudBean = ComponentLookup.lookupComponent("op.salesmanCloudBean");
        salesmanCloudBean.updateCloudVolumePerZone(cloud);
    }

    /**
     * Prepare volume and details.
     *
     * @return the string
     */
    public String prepareVolumeAndDetails() {

        Cloud tmpCloud = (null != selectedCloud) ? selectedCloud : cloudsMulti[0];

        detailsMap = new HashMap<ZoneType, Double>();
        detailsMap = this.preparePpeVolume(tmpCloud);
        List<CloudVolume> cloudVolumeList = new ArrayList<CloudVolume>();

        for (Map.Entry<ZoneType, Double> entry : detailsMap.entrySet()) {
            CloudVolume cloudVolume = new CloudVolume();
            cloudVolume.setVolume(entry.getValue());
            cloudVolume.setZoneType(entry.getKey());
            cloudVolumeList.add(cloudVolume);
        }

        selectedCloud.setCloudVolume(cloudVolumeList);
        CloudUtil.checkCloudAuctionList(selectedCloud);

        return "cloudDetails";
    }

    public String prepareVolumeAndDetailsForUser() {

        Cloud tmpCloud = (null != selectedCloud) ? selectedCloud : cloudsMulti[0];

        detailsMap = new HashMap<ZoneType, Double>();
        detailsMap = this.preparePpeVolumeForUser(tmpCloud);
        List<CloudVolume> cloudVolumeList = new ArrayList<CloudVolume>();

        for (Map.Entry<ZoneType, Double> entry : detailsMap.entrySet()) {
            CloudVolume cloudVolume = new CloudVolume();
            cloudVolume.setVolume(entry.getValue());
            cloudVolume.setZoneType(entry.getKey());
            cloudVolumeList.add(cloudVolume);
        }

        selectedCloud.setCloudVolume(cloudVolumeList);
        CloudUtil.checkCloudAuctionList(selectedCloud);

        return "cloudDetails";
    }

    /**
     * Initialize cloud edit.
     *
     * @param cloud the cloud
     * @return the string
     */
    public String initializeCloudEdit(Cloud cloud) {
        this.selectedCloud = cloud;

        return editAction();
    }

    /**
     * Edits the action.
     *
     * @return the string
     */
    public String editAction() {
        dualUsers = new DualListModel<UserApp>();
        try {
            // dualUsers.setSource(cloudDao.getCloudPotentialUsers(selectedCloud));
            dualUsers.setTarget(selectedCloud.getUsers());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "cloudEdit";
    }

    /**
     * Update cloud users.
     *
     * @return the string
     */
    public String updateCloudUsers() {
        try {
            cloudDao.deleteCloudUsers(selectedCloud);
            for (UserApp user : dualUsers.getTarget()) {
                cloudDao.saveUserCloud(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        searchClouds();

        return "clouds";
    }

    /**
     * Checks if is gallery view.
     *
     * @return true, if is gallery view
     */
    public boolean isGalleryView() {
        return galleryView;
    }

    /**
     * Sets the gallery view.
     *
     * @param galleryView the new gallery view
     */
    public void setGalleryView(boolean galleryView) {
        this.galleryView = galleryView;
    }

    /**
     * Change gallery view.
     */
    public void changeGalleryView() {
        galleryView = !galleryView;
        buttonDisabled = true;
        buttonMultiDisabled = true;
        selectedCloud = null;
        cloudsMulti = null;
    }

    /**
     * Gets the selected cloud.
     *
     * @return the selected cloud
     */
    public Cloud getSelectedCloud() {
        return selectedCloud;
    }

    /**
     * Sets the selected cloud.
     *
     * @param selectedCloud the new selected cloud
     */
    public void setSelectedCloud(Cloud selectedCloud) {
        this.selectedCloud = selectedCloud;
    }

    /**
     * Gets the sector.
     *
     * @return the sector
     */
    public Sector getSector() {
        return sector;
    }

    /**
     * Sets the sector.
     *
     * @param sector the new sector
     */
    public void setSector(Sector sector) {
        this.sector = sector;
    }

    /**
     * Gets the potential users.
     *
     * @return the potential users
     */
    public List<UserApp> getPotentialUsers() {
        return potentialUsers;
    }

    /**
     * Sets the potential users.
     *
     * @param potentialUsers the new potential users
     */
    public void setPotentialUsers(List<UserApp> potentialUsers) {
        this.potentialUsers = potentialUsers;
    }

    /**
     * Gets the dual users.
     *
     * @return the dual users
     */
    public DualListModel<UserApp> getDualUsers() {
        return dualUsers;
    }

    /**
     * Sets the dual users.
     *
     * @param dualUsers the new dual users
     */
    public void setDualUsers(DualListModel<UserApp> dualUsers) {
        this.dualUsers = dualUsers;
    }

    /**
     * Gets the city name.
     *
     * @return the city name
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * Sets the city name.
     *
     * @param cityName the new city name
     */
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    /**
     * Gets the details map.
     *
     * @return the details map
     */
    public Map<ZoneType, Double> getDetailsMap() {
        return detailsMap;
    }

    /**
     * Sets the details map.
     *
     * @param detailsMap the details map
     */
    public void setDetailsMap(Map<ZoneType, Double> detailsMap) {
        this.detailsMap = detailsMap;
    }

    /**
     * Gets the location creator cloud type.
     *
     * @return the location creator cloud type
     */
    public String getLocationCreatorCloudType() {
        return locationCreatorCloudType;
    }

    /**
     * Sets the location creator cloud type.
     *
     * @param locationCreatorCloudType the new location creator cloud type
     */
    public void setLocationCreatorCloudType(String locationCreatorCloudType) {
        log.info("locationCreatorCloudType: " + locationCreatorCloudType);
        addLocation();
        if (locationCreatorCloudType.equals("many_area")) {
            locationCreatorType1Rendered = true;
            locationCreatorType2Rendered = false;
            locationCreatorType3Rendered = false;
        }
        if (locationCreatorCloudType.equals("many_city")) {
            locationCreatorType1Rendered = false;
            locationCreatorType2Rendered = true;
            locationCreatorType3Rendered = false;
        }
        if (locationCreatorCloudType.equals("many_street")) {
            locationCreatorType1Rendered = false;
            locationCreatorType2Rendered = false;
            locationCreatorType3Rendered = true;
        }
        locationCreatorAreaId = 1;
        locationCreatorCityId = 1;
        this.locationCreatorCloudType = locationCreatorCloudType;
    }

    /**
     * Adds the location.
     */
    public void addLocation() {
        log.info("set default value to location creator");
        setLocationCreatorStreetName("");
        locationCreatorCloudType = "many_area";
        locationCreatorType1Rendered = true;
        locationCreatorType2Rendered = false;
        locationCreatorType2Rendered = false;
    }

    /**
     * Location creator city change.
     */
    public void locationCreatorCityChange() {
        cloudStreets = new ArrayList<String>();
    }

    /**
     * Checks if is location creator type1 rendered.
     *
     * @return true, if is location creator type1 rendered
     */
    public boolean isLocationCreatorType1Rendered() {
        return locationCreatorType1Rendered;
    }

    /**
     * Sets the location creator type1 rendered.
     *
     * @param locationCreatorType1Rendered the new location creator type1
     * rendered
     */
    public void setLocationCreatorType1Rendered(boolean locationCreatorType1Rendered) {
        this.locationCreatorType1Rendered = locationCreatorType1Rendered;
    }

    /**
     * Checks if is location creator type2 rendered.
     *
     * @return true, if is location creator type2 rendered
     */
    public boolean isLocationCreatorType2Rendered() {
        return locationCreatorType2Rendered;
    }

    /**
     * Sets the location creator type2 rendered.
     *
     * @param locationCreatorType2Rendered the new location creator type2
     * rendered
     */
    public void setLocationCreatorType2Rendered(boolean locationCreatorType2Rendered) {
        this.locationCreatorType2Rendered = locationCreatorType2Rendered;
    }

    /**
     * Checks if is location creator type3 rendered.
     *
     * @return true, if is location creator type3 rendered
     */
    public boolean isLocationCreatorType3Rendered() {
        return locationCreatorType3Rendered;
    }

    /**
     * Sets the location creator type3 rendered.
     *
     * @param locationCreatorType3Rendered the new location creator type3
     * rendered
     */
    public void setLocationCreatorType3Rendered(boolean locationCreatorType3Rendered) {
        this.locationCreatorType3Rendered = locationCreatorType3Rendered;
    }

    /**
     * Gets the location creator area id.
     *
     * @return the location creator area id
     */
    public Integer getLocationCreatorAreaId() {
        return locationCreatorAreaId;
    }

    /**
     * Sets the location creator area id.
     *
     * @param locationCreatorAreaId the new location creator area id
     */
    public void setLocationCreatorAreaId(Integer locationCreatorAreaId) {
        this.locationCreatorAreaId = locationCreatorAreaId;
    }

    /**
     * Gets the location creator city id.
     *
     * @return the location creator city id
     */
    public Integer getLocationCreatorCityId() {
        return locationCreatorCityId;
    }

    /**
     * Sets the location creator city id.
     *
     * @param locationCreatorCityId the new location creator city id
     */
    public void setLocationCreatorCityId(Integer locationCreatorCityId) {
        this.locationCreatorCityId = locationCreatorCityId;
    }

    /**
     * Gets the location creator street name.
     *
     * @return the location creator street name
     */
    public String getLocationCreatorStreetName() {
        return locationCreatorStreetName;
    }

    /**
     * Sets the location creator street name.
     *
     * @param locationCreatorStreetName the new location creator street name
     */
    public void setLocationCreatorStreetName(String locationCreatorStreetName) {
        this.locationCreatorStreetName = locationCreatorStreetName;
    }

    /**
     * Gets the ppe list.
     *
     * @return the ppe list
     */
    public List<PPE> getPpeList() {
        return ppeList;
    }

    /**
     * Sets the ppe list.
     *
     * @param ppeList the new ppe list
     */
    public void setPpeList(List<PPE> ppeList) {
        this.ppeList = ppeList;
    }

    /**
     * Gets the selected users.
     *
     * @return the selected users
     */
    public UserApp[] getSelectedUsers() {
        return selectedUsers;
    }

    /**
     * Sets the selected users.
     *
     * @param selectedUsers the new selected users
     */
    public void setSelectedUsers(UserApp[] selectedUsers) {
        this.selectedUsers = selectedUsers;
    }

    /**
     * Checks if is button delete users.
     *
     * @return true, if is button delete users
     */
    public boolean isButtonDeleteUsers() {
        return buttonDeleteUsers;
    }

    /**
     * Sets the button delete users.
     *
     * @param buttonDeleteUsers the new button delete users
     */
    public void setButtonDeleteUsers(boolean buttonDeleteUsers) {
        this.buttonDeleteUsers = buttonDeleteUsers;
    }

    /**
     * On city select.
     */
    public void onCitySelect() {
        try {
            City selectedCity = LocationUtil.getCity(cityName, cloudFilter.getArea());
            cloudFilter.setCity(selectedCity);
        } catch (Exception e) {
            log.error("Problem while search selected city: ", e);
        }
    }

    /**
     * Gets the sector list.
     *
     * @return the sector list
     */
    public List<Sector> getSectorList() {
        if (null == cloudFilter) {
            return new ArrayList<Sector>();
        }
        if (null == cloudFilter.getCloud()) {
            return new ArrayList<Sector>();
        }
        return DictUtil.getSectorListByType(cloudFilter.getCloud().getIsCompany());
    }

    public List<UserApp> getUsersCloudCreator() {
        return usersCloudCreator;
    }

    public void setUsersCloudCreator(List<UserApp> users) {
        this.usersCloudCreator = users;
    }
}
