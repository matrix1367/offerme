package pl.op.web.beans.bonus;

import java.io.Serializable;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.io.FilenameUtils;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.EventDao;
import pl.op.dao.PointsRulesDao;
import pl.op.dao.UserDao;
import pl.op.dao.UserPointsDao;
import pl.op.model.bonus.Event;
import pl.op.model.bonus.PointsRules;
import pl.op.model.bonus.UserPoints;
import pl.op.model.user.UserApp;
import pl.op.model.user.UserRole;
import pl.op.web.beans.AdminBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.listener.GuiceSingleton;
import pl.op.web.service.BonusService;

@Name("op.bonusBean")
@Scope(ScopeType.SESSION)
public class BonusBean implements Serializable {

    private static final long serialVersionUID = -4739928019622373031L;

    private Logger log = LoggerFactory.getLogger(BonusBean.class);

    private UserDao userDao;
    private EventDao eventDao;
    private PointsRulesDao pointsRulesDao;
    private UserPointsDao userPointsDao;

    private UserApp userApp;
    private UserApp userRanking;
    private List<UserApp> userRankingList;

    private PointsRules pointsRules;
    private PointsRules selectedPointsRules;
    private PointsRules selectedBonus;
    private PointsRules selectedBonusCompanyActive;
    private PointsRules selectedBonusCompanyNoActive;
    private List<PointsRules> pointsRulesList;
    private List<PointsRules> pointsRulesFiltered;
    private List<PointsRules> bonusList;
    private List<PointsRules> bonusFiltered;
    private List<PointsRules> bonusCompanyActiveList;
    private List<PointsRules> bonusCompanyActiveFiltered;
    private List<PointsRules> bonusCompanyNoActiveList;
    private List<PointsRules> bonusCompanyNoActiveFiltered;

    private UserPoints userPoints;
    private UserPoints selectedUserPointsGrantedBuy;
    private UserPoints selectedUserPointsNoGrantedBuy;
    private List<UserPoints> userPointsGrantedBuyList;
    private List<UserPoints> userPointsGrantedBuyFiltered;
    private List<UserPoints> userPointsNoGrantedBuyList;
    private List<UserPoints> userPointsNoGrantedBuyFiltered;

    private Boolean buttonsPointsRulesDisabled;
    private Boolean buttonsBonusDisabled;
    private Boolean buttonsBonusCompanyActiveDisabled;
    private Boolean buttonsBonusCompanyNoActiveDisabled;
    private Boolean buttonsUserPointsGrantedBuyDisabled;
    private Boolean buttonsUserPointsNoGrantedBuyDisabled;

    private List<SelectItem> selectEvent;
    private List<SelectItem> selectUser;
    private List<SelectItem> selectBonuses;

    private Integer selectedEvent;
    private Integer selectedUser;
    private Integer selectedBonuses;

    private Map<String, Event> eventMap;

    private String mode;
    private Integer viewActive;

    public BonusBean() {
        log.info("BonusBean Constructor");
        initialize();
    }

    private void initialize() {

        userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);
        eventDao = GuiceSingleton.getInstance().getInstance(EventDao.class);
        pointsRulesDao = GuiceSingleton.getInstance().getInstance(PointsRulesDao.class);
        userPointsDao = GuiceSingleton.getInstance().getInstance(UserPointsDao.class);

        userPoints = new UserPoints();
        pointsRules = new PointsRules();

        try {
            eventMap = eventDao.prepareMap();
        } catch (Exception e) {
            e.printStackTrace();
        }

        setLoggedUserApp();

        if(userApp != null) {
            fillSelectEvent();
            fillSelectUsers();
            fillSelectBonuses();
        }

    }

    private void fillSelectEvent() {
        selectEvent = new ArrayList<SelectItem>();
        for(Event item : eventMap.values()) {
            selectEvent.add(new SelectItem(item.getEventId(), item.getEventName()));
        }
    }

    private void fillSelectUsers() {
        List<UserApp> usersList = new ArrayList<UserApp>();

        if(userApp.getUserRole().equals(UserRole.admin)) {
            FacesContext ctx = FacesContext.getCurrentInstance();
            AdminBean adminBean = (AdminBean) ctx.getApplication().getELResolver()
                    .getValue(ctx.getELContext(), null, "op.adminBean");
            new HashMap<Integer, UserApp>();

            adminBean.listUsers();
            usersList = adminBean.getUsers();
        } else {
            try {
                usersList = userDao.getUsersByRoleNoAdminAndOperator();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        selectUser = new ArrayList<SelectItem>();
        for(UserApp item : usersList) {
            selectUser.add(new SelectItem(item.getUserId(), item.getFullName()));
        }
    }

    private void fillSelectBonuses() {
        selectBonuses = new ArrayList<SelectItem>();
        try {
            List<PointsRules> bonuses = pointsRulesDao.getBonusRules();
            for(PointsRules item : bonuses) {
                selectBonuses.add(new SelectItem(item.getPointsRulesId(), item.getBonusName()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void preparePointsRulesList() {

        try {
            pointsRulesList = pointsRulesDao.getPointsRules();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void prepareBonusList() {

        try {
            bonusList = pointsRulesDao.getBonusRulesByUser(userApp);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void prepareBonusCompanyActiveList() {

        try {
            bonusCompanyActiveList = pointsRulesDao.getBonusRulesOnlyUsers(true);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void prepareBonusCompanyNoActiveList() {

        try {
            bonusCompanyNoActiveList = pointsRulesDao.getBonusRulesOnlyUsers(false);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void prepareUserPointsGrantedBuyList() {

        try {
            List<PointsRules> pointsRulesIds = pointsRulesDao.getBonusRules();
            if(pointsRulesIds != null) {
                userPointsGrantedBuyList = userPointsDao.getUserPointsIsBuy(pointsRulesIds, true);
            } else {
                userPointsGrantedBuyList = new ArrayList<UserPoints>();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void prepareUserPointsNoGrantedBuyList() {

        try {
            List<PointsRules> pointsRulesIds = pointsRulesDao.getBonusRules();
            if(pointsRulesIds != null) {
                userPointsNoGrantedBuyList = userPointsDao.getUserPointsIsBuy(pointsRulesIds, false);
            } else {
                userPointsNoGrantedBuyList = new ArrayList<UserPoints>();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void prepareUserRankingList() {

        try {
            userRankingList = userDao.getUsersByRoleNoAdminAndOperator();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void displayMessage(String id, String key) {
        String message = BundlesUtils.getMessageResourceString("messages", key, null, Locale.getDefault());
        FacesContext context = FacesContext.getCurrentInstance();
        FacesMessage facesMessage = new FacesMessage(message);
        context.addMessage(id, facesMessage);
    }

    public void loadBonus() {

        this.buttonsPointsRulesDisabled = true;
        this.buttonsBonusDisabled = true;
        this.buttonsBonusCompanyActiveDisabled = true;
        this.buttonsBonusCompanyNoActiveDisabled = true;
        this.buttonsUserPointsGrantedBuyDisabled = true;
        this.buttonsUserPointsNoGrantedBuyDisabled = true;

        this.selectedPointsRules = new PointsRules();
        this.selectedBonus = new PointsRules();
        this.selectedBonusCompanyActive = new PointsRules();
        this.selectedBonusCompanyNoActive = new PointsRules();

        this.userPoints = new UserPoints();
        this.pointsRules = new PointsRules();

        setLoggedUserApp();

        fillSelectEvent();
        fillSelectUsers();
        fillSelectBonuses();

        preparePointsRulesList();
        prepareBonusList();
        prepareBonusCompanyActiveList();
        prepareBonusCompanyNoActiveList();
        prepareUserPointsGrantedBuyList();
        prepareUserPointsNoGrantedBuyList();
        prepareUserRankingList();

    }

    public void onPointsRulesSelect(SelectEvent event) {
        setButtonsPointsRulesDisabled(false);
        PointsRules pr = (PointsRules) event.getObject();
        try {
            PointsRules spr = pointsRulesDao.getPointsRulesById(pr.getPointsRulesId());
            setSelectedPointsRules(spr);
            setSelectedEvent(spr.getEvent().getEventId());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBonusSelect(SelectEvent event) {
        setButtonsBonusDisabled(false);
        PointsRules pr = (PointsRules) event.getObject();
        try {
            PointsRules spr = pointsRulesDao.getPointsRulesById(pr.getPointsRulesId());
            setSelectedBonus(spr);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBonusCompanyActiveSelect(SelectEvent event) {
        setButtonsBonusCompanyActiveDisabled(false);
        PointsRules pr = (PointsRules) event.getObject();
        try {
            PointsRules spr = pointsRulesDao.getPointsRulesById(pr.getPointsRulesId());
            setSelectedBonusCompanyActive(spr);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBonusCompanyNoActiveSelect(SelectEvent event) {
        setButtonsBonusCompanyNoActiveDisabled(false);
        PointsRules pr = (PointsRules) event.getObject();
        try {
            PointsRules spr = pointsRulesDao.getPointsRulesById(pr.getPointsRulesId());
            setSelectedBonusCompanyNoActive(spr);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBuyGrantedSelect(SelectEvent event) {
        setButtonsUserPointsGrantedBuyDisabled(false);
        UserPoints up = (UserPoints) event.getObject();
        try {
            UserPoints sup = userPointsDao.getUserPointsById(up.getUserPointsId());
            setSelectedUserPointsGrantedBuy(sup);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBuyNoGrantedSelect(SelectEvent event) {
        setButtonsUserPointsNoGrantedBuyDisabled(false);
        UserPoints up = (UserPoints) event.getObject();
        try {
            UserPoints sup = userPointsDao.getUserPointsById(up.getUserPointsId());
            setSelectedUserPointsNoGrantedBuy(sup);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Integer getTotalPoints(UserApp user) {

        Integer total = 0;
        try {
            List<UserPoints> allUserPoints = userPointsDao.getUserPointsByUserApp(user);
            for(UserPoints userPoint : allUserPoints) {
                if(userPoint.getIsGranted()) {
                    total += userPoint.getPointsRules().getPointsAmount();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return total;

    }

    public Integer getTotalBonus(UserApp user) {

        Integer total = 0;
        try {
            List<UserPoints> allUserPoints = userPointsDao.getUserPointsByUserApp(user);
            for(UserPoints userPoint : allUserPoints) {
                if(userPoint.getPointsRules().getPointsAmount() < 0) {
                    total += 1;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return total;

    }

    public void editBonus() {
        setMode("edit");
        pointsRules = selectedBonus;
        pointsRules.setUpdatedAt(new Date());
        Integer pointsAmount = pointsRules.getPointsAmount() * -1;
        pointsRules.setPointsAmount(pointsAmount);
    }

    public void addBonus() {
        setMode("add");
        addPointsRules();
        pointsRules.setIsOncePerDay(false);
        pointsRules.setIsRepeatable(false);
    }

    public void deleteBonus() {
        setMode("delete");
        try {
            pointsRules = selectedBonus;
            pointsRules.setIsDeleted(true);
            pointsRulesDao.updatePointsRules(pointsRules);
            displayMessage("messagesPointsRules", "messages.pointsRules.deleteComplete");
            loadBonus();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void saveBonus() {
        Integer pointsAmount = pointsRules.getPointsAmount() * -1;
        pointsRules.setPointsAmount(pointsAmount);
        try {
            Event event = eventDao.getEventByCodeName("bonus");
            setSelectedEvent(event.getEventId());
        } catch (Exception e) {
            e.printStackTrace();
        }
        savePointsRules();
    }

    public void activeBonus() {
        try {
            Integer pointsAmount = pointsRules.getPointsAmount() * -1;
            pointsRules.setPointsAmount(pointsAmount);
            pointsRules.setIsActive(true);
            pointsRulesDao.updatePointsRules(pointsRules);
            displayMessage("messagesPointsRules", "messages.pointsRules.activeComplete");
            loadBonus();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void editBonusCompanyActive() {
        setMode("edit");
        pointsRules = selectedBonusCompanyActive;
        pointsRules.setUpdatedAt(new Date());
        Integer pointsAmount = pointsRules.getPointsAmount() * -1;
        pointsRules.setPointsAmount(pointsAmount);
        selectedUser = pointsRules.getUser().getUserId();
    }

    public void addBonusCompanyActive() {
        setMode("add");
        pointsRules = new PointsRules();
        pointsRules.setRepeatsNeed(1);
        pointsRules.setPointsAmount(1);
        pointsRules.setIsDeleted(false);
        pointsRules.setCreatedAt(new Date());
        pointsRules.setIsOncePerDay(false);
        pointsRules.setIsRepeatable(false);
    }

    public void deleteBonusCompanyActive() {
        setMode("delete");
        try {
            pointsRules = selectedBonusCompanyActive;
            pointsRules.setIsDeleted(true);
            pointsRulesDao.updatePointsRules(pointsRules);
            displayMessage("messagesPointsRules", "messages.pointsRules.deleteComplete");
            loadBonus();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void saveBonusCompanyActive() {
        Integer pointsAmount = pointsRules.getPointsAmount() * -1;
        pointsRules.setPointsAmount(pointsAmount);
        try {
            Event event = eventDao.getEventByCodeName("bonus");
            setSelectedEvent(event.getEventId());
            pointsRules.setUser(userDao.getUserAppbyId(selectedUser));
        } catch (Exception e) {
            e.printStackTrace();
        }
        savePointsRules();
    }

    public void activeBonusCompanyNoActive() {
        setMode("active");
        pointsRules = selectedBonusCompanyNoActive;
        pointsRules.setUpdatedAt(new Date());
        Integer pointsAmount = pointsRules.getPointsAmount() * -1;
        pointsRules.setPointsAmount(pointsAmount);
    }

    public void deleteBonusCompanyNoActive() {
        setMode("delete");
        try {
            pointsRules = selectedBonusCompanyNoActive;
            pointsRules.setIsDeleted(true);
            pointsRulesDao.updatePointsRules(pointsRules);
            displayMessage("messagesPointsRules", "messages.pointsRules.deleteComplete");
            loadBonus();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteBuyNoGranted() {
        setMode("delete");
        try {
            userPointsDao.deleteUserPoints(selectedUserPointsNoGrantedBuy);
            displayMessage("messagesPointsRules", "messages.pointsRules.deleteComplete");
            loadBonus();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteBuyGranted() {
        setMode("delete");
        try {
            userPointsDao.deleteUserPoints(selectedUserPointsGrantedBuy);
            displayMessage("messagesPointsRules", "messages.pointsRules.deleteComplete");
            loadBonus();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void acceptBuyNoGranted(Integer pointsAmmount) {
        setMode("accept");
        try {
            userPoints = selectedUserPointsNoGrantedBuy;
            Integer userTotal = getTotalPoints(userPoints.getUser());
            pointsAmmount = pointsAmmount * -1;

            if(userTotal >= pointsAmmount) {
                userPoints.setIsGranted(true);
                userPoints.setUpdatedAt(new Date());
                userPointsDao.updateUserPoints(userPoints);
                displayMessage("messagesPointsRules", "messages.pointsRules.acceptComplete");
            } else {
                displayMessage("messagesPointsRules", "messages.pointsRules.acceptError");
            }

            loadBonus();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addUserPoints() {
        setMode("add");
        userPoints = new UserPoints();
        userPoints.setNoRepeats(1);
        userPoints.setUpdatedAt(new Date());
    }

    public void saveUserPoints() {
        try {
            PointsRules pr = pointsRulesDao.getPointsRulesById(selectedBonuses);

            userPoints.setUser(userDao.getUserAppbyId(selectedUser));

            Integer userTotal = getTotalPoints(userPoints.getUser());
            Integer pointsAmmount = pr.getPointsAmount() * -1;

            if(userTotal >= pointsAmmount) {
                userPoints.setPointsRules(pr);
                userPointsDao.saveUserPoints(userPoints);
                displayMessage("messagesPointsRules", "messages.pointsRules.addComplete");
            } else {
                displayMessage("messagesPointsRules", "messages.pointsRules.acceptError");
            }
            loadBonus();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void editPointsRules() {
        setMode("edit");
        pointsRules = selectedPointsRules;
        pointsRules.setUpdatedAt(new Date());
    }

    public void addPointsRules() {
        setMode("add");
        pointsRules = new PointsRules();
        pointsRules.setRepeatsNeed(1);
        pointsRules.setPointsAmount(1);
        pointsRules.setUser(userApp);
        pointsRules.setIsDeleted(false);
        pointsRules.setCreatedAt(new Date());
    }

    public void deletePointsRules() {
        setMode("delete");
        try {
            pointsRules = selectedPointsRules;
            pointsRules.setIsDeleted(true);
            pointsRulesDao.updatePointsRules(pointsRules);
            displayMessage("messagesPointsRules", "messages.pointsRules.deleteComplete");
            loadBonus();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void handleFileUpload(FileUploadEvent event) {

        UploadedFile file = event.getFile();
        SecureRandom random = new SecureRandom();
        String randomName = new BigInteger(130, random).toString(32);
        String ext = FilenameUtils.getExtension(file.getFileName());
        String fileName = randomName + '.' + ext;
        if(BonusService.uploadPhoto(file, fileName, ext)) {
            pointsRules.setPhotoLink(fileName);
        }

    }

    public void savePointsRules() {
        Event event = null;
        String msg = "";
        try {
            event = eventDao.getEventById(selectedEvent);
            pointsRules.setEvent(event);

            log.info("mode: " + mode);
            if(mode.equals("edit")) {
                pointsRulesDao.updatePointsRules(pointsRules);
                msg = "messages.pointsRules.editComplete";
            }
            if(mode.equals("add")) {
                pointsRulesDao.savePointsRules(pointsRules);
                msg = "messages.pointsRules.addComplete";
            }
            displayMessage("messagesPointsRules", msg);
            loadBonus();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void activePointsRules() {
        try {
            pointsRules.setIsActive(true);
            pointsRulesDao.updatePointsRules(pointsRules);
            displayMessage("messagesPointsRules", "messages.pointsRules.activeComplete");
            loadBonus();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setLoggedUserApp() {
        FacesContext ctx = FacesContext.getCurrentInstance();
        AdminBean adminBean = (AdminBean) ctx.getApplication().getELResolver()
                .getValue(ctx.getELContext(), null, "op.adminBean");

        try {
            setUserApp(adminBean.getUserLog());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<PointsRules> getPointsRulesList() {
        return pointsRulesList;
    }

    public void setPointsRulesList(List<PointsRules> pointsRulesList) {
        this.pointsRulesList = pointsRulesList;
    }

    public PointsRules getPointsRules() {
        return pointsRules;
    }

    public void setPointsRules(PointsRules pointsRules) {
        this.pointsRules = pointsRules;
    }

    public PointsRules getSelectedPointsRules() {
        return selectedPointsRules;
    }

    public void setSelectedPointsRules(PointsRules selectedPointsRules) {
        this.selectedPointsRules = selectedPointsRules;
    }

    public List<PointsRules> getPointsRulesFiltered() {
        return pointsRulesFiltered;
    }

    public void setPointsRulesFiltered(List<PointsRules> pointsRulesFiltered) {
        this.pointsRulesFiltered = pointsRulesFiltered;
    }

    public Boolean getButtonsPointsRulesDisabled() {
        return buttonsPointsRulesDisabled;
    }

    public void setButtonsPointsRulesDisabled(Boolean buttonsPointsRulesDisabled) {
        this.buttonsPointsRulesDisabled = buttonsPointsRulesDisabled;
    }

    public Integer getSelectedEvent() {
        return selectedEvent;
    }

    public void setSelectedEvent(Integer selectedEvent) {
        this.selectedEvent = selectedEvent;
    }

    public Map<String, Event> getEventMap() {
        return this.eventMap;
    }

    public void setEventMap(Map<String, Event> eventMap) {
        this.eventMap = eventMap;
    }

    public List<SelectItem> getSelectEvent() {
        return selectEvent;
    }

    public void setSelectEvent(List<SelectItem> selectEvent) {
        this.selectEvent = selectEvent;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public UserApp getUserApp() {
        return userApp;
    }

    public void setUserApp(UserApp userApp) {
        this.userApp = userApp;
    }

    public List<PointsRules> getBonusList() {
        return bonusList;
    }

    public void setBonusList(List<PointsRules> bonusList) {
        this.bonusList = bonusList;
    }

    public List<PointsRules> getBonusFiltered() {
        return bonusFiltered;
    }

    public void setBonusFiltered(List<PointsRules> bonusFiltered) {
        this.bonusFiltered = bonusFiltered;
    }

    public PointsRules getSelectedBonus() {
        return selectedBonus;
    }

    public void setSelectedBonus(PointsRules selectedBonus) {
        this.selectedBonus = selectedBonus;
    }

    public Boolean getButtonsBonusDisabled() {
        return buttonsBonusDisabled;
    }

    public void setButtonsBonusDisabled(Boolean buttonsBonusDisabled) {
        this.buttonsBonusDisabled = buttonsBonusDisabled;
    }

    public Integer getViewActive() {
        return viewActive;
    }

    public void setViewActive(Integer viewActive) {
        this.viewActive = viewActive;
    }

    public List<PointsRules> getBonusCompanyActiveList() {
        return bonusCompanyActiveList;
    }

    public void setBonusCompanyActiveList(List<PointsRules> bonusCompanyActiveList) {
        this.bonusCompanyActiveList = bonusCompanyActiveList;
    }

    public List<PointsRules> getBonusCompanyActiveFiltered() {
        return bonusCompanyActiveFiltered;
    }

    public void setBonusCompanyActiveFiltered(List<PointsRules> bonusCompanyActiveFiltered) {
        this.bonusCompanyActiveFiltered = bonusCompanyActiveFiltered;
    }

    public List<PointsRules> getBonusCompanyNoActiveList() {
        return bonusCompanyNoActiveList;
    }

    public void setBonusCompanyNoActiveList(List<PointsRules> bonusCompanyNoActiveList) {
        this.bonusCompanyNoActiveList = bonusCompanyNoActiveList;
    }

    public List<PointsRules> getBonusCompanyNoActiveFiltered() {
        return bonusCompanyNoActiveFiltered;
    }

    public void setBonusCompanyNoActiveFiltered(List<PointsRules> bonusCompanyNoActiveFiltered) {
        this.bonusCompanyNoActiveFiltered = bonusCompanyNoActiveFiltered;
    }

    public Boolean getButtonsBonusCompanyActiveDisabled() {
        return buttonsBonusCompanyActiveDisabled;
    }

    public void setButtonsBonusCompanyActiveDisabled(Boolean buttonsBonusCompanyActiveDisabled) {
        this.buttonsBonusCompanyActiveDisabled = buttonsBonusCompanyActiveDisabled;
    }

    public Boolean getButtonsBonusCompanyNoActiveDisabled() {
        return buttonsBonusCompanyNoActiveDisabled;
    }

    public void setButtonsBonusCompanyNoActiveDisabled(Boolean buttonsBonusCompanyNoActiveDisabled) {
        this.buttonsBonusCompanyNoActiveDisabled = buttonsBonusCompanyNoActiveDisabled;
    }

    public PointsRules getSelectedBonusCompanyActive() {
        return selectedBonusCompanyActive;
    }

    public void setSelectedBonusCompanyActive(PointsRules selectedBonusCompanyActive) {
        this.selectedBonusCompanyActive = selectedBonusCompanyActive;
    }

    public PointsRules getSelectedBonusCompanyNoActive() {
        return selectedBonusCompanyNoActive;
    }

    public void setSelectedBonusCompanyNoActive(PointsRules selectedBonusCompanyNoActive) {
        this.selectedBonusCompanyNoActive = selectedBonusCompanyNoActive;
    }

    public List<SelectItem> getSelectUser() {
        return selectUser;
    }

    public void setSelectUser(List<SelectItem> selectUser) {
        this.selectUser = selectUser;
    }

    public Integer getSelectedUser() {
        return selectedUser;
    }

    public void setSelectedUser(Integer selectedUser) {
        this.selectedUser = selectedUser;
    }

    public List<UserPoints> getUserPointsGrantedBuyList() {
        return userPointsGrantedBuyList;
    }

    public void setUserPointsGrantedBuyList(List<UserPoints> userPointsGrantedBuyList) {
        this.userPointsGrantedBuyList = userPointsGrantedBuyList;
    }

    public List<UserPoints> getUserPointsNoGrantedBuyList() {
        return userPointsNoGrantedBuyList;
    }

    public void setUserPointsNoGrantedBuyList(List<UserPoints> userPointsNoGrantedBuyList) {
        this.userPointsNoGrantedBuyList = userPointsNoGrantedBuyList;
    }

    public UserPoints getSelectedUserPointsGrantedBuy() {
        return selectedUserPointsGrantedBuy;
    }

    public void setSelectedUserPointsGrantedBuy(UserPoints selectedUserPointsGrantedBuy) {
        this.selectedUserPointsGrantedBuy = selectedUserPointsGrantedBuy;
    }

    public UserPoints getSelectedUserPointsNoGrantedBuy() {
        return selectedUserPointsNoGrantedBuy;
    }

    public void setSelectedUserPointsNoGrantedBuy(UserPoints selectedUserPointsNoGrantedBuy) {
        this.selectedUserPointsNoGrantedBuy = selectedUserPointsNoGrantedBuy;
    }

    public UserPoints getUserPoints() {
        return userPoints;
    }

    public void setUserPoints(UserPoints userPoints) {
        this.userPoints = userPoints;
    }

    public Boolean getButtonsUserPointsGrantedBuyDisabled() {
        return buttonsUserPointsGrantedBuyDisabled;
    }

    public void setButtonsUserPointsGrantedBuyDisabled(Boolean buttonsUserPointsGrantedBuyDisabled) {
        this.buttonsUserPointsGrantedBuyDisabled = buttonsUserPointsGrantedBuyDisabled;
    }

    public Boolean getButtonsUserPointsNoGrantedBuyDisabled() {
        return buttonsUserPointsNoGrantedBuyDisabled;
    }

    public void setButtonsUserPointsNoGrantedBuyDisabled(Boolean buttonsUserPointsNoGrantedBuyDisabled) {
        this.buttonsUserPointsNoGrantedBuyDisabled = buttonsUserPointsNoGrantedBuyDisabled;
    }

    public List<SelectItem> getSelectBonuses() {
        return selectBonuses;
    }

    public void setSelectBonuses(List<SelectItem> selectBonuses) {
        this.selectBonuses = selectBonuses;
    }

    public Integer getSelectedBonuses() {
        return selectedBonuses;
    }

    public void setSelectedBonuses(Integer selectedBonuses) {
        this.selectedBonuses = selectedBonuses;
    }

    public UserApp getUserRanking() {
        return userRanking;
    }

    public void setUserRanking(UserApp userRanking) {
        this.userRanking = userRanking;
    }

    public List<UserApp> getUserRankingList() {
        return userRankingList;
    }

    public void setUserRankingList(List<UserApp> userRankingList) {
        this.userRankingList = userRankingList;
    }

    public List<UserPoints> getUserPointsGrantedBuyFiltered() {
        return userPointsGrantedBuyFiltered;
    }

    public void setUserPointsGrantedBuyFiltered(List<UserPoints> userPointsGrantedBuyFiltered) {
        this.userPointsGrantedBuyFiltered = userPointsGrantedBuyFiltered;
    }

    public List<UserPoints> getUserPointsNoGrantedBuyFiltered() {
        return userPointsNoGrantedBuyFiltered;
    }

    public void setUserPointsNoGrantedBuyFiltered(List<UserPoints> userPointsNoGrantedBuyFiltered) {
        this.userPointsNoGrantedBuyFiltered = userPointsNoGrantedBuyFiltered;
    }

}
