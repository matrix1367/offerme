package pl.op.web.beans;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.op.dao.EmailDao;
import pl.op.dao.NewsletterDao;
import pl.op.dao.UserDao;
import pl.op.model.dict.Email;
import pl.op.model.newsletter.Newsletter;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

@Name("op.mailingBean")
@Scope(ScopeType.SESSION)
public class MailingBean implements Serializable {

    private static final long serialVersionUID = 3816743076622929715L;
    private Logger log = LoggerFactory.getLogger(NewsletterBean.class);

    private NewsletterDao newsletterDao;
    private EmailDao emailDao;
    
    private List<String> category;
    private String selectCategory;

    private List<Newsletter> newsletters;
    private Newsletter newsletter;

   // private MessageBean messageBean;
    String progress;
    Boolean isSend = false;

    public MailingBean() {
        log.info("MailingBean constructor");
        initialize();
    }

    public void initialize() {
        newsletterDao = GuiceSingleton.getInstance().getInstance(NewsletterDao.class);
        emailDao = GuiceSingleton.getInstance().getInstance(EmailDao.class);
        
       
    }

    public List<String> getCategory() {
        return category;
    }

    public void setCategory(List<String> category) {
        this.category = category;
    }

    public String getSelectCategory() {
        return selectCategory;
    }

    public void setSelectCategory(String selectCategory) {
        this.selectCategory = selectCategory;
    }
    
    

    public String getProgress() {
        return progress;
    }

    public void setProgress(String progress) {
        this.progress = progress;
    }

    public void searchMailing() {
        try {
            newsletters = newsletterDao.getMailing();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Newsletter> getNewsletters() {
        return newsletters;
    }

    public void setNewsletters(List<Newsletter> newsletters) {
        this.newsletters = newsletters;
    }
    
    public void stopSending() {
        isSend = false;
    }

    public String saveMailing() {
        final MailBean mailBean = ComponentLookup.lookupComponent("op.mailBean");
        if ("".equals(selectCategory)) return "mailBox"; //todo doac komunikat
        try {
            newsletter.setCreatedAt(new Date());
            newsletter.setType(2);
            
            newsletterDao.saveNewsletter(newsletter);

            isSend = true;
            new Thread() {
                @Override
                public void run() {                    
                    try {
                        Integer countEmails = emailDao.getEmailMaxId(selectCategory);                        
                        int split = 0;
                        int splitMax;
                        int count = 0;
                        while (split < countEmails && isSend) {                            
                            if (split + 100 > countEmails) {
                                splitMax = countEmails; 
                            } else {
                                splitMax = split + 100;
                            }                            
                            List<Email> emailsTemp = emailDao.getEmailListPart(split, splitMax,selectCategory);
                            
                            if (emailsTemp.size() > 0) {                                
                                count+= emailsTemp.size();
                                mailBean.sendMailingEmail(emailsTemp, newsletter);
                                progress = "Wysłano : " + count ;
                            }
                            split += 100;
                        }

                    } catch (Exception e) {
                        log.error("[saveMailing] thrade is errore:"+ e.toString());
                    }

                }
            }.start();
/*
            List<Email> emails = emailDao.getEmailList();
            int split = 0;

            while (split < emails.size()) {
                int splitMax = 0;
                if (split + 100 > emails.size()) {
                    splitMax = emails.size();
                } else {
                    splitMax = split + 100;
                }
                List<Email> emailsTemp = emails.subList(split, splitMax);
                mailBean.sendMailingEmail(emailsTemp, newsletter);
                split += 100;
            }
*/
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }

        searchMailing();

        return "mailBox";
    }

    public String cancelsaveMailing() {
        // messageBean.refreshInboxMessageList();
        //messageBean.refreshOutboxMessageList();
        searchMailing();

        return "mailBox";
    }

    public void initializeNewsletter() {
        newsletter = new Newsletter();
        try {
            category = emailDao.getCategory();
        } catch (Exception ex) {
            log.error("initializeNewsletter:" + ex.toString());
        }
    }

    public Newsletter getNewsletter() {
        return newsletter;
    }

    public void setNewsletter(Newsletter newsletter) {
        this.newsletter = newsletter;
    }
}
