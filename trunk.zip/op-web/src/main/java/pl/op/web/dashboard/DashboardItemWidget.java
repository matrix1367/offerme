package pl.op.web.dashboard;

public class DashboardItemWidget implements DashboardItemWidgetInterface {

	@Override
	public String getContent() {
		// TODO Auto-generated method stub
		return null;
	}

}
