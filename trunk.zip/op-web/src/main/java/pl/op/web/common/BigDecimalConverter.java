package pl.op.web.common;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;
import javax.faces.convert.NumberConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.faces.util.MessageFactory;

@FacesConverter(value = "op.BigDecimalConverter")
public class BigDecimalConverter extends NumberConverter {

	private Logger log = LoggerFactory.getLogger(BigDecimalConverter.class);
	
	@Override
	public Object getAsObject(FacesContext facesContext,
			UIComponent uiComponent, String value) {
		
		log.debug("->>>>>>>>>>>>>>>> BigDecimalConverter.getAsObject().value = " + value);
		
		if (value == null || "".equals(value)) {
			return null;
		}
		
		Number result = null;
		
		if(value!=null){
			if(value.trim().length()>0){
				int i = value.indexOf(".");
				if(i!=-1){
					value = value.replace('.',',');
				}
			}
			
		} 
		
		DecimalFormat parser = (DecimalFormat) NumberFormat
				.getNumberInstance(facesContext.getViewRoot().getLocale());
		
		DecimalFormatSymbols custom = new DecimalFormatSymbols();
		custom.setDecimalSeparator(',');
		custom.setGroupingSeparator(' ');
		parser.setDecimalFormatSymbols(custom);
		
		value = value.replaceAll(" ", "").replaceAll(
				"" + parser.getDecimalFormatSymbols().getGroupingSeparator(),
				"");
		
		parser.setMaximumFractionDigits(2);
		try {
			if (!value.matches("^[0-9]+([,.][0-9]{1,})?$"))
				throw new Exception();
			result = parser.parse(value);
		} catch (Exception e) {
			throw new ConverterException(MessageFactory.getMessage(facesContext
					.getExternalContext().getRequestLocale(),
					"incorrect.value", new Object[] {}));
		}
		return new BigDecimal(result.doubleValue());
	}

	@Override
	public String getAsString(FacesContext facesContext,
			UIComponent uiComponent, Object value) {
		
		log.debug("->>>>>>>>>>>>>>>> BigDecimalConverter.getAsString().value = " + value);
		
		Number result = (Number) value;
		NumberFormat parser = NumberFormat.getNumberInstance(facesContext
				.getViewRoot().getLocale());
		parser.setMaximumFractionDigits(2);
		parser.setMinimumFractionDigits(2);
		return parser.format(result);
	}

	
}
