package pl.op.web.beans.dictionary;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.MeterModelDao;
import pl.op.model.dict.MeterModel;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class MeterModelBean. This class manages the meter models. Can
 * add/edit/delete data from database table named "tb_metermodel".
 */
@Name("op.meterModelBean")
@Scope(ScopeType.SESSION)
public class MeterModelBean implements Serializable{

	private static final long serialVersionUID = 7904163544673668734L;

	private Logger log = LoggerFactory.getLogger(MeterModelBean.class);

	private List<MeterModel> meterModelsList;
	private MeterModel newMeterModel;
	private MeterModel selectedMeterModel;

	private boolean edit;
	private boolean disableShow = true;
	private boolean disableEdit = true;
	private boolean disableRemove = true;

	private MeterModelDao meterModelDao;
	
	public MeterModelBean() {
		log.info("MeterModelBean constructor");
		initialize();
	}
	
	/**
	 * Initialize the MeterModelBean.
	 */
	private void initialize() {
		notAvailableAction();
		
		meterModelDao = GuiceSingleton.getInstance().getInstance(MeterModelDao.class);
		
		meterModelsList = new ArrayList<MeterModel>();
	}	
	
	/**
	 * Downloads meter models from database and prepares list for display.
	 */
	public void refreshMeterModelList() {
		try {
			meterModelsList = meterModelDao.getMeterModels();
		} catch (Exception e) {
			log.error("error while getting meterModels: ", e);
		}
	}

	/**
	 * Prepares the data for XHTML template to add new meter model.
	 *
	 * @return the string
	 */
	public String addMeterModel() {
		edit = false;
		selectedMeterModel = new MeterModel();
		newMeterModel = new MeterModel();
		return "modelMeters";
	}

	/**
	 * Cancel add meter model.
	 *
	 * @return the string
	 */
	public String cancelAddMeterModel() {
		notAvailableAction();
		return "dictionaries";
	}

	/**
	 * Saves meter model defined in XHTML template.
	 *
	 * @return the string
	 */
	public String saveMeterModel() {
		try {
			if (edit) {
				meterModelDao.updateMeterModel(selectedMeterModel);
			} else {
				meterModelDao.saveMeterModel(newMeterModel);
			}
		} catch (Exception e) {
			log.error("Error while saveMeterModel: ", e);
		}
		refreshMeterModelList();
		return "dictionaries";
	}

	/**
	 * Deletes meter model form database.
	 */
	public void deleteMeterModel() {
		try {
			meterModelDao.deleteMeterModel(selectedMeterModel);
		} catch (Exception e) {
			log.error("Error while deleteMeterModel: ", e);
		}
		refreshMeterModelList();
		notAvailableAction();
	}

	/**
	 * Edits the meter model selected from XHTML template.
	 *
	 * @return the string
	 */
	public String editMeterModel() {
		edit = true;
		newMeterModel = selectedMeterModel;
		return "modelMeters";
	}
	
	/**
	 * On row select dictionaries list.
	 *
	 * @param event the event
	 */
	public void onRowSelectDictionariesList(SelectEvent event) {
		availableAction();
	}

	/**
	 * On row unselect dictionaries list.
	 *
	 * @param event the event
	 */
	public void onRowUnselectDictionariesList(UnselectEvent event) {
		notAvailableAction();
	}

	/**
	 * Activates if action on selected element is available.
	 */
	public void availableAction() {
		disableShow = false;
		disableEdit = false;
		disableRemove = false;
	}

	/**
	 * Activates if action on selected element is not available.
	 */
	public void notAvailableAction() {
		selectedMeterModel = new MeterModel();
		
		disableShow = true;
		disableEdit = true;
		disableRemove = true;
	}
	
	public MeterModel getNewMeterModel() {
		return newMeterModel;
	}

	public void setNewMeterModel(MeterModel newMeterModel) {
		this.newMeterModel = newMeterModel;
	}
	
	public List<MeterModel> getMeterModelsList() {
		return meterModelsList;
	}

	public void setMeterModelsList(List<MeterModel> meterModelsList) {
		this.meterModelsList = meterModelsList;
	}
	
	public MeterModel getSelectedMeterModel() {
		return selectedMeterModel;
	}

	public void setSelectedMeterModel(MeterModel selectedMeterModel) {
		this.selectedMeterModel = selectedMeterModel;
	}
	
	public boolean isDisableShow() {
		return disableShow;
	}

	public void setDisableShow(boolean disableShow) {
		this.disableShow = disableShow;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}

	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}
}