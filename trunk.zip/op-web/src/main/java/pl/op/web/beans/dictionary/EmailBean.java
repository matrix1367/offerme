/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.op.web.beans.dictionary;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.primefaces.model.UploadedFile;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.EmailDao;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Email;
import pl.op.web.listener.GuiceSingleton;

/**
 *
 * @author dev
 */
@Name("op.emailBean")
@Scope(ScopeType.SESSION)
public class EmailBean implements Serializable {

    private static final long serialVersionUID = 3089977328308014054L;

    private Logger log = LoggerFactory.getLogger(EmailBean.class);
    private boolean edit;
    private boolean disableRemove = true;
    private boolean disableEdit = true;

    private Email newEmail;
    private Email filtrEmail;

    private EmailDao emailDao;

    private List<Email> emailList;
    private Email selectedEmail;

    private UploadedFile file;

    public Email getFiltrEmail() {
        return filtrEmail;
    }

    public void setFiltrEmail(Email filtrEmail) {
        this.filtrEmail = filtrEmail;
    }
        

    public UploadedFile getFile() {
        return file;
    }

    public void setFile(UploadedFile file) {
        this.file = file;
    }
    
    	/**
	 * Search city by name in database.
	 */
	public void searchEmail() {
		try {
                    log.info(">>>>>>"+filtrEmail.getEmail());
			emailList = emailDao.getEmailByFiltr(filtrEmail);
                        log.info("size list email ::: " + emailList.size());
		} catch (Exception e) {
			log.error("Error while searchEmail: ", e);
		}
	}

	/**
	 * Cleans city search.
	 */
	public void cleanEmailSearch() {
		filtrEmail  = new Email();
                filtrEmail.setEmail("");
		filtrEmail.setRemoved(false);

		try {
			//citiesList = cityDao.getCitiesList();
		} catch (Exception e) {
			log.error("Error while searchCity: ", e);
		}
	}

    public void read() {
        try {
            if (file != null) {
                if ("".equals(newEmail.getCategory())) newEmail.setCategory("main");
                BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputstream()));
                String line;
                while ((line = br.readLine()) != null) {
                    newEmail.setEmail(line);
                    newEmail.setRemoved(false);
                    emailDao.saveEmail(newEmail);
                }

                br.close();
                file = null;
            } else {
                log.info("file is null");
            }

        } catch (Exception e) {
            log.error("Exception read:" + e.toString());
        }
    }

    public List<Email> getEmailList() {
        return emailList;
    }

    public void setEmailList(List<Email> emailList) {
        this.emailList = emailList;
    }

    public Email getSelectedEmail() {
        return selectedEmail;
    }

    public void setSelectedEmail(Email selectedEmail) {
        this.selectedEmail = selectedEmail;
    }

    public EmailBean() throws Exception {
        log.info("EmailBean constructor");
        initialize();
    }

    private void initialize() throws Exception {
        emailDao = GuiceSingleton.getInstance().getInstance(EmailDao.class);
        emailList = emailDao.getEmailList();
        newEmail = new Email();
        filtrEmail = new Email();

    }

    public void refreshEmailsList() throws Exception {
       // emailList = emailDao.getEmailList();
        emailList = new ArrayList<Email>();
        notAvailableAction();
    }
    
    public void desactive() throws Exception {
        if (selectedEmail != null && selectedEmail.getEmailId() != null) {
            selectedEmail.setRemoved(!selectedEmail.getRemoved());
            emailDao.updateEmail(selectedEmail);
        }
    }

    /**
     * Prepares the data for XHTML template to add new Email
     *
     * @return the string
     */
    public String addEmail() {
        edit = false;
        selectedEmail = new Email();
        newEmail = new Email();
        newEmail.setRemoved(false);

        return "emails";
    }

    /**
     * Cancel add email.
     *
     * @return the string
     */
    public String cancelAddEmail() {
        notAvailableAction();
        //refreshCitiesList();
        return "dictionaries";
    }

    /**
     * Saves city defined in XHTML template.
     *
     * @return the string
     */
    public String saveEmail() throws Exception {
        try {
            if (edit) {
                emailDao.updateEmail(selectedEmail);
            } else {

                emailDao.saveEmail(newEmail);
            }
        } catch (Exception e) {
            log.error("Error while saveEmail: ", e);
        }

        refreshEmailsList();
        return "dictionaries";
    }

    public boolean isDisableRemove() {
        return disableRemove;
    }

    public boolean getDisableRemove() {
        return disableRemove;
    }

    public void setDisableRemove(boolean disableRemove) {
        this.disableRemove = disableRemove;
    }

    public Email getNewEmail() {
        return newEmail;
    }

    public void setNewEmail(Email newEmail) {
        this.newEmail = newEmail;
    }

    public boolean isDisableEdit() {
        return disableEdit;
    }

    public boolean getDisableEdit() {
        return disableEdit;
    }

    public void setDisableEdit(boolean disableEdit) {
        this.disableEdit = disableEdit;
    }

    /**
     * On row select dictionaries list.
     *
     * @param event the event
     */
    public void onRowSelectDictionariesList(SelectEvent event) {
        availableAction();
    }

    /**
     * On row unselect dictionaries list.
     *
     * @param event the event
     */
    public void onRowUnselectDictionariesList(UnselectEvent event) {
        notAvailableAction();
    }

    /**
     * Activates if action on selected element is available.
     */
    public void availableAction() {
        //disableShow = false;
        disableEdit = false;
        disableRemove = false;
    }

    /**
     * Activates if action on selected element is not available.
     */
    public void notAvailableAction() {
        selectedEmail = new Email();

        //disableShow = true;
        disableEdit = true;
        disableRemove = true;
    }

    public String editEmail() {
        edit = true;
        newEmail = selectedEmail;
        return "emails";
    }

    public void deleteEmail() {
        try {
            emailDao.deleteEmail(selectedEmail);
            refreshEmailsList();
            notAvailableAction();
        } catch (Exception e) {
            log.error("Error while deleteEmail ", e);
        }

    }
}
