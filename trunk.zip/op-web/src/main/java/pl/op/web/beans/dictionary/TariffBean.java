package pl.op.web.beans.dictionary;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.PriceComponentDao;
import pl.op.dao.TariffDao;
import pl.op.model.auction.PriceComponent;
import pl.op.model.dict.Tariff;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class TariffBean. This class manages the tariffs. Can
 * add/edit/delete data from database table named "tb_tariff".
 */
@Name("op.tariffBean")
@Scope(ScopeType.SESSION)
public class TariffBean implements Serializable {

	private static final long serialVersionUID = -6279643205980539654L;

	private Logger log = LoggerFactory.getLogger(TariffBean.class);

	private List<Tariff> tariffsList;
	private List<SelectItem> tariffSelectList;
	private Tariff newTariff;
	private Tariff selectedTariff;
	private List<PriceComponent> priceComponent;
	private List<Integer> priceComponentsIdList;
	private List<Integer> selectedPriceComponentsIdList;

	private boolean edit;

	private String tariffPriceComponents;

	private boolean disableShow = true;
	private boolean disableEdit = true;
	private boolean disableRemove = true;

	private TariffDao tariffDao;
	private PriceComponentDao priceComponentDao;

	public TariffBean() {
		log.info("TariffBean constructor");
		initialize();
	}

	/**
	 * Initialize the TariffBean.
	 */
	private void initialize() {
		notAvailableAction();

		tariffDao = GuiceSingleton.getInstance().getInstance(TariffDao.class);
		priceComponentDao = GuiceSingleton.getInstance().getInstance(
				PriceComponentDao.class);

		tariffsList = new ArrayList<Tariff>();
		priceComponentsIdList = new ArrayList<Integer>();
		selectedPriceComponentsIdList = new ArrayList<Integer>();
		newTariff = new Tariff();
	}

	/**
	 * Filling tariffs select list.
	 */
	private void fillSelectTariff() {
		tariffSelectList = new ArrayList<SelectItem>();
		try {
			for (Tariff item : tariffsList) {
				tariffSelectList.add(new SelectItem(item.getTariffId(), item
						.getTariffName()));
				log.debug("Tariff ID: " + item.getTariffId());
				log.debug("Tariff Name: " + item.getTariffName());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Downloads tariffs from database and prepares list for display.
	 */
	public void refreshTariffList() {
		try {
			tariffsList = tariffDao.getTariffs(new Tariff());
			fillSelectTariff();
		} catch (Exception e) {
			log.error("error while getting tariffs: ", e);
		}
	}

	/**
	 * Shows price components that is assigned to tariff
	 * 
	 * @param tariff
	 *            the tariff
	 * @return the string
	 */
	public String priceComponentsAssignedToTariff(Tariff tariff) {
		tariffPriceComponents = "";

		for (PriceComponent priceComponent : tariff.getPriceComponents()) {
			tariffPriceComponents += "\u25CF " + priceComponent.getName()
					+ "<br/>";
			log.debug("Price Component Name: " + priceComponent.getName());
		}
		return tariffPriceComponents;
	}

	/**
	 * Prepares the data for XHTML template to add new tariff.
	 * 
	 * @return the string
	 */
	public String addTariff() {
		edit = false;
		selectedTariff = new Tariff();
		newTariff = new Tariff();
		try {
			priceComponent = priceComponentDao.getPriceComponent();
		} catch (Exception e) {
			log.error("Error while getting Price component by Tariff: ", e);
			e.printStackTrace();
		}
		refreshTariffList();
		return "tariffs";
	}

	/**
	 * Cancel add tariff.
	 * 
	 * @return the string
	 */
	public String cancelAddTariff() {
		notAvailableAction();
		refreshTariffList();
		return "dictionaries";
	}

	/**
	 * Saves tariff defined in XHTML template.
	 * 
	 * @return the string
	 */
	public String saveTariff() {
		try {
			if (edit) {
				tariffDao.updateTariff(selectedTariff, priceComponentsIdList,
						selectedPriceComponentsIdList);
			} else {
				tariffDao.saveTariff(newTariff, priceComponentsIdList);
			}
		} catch (Exception e) {
			log.error("Error while saveTariff: ", e);
		}
		refreshTariffList();
		priceComponentsIdList.clear();
		selectedPriceComponentsIdList.clear();
		return "dictionaries";
	}

	/**
	 * Deletes tariff form database.
	 */
	public void deleteTariff() {
		try {
			tariffDao.deleteTariff(selectedTariff);
		} catch (Exception e) {
			log.error("Error while deleteTariff: ", e);
		}
		refreshTariffList();
		notAvailableAction();
	}

	/**
	 * Edits the tariff selected from XHTML template.
	 * 
	 * @return the string
	 */
	public String editTariff() {
		edit = true;
		newTariff = selectedTariff;
		for (int i = 0; i < selectedTariff.getPriceComponents().size(); i++) {
			selectedPriceComponentsIdList.add(selectedTariff
					.getPriceComponents().get(i).getPriceComponentId());
			log.debug("Price Component ID: "
					+ selectedTariff.getPriceComponents().get(i)
							.getPriceComponentId());
		}

		priceComponentsIdList = selectedPriceComponentsIdList;
		refreshTariffList();
		try {
			priceComponent = priceComponentDao.getPriceComponent();
		} catch (Exception e) {
			log.error("Error while getting Price component by Tariff: ", e);
			e.printStackTrace();
		}
		log.info("priceComponentList.size " + priceComponent.size());
		return "tariffs";
	}

	/**
	 * On row select dictionaries list.
	 * 
	 * @param event
	 *            the event
	 */
	public void onRowSelectDictionariesList(SelectEvent event) {
		availableAction();
	}

	/**
	 * On row unselect dictionaries list.
	 * 
	 * @param event
	 *            the event
	 */
	public void onRowUnselectDictionariesList(UnselectEvent event) {
		notAvailableAction();
	}

	/**
	 * Activates if action on selected element is available.
	 */
	public void availableAction() {
		disableShow = false;
		disableEdit = false;
		disableRemove = false;
	}

	/**
	 * Activates if action on selected element is not available.
	 */
	public void notAvailableAction() {
		selectedTariff = new Tariff();

		disableShow = true;
		disableEdit = true;
		disableRemove = true;
	}

	public Tariff getNewTariff() {
		return newTariff;
	}

	public void setNewTariff(Tariff newTariff) {
		this.newTariff = newTariff;
	}

	public List<Tariff> getTarrifsList() {
		return tariffsList;
	}

	public void setTarrifsList(List<Tariff> tarrifsList) {
		this.tariffsList = tarrifsList;
	}

	public Tariff getSelectedTariff() {
		return selectedTariff;
	}

	public void setSelectedTariff(Tariff selectedTariff) {
		this.selectedTariff = selectedTariff;
	}

	public boolean isDisableShow() {
		return disableShow;
	}

	public void setDisableShow(boolean disableShow) {
		this.disableShow = disableShow;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}

	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}

	public List<SelectItem> getTariffSelectList() {
		return tariffSelectList;
	}

	public void setTariffSelectList(List<SelectItem> tariffSelectList) {
		this.tariffSelectList = tariffSelectList;
	}

	public List<PriceComponent> getPriceComponent() {
		return priceComponent;
	}

	public void setPriceComponent(List<PriceComponent> priceComponent) {
		this.priceComponent = priceComponent;
	}

	public String getTariffPriceComponents() {
		return tariffPriceComponents;
	}

	public void setTariffPriceComponents(String tariffPriceComponents) {
		this.tariffPriceComponents = tariffPriceComponents;
	}

	public List<Integer> getPriceComponentsIdList() {
		return priceComponentsIdList;
	}

	public void setPriceComponentsIdList(List<Integer> priceComponentsIdList) {
		this.priceComponentsIdList = priceComponentsIdList;
	}
}