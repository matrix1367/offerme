package pl.op.web.beans.dynamicText;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.DynamicTextDao;
import pl.op.dynamicText.DynamicText;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

@Name("op.dynamicTextBean")
@Scope(ScopeType.SESSION)
public class DynamicTextBean implements Serializable {

	private static final long serialVersionUID = -8760076414560548708L;
	
	private Logger log = LoggerFactory.getLogger(DynamicTextBean.class);
	
	private List<DynamicText> dynamicTextList;
	private DynamicText selectedDynamicText;

	// buttons disable
	private boolean disableEdit = true;
	private boolean disableRemove = true;
	
	private DynamicTextDao dynamicTextDao;
	
	private DictionaryBean dictionaryBean;
	
	public DynamicTextBean () {
		log.info("dynamicTextBean Constructor");
		initialize();
	}
	
	private void initialize () {
		notAvailableAction();
		dynamicTextDao = GuiceSingleton.getInstance().getInstance(DynamicTextDao.class);
		dictionaryBean = ComponentLookup.lookupComponent("op.dictionaryBean");
		
		dynamicTextList = new ArrayList<DynamicText>();
	}
	
	private void prepareDynamicTextList(){
		try {
			dynamicTextList = dynamicTextDao.getDynamicTextList(new DynamicText());
		} catch (Exception e) {
			log.error("Error while getting DynamicTextList : ",e);
			e.printStackTrace();
		}
	}
	
	public void refreshDynamicTextList(){
		prepareDynamicTextList();
	}
	
	public String saveDynamicText() {
		log.info("saveDynamicText");
		try {
			dynamicTextDao.updateDynamicText(selectedDynamicText);
			if(selectedDynamicText.getDynamicTextType().equals("auctionDurationDays")) {
				dictionaryBean.refreshAuctionDurationDays();
			}
		} catch (Exception e) {
			log.error("Error while saveDynamicText : ",e);
			e.printStackTrace();
		}
		prepareDynamicTextList();
		return "banerList";
	}
	
	public String cancelEditDynamicText() {
		notAvailableAction();
		return "dynamicTextList";
	}
	
	public String editDynamicText() {
		return "dynamicTextEdit";
	}
	
	public void onRowSelectDynamicTextList(SelectEvent event) {
		availableAction();
	}
	
	public void onRowUnselectDynamicTextList(UnselectEvent event) {
		notAvailableAction();
	}
	
	public void availableAction() {
		disableEdit = false;
		disableRemove = false;
	}
	
	public void notAvailableAction() {
		selectedDynamicText = new DynamicText();
		
		disableEdit = true;
		disableRemove = true;
	}

	public List<DynamicText> getDynamicTextList() {
		return dynamicTextList;
	}

	public void setDynamicTextList(List<DynamicText> dynamicTextList) {
		this.dynamicTextList = dynamicTextList;
	}

	public DynamicText getSelectedDynamicText() {
		return selectedDynamicText;
	}

	public void setSelectedDynamicText(DynamicText selectedDynamicText) {
		this.selectedDynamicText = selectedDynamicText;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}

	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}
}