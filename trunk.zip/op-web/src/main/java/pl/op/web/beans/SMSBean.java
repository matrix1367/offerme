package pl.op.web.beans;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import javax.faces.context.FacesContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import pl.op.dao.SMSDao;
import pl.op.dao.UserDao;
import pl.op.model.sms.SMS;
import pl.op.model.sms.SMSTemplate;
import pl.op.model.user.UserApp;
import pl.op.smsapi.SMSAPIGate;
import pl.op.smsapi.TextMessage;
import pl.op.web.exception.SMSException;
import pl.op.web.listener.GuiceSingleton;

@Name("op.smsBean")
@Scope(ScopeType.SESSION)
public class SMSBean {
	/**
	 * domyślny język dla template'ów
	 */
	private final static String DEFAULT_LANGUAGE = "pl";
	private final static Integer MAX_TRIALS = 3;

	private Logger log = LoggerFactory.getLogger(SMSBean.class);

	private SMSDao smsDao;
	private UserDao userDao;
	
	private FacesContext facesContext;
	
	private SMSAPIGate gate;
	private UserApp userApp;
	
	public SMSBean() {
		log.info("SMSBean constructor");
		smsDao = GuiceSingleton.getInstance().getInstance(SMSDao.class);
		userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);
		gate = SMSAPIGate.getDefault();
	}
	
	/**
	 * Sends text SMS to current logged-in user
	 * @param	templateName	template name that should be applied (it has to be already in the database); if null or empty, the general, default template is applied ('text') with nothing but one parameter
	 * @param	data			the array of String parameters (content) that should be input to the template (e.g. date)
	 * @return sent SMS
	 */
	public SMS sendText(String templateName, String[] data) throws Exception {
		facesContext  = FacesContext.getCurrentInstance();
		AdminBean adminBean = (AdminBean) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "adminBean");
        userApp = adminBean.getUserLog();
        if(userApp!=null) {
    		userApp = userDao.getUserByLogin(userApp.getLogin());
        }
        return sendText(userApp, templateName, data);
	}
	
	/**
	 * Sends text SMS to given user
	 * @param	templateName	template name that should be applied (it has to be already in the database); if null or empty, the general, default template is applied ('text') with nothing but one parameter
	 * @param	data			the array of String parameters (content) that should be input to the template (e.g. date)
	 * @param	userApp			user to which the text should be sent
	 * @return sent SMS
	 */
	public SMS sendText(UserApp userApp, String templateName, String[] data) throws Exception {
		Long id = null;

//czy type powinien byc parametrem?
//		if(type==null || type.isEmpty())
//			type="text";
		
		//Check if there's no error...
		
		//TODO czy mogą być wysyłane SMSy bez parametrów?
//		if(data==null || data.length==0)
//			throw new SMSException("No SMS data.");
		
		if(userApp==null) {
			throw new SMSException("No ogarniamPrad user.");
		}
		if(userApp.getPhoneActivated()==null || userApp.getPhoneActivated().booleanValue()==false || userApp.getPhone().isEmpty())
			throw new SMSException("User has no phone number activated.");
		
		if(templateName==null || templateName.isEmpty())
			templateName="text";
		
		SMSTemplate smsTemplate = smsDao.getSMSTemplateByName(templateName, Locale.getDefault().getLanguage());
		if(smsTemplate==null)
			smsTemplate = smsDao.getSMSTemplateByName(templateName, DEFAULT_LANGUAGE);
		if(smsTemplate==null)
			throw new SMSException("No such template.");
		//...end check
		
		String text = smsTemplate.getMessageFromTemplate(data);
		if(text==null || text.isEmpty())
			throw new SMSException("Empty SMS.");
		
		TextMessage msg = new TextMessage(text);
		gate.sendTextMessage(userApp.getPhone(), msg);

		SMS sms = new SMS();
		sms.setSendTime(new Date());
		sms.setSmsPhoneNumber(userApp.getPhone());
		sms.setSmsType("text");
		sms.setSmsTemplateId(templateName);
		sms.setSmsData(arrayToString(data,";"));
		sms.setSmsSendStatus("sent");
		sms.setUserApp(userApp);
		sms.setOperationType(smsDao.getSMSOperationTypeByType("text"));
		
		id = smsDao.saveSMS(sms);		
		
		return smsDao.getSMSById(id);
	}
	
	/**
	 * Sends code SMS to current logged in user
	 * @param	smsOperationType	if null or empty, the general, default operation type is applied ('code') with default template
	 * @return	sent SMS
	 */
	public SMS sendCode(String smsOperationType) throws Exception {
		facesContext  = FacesContext.getCurrentInstance();
		AdminBean adminBean = (AdminBean) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "adminBean");
        userApp = adminBean.getUserLog();
        if(userApp!=null) {
    		userApp = userDao.getUserByLogin(userApp.getLogin());
        }
        return sendCode(userApp, smsOperationType, false);
	}

	/**
	 * Sends code SMS to given user
	 * @param	smsOperationType	if null or empty, the general, default operation type is applied ('code') with default template
	 * @param	userApp				user to which the code should be sent (whose operation should be verified)
	 * @return	sent SMS
	 */
	public SMS sendCode(UserApp userApp, String smsOperationType) throws Exception {
        return sendCode(userApp, smsOperationType, false);
	}
	
	/**
	 * Sends code (may be the first) SMS to given user
	 * @param	smsOperationType			if null or empty, the general, default operation type is applied ('code') with default template
	 * @param	userApp						user to which the code should be sent (whose operation should be verified)
	 * @param   userWithNoPhoneActivated	if true, there's no check if the user has phone number activated
	 * @return	sent SMS
	 */
	public SMS sendCode(UserApp userApp, String smsOperationType, boolean userWithNoPhoneActivated) throws Exception {
		Long id = null;
		
//Check if there's no error...
		//TODO czy mogą być wysyłane SMSy bez parametrów?
//		if(data==null || data.length==0)
//			throw new SMSException("No SMS data.");
		
		if(userApp==null) {
			throw new SMSException("No sm user.");
		}
		if(!userWithNoPhoneActivated && (userApp.getPhoneActivated()==null || userApp.getPhoneActivated().booleanValue()==false || userApp.getPhone().isEmpty()))
			throw new SMSException("User has no phone number activated.");
		
		if(smsOperationType==null || smsOperationType.isEmpty())
			smsOperationType="code";
		
		SMSTemplate smsTemplate = smsDao.getSMSTemplateByName(smsOperationType, Locale.getDefault().getLanguage());
		if(smsTemplate==null)
			smsTemplate = smsDao.getSMSTemplateByName(smsOperationType, DEFAULT_LANGUAGE);
		if(smsTemplate==null)
			throw new SMSException("No such template.");
//...end check
		
		List<Integer> smsCodesUsedToday = smsDao.getSMSCodesTodayByUserAndOperation(userApp, smsOperationType);
		Random generator = new Random();
		Integer smsCode = new Integer(generator.nextInt(89999999)+10000000);
		int i=0;
		while(smsCodesUsedToday.contains(smsCode) && i<10000) {
			smsCode = new Integer(generator.nextInt(89999999)+10000000);
			i = i + 1;
		}
		
		String text = smsTemplate.getMessageFromTemplate(new String[]{smsCode.toString()});
		if(text==null || text.isEmpty())
			throw new SMSException("Empty SMS.");
		
		TextMessage msg = new TextMessage(text);
		gate.sendTextMessage(userApp.getPhone(), msg);

		SMS sms = new SMS();
		sms.setSendTime(new Date());
		sms.setSmsPhoneNumber(userApp.getPhone());
		sms.setSmsType("smscode");
		sms.setSmsTemplateId(smsOperationType);
		sms.setSmsData(smsCode.toString());
		sms.setSmsCode(smsCode);
		sms.setSmsSendStatus("sent");
		sms.setUserApp(userApp);
		sms.setOperationType(smsDao.getSMSOperationTypeByType(smsOperationType));
		sms.setSmsCodeCounter(0);
		
		id = smsDao.saveSMS(sms);
		
		return smsDao.getSMSById(id);
	}
	
	/**
	 * Verifies code from SMS sent to current logged-in user
	 * @param	smsOperationType	if null or empty, the general, default operation type is applied ('code')
	 * @param	smsCode				code input by user to verify
	 * @return	true if the code is correct, false if not
	 */
	public boolean verifyCode(String smsOperationType, Integer smsCode) throws Exception {
		facesContext  = FacesContext.getCurrentInstance();
		AdminBean adminBean = (AdminBean) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "adminBean");
        userApp = adminBean.getUserLog();
        if(userApp!=null) {
    		userApp = userDao.getUserByLogin(userApp.getLogin());
        }
        return verifyCode(userApp, smsOperationType, smsCode);
	}
	
	/**
	 * Verifies code (may be the first) from SMS sent to current logged-in user
	 * @param	smsOperationType	if null or empty, the general, default operation type is applied ('code')
	 * @param	smsCode				code input by user to verify
	 * @param   userWithNoPhoneActivated	if true, there's no check if the user has phone number activated
	 * @return	true if the code is correct, false if not
	 */
	public boolean verifyCode(String smsOperationType, Integer smsCode, boolean userWithNoPhoneActivated) throws Exception {
		facesContext  = FacesContext.getCurrentInstance();
		AdminBean adminBean = (AdminBean) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "adminBean");
        userApp = adminBean.getUserLog();
        if(userApp!=null) {
    		userApp = userDao.getUserByLogin(userApp.getLogin());
        }
        return verifyCode(userApp, smsOperationType, smsCode, userWithNoPhoneActivated);
	}
	
	/**
	 * Verifies code from SMS sent to given user
	 * @param	smsOperationType	if null or empty, the general, default operation type is applied ('code')
	 * @param	smsCode				code input by user to verify
	 * @param	userApp				user to which the code was sent (whose operation is verified)
	 * @return	true if the code is correct, false if not
	 */
	public boolean verifyCode(UserApp userApp, String smsOperationType, Integer smsCode) throws Exception {
        return verifyCode(userApp, smsOperationType, smsCode, false);
	}
	
	/**
	 * Verifies code (may be the first) from SMS sent to given user
	 * @param	smsOperationType	if null or empty, the general, default operation type is applied ('code')
	 * @param	smsCode				code input by user to verify
	 * @param	userApp				user to which the code was sent (whose operation is verified)
	 * @param   userWithNoPhoneActivated	if true, there's no check if the user has phone number activated
	 * @return	true if the code is correct, false if not
	 */
	public boolean verifyCode(UserApp userApp, String smsOperationType, Integer smsCode, boolean userWithNoPhoneActivated) throws Exception {
		if(userApp==null) {
			throw new SMSException("No ogarniamPrad user.");
		}
		if(!userWithNoPhoneActivated && (userApp.getPhoneActivated()==null || userApp.getPhoneActivated().booleanValue()==false || userApp.getPhone().isEmpty()))
			throw new SMSException("User has no phone number activated.");
		
		if(smsOperationType==null || smsOperationType.isEmpty())
			smsOperationType="code";
		
		SMS sms = smsDao.getLastSMSByUserAndOperation(userApp, smsOperationType);
		
		if(sms==null)
			throw new SMSException("User has no sms code for the operation.");
		if(sms.getSmsCodeCounter()==null)
			throw new SMSException("Error.");
		if(sms.getSmsSendStatus().equals("canceled"))
			throw new SMSException("SMS code canceled.");
		if(sms.getSmsSendStatus().equals("verified"))
			throw new SMSException("SMS code already used.");
		
		sms.setSmsCodeCounter(sms.getSmsCodeCounter()+1);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MINUTE, -5);
		if(!sms.getSendTime().after(cal.getTime())) {
			sms.setSmsSendStatus("canceled");
			smsDao.updateSMS(sms);
			throw new SMSException("SMS code canceled (time).");
		}
		if(sms.getSmsCode().equals(smsCode)) {
			sms.setSmsSendStatus("verified");
			smsDao.updateSMS(sms);
			return true;
		}
		if(sms.getSmsCodeCounter()>=MAX_TRIALS) {
			sms.setSmsSendStatus("canceled");
			smsDao.updateSMS(sms);
			throw new SMSException("SMS code canceled (trials).");
		}
		
		smsDao.updateSMS(sms);
		return false;
	}
	
	private String arrayToString(String[] a, String separator) {
	    StringBuffer result = new StringBuffer();
	    if (a.length > 0) {
	        result.append(a[0]);
	        for (int i=1; i<a.length; i++) {
	            result.append(separator);
	            result.append(a[i]);
	        }
	    }
	    return result.toString();
	}
}
