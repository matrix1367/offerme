package pl.op.web.common;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;
import javax.faces.convert.NumberConverter;

import com.sun.faces.util.MessageFactory;

@FacesConverter(value = "op.BigDecimalCurrencyConverter")
public class BigDecimalCurrencyConverter extends NumberConverter {
	
	protected int getFractionDigits() {
		return 2;
	}

	@Override
	public Object getAsObject(FacesContext facesContext,
			UIComponent uiComponent, String value) {
		Number result = null;
		
		if(value!=null){
			if(value.trim().length()>0){
				int i = value.indexOf(".");
				if(i!=-1){
					value = value.replace('.',',');
				}
			}
			
		}
		
		DecimalFormat parser = (DecimalFormat) NumberFormat
				.getNumberInstance(facesContext.getViewRoot().getLocale());
		
		DecimalFormatSymbols custom = new DecimalFormatSymbols();
		custom.setDecimalSeparator(',');
		custom.setGroupingSeparator(' ');
		parser.setDecimalFormatSymbols(custom);
		
		value = value.replaceAll(" ", "").replaceAll(
				"" + parser.getDecimalFormatSymbols().getGroupingSeparator(),
				"");
		
		parser.setMaximumFractionDigits(getFractionDigits());
		try {
			if (!value.matches("^[0-9]+([,.][0-9]{1,"+getFractionDigits()+"})?$"))
				throw new Exception();
			result = parser.parse(value);
		} catch (Exception e) {
			throw new ConverterException(MessageFactory.getMessage(facesContext
					.getExternalContext().getRequestLocale(),
					"incorrect_amount", new Object[] {}));
		}
		return new BigDecimal(result.doubleValue()).setScale(getFractionDigits(),
				BigDecimal.ROUND_HALF_EVEN);
	}

	@Override
	public String getAsString(FacesContext facesContext,
			UIComponent uiComponent, Object value) {
		Number result = (Number) value;
		NumberFormat parser = NumberFormat.getNumberInstance(facesContext
				.getViewRoot().getLocale());
		parser.setMaximumFractionDigits(getFractionDigits());
		parser.setMinimumFractionDigits(getFractionDigits());
		return parser.format(result);
	}

}