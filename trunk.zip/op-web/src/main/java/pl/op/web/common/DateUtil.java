package pl.op.web.common;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.MutableDateTime;
import org.joda.time.ReadableDuration;

import com.google.common.base.Function;
import com.google.common.collect.Iterables;

public class DateUtil {

    private static final Log log = LogFactory.getLog(DateUtil.class);
    private static final int MILLISECONDS_IN_DAY = 1000 * 60 * 60 * 24;

    public enum DateUtilReturn {
        MINUTES, SECONDS, HOURS, DAYS
    };

    public static Integer getDifferenceBetweenDates(Date mainDate, Date secondDate) {
        if (log.isTraceEnabled()) {
            log.trace("Date main: " + mainDate);
            log.trace("Date second: " + secondDate);
        }
        if (mainDate.equals(secondDate))
            return 0;

        if (mainDate.after(secondDate)) {
            Calendar mainDateC = Calendar.getInstance();
            mainDateC.setTime(mainDate);

            Calendar secondDateC = Calendar.getInstance();
            secondDateC.setTime(secondDate);

            int count = 0;

            while (secondDateC.getTime().before(mainDateC.getTime())) {
                count++;
                secondDateC.add(Calendar.DATE, 1);
            }

            return -count;
        } else {

            Calendar mainDateC = Calendar.getInstance();
            mainDateC.setTime(mainDate);

            Calendar secondDateC = Calendar.getInstance();
            secondDateC.setTime(secondDate);

            int count = 0;

            while (mainDateC.getTime().before(secondDateC.getTime())) {
                count++;
                mainDateC.add(Calendar.DATE, 1);
            }

            return count;

        }

    }

    /**
     * 
     * @param date
     * @param pattern
     * @return
     */
    public static String outputDate(Date date, String pattern) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
        return dateFormat.format(date);
    }

    /**
     * Calculates the number of days between start and end dates, taking into
     * consideration leap years, year boundaries etc.
     * 
     * @param start
     *            the start date
     * @param end
     *            the end date, must be later than the start date
     * @return the number of days between the start and end dates
     */
    public static long daysBetween(Date start, Date end) {
        return timeBetween(start, end, DateUtilReturn.DAYS);
    }

    public static long timeBetween(Date start, Date end, DateUtilReturn returnType) {
        if (end.before(start)) {
            throw new IllegalArgumentException("The end date must be later than the start date");
        }

        // reset all hours mins and secs to zero on start date
        Calendar startCal = GregorianCalendar.getInstance();
        startCal.setTime(start);
        if (returnType.equals(DateUtilReturn.DAYS)) {
            startCal.set(Calendar.HOUR_OF_DAY, 0);
            startCal.set(Calendar.MINUTE, 0);
            startCal.set(Calendar.SECOND, 0);
        }
        long startTime = startCal.getTimeInMillis();

        // reset all hours mins and secs to zero on end date
        Calendar endCal = GregorianCalendar.getInstance();
        endCal.setTime(end);
        if (returnType.equals(DateUtilReturn.DAYS)) {
            endCal.set(Calendar.HOUR_OF_DAY, 0);
            endCal.set(Calendar.MINUTE, 0);
            endCal.set(Calendar.SECOND, 0);
        }
        long endTime = endCal.getTimeInMillis();
        if (returnType.equals(DateUtilReturn.DAYS))
            return (endTime - startTime) / (1000 * 60 * 60 * 24);
        else if (returnType.equals(DateUtilReturn.HOURS))
            return (endTime - startTime) / (1000 * 60 * 60);
        else if (returnType.equals(DateUtilReturn.MINUTES))
            return (endTime - startTime) / (1000 * 60);
        else
            return (endTime - startTime) / 1000;
    }

    public static Iterable<Date> createDateRange(final Date start, final Date end) {
        return createDateRange(start, end, Days.ONE.toStandardDuration());
    }

    public static Iterable<Date> createDateRange(final Date start, final Date end, final ReadableDuration interval) {
        return Iterables.transform(createDateRange(DateUtil.valueOf(start), DateUtil.valueOf(end), interval), toDate());
    }

    public static Iterable<DateTime> createDateRange(final DateTime start, final DateTime end) {
        return createDateRange(start, end, Days.ONE.toStandardDuration());

    }

    public static Iterable<DateTime> createDateRange(final DateTime start, final DateTime end,
            final ReadableDuration interval) {
        return new Iterable<DateTime>() {

            @Override
            public Iterator<DateTime> iterator() {

                return new Iterator<DateTime>() {

                    final MutableDateTime current;
                    {
                        current = start.minus(interval).toMutableDateTime();
                    }

                    @Override
                    public void remove() {
                        throw new UnsupportedOperationException();
                    }

                    @Override
                    public DateTime next() {
                        current.add(interval);
                        return current.toDateTime();

                    }

                    @Override
                    public boolean hasNext() {
                        return current.isBefore(end);
                    }
                };
            }
        };
    }

    public static Date today() {
        Calendar nowCalendar = Calendar.getInstance();
        Calendar todayCalendar = Calendar.getInstance();
        todayCalendar.clear();
        todayCalendar.set(Calendar.YEAR, nowCalendar.get(Calendar.YEAR));
        todayCalendar.set(Calendar.MONTH, nowCalendar.get(Calendar.MONTH));
        todayCalendar.set(Calendar.DAY_OF_MONTH, nowCalendar.get(Calendar.DAY_OF_MONTH));
        return todayCalendar.getTime();
    }

    public static Date valueOf(DateTime dateTime) {
        return dateTime.toDate();
    }

    public static DateTime valueOf(Date date) {
        return new DateTime(date.getTime());
    }

    public static Function<DateTime, Date> toDate() {
        return DATE_TIME_TO_DATE_FUNCTION;
    }

    private static final DateTimeToDateFunction DATE_TIME_TO_DATE_FUNCTION = new DateTimeToDateFunction();

    private static final class DateTimeToDateFunction implements Function<DateTime, Date> {
        @Override
        public Date apply(DateTime input) {
            return input.toDate();
        }
    }

}