package pl.op.web.common;

public enum WizardStepEnum {

	STEPONE, STEPTWO, STEPTHREE,STEPFOUR,STEPFIVE,STEPSIX;
	
	private String label;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
}