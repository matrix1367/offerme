package pl.op.web.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.op.dao.NewsletterDao;
import pl.op.dao.UserDao;
import pl.op.model.newsletter.Newsletter;
import pl.op.model.user.UserApp;
import pl.op.web.beans.message.MessageBean;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

@Name("op.newsletterBean")
@Scope(ScopeType.SESSION)
public class NewsletterBean implements Serializable {

    private static final long serialVersionUID = 7816743076622929715L;
    private Logger log = LoggerFactory.getLogger(NewsletterBean.class);

    private NewsletterDao newsletterDao;
    private UserDao userDao;

    private List<Newsletter> newsletters;
    private Newsletter newsletter;

    private MessageBean messageBean;

   

    public NewsletterBean() {
        log.info("NewsletterBean constructor");
        initialize();
    }

    public void initialize() {
        newsletterDao = GuiceSingleton.getInstance().getInstance(
                NewsletterDao.class);
        userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);

        messageBean = ComponentLookup.lookupComponent("op.messageBean");

       
    }

    public void searchNewsletters() {
        try {
            newsletters = newsletterDao.getNewsletters(new Newsletter());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Newsletter> getNewsletters() {
        return newsletters;
    }

    public void setNewsletters(List<Newsletter> newsletters) {
        this.newsletters = newsletters;
    }

    public String saveNewsletter() {
        MailBean mailBean = ComponentLookup.lookupComponent("op.mailBean");

        try {
            newsletter.setCreatedAt(new Date());
            newsletter.setType(1);
            newsletterDao.saveNewsletter(newsletter);

            UserApp userFilter = new UserApp();
            userFilter.setActive(true);
            userFilter.setRemoved(false);
          

            //uzytkownicy ktozy nie dokonczyli rejestracji;
            userFilter.setFirstLogin(newsletter.getIsSendNoRegisterUser());

            List<UserApp> users =  userDao.getAllUserApp(userFilter);
            int split = 0;
            
            while (split < users.size()) 
            {
                int splitMax = 0;
                if (split+100 > users.size()) splitMax = users.size(); else splitMax= split + 100;
                List<UserApp> ueersTemp = users.subList(split, splitMax);
                mailBean.sendNewsletterEmail(ueersTemp, newsletter);
                split+=100;                
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }

        searchNewsletters();

        return "mailBox";
    }

    public String cancelsaveNewsletter() {
        messageBean.refreshInboxMessageList();
        messageBean.refreshOutboxMessageList();
        searchNewsletters();

        return "mailBox";
    }

    public void initializeNewsletter() {
        newsletter = new Newsletter();
    }

    public Newsletter getNewsletter() {
        return newsletter;
    }

    public void setNewsletter(Newsletter newsletter) {
        this.newsletter = newsletter;
    }
}
