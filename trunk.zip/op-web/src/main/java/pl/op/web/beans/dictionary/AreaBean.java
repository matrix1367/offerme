package pl.op.web.beans.dictionary;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import pl.op.dao.AreaDao;
import pl.op.model.dict.Area;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class AreaBean. This class manages the areas of the country. Can
 * add/edit/delete data from database table named "tb_area".
 */
@Name("op.areaBean")
@Scope(ScopeType.SESSION)
public class AreaBean implements Serializable {

	private static final long serialVersionUID = -7459799658787305116L;

	private Logger log = LoggerFactory.getLogger(AreaBean.class);

	private List<Area> areasList;
	private Area newArea;
	private Area selectedArea;
	private Area filterArea;

	private boolean edit;
	private boolean disableShow = true;
	private boolean disableEdit = true;
	private boolean disableRemove = true;

	private AreaDao areaDao;

	public AreaBean() {
		log.info("AreaBean constructor");
		initialize();
	}

	/**
	 * Initialize the AreaBean.
	 */
	private void initialize() {
		notAvailableAction();

		areaDao = GuiceSingleton.getInstance().getInstance(AreaDao.class);

		areasList = new ArrayList<Area>();
		filterArea = new Area();
	}

	/**
	 * Downloads areas from database and prepares list for display.
	 */
	public void refreshAreasList() {
		filterArea = new Area();
		try {
			areasList = areaDao.getAreas(new Area());
		} catch (Exception e) {
			log.error("error while getting areas: ", e);
		}
	}

	/**
	 * Prepares the data for XHTML template to add new Area.
	 * 
	 * @return the string
	 */
	public String addArea() {
		edit = false;
		selectedArea = new Area();
		newArea = new Area();
		return "areas";
	}

	/**
	 * Cancels add area.
	 * 
	 * @return the string
	 */
	public String cancelAddArea() {
		notAvailableAction();
		return "dictionaries";
	}

	/**
	 * Saves area defined in XHTML template.
	 * 
	 * @return the string
	 */
	public String saveArea() {
		try {
			if (edit) {
				areaDao.updateArea(selectedArea);
			} else {
				areaDao.saveArea(newArea);
			}
		} catch (Exception e) {
			log.error("Error while saveArea: ", e);
		}
		refreshAreasList();
		return "dictionaries";
	}

	/**
	 * Deletes area form database.
	 */
	public void deleteArea() {
		try {
			areaDao.deleteArea(selectedArea);
		} catch (Exception e) {
			log.error("Error while deleteArea: ", e);
		}
		refreshAreasList();
		notAvailableAction();
	}

	/**
	 * Edits the area selected from XHTML template.
	 * 
	 * @return the string
	 */
	public String editArea() {
		edit = true;
		newArea = selectedArea;
		return "areas";
	}

	/**
	 * Search area by name in database.
	 */
	public void searchArea() {
		try {
			areasList = areaDao.getAreasByName(filterArea.getAreaName());
		} catch (Exception e) {
			log.error("Error while searchArea: ", e);
		}
	}

	/**
	 * Cleans area search.
	 */
	public void cleanAreaSearch() {
		filterArea = new Area();

		try {
			areasList = areaDao.getAreas(filterArea);
		} catch (Exception e) {
			log.error("Error while cleanAreaSearch:", e);
		}
	}

	/**
	 * On row select dictionaries list.
	 * 
	 * @param event
	 *            the event
	 */
	public void onRowSelectDictionariesList(SelectEvent event) {
		availableAction();
	}

	/**
	 * On row unselect dictionaries list.
	 * 
	 * @param event
	 *            the event
	 */
	public void onRowUnselectDictionariesList(UnselectEvent event) {
		notAvailableAction();
	}

	/**
	 * Activates if action on selected element is available.
	 */
	public void availableAction() {
		disableShow = false;
		disableEdit = false;
		disableRemove = false;
	}

	/**
	 * Activates if action on selected element is not available.
	 */
	public void notAvailableAction() {
		selectedArea = new Area();

		disableShow = true;
		disableEdit = true;
		disableRemove = true;
	}

	public Area getNewArea() {
		return newArea;
	}

	public void setNewArea(Area newArea) {
		this.newArea = newArea;
	}

	public Area getFilterArea() {
		return filterArea;
	}

	public void setFilterArea(Area filterArea) {
		this.filterArea = filterArea;
	}

	public List<Area> getAreasList() {
		return areasList;
	}

	public void setAreasList(List<Area> areasList) {
		this.areasList = areasList;
	}

	public Area getSelectedArea() {
		return selectedArea;
	}

	public void setSelectedArea(Area selectedArea) {
		this.selectedArea = selectedArea;
	}

	public boolean isDisableShow() {
		return disableShow;
	}

	public void setDisableShow(boolean disableShow) {
		this.disableShow = disableShow;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}

	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}
}