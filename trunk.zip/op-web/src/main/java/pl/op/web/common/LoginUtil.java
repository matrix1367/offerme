package pl.op.web.common;

import org.jboss.seam.annotations.security.management.UserPassword;
import org.jboss.seam.security.management.PasswordHash;
import org.jboss.seam.util.AnnotatedBeanProperty;

import pl.op.model.user.UserApp;

public class LoginUtil {

	@SuppressWarnings({ "deprecation", "unused" })
	public static String generatePasswordHash(String password, String salt) {
		AnnotatedBeanProperty<UserPassword> userPasswordProperty = new AnnotatedBeanProperty<UserPassword>(
				UserApp.class, UserPassword.class);
		// Will get the hash value from annotation UserPassword in
		// ProcessUser.class
		String algorithm = "MD5"; // userPasswordProperty.getAnnotation().hash();
		return PasswordHash.instance().generateSaltedHash(password, salt,
				algorithm);
	}

	
}
