package pl.op.web.comparator;

import java.util.Comparator;

import pl.op.model.auction.Auction;

public class AuctionByScoreComparator implements Comparator<Auction> {
	private String direction;
	
	public AuctionByScoreComparator(String direction) {
		this.direction = direction;
	}
	
	@Override
	public int compare(Auction auction, Auction auction2) {
		if(direction.equals("ASC")) {
			return compareAsc(auction, auction2);
		}
		
		return compareDesc(auction, auction2);
	}
	
	public int compareAsc(Auction auction, Auction auction2) {
		return getOfferScore(auction).compareTo(getOfferScore(auction2));
	}
	
	public int compareDesc(Auction auction, Auction auction2) {
		return getOfferScore(auction2).compareTo(getOfferScore(auction));
	}
	
	public Double getOfferScore(Auction auction) {
		if(auction.isAuctionOffersNotNull()) {
			return auction.getLastOffer().getScore();
		}
		
		return 0.0;
	}
}
