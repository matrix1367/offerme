package pl.op.web.beans;

import java.io.Serializable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import pl.op.dao.CommentDao;
import pl.op.model.comment.Comment;
import pl.op.model.comment.News;
import pl.op.web.listener.GuiceSingleton;

@Name("op.messageActualBean")
@Scope(ScopeType.APPLICATION)
public class MessageActualBean implements Serializable {

	private static final long serialVersionUID = 2502920143397715653L;

	private Logger log = LoggerFactory.getLogger(MessageActualBean.class);

	private Integer NUMBER_OF_COMMENTS = 2;
	private Integer NUMBER_OF_NEWS = 3;

	public MessageActualBean() {

		commentDao = GuiceSingleton.getInstance().getInstance(CommentDao.class);
		initialize();
		// TODO Auto-generated constructor stub
	}

	private List<Comment> actualComments;
	private List<News> actualNews;
	private CommentDao commentDao;

	private Comment comment0;
	private Comment comment1;

	private String comment0Visible = "false";
	private String comment1Visible = "false";

	private String comment0FullVisible = "false";
	private String comment1FullVisible = "false"; 
	
	private String news0FullVisible = "false";
	private String news1FullVisible = "false";
	private String news2FullVisible = "false";

	private String news0Visible = "false";
	private String news1Visible = "false";
	private String news2Visible = "false";

	private String fullCommentVisible = "false";
	private String fullNewsVisible = "false";
	
	private News news0;
	private News news1;
	private News news2;

	public void initialize() {
		getActualCommentsList();
		getActualNewsList();

	}

	public void getActualCommentsList() {
		try {
			actualComments = commentDao.getActualComments();
			if (actualComments != null) {

				if (actualComments.size() == 1) {
					comment0 = actualComments.get(0);
					comment0Visible = "true";
				}

				if (actualComments.size() == 2) {
					comment0 = actualComments.get(0);
					comment0Visible = "true";
					comment1 = actualComments.get(1);
					comment1Visible = "true";
				}


				if (actualComments.size() > NUMBER_OF_COMMENTS) {
					comment0 = actualComments.get(0);
					comment0Visible = "true";
					comment1 = actualComments.get(1);
					comment1Visible = "true";
				}

				log.info("number actual comments: " + actualComments.size());
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error("EXCEPTION: ",e);
		}
	}

	public void getActualNewsList() {
		try {
			actualNews = commentDao.getActualNews();
			if (actualNews != null) {

				if (actualNews.size() == 1) {
					news0 = actualNews.get(0);
					news0Visible = "true";
				}

				if (actualNews.size() == 2) {
					news0 = actualNews.get(0);
					news0Visible = "true";
					news1 = actualNews.get(1);
					news1Visible = "true";
				}

				if (actualNews.size() == 3) {
					news0 = actualNews.get(0);
					news0Visible = "true";
					news1 = actualNews.get(1);
					news1Visible = "true";
					news2 = actualNews.get(2);
					news2Visible = "true";
					
				}
				
				if (actualNews.size() > NUMBER_OF_NEWS) {
					news0 = actualNews.get(0);
					news0Visible = "true";
					news1 = actualNews.get(1);
					news1Visible = "true";
					news2 = actualNews.get(2);
					news2Visible = "true";					
				}

				log.info("number actual news: " + actualNews.size());
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error("EXCEPTION: ", e);
		}
	}

	public List<Comment> getActualComments() {
		return actualComments;
	}

	public void setActualComments(List<Comment> actualComments) {
		this.actualComments = actualComments;
	}

	public List<News> getActualNews() {
		return actualNews;
	}

	public void setActualNews(List<News> actualNews) {
		this.actualNews = actualNews;
	}

	public Comment getComment0() {
		return comment0;
	}

	public void setComment0(Comment comment0) {
		this.comment0 = comment0;
	}

	public Comment getComment1() {
		return comment1;
	}

	public void setComment1(Comment comment1) {
		this.comment1 = comment1;
	}

	public News getNews0() {
		return news0;
	}

	public void setNews0(News news0) {
		this.news0 = news0;
	}

	public News getNews1() {
		return news1;
	}

	public void setNews1(News news1) {
		this.news1 = news1;
	}

	public String getComment0Visible() {
		return comment0Visible;
	}

	public void setComment0Visible(String comment0Visible) {
		this.comment0Visible = comment0Visible;
	}

	public String getComment1Visible() {
		return comment1Visible;
	}

	public void setComment1Visible(String comment1Visible) {
		this.comment1Visible = comment1Visible;
	}

	public String getNews2Visible() {
		return news2Visible;
	}

	public void setNews2Visible(String news2Visible) {
		this.news2Visible = news2Visible;
	}

	public News getNews2() {
		return news2;
	}

	public void setNews2(News news2) {
		this.news2 = news2;
	}

	public String getNews0Visible() {
		return news0Visible;
	}

	public void setNews0Visible(String news0Visible) {
		this.news0Visible = news0Visible;
	}

	public String getNews1Visible() {
		return news1Visible;
	}

	public void setNews1Visible(String news1Visible) {
		this.news1Visible = news1Visible;
	}

	public String getComment0FullVisible() {
		return comment0FullVisible;
	}

	public void setComment0FullVisible(String comment0FullVisible) {
		this.comment0FullVisible = comment0FullVisible;
	}

	public String getComment1FullVisible() {
		return comment1FullVisible;
	}

	public void setComment1FullVisible(String comment1FullVisible) {
		this.comment1FullVisible = comment1FullVisible;
	}

	public String getNews0FullVisible() {
		return news0FullVisible;
	}

	public void setNews0FullVisible(String news0FullVisible) {
		this.news0FullVisible = news0FullVisible;
	}

	public String getNews1FullVisible() {
		return news1FullVisible;
	}

	public void setNews1FullVisible(String news1FullVisible) {
		this.news1FullVisible = news1FullVisible;
	}

	public String getNews2FullVisible() {
		return news2FullVisible;
	}

	public void setNews2FullVisible(String news2FullVisible) {
		this.news2FullVisible = news2FullVisible;
	}
	
	public String getFullCommentVisible() {
		return fullCommentVisible;
	}

	public void setFullCommentVisible(String fullCommentVisible) {
		this.fullCommentVisible = fullCommentVisible;
	}

	public String getFullNewsVisible() {
		return fullNewsVisible;
	}

	public void setFullNewsVisible(String fullNewsVisible) {
		this.fullNewsVisible = fullNewsVisible;
	}

	public String showComment0Full()
	{
		comment0FullVisible = "true";
		fullCommentVisible = "true";
		log.info("visible all content of coment...");
		return "";
	}
	
	public String returnComment0Full()
	{
		comment0FullVisible = "false";
		fullCommentVisible = "false";
		log.info("hide all content of coment...");
		return "";
	}

	public String showComment1Full()
	{
		comment1FullVisible = "true";
		fullCommentVisible = "true";
		log.info("visible all content of comment...");
		return "";
	}
	
	public String returnComment1Full()
	{
		comment1FullVisible = "false";
		fullCommentVisible = "false";
		log.info("hide all content of comment...");
		return "";
	}
	
	public String showNews0Full()
	{
		news0FullVisible = "true";
		fullNewsVisible = "true";
		log.info("visible all content of news...");
		return "";
	}
	
	public String returnNews0Full()
	{
		news0FullVisible = "false";
		fullNewsVisible = "false";
		log.info("hide all content of news...");
		return "";
	}

	public String showNews1Full()
	{
		news1FullVisible = "true";
		fullNewsVisible = "true";
		log.info("visible all content of news...");
		return "";
	}
	
	public String returnNews1Full()
	{
		news1FullVisible = "false";
		fullNewsVisible = "false";
		log.info("hide all content of news...");
		return "";
	}

	public String showNews2Full()
	{
		news2FullVisible = "true";
		fullNewsVisible = "true";
		log.info("visible all content of news...");
		return "";
	}
	
	public String returnNews2Full()
	{
		news2FullVisible = "false";
		fullNewsVisible = "false";
		log.info("hide all content of news...");
		return "";
	}

}
