package pl.op.web.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class UploadService.
 */
public class UploadService {
    public final static String UPLOAD_DIR = "/../upload/";

    private static Logger log = LoggerFactory.getLogger(UploadService.class);


    public final static Integer BUFFER_SIZE = 6124;

    /**
     * Upload.
     * 
     * @param file
     *            - the file to upload
     * @param catalog
     *            - the catalog name to upload
     * @param fileName
     *            - the file name
     * @return the boolean if upload success
     */
    public static Boolean upload(UploadedFile file, String catalog, String fileName) {

        Boolean result = false;
        String path = UPLOAD_DIR + catalog + "/";

        File dir = new File(path);
        dir.mkdir();

        ExternalContext extContext = FacesContext.getCurrentInstance().getExternalContext();
        File uploadFile = new File(extContext.getRealPath(path + fileName));

        try {
            FileOutputStream fileOutputStream = new FileOutputStream(uploadFile);
            byte[] buffer = new byte[BUFFER_SIZE];
            int bulk;
            InputStream inputStream = file.getInputstream();
            while(true) {
                bulk = inputStream.read(buffer);
                if(bulk < 0) {
                    break;
                }
                fileOutputStream.write(buffer, 0, bulk);
                fileOutputStream.flush();
            }
            fileOutputStream.close();
            inputStream.close();
            result = true;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return result;

    }

}
