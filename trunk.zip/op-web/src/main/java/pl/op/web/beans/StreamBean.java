package pl.op.web.beans;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

@Name("op.streamBean")
@Scope(ScopeType.SESSION)
public class StreamBean implements Serializable {

	private static final long serialVersionUID = 7816743076622929715L;

	public StreamBean() {
		log.info("StramBean constructor");
		initialize();
	}
	
	public void initialize() {
		log.info("initialize stream bean...");
		
	}
		
	private Logger log = LoggerFactory.getLogger(StreamBean.class);	
	
	public String goToStreamList()
	{
		log.info("go to stream list...");
		return "streamList";
	}
}
