package pl.op.web.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.jboss.seam.servlet.SeamFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebAppFilter extends SeamFilter {

    private Logger log = LoggerFactory.getLogger(WebAppFilter.class);

    private String mode = "ALLOW-FROM https://www.facebook.com";

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {

        // log.info("-------------- WebAppFilter response adjustment ---------------");

        HttpServletResponse res = (HttpServletResponse) response;
        
        request.setCharacterEncoding("UTF-8");
        res.setCharacterEncoding("UTF-8");
    
        // res.addHeader("X-FRAME-OPTIONS", mode);
        res.setHeader("X-FRAME-OPTIONS", mode);
        // res.log.info("has X-FRAME-OPTIONS " +
        // res.containsHeader("X-FRAME-OPTIONS"));
        chain.doFilter(request, res);
    }

    public void destroy() {
    }

    public void init(FilterConfig filterConfig) {
        String configMode = filterConfig.getInitParameter("mode");
        if (configMode != null) {
            mode = configMode;
        }
    }

}