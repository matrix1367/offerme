package pl.op.web.parsers;


import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.FileUploadEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import pl.op.dao.AreaDao;
import pl.op.dao.CityDao;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.web.listener.GuiceSingleton;

@Name("op.cityXMLParser")
@Scope(ScopeType.SESSION)
public class CityXMLParser extends DefaultHandler {

	private Logger log = LoggerFactory.getLogger(CityXMLParser.class);

	private InputStream uploadedCityFile;

	private String areaId;
	private String districtId;
	private String communityId;
	private String unitTypeId;
	private String cityType;
	private String additionalName;
	private String cityName;
	private String cityId;
	private String baseCityId;
	private String date;

	private City cityFromXML;
	private Area areaFromDB;

	private AreaDao areaDao;
	private CityDao cityDao;

	private HashMap<String, String> cityMap;

	private Boolean isAreaId = false;
	private Boolean isDistrictId = false;
	private Boolean isCommunityId = false;
	private Boolean isUnitTypeId = false;
	private Boolean isCityType = false;
	private Boolean isAdditionalName = false;
	private Boolean isCityName = false;
	private Boolean isCityId = false;
	private Boolean isBaseCityId = false;
	private Boolean isDate = false;
	
	private Map<String, Area> areaMap = new HashMap<String, Area>();

	public CityXMLParser() {
		log.info("CityXMLParser constructor");
		initialize();
	}

	private void initialize() {
		areaDao = GuiceSingleton.getInstance().getInstance(AreaDao.class);
		cityDao = GuiceSingleton.getInstance().getInstance(CityDao.class);

		cityFromXML = new City();
		cityFromXML.setArea(new Area());

		cityMap = new HashMap<String, String>();
		
		try {
			List<Area> areaList = areaDao.getAreas(null);
			
			for(Area area: areaList){
				areaMap.put(area.getAreaSymbol(),area);
			}			
		} catch (Exception e) {
			log.error("Error while getting Areas : ",e);
			e.printStackTrace();
		}
	}

	public void uploadCityXML(FileUploadEvent event) {
		try {
			uploadedCityFile = event.getFile().getInputstream();
		} catch (IOException e) {
			log.error("error while getting CityXML : ",e);
			e.printStackTrace();
		}
	}
	
	private boolean citiesAreEqual(City city1, City city2){
		if(city1.getSymbol().equals(city2.getSymbol())){
			return true;
		}
		return false;
	}

	public void importCityXml() throws Exception {

		try {
			SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserFactory.newSAXParser();

			DefaultHandler defaultHandler = new DefaultHandler() {

				public void startElement(String uri, String localName,
						String qName, Attributes attributes)
						throws SAXException {
					
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equals("WOJ")) {
							isAreaId = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equals("POW")) {
							isDistrictId = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equals("GMI")) {
							isCommunityId = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equals("RODZ_GMI")) {
							isUnitTypeId = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equals("RM")) {
							isCityType = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equals("MZ")) {
							isAdditionalName = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equals("NAZWA")) {
							isCityName = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equals("SYM")) {
							isCityId = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equals("SYMPOD")) {
							isBaseCityId = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equals("STAN_NA")) {
							isDate = true;
					}
				}

				public void characters(char ch[], int start, int length)
						throws SAXException {

					if (isAreaId) {
						areaId = new String(ch, start, length);
						log.info("WOJ : " + areaId);
						
							cityMap.put("areaId", areaId);
					}
					
					if (isDistrictId) {
						districtId = new String(ch, start, length);
						log.info("POW : " + districtId);

							cityMap.put("districtId", districtId);
					}
					if (isCommunityId) {
						communityId = new String(ch, start, length);
						log.info("GMI : " + communityId);

							cityMap.put("communityId", communityId);
					}
					if (isUnitTypeId) {
						unitTypeId = new String(ch, start, length);
						log.info("RODZ_GMI : " + unitTypeId);
						
							cityMap.put("unitTypeId", unitTypeId);
					}
					if (isCityType) {
						cityType = new String(ch, start, length);
						log.info("RM : " + cityType);

							cityMap.put("cityType", cityType);
					}
					if (isAdditionalName) {
						additionalName = new String(ch, start, length);
						log.info("MZ : " + additionalName);

							cityMap.put("additionalName", additionalName);
					}
					if (isCityName) {
						cityName = new String(ch, start, length);
						log.info("NAZWA : " + cityName);

							cityMap.put("cityName", cityName);
					}
					if (isCityId) {
						cityId = new String(ch, start, length);
						log.info("SYM : " + cityId);

							cityMap.put("cityId", cityId);
					}
					if (isBaseCityId) {
						baseCityId = new String(ch, start, length);
						log.info("SYMPOD : " + baseCityId);

							cityMap.put("baseCityId", baseCityId);
					}
					if (isDate) {
						date = new String(ch, start, length);
						log.info("STAN_NA : " + date);

							cityMap.put("date", date);
						
						if (cityMap.size() == 10) {
							try {
								
								cityFromXML.setArea(new Area());
								City cityFromDB = cityDao.getCityBySymbol(cityMap.get("cityId"));
								areaFromDB = areaMap.get(areaId);
								cityFromXML = new City();
								cityFromXML.setSymbol(cityMap.get("cityId"));
								
								if(cityFromDB == null || !citiesAreEqual(cityFromXML,cityFromDB)) {
									
									cityFromXML.setCityName(cityMap.get("cityName"));
									cityFromXML.setArea(areaFromDB);
									
									if((cityMap.get("unitTypeId").equals("4") || cityMap.get("unitTypeId").equals("1"))) {
										cityFromXML.setHasStatus(true);
										cityDao.saveCityWithAreaId(cityFromXML,areaFromDB.getAreaId());
									}							
									if((cityMap.get("unitTypeId").equals("5") || cityMap.get("unitTypeId").equals("2"))) {
										cityFromXML.setHasStatus(false);
										cityDao.saveCityWithAreaId(cityFromXML,areaFromDB.getAreaId());
									}
								}						
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
						cityMap.clear();
						
						cityMap.put("areaId", areaId);						
					}	
				}

				public void endElement(String uri, String localName,
						String qName) throws SAXException {

					if (qName.contains("col")) {
						isAreaId = false;
					}
					if (qName.contains("col")) {
						isDistrictId = false;
					}
					if (qName.contains("col")) {
						isCommunityId = false;
					}
					if (qName.contains("col")) {
						isUnitTypeId = false;
					}
					if (qName.contains("col")) {
						isCityType = false;
					}
					if (qName.contains("col")) {
						isAdditionalName = false;
					}
					if (qName.contains("col")) {
						isCityName = false;
					}
					if (qName.contains("col")) {
						isCityId = false;
					}
					if (qName.contains("col")) {
						isBaseCityId = false;
					}
					if (qName.contains("col")) {
						isDate = false;
					}
				}
			};

			saxParser.parse(uploadedCityFile, defaultHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}