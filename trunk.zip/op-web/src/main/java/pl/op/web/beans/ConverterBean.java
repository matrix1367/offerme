package pl.op.web.beans;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class ConverterBean.
 */
@Name("op.converterBean")
@Scope(ScopeType.SESSION)
public class ConverterBean {

    private Logger log = LoggerFactory.getLogger(ConverterBean.class);

    /**
     * Instantiates a new converter bean.
     */
    public ConverterBean() {
        log.info("DateBean constructor");
    }
    
    public String getAuctionTime(Date date)
    {
        if(date != null)
        {
            Date now = new Date();
            long diff = date.getTime() -  now.getTime() ;
            
            long diffSeconds = diff / 1000 % 60;
            long diffMinutes = diff / (60 * 1000) % 60;
            long diffHours = diff / (60 * 60 * 1000) % 24;
            long diffDays = diff / (24 * 60 * 60 * 1000);
            
            if (diffSeconds < 0) return "aukcja zakończona";
            
            return diffDays + "d " + diffHours + "h " + diffMinutes + "m " + diffSeconds +"s";
        }
        return "error";
    }

    /**
     * Date converter.
     * 
     * @param date
     *            the date
     * @return the date string in format: dd-MM-yyyy
     */
    public String dateConverter(Date date) {
        if(date != null)
            return new SimpleDateFormat("dd-MM-yyyy").format(date);

        return "";
    }

    /**
     * Current date.
     * 
     * @return the date string in format: dd-MM-yyyy
     */
    public String currentDate() {
        return new SimpleDateFormat("dd-MM-yyyy").format(new Date());
    }

    /**
     * Date time converter.
     * 
     * @param date
     *            the date
     * @return the date string in format: dd-MM-yyyy HH:mm
     */
    public String dateTimeConverter(Date date) {
        if(date != null)
            return new SimpleDateFormat("dd-MM-yyyy HH:mm").format(date);

        return new SimpleDateFormat("dd-MM-yyyy HH:mm").format(new Date());
    }

    /**
     * Date custom converter.
     * 
     * @param date
     *            the date
     * @param format
     *            the format
     * @return the string
     */
    public String dateCustomConverter(Date date, String format) {
        if(date != null)
            return new SimpleDateFormat(format).format(date);

        return "";
    }

    /**
     * Date miliseconds.
     * 
     * @param date
     *            the date
     * @return the long
     */
    public long dateMiliseconds(Date date) {
        if(null == date)
            return 0;

        return date.getTime();
    }

    /**
     * Dates to months.
     * 
     * @param beginDate
     *            the begin date
     * @param endDate
     *            the end date
     * @return the integer
     */
    public Integer datesToMonths(Date beginDate, Date endDate) {
        long diff = endDate.getTime() - beginDate.getTime();

        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(diff);

        return c.get(Calendar.MONTH);
    }

}