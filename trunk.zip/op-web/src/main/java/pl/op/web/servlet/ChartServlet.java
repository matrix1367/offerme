package pl.op.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jboss.seam.Component;
import org.jboss.seam.servlet.ContextualHttpServletRequest;

import pl.op.web.beans.ReportBean;

public class ChartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static Logger log = LoggerFactory.getLogger(ChartServlet.class);

	@Override
	protected void doGet(final HttpServletRequest request,
			final HttpServletResponse response) throws ServletException,
			IOException {

		new ContextualHttpServletRequest(request) {
			@Override
			public void process() throws ServletException, IOException {
				processRequest(request, response);
			}
		}.run();

	}
	
	void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException { 
		String respMsg ="";
		
		ReportBean reportBean = (ReportBean) Component.getInstance("op.reportBean");//(ReportBean)ComponentLookup.lookupComponent("op.reportBean"); //
		
		log.info("reportBean: "+reportBean);
		if(reportBean==null) {
			throw new NullPointerException("seam bean was null: reportBean"); 
		}
		
		log.info("processRequest");

		// create chart data 
		respMsg = reportBean.getContentChart();
		System.out.println("wygenerowna "+respMsg);
					
		byte respBytes[] = respMsg.getBytes("UTF-8");
		log.info("response message created ("+respBytes.length+" bytes)");
				
		// headers: content size, type, caching 				
		response.setContentLength(respBytes.length);		
		response.addHeader("Cache-Control", "no-cache");
		response.setContentType("text/plain");		
		response.setCharacterEncoding("UTF-8");
		
		// send 
		response.getOutputStream().write(respBytes);		
		response.flushBuffer();
		log.info("response message sent");
	}
	
}
