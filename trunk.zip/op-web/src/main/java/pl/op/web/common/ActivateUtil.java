package pl.op.web.common;

import org.apache.commons.codec.digest.DigestUtils;

public class ActivateUtil {

	public static final String ACTIVATION_CODE="Activation";
	
	public static String getActivationCode(String memberName){
	    String raw = ACTIVATION_CODE.concat(memberName);
	    return DigestUtils.md5Hex(raw);
	}
}
