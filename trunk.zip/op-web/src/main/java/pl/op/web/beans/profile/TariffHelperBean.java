package pl.op.web.beans.profile;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.MeasureDao;
import pl.op.dao.ProfileDao;
import pl.op.model.auction.ZoneType;
import pl.op.model.contract.Measure;
import pl.op.model.contract.MeasureFilter;
import pl.op.model.contract.PPE;
import pl.op.model.contract.Priority;
import pl.op.model.profile.ProfileIndicatorFilter;
import pl.op.web.listener.GuiceSingleton;

@Name("op.tariffHelperBean")
@Scope(ScopeType.SESSION)
public class TariffHelperBean {

	private Logger log = LoggerFactory.getLogger(TariffHelperBean.class);

	private MeasureDao measureDao;
	private ProfileDao profileDao;
	
	private Double topZoneValue;
	private Double restZoneValue;
	private Map<Integer, String> monthAsString = new HashMap<Integer, String>();
	
	private String helperResult;
	
	public TariffHelperBean() {
		log.info("TariffHelperBean - initialize");
		initialize();
	}

	public void initialize() {
		measureDao = GuiceSingleton.getInstance().getInstance(MeasureDao.class);
		profileDao = GuiceSingleton.getInstance().getInstance(ProfileDao.class);
		
		monthAsString.put(0, "I");
		monthAsString.put(1, "II");
		monthAsString.put(2, "III");
		monthAsString.put(3, "IV");
		monthAsString.put(4, "V");
		monthAsString.put(5, "VI");
		monthAsString.put(6, "VII");
		monthAsString.put(7, "VIII");
		monthAsString.put(8, "IX");
		monthAsString.put(9, "X");
		monthAsString.put(10, "XI");
		monthAsString.put(11, "XII");
		
		helperResult = "high";
	}

	public void initializeTaiffHelper(PPE ppe) {
		DateTime temp = new DateTime();
		DateTime df = new DateTime(temp.getYear() - 1, temp.getMonthOfYear(), 1, 0, 0, 0, 000);
		DateTime dt = new DateTime(temp.getYear(), temp.getMonthOfYear(), temp.dayOfMonth().getMaximumValue(), 0, 0, 0, 000);
		
		
		topZoneValue = 0.0;
		restZoneValue = 0.0;
		
		int result = prepareData(ppe, df, dt);
		
		log.info("result: " + result + "%");
		
		if(result <= 60) {
			setHelperResult("high");
		} else {
			setHelperResult("low");
		}
	}

	public int prepareData(PPE ppe, DateTime dateFrom, DateTime dateTo) {
		log.info("df - " + dateFrom);
		log.info("dt - " + dateTo);
		log.info("ppeId - " + ppe.getPpeId());

		try {
			MeasureFilter filter = new MeasureFilter();
			filter.setDateFrom(dateFrom.toDate());
			filter.setDateTo(dateTo.toDate());
			filter.setPpeId(ppe.getPpeId());
			filter.setPriority(null);
			
			List<Measure> measureValList = measureDao.getMeasureByFilter(filter);
			
			if(measureValList != null && measureValList.size() > 0) {
				for(Measure measure : measureValList) {
					if(measure.getZoneType().equals(ZoneType.day) || measure.getZoneType().equals(ZoneType.peak))
						topZoneValue += measure.getValue();
					else
						restZoneValue += measure.getValue();
				}
				
				if(topZoneValue > 0) {
					Double result = topZoneValue / (restZoneValue + topZoneValue);
					
					return result.intValue();
				}
			} 
			
			
			measureValList = new ArrayList<Measure>();
			filter.setDateFrom(null);
			filter.setDateTo(null);
			
			measureValList = measureDao.getMeasureByFilter(filter);
			
			if(measureValList != null && measureValList.size() > 0) {
				Measure measure = measureValList.get((measureValList.size() - 1));
					if(measure.getDateTo() == null) {
						topZoneValue = measure.getValue();
					} else {
						topZoneValue = (measure.getValue()) / ((measure.getDateTo().getTime() - measure.getDateFrom().getTime())/1000/3600/24);
					}
			}
			
			log.info("topZoneValue - " + topZoneValue);
			
			Double sum  = 0.0;
			Double sumTemp = 0.0;
			
			ProfileIndicatorFilter profileFilter = new ProfileIndicatorFilter();
			profileFilter.setTariffId(ppe.getTariff().getTariffId());
			profileFilter.setValue(topZoneValue);	
			profileFilter.setMonth(monthAsString.get(dateTo.getMonthOfYear()));
			
			profileFilter.setMinHour(6);
			profileFilter.setMaxHour(15);
				
			sumTemp = profileDao.getSumValueByFilter(profileFilter);
			if(null != sumTemp) {
				sum += sumTemp;
			}
				
			profileFilter.setMinHour(17);
			profileFilter.setMaxHour(22);
				
			sumTemp = profileDao.getSumValueByFilter(profileFilter);
			if(null != sumTemp) {
				sum += sumTemp;
			}
			log.info("sum - " + sum);
			log.info("("+dateTo.dayOfMonth().getMaximumValue()+ " * topZoneValue) - " + (dateTo.dayOfMonth().getMaximumValue() * topZoneValue));
		
			Double result = (sum / (dateTo.dayOfMonth().getMaximumValue() * topZoneValue)) * 100;
			
			return result.intValue();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return 0;
	}

	public String getHelperResult() {
		return helperResult;
	}

	public void setHelperResult(String helperResult) {
		this.helperResult = helperResult;
	}
}
