package pl.op.web.beans.wizard;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.op.dao.AgreementDao;
import pl.op.dao.InvoiceDao;
import pl.op.dao.PPEDao;
import pl.op.dao.TariffDao;
import pl.op.model.auction.PriceComponent;
import pl.op.model.cloud.VolumeEnum;
import pl.op.model.contract.Agreement;
import pl.op.model.contract.Invoice;
import pl.op.model.contract.InvoicePriceComponentValue;
import pl.op.model.contract.Location;
import pl.op.model.contract.PPE;
import pl.op.model.dict.Tariff;
import pl.op.model.user.UserApp;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;
import pl.op.web.service.InvoiceService;

@Name("op.wizardInvoiceBean")
@Scope(ScopeType.SESSION)
public class WizardInvoiceBean implements Serializable {

    private static final long serialVersionUID = 7657279753756327544L;

    public WizardInvoiceBean() {
        log.info("WizardInvoiceBean constructor");
        initialize();
    }

    private Logger log = LoggerFactory.getLogger(WizardInvoiceBean.class);

    private WizardLocationBean wizardLocationBean;

    private Invoice invoice;
    private Integer invoiceFakeId;

    private List<VolumeEnum> volumes;
    private List<PPE> ppeList;
    private List<Invoice> invoices;
    private List<InvoicePriceComponentValue> priceComponentValues;

    private boolean invoiceButtons = true;
    private boolean invoiceAdd = false;
    private boolean isEdit = false;

    private UserApp user;

    private InvoiceDao invoiceDao;
    private Integer ppeId;
    private VolumeEnum volumeEnum;

    private FacesContext facesContext;
    private ExternalContext ectx;

    private String sample;

    private void initialize() {
        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();

        invoice = new Invoice();
        invoice.setPpe(new PPE());
        invoice.setVolumeEnum(VolumeEnum.KWH);
        invoice.getPpe().setLocation(new Location());

        invoiceFakeId = 1;

        invoices = new ArrayList<Invoice>();

        wizardLocationBean = ComponentLookup.lookupComponent("op.wizardLocationBean");
        ppeList = wizardLocationBean.getPpeList();

        invoiceDao = GuiceSingleton.getInstance().getInstance(InvoiceDao.class);
    }

    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }

    public void addInvoice() {
        if(!validInvoiceDate()) {
            return;
        }

        if(invoice.getInvoiceId() == null) {
            invoice.setInvoiceId(invoiceFakeId);
            invoice.setInvoicePriceComponentValue(priceComponentValues);

            invoices.add(invoice);
            invoiceFakeId++;
        }

        unselectInvoice();
        invoiceAdd = false;
        invoiceButtons = true;
        isEdit = false;

        ppeId = null;
    }

    public void updateAmount(InvoicePriceComponentValue ipcv) {        
        
        if (ipcv != null && ipcv.getAmount() != null && invoice.getInvoicePriceComponentValue() != null) {
            for(InvoicePriceComponentValue ipcv1 : invoice.getInvoicePriceComponentValue()) {
                if(!ipcv1.getPriceComponent().isConstant()) {
                    if(invoice.getVolumeEnum().equals(VolumeEnum.KWH)) {
                        ipcv1.setAmount(ipcv1.getAmount() * 1000.0);
                        ipcv1.setValue(ipcv1.getValue() / 1000.0);
                    } else {
                        ipcv1.setAmount(ipcv1.getAmount() / 1000.0);
                        ipcv1.setValue(ipcv1.getValue() * 1000.0);
                    }
                }
            }
        } else {
            
            for (InvoicePriceComponentValue ipcv1 : priceComponentValues) {
                if (!ipcv1.getPriceComponent().isConstant()) {
                    log.info("ilosc" + ipcv1.getAmount());
                    log.info("value" + ipcv1.getValue());
                    if (invoice.getVolumeEnum().equals(volumeEnum.KWH)) {
                        ipcv1.setAmount(ipcv1.getAmount() * 1000.0);
                        ipcv1.setValue(ipcv1.getValue() / 1000.0);
                    } else {
                        ipcv1.setAmount(ipcv1.getAmount() / 1000.0);
                        ipcv1.setValue(ipcv1.getValue() * 1000.0);
                    }
                }
            }
           
        }

    }

    private boolean validInvoiceDate() {
        if(invoice.getDateFrom() != null && invoice.getDateTo() != null
                && invoice.getDateFrom().after(invoice.getDateTo())) {
            warning("warning.two.dates.invalid");
            return false;
        }
        if(invoice.getDateFrom().after(new Date())) {
            warning("warning.dates.future.invalid");
            return false;
        }

        if(invoice.getDateTo().after(new Date())) {
            warning("warning.dates.future.invalid");
            return false;
        }

        log.info("invoice.getDateFrom(): " + invoice.getDateFrom());
        log.info("invoice.getDateTo(): " + invoice.getDateTo());

        for(Invoice inv : invoices) {
            if(inv.getPpe().getPpeId().intValue() == invoice.getPpe().getPpeId().intValue()) {
                log.info("inv.getDateFrom(): " + inv.getDateFrom());
                log.info("inv.getDateTo(): " + inv.getDateTo());

                if(invoice.getInvoiceId() != null && inv.getInvoiceId() != null) {
                    if(invoice.getInvoiceId().equals(inv.getInvoiceId())) {
                        continue;
                    }
                }

                if(invoice.getDateFrom().after(inv.getDateFrom()) && invoice.getDateFrom().before(inv.getDateTo())) {
                    warning("warning.dates.overlap");
                    return false;
                }
                if(invoice.getDateTo().after(inv.getDateFrom()) && invoice.getDateTo().before(inv.getDateTo())) {
                    warning("warning.dates.overlap");
                    return false;
                }

                if(invoice.getDateTo().equals(inv.getDateTo())) {
                    warning("warning.dates.overlap");
                    return false;
                }

                if(invoice.getDateFrom().equals(inv.getDateFrom())) {
                    warning("warning.dates.overlap");
                    return false;
                }

                if(invoice.getDateFrom().equals(inv.getDateFrom()) && invoice.getDateTo().equals(inv.getDateTo())) {
                    warning("warning.dates.overlap");
                    return false;
                }

                if(invoice.getDateFrom().before(inv.getDateFrom()) && invoice.getDateTo().after(inv.getDateTo())) {
                    warning("warning.dates.overlap");
                    return false;
                }
            }
        }

        return true;
    }

    public void onInvoiceSelect(SelectEvent event) {
        invoiceButtons = false;
        priceComponentValues = invoice.getInvoicePriceComponentValue();
        ppeId = invoice.getPpe().getPpeId();
    }

    public void deleteInvoice() {
        if(invoice != null) {
            invoices.remove(invoice);
            unselectInvoice();
        }
        invoiceButtons = true;
    }

    public void unselectInvoice() {
        invoice = new Invoice();
        invoice.setPpe(new PPE());
        invoice.setVolumeEnum(VolumeEnum.KWH);
        invoice.getPpe().setLocation(new Location());

        invoiceButtons = true;
        priceComponentValues = new ArrayList<InvoicePriceComponentValue>();
    }

    public void onPPESelect(AjaxBehaviorEvent ev) {
        unselectInvoice();

        for(int i = 0; i < ppeList.size(); i++) {
            if(ppeList.get(i).getPpeId().intValue() == ppeId.intValue()) {
                invoice.setPpe(ppeList.get(i));
                try {
                    priceComponentValues = new ArrayList<InvoicePriceComponentValue>();

                    List<PriceComponent> priceComponents = invoiceDao.getPPEPriceComponents(ppeList.get(i));
                    if(priceComponents != null)
                        for(PriceComponent pC : priceComponents) {
                            InvoicePriceComponentValue pCv = new InvoicePriceComponentValue();
                            pCv.setPriceComponent(pC);
                            if(pC.isConstant()) {
                                pCv.setAmount(0.00);
                                pCv.setValue(0.00);
                            }
                            priceComponentValues.add(pCv);
                        }

                    if(invoice.getVolumeEnum() == null)
                        invoice.setVolumeEnum(VolumeEnum.KWH);

                } catch (Exception e) {
                    e.printStackTrace();
                }
                try {   
                    sample =  InvoiceService.getFile(ppeList.get(i).getTariff());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
        }
    }

    public void invoiceAddAction() {
        unselectInvoice();
        ppeId = 0;
        invoice.setVolumeEnum(VolumeEnum.MWH);
        invoiceAdd = true;
        isEdit = false;
    }

    public void invoiceEditAction() {
        invoiceAdd = true;
        isEdit = true;
        priceComponentValues = invoice.getInvoicePriceComponentValue();
    }

    public boolean isInvoiceButtons() {
        return invoiceButtons;
    }

    public void setInvoiceButtons(boolean invoiceButtons) {
        this.invoiceButtons = invoiceButtons;
    }

    public boolean isInvoiceAdd() {
        return invoiceAdd;
    }

    public void setInvoiceAdd(boolean invoiceAdd) {
        this.invoiceAdd = invoiceAdd;
        if(invoiceAdd == false)
            unselectInvoice();
    }

    public List<PPE> getPpeList() {
        return ppeList;
    }

    public void setPpeList(List<PPE> ppeList) {
        this.ppeList = ppeList;
    }

    public List<Invoice> getInvoices() {
        return invoices;
    }

    public void setInvoices(List<Invoice> invoices) {
        this.invoices = invoices;
    }

    public List<InvoicePriceComponentValue> getPriceComponentValues() {
        return priceComponentValues;
    }

    public void setPriceComponentValues(List<InvoicePriceComponentValue> priceComponentValues) {
        this.priceComponentValues = priceComponentValues;
    }

    public Integer getPpeId() {
        return ppeId;
    }

    public void setPpeId(Integer ppeId) {
        this.ppeId = ppeId;
    }

    public List<VolumeEnum> getVolumes() {
        volumes = new ArrayList<VolumeEnum>();

        for(VolumeEnum a : VolumeEnum.values()) {
            if(a == VolumeEnum.KWH || a == VolumeEnum.MWH) {
                a.setLabel(BundlesUtils.getMessageResourceString("messages", "cloud.volume." + a, null,
                        Locale.getDefault()));
                volumes.add(a);
            }
        }

        return volumes;
    }

    public VolumeEnum getVolumeEnum() {
        return volumeEnum;
    }

    public void setVolumeEnum(VolumeEnum volumeEnum) {
        this.volumeEnum = volumeEnum;
    }

    public Double countPrice(Invoice invoice) {
        Double value = new Double(0);

        for(InvoicePriceComponentValue iPcV : invoice.getInvoicePriceComponentValue()) {
            value += iPcV.getAmount() * iPcV.getValue();
        }

        return value;
    }

    public Double countAmount(Invoice invoice) {
        Double value = new Double(0);

        for(InvoicePriceComponentValue iPcV : invoice.getInvoicePriceComponentValue()) {
            if(!iPcV.getPriceComponent().isConstant())
                value += iPcV.getAmount();
        }

        return value;
    }

    @SuppressWarnings({ "deprecation" })
    private void warning(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_WARN,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    public String getSample() {
        return sample;
    }

    public void setSample(String sample) {
        this.sample = sample;
    }

    public UserApp getUser() {
        return user;
    }

    public void setUser(UserApp user) {
        this.user = user;
    }

}