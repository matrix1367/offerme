package pl.op.web.beans.user;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;

import pl.op.dao.UserDao;
import pl.op.model.user.UserApp;
import pl.op.web.common.ActivateUtil;
import pl.op.web.common.LoginUtil;
import pl.op.web.listener.GuiceSingleton;
import pl.op.web.service.BonusService;

@Name("op.activationService")
@Scope(ScopeType.SESSION)
public class ActivationService {

	public ActivationService() {

		initialize();
		// TODO Auto-generated constructor stub
	}

	public void initialize() {
		bdUser = GuiceSingleton.getInstance().getInstance(UserDao.class);
	}

	private Logger log = LoggerFactory.getLogger(ActivationService.class);

	@In(value = "#{op.sendEmailBean}", scope = ScopeType.SESSION, required = true)
	private SendEmailBean sendEmailBean;

	@RequestParameter("code")
	private String activationCode;

	@RequestParameter("login")
	private String name;

	private UserDao bdUser;
	private UserApp userApp;
	private UserApp userPassword;
	
	private boolean errorActive;
	private boolean alreadyActive;
	private boolean active;
	private boolean loginNotExist;
	private boolean showDialog;

	public boolean isShowDialog() {
		return showDialog;
	}

	public void setShowDialog(boolean showDialog) {
		this.showDialog = showDialog;
	}

	public boolean isAlreadyActive() {
		return alreadyActive;
	}

	public void setAlreadyActive(boolean alreadyActive) {
		this.alreadyActive = alreadyActive;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isErrorActive() {
		return errorActive;
	}

	public void setErrorActive(boolean errorActive) {
		this.errorActive = errorActive;
	}

	public boolean isLoginNotExist() {
		return loginNotExist;
	}

	public void setLoginNotExist(boolean loginNotExist) {
		this.loginNotExist = loginNotExist;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setActivationCode(String activationCode) {
		this.activationCode = activationCode;
	}

	public void activate() {

		loginNotExist = false;
		errorActive = false;
		alreadyActive = false;
		active = false;
		showDialog = true;

		log.info("activation login: " + name);
		sendEmailBean.setLogin(name);
		log.info("activation code: " + activationCode);

		String userCode = null;

		boolean exist = false;

		try {
			exist = bdUser.checkLocalUserExist(name);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			log.error("EXCEPTION:", e1);
		}

		if (!exist) {
			// brak linka tylko komunikat
			loginNotExist = true;
			return;
		}

		try {
			userApp = bdUser.getUserByLogin(name);
			log.info("activation key from user: " + userApp.getActivateKey());
			if (userApp != null) {
				if (userApp.getActive().booleanValue()) {
					alreadyActive = true;
					return;
				}
				userCode = userApp.getActivateKey();
				if (userCode == null || userCode.equals("")) {
					errorActive = true;
					return;
				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error("EXCEPTION:", e);
			errorActive = true;
			return;
		}

		if (activationCode != null && !activationCode.trim().equals("")
				&& name != null && !name.trim().equals("")) {
			String code = ActivateUtil.getActivationCode(name);

			if (code.equals(activationCode) && code.equals(userCode)) {

				if (this.updateMemberAccount())
					active = true;
				else
					errorActive = true;

				return;
			} else {
				errorActive = true;
				System.err.println("Invalid activation code");
			}
		}
		errorActive = true;
	}

	private boolean updateMemberAccount() {

		try {
			log.info("user form request parameter: " + name);
			userApp.setActivateKey(null);
			userApp.setActive(true);
			bdUser.updateUser(userApp);
			
			BonusService.run("endRegister",userApp);
			
			return userApp.getActive();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error("EXCEPTION:", e);
		}
		return false;
	}
	
	public void createPasswordInit(){	
		log.info("Create password init name = "+name);
		if(userPassword == null){
			userPassword = new UserApp();
			userPassword.setLogin(name);
			userPassword.setActivateKey(activationCode);
		}
		log.info("USer password init name = "+userPassword.getLogin());
		
		try {
			if (!bdUser.checkLocalUserExist(userPassword.getLogin())){
				setErrorActive(true);
				return;
			}
			
			if(bdUser.getUserByLogin(userPassword.getLogin()).getActive()){
				setAlreadyActive(true);
				return;
			}
			
			setActive(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	} 

	public String createPassword() {
		try {
			log.info("tworze nowe haslo dla = "+userPassword.getLogin());
			
			UserApp user = bdUser.getUserByLogin(userPassword.getLogin());

			user.setPassword(LoginUtil.generatePasswordHash(
					userPassword.getPassword(), user.getLogin()));

			bdUser.updatePassword(user);
			
			name = userPassword.getLogin();
			activationCode = userPassword.getActivateKey();
			activate();
			
			setActive(false);
			return "login";			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "";

	}

	public UserApp getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(UserApp userPassword) {
		this.userPassword = userPassword;
	}
}
