package pl.op.web.beans.dictionary;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.ObisDao;
import pl.op.model.dict.Obis;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class ObisBean. This class manages the obis. Can
 * add/edit/delete data from database table named "tb_obis".
 */
@Name("op.obisBean")
@Scope(ScopeType.SESSION)
public class ObisBean implements Serializable{

	private static final long serialVersionUID = -1979288346895911219L;

	private Logger log = LoggerFactory.getLogger(ObisBean.class);
	
	private List<Obis> obisList;
	private Obis newObis;
	private Obis selectedObis;

	private boolean edit;
	private boolean disableShow = true;
	private boolean disableEdit = true;
	private boolean disableRemove = true;

	private ObisDao obisDao;

	public ObisBean() {
		log.info("ObisBean constructor");
		initialize();
	}
	
	/**
	 * Initialize the ObisBean.
	 */
	private void initialize() {
		notAvailableAction();
		obisDao = GuiceSingleton.getInstance().getInstance(ObisDao.class);
		
		obisList = new ArrayList<Obis>();
	}

	/**
	 * Downloads obis from database and prepares list for display.
	 */
	public void refreshObisList() {
		try {
			obisList = obisDao.getObisList();
		} catch (Exception e) {
			log.error("error while getting obisList: ", e);
		}
	}

	/**
	 * Prepares the data for XHTML template to add new obis.
	 *
	 * @return the string
	 */
	public String addObis() {
		edit = false;
		selectedObis = new Obis();
		newObis = new Obis();
		return "obis";
	}

	/**
	 * Cancel add obis.
	 *
	 * @return the string
	 */
	public String cancelAddObis() {
		notAvailableAction();
		return "dictionaries";
	}

	/**
	 * Saves obis defined in XHTML template.
	 *
	 * @return the string
	 */
	public String saveObis() {
		try {
			if (edit) {
				obisDao.updateObis(selectedObis);
			} else {
				obisDao.saveObis(newObis);
			}
		} catch (Exception e) {
			log.error("Error while saveObis: ", e);
		}
		refreshObisList();
		return "dictionaries";
	}

	/**
	 * Deletes obis form database.
	 */
	public void deleteObis() {
		try {
			obisDao.deleteObis(selectedObis);
		} catch (Exception e) {
			log.error("Error while deleteObis: ", e);
		}
		refreshObisList();
		notAvailableAction();
	}

	/**
	 * Edits the obis selected from XHTML template.
	 *
	 * @return the string
	 */
	public String editObis() {
		edit = true;
		newObis = selectedObis;
		return "obis";
	}

	/**
	 * On row select dictionaries list.
	 *
	 * @param event the event
	 */
	public void onRowSelectDictionariesList(SelectEvent event) {
		availableAction();
	}

	/**
	 * On row unselect dictionaries list.
	 *
	 * @param event the event
	 */
	public void onRowUnselectDictionariesList(UnselectEvent event) {
		notAvailableAction();
	}

	/**
	 * Activates if action on selected element is available.
	 */
	public void availableAction() {
		disableShow = false;
		disableEdit = false;
		disableRemove = false;
	}

	/**
	 * Activates if action on selected element is not available.
	 */
	public void notAvailableAction() {
		selectedObis = new Obis();

		disableShow = true;
		disableEdit = true;
		disableRemove = true;
	}

	public Obis getNewObis() {
		return newObis;
	}

	public void setNewObis(Obis newObis) {
		this.newObis = newObis;
	}

	public List<Obis> getObisList() {
		return obisList;
	}

	public void setObisList(List<Obis> obisList) {
		this.obisList = obisList;
	}

	public Obis getSelectedObis() {
		return selectedObis;
	}

	public void setSelectedObis(Obis selectedObis) {
		this.selectedObis = selectedObis;
	}

	public boolean isDisableShow() {
		return disableShow;
	}

	public void setDisableShow(boolean disableShow) {
		this.disableShow = disableShow;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}

	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}
}