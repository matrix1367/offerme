package pl.op.web.beans.dictionary;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.CityDao;
import pl.op.dao.StreetDao;
import pl.op.model.dict.City;
import pl.op.model.dict.Street;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class StreetBean. This class manages the streets in selected city of the
 * country. Can add/edit/delete data from database table named "tb_street".
 */
@Name("op.streetBean")
@Scope(ScopeType.SESSION)
public class StreetBean implements Serializable {

	private static final long serialVersionUID = 566124232808755211L;

	private Logger log = LoggerFactory.getLogger(StreetBean.class);

	private List<Street> streetsList;
	private Street newStreet;
	private Street selectedStreet;
	private Street filterStreet;
	private List<City> selectedAreaCitiesList;

	private Integer selectedAreaId;

	private boolean edit;
	private boolean disableShow = true;
	private boolean disableEdit = true;
	private boolean disableRemove = true;

	private StreetDao streetDao;
	private CityDao cityDao;

	private DictionaryBean dictionaryBean;

	public StreetBean() {
		log.info("StreetBean constructor");
		initialize();
	}

	/**
	 * Initialize the StreetBean.
	 */
	private void initialize() {
		notAvailableAction();

		streetDao = GuiceSingleton.getInstance().getInstance(StreetDao.class);
		cityDao = GuiceSingleton.getInstance().getInstance(CityDao.class);

		dictionaryBean = ComponentLookup.lookupComponent("op.dictionaryBean");

		streetsList = new ArrayList<Street>();
		filterStreet = new Street();
		filterStreet.setCity(new City());
	}

	/**
	 * Downloads streets from database and prepares list for display.
	 */
	public void refreshStreetList() {
		filterStreet = new Street();
		filterStreet.setCity(new City());
		try {
			streetsList = streetDao.getStreetsList();
		} catch (Exception e) {
			log.error("error while getting streets: ", e);
		}
	}

	/**
	 * Prepares the data for XHTML template to add new street.
	 * 
	 * @return the string
	 */
	public String addStreet() {
		edit = false;
		selectedStreet = new Street();
		newStreet = new Street();
		newStreet.setCity(new City());
		refreshStreetList();
		selectedAreaId = new Integer(0);
		selectedAreaCitiesList = new ArrayList<City>();
		return "streets";
	}

	/**
	 * Cancel add street.
	 * 
	 * @return the string
	 */
	public String cancelAddStreet() {
		notAvailableAction();
		refreshStreetList();
		return "dictionaries";
	}

	/**
	 * Saves street defined in XHTML template.
	 * 
	 * @return the string
	 */
	public String saveStreet() {
		City city = null;
		try {
			city = cityDao.getCitiesById(newStreet.getCity().getCityId());
		} catch (Exception e) {
			log.error(
					"Error while getAreaById(newCity.getArea().getAreaId()): ",
					e);
		}
		try {
			if (edit) {
				selectedStreet.setCity(city);
				streetDao.updateStreet(selectedStreet);
			} else {
				newStreet.setCity(city);
				streetDao.saveStreet(newStreet);
			}
		} catch (Exception e) {
			log.error("Error while saveStreet: ", e);
		}
		refreshStreetList();
		return "dictionaries";
	}

	/**
	 * Deletes street form database.
	 */
	public void deleteStreet() {
		try {
			streetDao.deleteStreet(selectedStreet);
		} catch (Exception e) {
			log.error("Error while deleteStreet: ", e);
		}
		refreshStreetList();
		notAvailableAction();
	}

	/**
	 * Edits the street selected from XHTML template.
	 * 
	 * @return the string
	 */
	public String editStreet() {
		edit = true;
		newStreet = selectedStreet;
		return "streets";
	}

	/**
	 * Search street by name in database.
	 */
	public void searchStreet() {
		try {
			streetsList = streetDao.getStreetsByName(filterStreet
					.getStreetName());
		} catch (Exception e) {
			log.error("Error while searchStreet: ", e);
		}
	}

	/**
	 * Clean street search.
	 */
	public void cleanStreetSearch() {
		filterStreet = new Street();
		try {
			streetsList = streetDao.getStreetsList();
		} catch (Exception e) {
			log.error("Error while cleanStreetSearch:", e);
		}
	}

	/**
	 * On area select.
	 */
	public void onAreaSelect() {
		if (selectedAreaId != null) {
			selectedAreaCitiesList = dictionaryBean.getCitiesMap().get(
					selectedAreaId);
			log.info("selected Area Id :" + selectedAreaId);
		}
	}

	/**
	 * On row select dictionaries list.
	 * 
	 * @param event
	 *            the event
	 */
	public void onRowSelectDictionariesList(SelectEvent event) {
		availableAction();
	}

	/**
	 * On row unselect dictionaries list.
	 * 
	 * @param event
	 *            the event
	 */
	public void onRowUnselectDictionariesList(UnselectEvent event) {
		notAvailableAction();
	}

	/**
	 * Activates if action on selected element is available.
	 */
	public void availableAction() {
		disableShow = false;
		disableEdit = false;
		disableRemove = false;
	}

	/**
	 * Activates if action on selected element is not available.
	 */
	public void notAvailableAction() {
		selectedStreet = new Street();

		disableShow = true;
		disableEdit = true;
		disableRemove = true;
	}

	public Street getNewStreet() {
		return newStreet;
	}

	public void setNewStreet(Street newStreet) {
		this.newStreet = newStreet;
	}

	public Street getFilterStreet() {
		return filterStreet;
	}

	public void setFilterStreet(Street filterStreet) {
		this.filterStreet = filterStreet;
	}

	public List<Street> getStreetsList() {
		return streetsList;
	}

	public void setStreetsList(List<Street> streetsList) {
		this.streetsList = streetsList;
	}

	public Street getSelectedStreet() {
		return selectedStreet;
	}

	public void setSelectedStreet(Street selectedStreet) {
		this.selectedStreet = selectedStreet;
	}

	public boolean isDisableShow() {
		return disableShow;
	}

	public void setDisableShow(boolean disableShow) {
		this.disableShow = disableShow;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}

	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}

	public Integer getSelectedAreaId() {
		return selectedAreaId;
	}

	public void setSelectedAreaId(Integer selectedAreaId) {
		this.selectedAreaId = selectedAreaId;
	}

	public List<City> getSelectedAreaCitiesList() {
		return selectedAreaCitiesList;
	}

	public void setSelectedAreaCitiesList(List<City> selectedAreaCitiesList) {
		this.selectedAreaCitiesList = selectedAreaCitiesList;
	}
}