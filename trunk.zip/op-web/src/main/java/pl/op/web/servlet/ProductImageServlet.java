package pl.op.web.servlet;

import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProductImageServlet extends HttpServlet {

	private static final long serialVersionUID = 4387285331585556798L;

	private static Logger log = LoggerFactory.getLogger(ProductImageServlet.class);
	
	private static final int DEFAULT_BUFFER_SIZE = 10240; // 10KB.
		
	@Override
	public void init() throws ServletException {
		super.init();

	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// Get ID from request.
		String imageId = request.getParameter("key");

		// Check if ID is supplied to the request.
		if (imageId == null) {
			response.sendError(HttpServletResponse.SC_NOT_FOUND); // 404.
			return;
		}

		byte[] bytes = null;

		String filename = "test.png";
				
		if (bytes == null) {
			response.sendError(HttpServletResponse.SC_NOT_FOUND); // 404.
			return;
		}

		// Init response.
		response.reset();
		response.setBufferSize(DEFAULT_BUFFER_SIZE);
		response.setContentType(getServletContext().getMimeType(filename));
		response.setHeader("Content-Length", String.valueOf(bytes.length));

		BufferedOutputStream output = null;

		try {

			output = new BufferedOutputStream(response.getOutputStream(),
					DEFAULT_BUFFER_SIZE);
			output.write(bytes);
		} catch (Exception e) {
			log.error("EXCEPTION: ",e);
		} finally {
			close(output);
		}
	}

	private static void close(Closeable resource) {
		if (resource != null) {
			try {
				resource.close();
			} catch (IOException e) {
				log.error("EXCEPTION: ",e);
			}
		}
	}
	
	
}
