package pl.op.web.beans.wizard;

import java.io.Serializable;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.PrefQuestDao;
import pl.op.dao.QuestValueDao;
import pl.op.model.question.PreferenceQuestion;
import pl.op.model.question.QuestionItem;
import pl.op.model.question.QuestionValue;
import pl.op.model.question.ValueType;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

@Name("op.wizardPreferenceQuestionBean")
@Scope(ScopeType.SESSION)
public class WizardPreferenceQuestionBean implements Serializable {

    private static final long serialVersionUID = 7657279753756327544L;

    public WizardPreferenceQuestionBean() {
        log.info("WizardPreferenceQuestionBean constructor");
        initialize();
    }

    private Logger log = LoggerFactory.getLogger(WizardPreferenceQuestionBean.class);

    private List<PreferenceQuestion> preferenceQuestionList;
    private PrefQuestDao prefQuestDao;
    private WizardUserBean wizardUserBean;
    private QuestValueDao questValueDao;

    private void initialize() {
        prefQuestDao = GuiceSingleton.getInstance().getInstance(PrefQuestDao.class);
        wizardUserBean = ComponentLookup.lookupComponent("op.wizardUserBean");
        questValueDao = GuiceSingleton.getInstance().getInstance(QuestValueDao.class);
    }
    
    private void print(PreferenceQuestion pq) {
        try {                
            log.info("###########################st##################################");
            log.info("ID:" + pq.getPreferenceQuestionId().toString());
            log.info("Question:" + pq.getQuestion());
            log.info("Removed : " + pq.getRemoved().toString());
            log.info("ValueType: " + pq.getValueType().name());
            log.info("Stereotyp: " + pq.getStereotype().getStereotypeName());
            log.info("User_ID:" + pq.getUserId().toString());
            log.info("QuestionValue ID:" + pq.getQuestionValue().getQuestionValueId());
            log.info("QuestionValue String:" + pq.getQuestionValue().getQuestionValueString());
            if (pq.getQuestionValue().getQuestionValueBoolean() == null) log.info("QuestionValue Boolena: null"); else
                log.info("QuestionValue Boolena:" + pq.getQuestionValue().getQuestionValueBoolean().toString());
            if (pq.getValueType() != ValueType.OneValue) {
                log.info("###############QuestionItem##################################");
                for (QuestionItem pi : pq.getQuestionItems()) {
                    log.info("################st######################");    
                    log.info("pi_ID: " + pi.getQuestionItemId().toString());
                    log.info("Value: " + pi.getQuestionItemValue());
                    log.info("Name: " + pi.getQuestionItemName());
                    log.info("Removed : " + pi.getRemoved().toString());
                    if (pi.getPreferenceQuestion() == null) log.info("ID : null"); else 
                        log.info("ID : " + pi.getPreferenceQuestion().getPreferenceQuestionId().toString());
                    log.info("################en######################");    
                }            
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initializeOnLoad() {
        try {
            PreferenceQuestion filterpreferenceQuestion = new PreferenceQuestion();
            if(wizardUserBean != null && wizardUserBean.getStereotype() != null) {
                log.info("[initializeOnLoad] wizardUserBean.getStereotype(): " + wizardUserBean.getStereotype().getStereotypeName());
                filterpreferenceQuestion.setStereotype(wizardUserBean.getStereotype());
                filterpreferenceQuestion.setUserId(wizardUserBean.getUserApp().getUserId());
                
                preferenceQuestionList = prefQuestDao.getPreferenceQuestionList(filterpreferenceQuestion);
                
            } else {
                log.info("null : wizardUserBean is null ");
            }
            
            for (PreferenceQuestion pq : preferenceQuestionList){
                pq.setStereotype(wizardUserBean.getStereotype());
                pq.setUserId(wizardUserBean.getUserApp().getUserId());
                QuestionValue answer = questValueDao.getQuestionValue(pq);                
                pq.setQuestionValue(answer);
               //print(pq);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<PreferenceQuestion> getPreferenceQuestionList() {
        initializeOnLoad();
        return preferenceQuestionList;
    }
    
    public void savePreferencesQuestionAnswer() {
         try {
            log.info("[savePreference] preferenceQuestionList size: " + preferenceQuestionList.size());
            for(PreferenceQuestion pq : preferenceQuestionList) {
                print(pq);
                
                QuestionValue answer = pq.getQuestionValue();
                log.info("[savePreference] stereotype:: " + wizardUserBean.getStereotype().getStereotypeName());
                answer.setStereotype(wizardUserBean.getStereotype());
                answer.setUserApp(wizardUserBean.getUserApp());
                answer.setPreferenceQuestion(pq);

                if(answer.getQuestionValueId() == null)
                    questValueDao.saveQuestionValue(answer);
                else
                    questValueDao.updateQuestionValue(answer);

            }
            log.info("save.user.preferences.success");
        } catch (Exception e) {
            log.error("save.user.preferences.error");
            e.printStackTrace();
        }
    }

    public void setPreferenceQuestionList(List<PreferenceQuestion> preferenceQuestionList) {
        this.preferenceQuestionList = preferenceQuestionList;
        log.info("setPreferenceQuestionList");
        savePreferencesQuestionAnswer();
    }

}