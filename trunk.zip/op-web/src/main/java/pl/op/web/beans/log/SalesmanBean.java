package pl.op.web.beans.log;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AuctionDao;
import pl.op.dao.CityDao;
import pl.op.dao.SalesmanDao;
import pl.op.dao.StereotypeDao;
import pl.op.dao.StreetDao;
import pl.op.dao.UserDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionFilter;
import pl.op.model.auction.AuctionStatus;
import pl.op.model.contract.Agreement;
import pl.op.model.contract.OperatorInvoice;
import pl.op.model.dict.Address;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Street;
import pl.op.model.dict.Tariff;
import pl.op.model.salesman.BusinessType;
import pl.op.model.salesman.Salesman;
import pl.op.model.stereotype.Sector;
import pl.op.model.stereotype.Stereotype;
import pl.op.model.user.UserApp;
import pl.op.model.user.UserRole;
import pl.op.util.DictUtil;
import pl.op.validation.Validations;
import pl.op.web.beans.AdminBean;
import pl.op.web.beans.MailBean;
import pl.op.web.beans.MenuBean;
import pl.op.web.beans.auction.operator.AuctionBean;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.common.ActivateUtil;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

// TODO: Auto-generated Javadoc
/**
 * The Class SalesmanBean.
 */
@Name("op.salesmanBean")
@Scope(ScopeType.SESSION)
public class SalesmanBean implements Serializable {

    private static final long serialVersionUID = 1L;
    public final String SERVER_URL = "serverURL";
    private Logger log = LoggerFactory.getLogger(SalesmanBean.class);

    private Salesman salesman;

    private Salesman newSalesman;

    private Salesman salesmanFilter;
    private AuctionFilter auctionFilter;
    // private UserApp user;

    private List<Salesman> salesmanList;
    private List<Integer> greenPercentage = new ArrayList<Integer>();
    private List<Agreement> agreements;
    private List<BusinessType> businessTypes;

    private Salesman salesmanToUser;

    private SalesmanDao salesmanDao;
    private UserDao userDao;
    private CityDao cityDao;
    private StreetDao streetDao;
    private AuctionDao auctionDao;
    private StereotypeDao stereotypeDao;

    private DictionaryBean dictionaryBean;
    private AdminBean adminBean;

    private UserApp userApp;
    private String activationUrl;
    private String activationCode;
    private FacesContext facesContext;
    private ExternalContext ectx;

    private List<City> cities;
    private List<Area> areas;
    private List<Street> streets;
    private List<Stereotype> stereotypes;
    private List<Sector> sectors;
    private List<Tariff> tariffs;
    private Integer areaId;
    private Integer cityId;
    private Integer sectorId;
    private String streetName;

    private List<Auction> auctions;
    private List<UserApp> users;

    // Selection
    private Auction selectedAuction;
    private Agreement selectedAgreement;
    private Salesman selectedSalesman;

    // Buttons disable
    private Boolean auctionButtonDisabled;
    private boolean agreementButtonsDisabled;

    private boolean buttonsVisible = true;
    private boolean agentButtonsVisible = true;

    private boolean disableEdit = true;
    private boolean disableRemove = true;

    /**
     * Instantiates a new salesman bean.
     */
    public SalesmanBean() {
        log.info("SalesmanBean constructor");
        initialize();
    }

    /**
     * Initialize.
     */
    private void initialize() {
        notAvailableAction();

        initializeVars();

        clearSalesmanFilter();
        clearAuctionFilter();
        clearSalesman();

        initializeDao();

        try {
            initializeDicts();
        } catch (Exception e) {
            e.printStackTrace();
        }

        activationUrl = System.getProperty(SERVER_URL);

        if(activationUrl == null || activationUrl.isEmpty())
            activationUrl = BundlesUtils.getMessageResourceString("seam", "activation.url", null, Locale.getDefault())
                    .trim();

        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();

        filterSalesmanList();
    }

    /**
     * Initialize dao.
     */
    public void initializeDao() {
        salesmanDao = GuiceSingleton.getInstance().getInstance(SalesmanDao.class);
        userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);
        cityDao = GuiceSingleton.getInstance().getInstance(CityDao.class);
        streetDao = GuiceSingleton.getInstance().getInstance(StreetDao.class);
        auctionDao = GuiceSingleton.getInstance().getInstance(AuctionDao.class);
        stereotypeDao = GuiceSingleton.getInstance().getInstance(StereotypeDao.class);
    }

    /**
     * Initialize vars.
     */
    private void initializeVars() {
        dictionaryBean = ComponentLookup.lookupComponent("op.dictionaryBean");
        adminBean = ComponentLookup.lookupComponent("op.adminBean");

        userApp = new UserApp();
        areas = new ArrayList<Area>();
        streets = new ArrayList<Street>();
        tariffs = new ArrayList<Tariff>();
        stereotypes = new ArrayList<Stereotype>();
        sectors = new ArrayList<Sector>();
        salesmanList = new ArrayList<Salesman>();
    }

    /**
     * Initialize dicts.
     * 
     * @throws Exception
     *             the exception
     */
    private void initializeDicts() throws Exception {
        areas = dictionaryBean.getAreasList();
        streets = dictionaryBean.getStreetsList();
        tariffs = dictionaryBean.getTariffsList();
        stereotypes = dictionaryBean.getStereotypesList();
        sectors = DictUtil.getSectorListByType(true);
    }

    /**
     * Initializa new.
     */
    public void initializaNew() {
        clearSalesman();
    }

    /**
     * Prepare salesman list.
     */
    private void prepareSalesmanList() {
        try {
            salesmanList = salesmanDao.getAllSalesmans();
        } catch (Exception e) {
            log.error("error while getting Salesman List : ", e);
        }
        log.info("salesmanList : " + salesmanList);
    }

    /**
     * Refresh salesman list.
     */
    public void refreshSalesmanList() {
        prepareSalesmanList();
    }

    /**
     * Delete salesman.
     * 
     * @return the string
     */
    public String deleteSalesman() {
        log.info("salesman id: " + salesman.getSalesmanId());
        try {
            salesmanDao.deleteSalesman(salesman);
        } catch (Exception e) {
            e.printStackTrace();
        }
        prepareSalesmanList();
        notAvailableAction();
        return "logs";
    }

    /**
     * Update salesman assigned to user.
     */
    public void updateSalesmanAssignedToUser() {
        try {
            salesmanToUser = salesmanDao.getSalesmanByUserId(adminBean.getUserLog().getUserId());
        } catch (Exception e) {
            log.error("Error while geting Salesman assigned to User: ", e);
            e.printStackTrace();
        }
    }

    /**
     * Adds the salesman.
     * 
     * @return the string
     */
    public String addSalesman() {
        newSalesman = new Salesman();

        try {
            Area a = new Area();
            a.setAreaId(areaId);
            City c = new City();
            c.setCityId(cityId);
            c.setArea(a);

            Street tempStreet = new Street();
            tempStreet.setCity(c);
            tempStreet.setStreetName(streetName);

            Street s = streetDao.getStreet(tempStreet);

            log.info("s: " + s);

            if(s == null) {
                s = tempStreet;
                streetDao.saveStreet(s);
            }
            log.info("s StreetName: " + s.getStreetName());

            if(!Validations.validNip(salesman.getNip())) {
                warning("warning.nip");
                return "salesmanNew";
            }

            salesman.setCreatedAt(new Date());
            salesman.getAddress().setStreet(s);

            salesmanDao.saveAddress(salesman.getAddress());
            salesmanDao.saveSalesman(salesman);

            // user.setSalesman(salesman);
            // saveUser(user);

        } catch (Exception e) {
            e.printStackTrace();
        }

        for(int i = 0; i < salesman.getUserList().size(); i++) {
            UserApp user = salesman.getUserList().get(i);
            user.setSalesman(salesman);
            saveUser(user);
        }

        info("messages.save.complete");

        salesman = new Salesman();
        filterSalesmanList();

        return "logs";
    }

    /**
     * Update salesman.
     * 
     * @return the string
     */
    public String updateSalesman() {
        try {
            Area a = new Area();
            a.setAreaId(areaId);
            City c = new City();
            c.setCityId(cityId);
            c.setArea(a);

            Street tempStreet = new Street();
            tempStreet.setCity(c);
            tempStreet.setStreetName(streetName);

            Street s = streetDao.getStreet(tempStreet);

            log.info("s: " + s);

            if(s == null) {
                s = tempStreet;
                streetDao.saveStreet(s);
            }
            log.info("s StreetName: " + s.getStreetName());

            if(salesman.getAddress() != null) {
                salesman.getAddress().setStreet(s);
                if(salesman.getAddress().getAddressId() != null)
                    salesmanDao.updateAddress(salesman.getAddress());
                else
                    salesmanDao.saveAddress(salesman.getAddress());
            }

            salesmanDao.updateSalesman(salesman);
        } catch (Exception e) {
            e.printStackTrace();
        }

        for(int i = 0; i < salesman.getUserList().size(); i++) {
            UserApp user = salesman.getUserList().get(i);
            if(user.getUserId() == null || user.getUserId() == 0) {
                user.setSalesman(salesman);
                saveUser(user);
            } else {
                try {
                    userDao.updateUser(user);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        salesman = new Salesman();
        filterSalesmanList();

        PPEBean ppeBean = ComponentLookup.lookupComponent("op.ppeBean");
        ppeBean.setActiveTab("2");

        return "logs";
    }

    /**
     * Filter salesman list.
     */
    public void filterSalesmanList() {
        log.info("filterSalesmanList");
        try {
            salesmanList = salesmanDao.getSalesmans(salesmanFilter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Clear agent.
     */
    public void clearAgent() {
        userApp = new UserApp();
    }

    /**
     * Adds the agent.
     */
    public void addAgent() {
        log.info("beforce salesman.getUserList() size: " + salesman.getUserList().size());

        if(salesman.getUserList() == null)
            salesman.setUserList(new ArrayList<UserApp>());

        log.info("Add agent data: " + userApp.getFullName() + " " + userApp.getLogin());

        if(userApp.getUserId() == null)
            salesman.getUserList().add(userApp);

        userApp = new UserApp();

        log.info("after salesman.getUserList() size: " + salesman.getUserList().size());
    }

    /**
     * Clear salesman filter.
     */
    public void clearSalesmanFilter() {
        salesmanFilter = new Salesman();
        Address address = new Address();
        address.setStreet(new Street());
        salesmanFilter.setAddress(address);
        buttonsVisible = true;
    }

    /**
     * Clear salesman.
     */
    public void clearSalesman() {
        salesman = new Salesman();
        Address address = new Address();
        address.setStreet(new Street());
        salesman.setAddress(address);
        salesman.setRemoved(false);
        salesman.setUserList(new ArrayList<UserApp>());

        areaId = null;
        cityId = null;
    }

    /**
     * Cancel add salesman.
     * 
     * @return the string
     */
    public String cancelAddSalesman() {
        notAvailableAction();

        return "logs";
    }

    /**
     * Salesman edit listener.
     */
    public void salesmanEditListener() {
    	MenuBean menuBean = ComponentLookup.lookupComponent("op.menuBean");
    	menuBean.setBackTo("dictionaries");
    	
        if(salesman.getAddress() != null) {
            log.info("salesman.getAddress(): " + salesman.getAddress());
            log.info("salesman.getAddress().getStreet(): " + salesman.getAddress().getStreet());
            log.info("salesman.getAddress().getStreet().getStreetId(): "
                    + salesman.getAddress().getStreet().getStreetId());
            cityId = salesman.getAddress().getStreet().getCity().getCityId();
            log.info("salesman cityId: " + cityId);
            areaId = salesman.getAddress().getStreet().getCity().getArea().getAreaId();
            log.info("salesman areaId: " + areaId);
            streetName = salesman.getAddress().getStreet().getStreetName();
            log.info("salesman streetName: " + streetName);
        } else {
            Address address = new Address();
            salesman.setAddress(address);
        }
    }
    
    public void salesmanEditListenerLogs() {
    	MenuBean menuBean = ComponentLookup.lookupComponent("op.menuBean");
    	menuBean.setBackTo("logs");
    	
        if(salesman.getAddress() != null) {
            log.info("salesman.getAddress(): " + salesman.getAddress());
            log.info("salesman.getAddress().getStreet(): " + salesman.getAddress().getStreet());
            log.info("salesman.getAddress().getStreet().getStreetId(): "
                    + salesman.getAddress().getStreet().getStreetId());
            cityId = salesman.getAddress().getStreet().getCity().getCityId();
            log.info("salesman cityId: " + cityId);
            areaId = salesman.getAddress().getStreet().getCity().getArea().getAreaId();
            log.info("salesman areaId: " + areaId);
            streetName = salesman.getAddress().getStreet().getStreetName();
            log.info("salesman streetName: " + streetName);
        } else {
            Address address = new Address();
            salesman.setAddress(address);
        }
    }

    /**
     * Profile status converter.
     * 
     * @param status
     *            the status
     * @return the string
     */
    public String profileStatusConverter(Boolean status) {
        return BundlesUtils.getMessageResourceString("messages", "salesman.state." + status.toString(), null,
                Locale.getDefault());
    }

    /**
     * On salesman select.
     * 
     * @param event
     *            the event
     */
    public void onSalesmanSelect(SelectEvent event) {
        buttonsVisible = false;
        streetName = "";
        try {
            salesman.setUserList(userDao.getUsersBySalesman(salesman));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * On salesman unselect.
     * 
     * @param event
     *            the event
     */
    public void onSalesmanUnselect(UnselectEvent event) {
        clearSalesmanFilter();
    }

    /**
     * On row select action.
     * 
     * @param event
     *            the event
     */
    public void onRowSelectAction(SelectEvent event) {
        availableAction();
    }

    /**
     * On row unselect action.
     * 
     * @param event
     *            the event
     */
    public void onRowUnselectAction(UnselectEvent event) {
        notAvailableAction();
    }

    /**
     * Available action.
     */
    public void availableAction() {
        disableEdit = false;
        disableRemove = false;
    }

    /**
     * Not available action.
     */
    public void notAvailableAction() {
        salesman = new Salesman();

        disableEdit = true;
        disableRemove = true;
    }

    /**
     * Gets the salesman.
     * 
     * @return the salesman
     */
    public Salesman getSalesman() {
        return salesman;
    }

    /**
     * Sets the salesman.
     * 
     * @param salesman
     *            the new salesman
     */
    public void setSalesman(Salesman salesman) {
        this.salesman = salesman;
    }

    /**
     * Gets the salesman list.
     * 
     * @return the salesman list
     */
    public List<Salesman> getSalesmanList() {
        return salesmanList;
    }

    /**
     * Sets the salesman list.
     * 
     * @param salesmanList
     *            the new salesman list
     */
    public void setSalesmanList(List<Salesman> salesmanList) {
        this.salesmanList = salesmanList;
    }

    /**
     * Gets the user app.
     * 
     * @return the user app
     */
    public UserApp getUserApp() {
        return userApp;
    }

    /**
     * Sets the user app.
     * 
     * @param userApp
     *            the new user app
     */
    public void setUserApp(UserApp userApp) {
        this.userApp = userApp;
    }

    /**
     * Checks if is buttons visible.
     * 
     * @return true, if is buttons visible
     */
    public boolean isButtonsVisible() {
        return buttonsVisible;
    }

    /**
     * Sets the buttons visible.
     * 
     * @param buttonsVisible
     *            the new buttons visible
     */
    public void setButtonsVisible(boolean buttonsVisible) {
        this.buttonsVisible = buttonsVisible;
    }

    /**
     * Save user.
     * 
     * @param user
     *            the user
     * @return the string
     */
    public String saveUser(UserApp user) {
        boolean userNotExist;

        try {
            userNotExist = checkuUserLoginExist(user);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            userNotExist = false;

            String message = BundlesUtils.getMessageResourceString("messages", "login_exist_error", null,
                    ectx.getRequestLocale());
            FacesMessages.instance().add(FacesMessage.SEVERITY_ERROR, message);
        }

        if(!userNotExist) {
            addCallback(false);
            return "";
        }

        log.info("valdate form correct");

        user.setActive(false);
        user.setRemoved(false);
        user.setFirstLogin(false);
        user.setCreationDate(new Date());
        user.setActivateKey(ActivateUtil.getActivationCode(user.getLogin()));
        user.setUserRole(UserRole.salesman);
        user.setPassword("pass");

        this.activationCode = ActivateUtil.getActivationCode(user.getLogin());

        log.info("user activation code: " + activationCode);
        log.info("user login: " + user.getLogin());

        // save user
        try {
            userDao.saveUser(user);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            String addUserFail = BundlesUtils.getMessageResourceString("messages", "add_error", null,
                    ectx.getRequestLocale());
            FacesMessages.instance().add(FacesMessage.SEVERITY_ERROR, addUserFail);
            addCallback(false);
            return "";
        }

        // sent confirm mail
        try {
            sentEmail(user);
        } catch (Exception e) {

            log.info("Locale: " + ectx.getRequestLocale());
            log.error(e.getMessage(), e);

            String mailFail = BundlesUtils.getMessageResourceString("messages", "user.register.mail.fail", null,
                    ectx.getRequestLocale());

            FacesMessages.instance().add(FacesMessage.SEVERITY_ERROR, mailFail);

            try {
                userDao.deleteUser(user);
            } catch (Exception e1) {
                log.error(e1.getMessage(), e1);
                String addUserFail = BundlesUtils.getMessageResourceString("messages", "add_error", null,
                        ectx.getRequestLocale());
                FacesMessages.instance().add(FacesMessage.SEVERITY_ERROR, addUserFail);
                addCallback(false);
                return "";
            }
            addCallback(false);
            return "";
        }
        addCallback(true);
        return "";
    }

    /**
     * Sent email.
     * 
     * @param user
     *            the user
     * @throws Exception
     *             the exception
     */
    public void sentEmail(UserApp user) throws Exception {

        MailBean mailBean = ComponentLookup.lookupComponent("op.mailBean");

        log.info("sent email confirmation");
        log.info(activationUrl + "/createPassword.seam?code=" + user.getActivateKey() + "&login=" + user.getLogin());

        try {
            log.info("getting template...");
            mailBean.sendRegistrationEmail(
                    user,
                    activationUrl + "/op-web/createPassword.seam?code=" + user.getActivateKey() + "&login="
                            + user.getLogin());
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
            throw new Exception();
        }
    }

    /**
     * Adds the callback.
     * 
     * @param result
     *            the result
     */
    private void addCallback(boolean result) {
        RequestContext.getCurrentInstance().addCallbackParam("registerSuccessful", result);
    }

    /**
     * Checku user login exist.
     * 
     * @param user
     *            the user
     * @return true, if successful
     * @throws Exception
     *             the exception
     */
    public boolean checkuUserLoginExist(UserApp user) throws Exception {

        boolean userExist = false;

        try {
            userExist = userDao.checkLocalUserExist(user.getLogin());

        } catch (Exception e) {
            throw new Exception();
        }

        if(userExist) {
            String message = BundlesUtils.getMessageResourceString("messages", "login_exist", null,
                    ectx.getRequestLocale());
            FacesMessages.instance().add(FacesMessage.SEVERITY_WARN, message);
        }

        log.info("userExist: " + userExist);

        return !userExist;
    }

    /**
     * Gets the salesman filter.
     * 
     * @return the salesman filter
     */
    public Salesman getSalesmanFilter() {
        return salesmanFilter;
    }

    /**
     * Sets the salesman filter.
     * 
     * @param salesmanFilter
     *            the new salesman filter
     */
    public void setSalesmanFilter(Salesman salesmanFilter) {
        this.salesmanFilter = salesmanFilter;
    }

    /**
     * Gets the cities.
     * 
     * @return the cities
     */
    public List<City> getCities() {
        cities = new ArrayList<City>();

        if(areaId != null && areaId > 0) {
            Area area = new Area();
            area.setAreaId(areaId);
            try {
                City city = new City();
                city.setArea(area);
                cities = cityDao.getCities(city);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if(auctionFilter.getArea().getAreaId() != null) {
            try {
                City city = new City();
                city.setArea(auctionFilter.getArea());
                cities = cityDao.getCities(city);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return cities;
    }

    /**
     * Autocomplete street.
     * 
     * @param query
     *            the query
     * @return the list
     */
    public List<String> autocompleteStreet(String query) {
        List<String> suggestions = new ArrayList<String>();

        for(Street s : streets) {
            if(s.getStreetName().startsWith(query))
                suggestions.add(s.getStreetName());
        }
        return suggestions;
    }

    /**
     * Sets the cities.
     * 
     * @param cities
     *            the new cities
     */
    public void setCities(List<City> cities) {
        this.cities = cities;
    }

    /**
     * Gets the areas.
     * 
     * @return the areas
     */
    public List<Area> getAreas() {
        return areas;
    }

    /**
     * Sets the areas.
     * 
     * @param areas
     *            the new areas
     */
    public void setAreas(List<Area> areas) {
        this.areas = areas;
    }

    /**
     * Gets the area id.
     * 
     * @return the area id
     */
    public Integer getAreaId() {
        return areaId;
    }

    /**
     * Sets the area id.
     * 
     * @param areaId
     *            the new area id
     */
    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    /**
     * Gets the city id.
     * 
     * @return the city id
     */
    public Integer getCityId() {
        return cityId;
    }

    /**
     * Sets the city id.
     * 
     * @param cityId
     *            the new city id
     */
    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    /**
     * Gets the green percentage.
     * 
     * @return the green percentage
     */
    public List<Integer> getGreenPercentage() {
        if(greenPercentage.size() < 1) {
            for(int i = 0; i <= 100; i++) {
                greenPercentage.add(i);
            }
        }
        return greenPercentage;
    }

    /**
     * Sets the green percentage.
     * 
     * @param greenPercentage
     *            the new green percentage
     */
    public void setGreenPercentage(List<Integer> greenPercentage) {
        this.greenPercentage = greenPercentage;
    }

    /**
     * Gets the streets.
     * 
     * @return the streets
     */
    public List<Street> getStreets() {
        return streets;
    }

    /**
     * Sets the streets.
     * 
     * @param streets
     *            the new streets
     */
    public void setStreets(List<Street> streets) {
        this.streets = streets;
    }

    /**
     * Delete agent.
     */
    public void deleteAgent() {
        userApp.setRemoved(!userApp.getRemoved());

        clearAgent();
    }

    /**
     * On agent select.
     * 
     * @param event
     *            the event
     */
    public void onAgentSelect(SelectEvent event) {
        agentButtonsVisible = false;
    }

    /**
     * On agent unselect.
     * 
     * @param event
     *            the event
     */
    public void onAgentUnselect(UnselectEvent event) {
        clearAgent();
    }

    /**
     * Checks if is agent buttons visible.
     * 
     * @return true, if is agent buttons visible
     */
    public boolean isAgentButtonsVisible() {
        return agentButtonsVisible;
    }

    /**
     * Sets the agent buttons visible.
     * 
     * @param agentButtonsVisible
     *            the new agent buttons visible
     */
    public void setAgentButtonsVisible(boolean agentButtonsVisible) {
        this.agentButtonsVisible = agentButtonsVisible;
    }

    /**
     * Gets the auctions.
     * 
     * @return the auctions
     */
    public List<Auction> getAuctions() {
        return auctions;
    }

    /**
     * Sets the auctions.
     * 
     * @param auctions
     *            the new auctions
     */
    public void setAuctions(List<Auction> auctions) {
        this.auctions = auctions;
    }

    /**
     * Gets the users.
     * 
     * @return the users
     */
    public List<UserApp> getUsers() {
        return users;
    }

    /**
     * Sets the users.
     * 
     * @param users
     *            the new users
     */
    public void setUsers(List<UserApp> users) {
        this.users = users;
    }

    /**
     * Salesman details action.
     * 
     * @return the string
     */
    public String salesmanDetailsAction() {
        agreementButtonsDisabled = true;
        auctionButtonDisabled = true;

        selectedAgreement = new Agreement();
        selectedAuction = new Auction();

        OperatorInvoiceBean operatorInvoiceBean = ComponentLookup.lookupComponent("op.operatorInvoiceBean");
        operatorInvoiceBean.clearOperatorInvoice();
        operatorInvoiceBean.setSalesmanInvoice(true);

        OperatorAgreementBean operatorAgreementBean = ComponentLookup.lookupComponent("op.operatorAgreementBean");
        operatorAgreementBean.initializeAgreement(true);

        AuctionAgreementBean auctionAgreementBean = ComponentLookup.lookupComponent("op.auctionAgreementBean");
        auctionAgreementBean.clearAgreementFilter();

        return "salesmanDetails";
    }

    /**
     * Search auctions.
     */
    public void searchAuctions() {
        log.info("Search auctions");

        try {
            auctionFilter.setSalesman(salesman);
            auctionFilter.getAuction().setStatus(AuctionStatus.INPROGRESS);
            auctions = auctionDao.getAuctions(auctionFilter);
            if(hasAuctionsOnList(auctions)) {
                log.info("Found auctions: " + auctions.size());
            } else {
                log.info("Not found auctions");
            }
        } catch (Exception e) {
            log.error("Problem while search auctions, ", e);
        }
    }

    /**
     * Checks for auctions on list.
     * 
     * @param auctionList
     *            the auction list
     * @return true, if successful
     */
    private boolean hasAuctionsOnList(List<Auction> auctionList) {
        if(null == auctionList) {
            return false;
        }
        if(auctionList.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Warning.
     * 
     * @param message_code
     *            the message_code
     */
    @SuppressWarnings({ "deprecation" })
    private void warning(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_WARN,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    /**
     * Info.
     * 
     * @param message_code
     *            the message_code
     */
    @SuppressWarnings({ "deprecation" })
    private void info(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_INFO,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    /**
     * Gets the new salesman.
     * 
     * @return the new salesman
     */
    public Salesman getNewSalesman() {
        return newSalesman;
    }

    /**
     * Sets the new salesman.
     * 
     * @param newSalesman
     *            the new new salesman
     */
    public void setNewSalesman(Salesman newSalesman) {
        this.newSalesman = newSalesman;
    }

    /**
     * Checks if is disable edit.
     * 
     * @return true, if is disable edit
     */
    public boolean isDisableEdit() {
        return disableEdit;
    }

    /**
     * Sets the disable edit.
     * 
     * @param disableEdit
     *            the new disable edit
     */
    public void setDisableEdit(boolean disableEdit) {
        this.disableEdit = disableEdit;
    }

    /**
     * Checks if is disable remove.
     * 
     * @return true, if is disable remove
     */
    public boolean isDisableRemove() {
        return disableRemove;
    }

    /**
     * Sets the disable remove.
     * 
     * @param disableRemove
     *            the new disable remove
     */
    public void setDisableRemove(boolean disableRemove) {
        this.disableRemove = disableRemove;
    }

    /**
     * Gets the selected auction.
     * 
     * @return the selected auction
     */
    public Auction getSelectedAuction() {
        return selectedAuction;
    }

    /**
     * Sets the selected auction.
     * 
     * @param selectedAuction
     *            the new selected auction
     */
    public void setSelectedAuction(Auction selectedAuction) {
        this.selectedAuction = selectedAuction;
    }

    /**
     * Gets the selected agreement.
     * 
     * @return the selected agreement
     */
    public Agreement getSelectedAgreement() {
        return selectedAgreement;
    }

    /**
     * Sets the selected agreement.
     * 
     * @param selectedAgreement
     *            the new selected agreement
     */
    public void setSelectedAgreement(Agreement selectedAgreement) {
        this.selectedAgreement = selectedAgreement;
    }

    /**
     * Gets the selected salesman.
     * 
     * @return the selected salesman
     */
    public Salesman getSelectedSalesman() {
        return selectedSalesman;
    }

    /**
     * Sets the selected salesman.
     * 
     * @param selectedSalesman
     *            the new selected salesman
     */
    public void setSelectedSalesman(Salesman selectedSalesman) {
        this.selectedSalesman = selectedSalesman;
    }

    /**
     * Gets the auction button disabled.
     * 
     * @return the auction button disabled
     */
    public Boolean getAuctionButtonDisabled() {
        return auctionButtonDisabled;
    }

    /**
     * Sets the auction button disabled.
     * 
     * @param auctionButtonDisabled
     *            the new auction button disabled
     */
    public void setAuctionButtonDisabled(Boolean auctionButtonDisabled) {
        this.auctionButtonDisabled = auctionButtonDisabled;
    }

    /**
     * Gets the stereotypes.
     * 
     * @return the stereotypes
     */
    public List<Stereotype> getStereotypes() {
        return stereotypes;
    }

    /**
     * Sets the stereotypes.
     * 
     * @param stereotypes
     *            the new stereotypes
     */
    public void setStereotypes(List<Stereotype> stereotypes) {
        this.stereotypes = stereotypes;
    }

    /**
     * Gets the sectors.
     * 
     * @return the sectors
     */
    public List<Sector> getSectors() {
        return sectors;
    }

    /**
     * Sets the sectors.
     * 
     * @param sectors
     *            the new sectors
     */
    public void setSectors(List<Sector> sectors) {
        this.sectors = sectors;
    }

    /**
     * Gets the tariffs.
     * 
     * @return the tariffs
     */
    public List<Tariff> getTariffs() {
        return tariffs;
    }

    /**
     * Sets the tariffs.
     * 
     * @param tariffs
     *            the new tariffs
     */
    public void setTariffs(List<Tariff> tariffs) {
        this.tariffs = tariffs;
    }

    /**
     * Gets the auction filter.
     * 
     * @return the auction filter
     */
    public AuctionFilter getAuctionFilter() {
        return auctionFilter;
    }

    /**
     * Sets the auction filter.
     * 
     * @param auctionFilter
     *            the new auction filter
     */
    public void setAuctionFilter(AuctionFilter auctionFilter) {
        this.auctionFilter = auctionFilter;
    }

    /**
     * Gets the sector id.
     * 
     * @return the sector id
     */
    public Integer getSectorId() {
        return sectorId;
    }

    /**
     * Sets the sector id.
     * 
     * @param sectorId
     *            the new sector id
     */
    public void setSectorId(Integer sectorId) {
        this.sectorId = sectorId;
    }

    /**
     * Update stereotype.
     */
    public void updateStereotype() {
        if(sectorId != null) {
            try {
                auctionFilter.getAuction().getCloud().setStereotype(stereotypeDao.getStereotypeBySectorId(sectorId));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            auctionFilter.getAuction().getCloud().setStereotype(new Stereotype());
        }
    }

    /**
     * Clear auction filter.
     */
    public void clearAuctionFilter() {
        auctionFilter = new AuctionFilter();
    }

    /**
     * Gets the agreements.
     * 
     * @return the agreements
     */
    public List<Agreement> getAgreements() {
        return agreements;
    }

    /**
     * Sets the agreements.
     * 
     * @param agreements
     *            the new agreements
     */
    public void setAgreements(List<Agreement> agreements) {
        this.agreements = agreements;
    }

    /**
     * Checks if is agreement buttons disabled.
     * 
     * @return true, if is agreement buttons disabled
     */
    public boolean isAgreementButtonsDisabled() {
        return agreementButtonsDisabled;
    }

    /**
     * Sets the agreement buttons disabled.
     * 
     * @param agreementButtonsDisabled
     *            the new agreement buttons disabled
     */
    public void setAgreementButtonsDisabled(boolean agreementButtonsDisabled) {
        this.agreementButtonsDisabled = agreementButtonsDisabled;
    }

    /**
     * Download invoice.
     * 
     * @param invoice
     *            the invoice
     * @return the streamed content
     */
    public StreamedContent downloadInvoice(OperatorInvoice invoice) {
        InputStream is = new ByteArrayInputStream(invoice.getFile());
        StreamedContent file = new DefaultStreamedContent(is);

        return file;
    }

    /**
     * Auction details.
     */
    public void auctionDetails() {
        AuctionBean auctionBean = ComponentLookup.lookupComponent("op.operatorAuctionBean");
        auctionBean.setAuctionComponents(selectedAuction);
    }

    /**
     * On auction select.
     * 
     * @param event
     *            the event
     */
    public void onAuctionSelect(SelectEvent event) {
        auctionButtonDisabled = false;
    }

    /**
     * On auction unselect.
     * 
     * @param event
     *            the event
     */
    public void onAuctionUnselect(UnselectEvent event) {
        auctionButtonDisabled = true;
        selectedAuction = new Auction();
    }

    /**
     * Gets the business types.
     * 
     * @return the business types
     */
    public List<BusinessType> getBusinessTypes() {
        businessTypes = new ArrayList<BusinessType>();

        for(BusinessType a : BusinessType.values()) {
            a.setLabel(BundlesUtils.getMessageResourceString("messages", "business.type." + a, null,
                    Locale.getDefault()));
            businessTypes.add(a);
        }

        return businessTypes;
    }

    /**
     * Sets the business types.
     * 
     * @param businessTypes
     *            the new business types
     */
    public void setBusinessTypes(List<BusinessType> businessTypes) {
        this.businessTypes = businessTypes;
    }

    /**
     * Gets the salesman to user.
     * 
     * @return the salesman to user
     */
    public Salesman getSalesmanToUser() {
        return salesmanToUser;
    }

    /**
     * Sets the salesman to user.
     * 
     * @param salesmanToUser
     *            the new salesman to user
     */
    public void setSalesmanToUser(Salesman salesmanToUser) {
        this.salesmanToUser = salesmanToUser;
    }

    /**
     * Gets the street name.
     * 
     * @return the street name
     */
    public String getStreetName() {
        return streetName;
    }

    /**
     * Sets the street name.
     * 
     * @param streetName
     *            the new street name
     */
    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }
}
