package pl.op.web.beans.dictionary;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.DeviceTypeDao;
import pl.op.dao.LocationDao;
import pl.op.dao.MessageRecommendationsDao;
import pl.op.dao.PPEDao;
import pl.op.dao.TariffDao;
import pl.op.model.contract.Location;
import pl.op.model.contract.PPE;
import pl.op.model.device.Device;
import pl.op.model.device.DeviceType;
import pl.op.model.dict.MessageRecommendations;
import pl.op.model.dict.Tariff;
import pl.op.model.user.UserApp;
import pl.op.web.beans.AdminBean;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class TodoBean. This class manages the todo list. Can
 * add/edit/delete data from database table named "tb_messageRecommendations".
 */
@Name("op.todoBean")
@Scope(ScopeType.SESSION)
public class TodoBean implements Serializable {

	private static final long serialVersionUID = -3789005989715893543L;
	
	private Logger log = LoggerFactory.getLogger(TodoBean.class);
	
	private UserApp userApp;

	private MessageRecommendationsDao messageRecommendationsDao;
	private LocationDao locationDao;
	private PPEDao ppeDao;
	private TariffDao tariffDao;
	private DeviceTypeDao deviceTypeDao;

	private MessageRecommendations messageRecommendation;
	private MessageRecommendations messageRecommendationSelected;
	private List<MessageRecommendations> messageRecommendations;	
	private List<MessageRecommendations> messageRecommendationsList;
	private List<SelectItem> selectTariff;
	private List<SelectItem> selectDeviceType;

	private Integer selectedTariff;
	private Integer selectedDeviceType;
	
	private boolean edit;
	private Boolean disableRemove;
	private Boolean disableEdit;

	public TodoBean() {
		log.info("TodoBean Constructor");
		initialize();
	}

	/**
	 * Initialize the TodoBean.
	 */
	private void initialize() {
		
		messageRecommendationsDao = GuiceSingleton.getInstance().getInstance(MessageRecommendationsDao.class);
		locationDao = GuiceSingleton.getInstance().getInstance(LocationDao.class);
		ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);
		tariffDao = GuiceSingleton.getInstance().getInstance(TariffDao.class);
		deviceTypeDao = GuiceSingleton.getInstance().getInstance(DeviceTypeDao.class);
		
		setLoggedUserApp();
		prepareTodo();
		
	}
	
	/**
	 * Filling tariffs select list.
	 */
	private void fillSelectTariff() {
		selectTariff = new ArrayList<SelectItem>();
		try {
			List<Tariff> tariffs = tariffDao.getTariffs(null);
			for(Tariff tariff : tariffs){
				selectTariff.add(new SelectItem(tariff.getTariffId(), tariff.getTariffName()));
				log.debug("Tariff ID: " + tariff.getTariffId());
				log.debug("Tariff Name: " + tariff.getTariffName());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Filling device types select list.
	 */
	private void fillSelectDeviceType() {
		selectDeviceType = new ArrayList<SelectItem>();
		try {
			List<DeviceType> deviceTypes = deviceTypeDao.getDeviceTypes();
			for(DeviceType deviceType : deviceTypes){
				selectDeviceType.add(new SelectItem(deviceType.getDeviceTypeId(), deviceType.getName()));
				log.debug("Device Type ID: " + deviceType.getDeviceTypeId());
				log.debug("Device Type Name: " + deviceType.getName());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	/**
	 * Deletes todo form database.
	 */
	public void deleteTodo(){
		messageRecommendation = messageRecommendationSelected;
		try {
			messageRecommendationsDao.deleteMessageRecommendations(messageRecommendation);
		} catch (Exception e) {
			e.printStackTrace();
		}	
		loadTodo();
	}
	
	/**
	 * Cancel add todo.
	 *
	 * @return the string
	 */
	public String cancelAddTodo(){
		loadTodo();
		return "dictionaries";		
	}
	
	/**
	 * Edits the todo selected from XHTML template.
	 *
	 * @return the string
	 */
	public String editTodo(){
		edit = true;
		fillSelectTariff();
		fillSelectDeviceType();
		messageRecommendation = messageRecommendationSelected;
		if(messageRecommendation.getTariff() != null){
			selectedTariff = messageRecommendation.getTariff().getTariffId();
		}
		if(messageRecommendation.getDeviceType() != null){
			selectedDeviceType = messageRecommendation.getDeviceType().getDeviceTypeId();
		}
		return "todo";
	}
	
	/**
	 * Prepares the data for XHTML template to add new todo.
	 *
	 * @return the string
	 */
	public String addTodo(){
		edit = false;
		fillSelectTariff();
		fillSelectDeviceType();
		messageRecommendation = new MessageRecommendations();
		messageRecommendationSelected = new MessageRecommendations();
		return "todo";		
	}
	
	/**
	 * Saves todo defined in XHTML template.
	 *
	 * @return the string
	 */
	public String saveTodo() {
		try {
			if(selectedDeviceType > 0){
				DeviceType deviceType = deviceTypeDao.getDeviceTypeById(selectedDeviceType);
				messageRecommendation.setDeviceType(deviceType);
			}
			if(selectedTariff > 0){
				Tariff tariff = tariffDao.getTariffById(selectedTariff);
				messageRecommendation.setTariff(tariff);
			}
			if (edit) {
				messageRecommendationsDao.updateMessageRecommendations(messageRecommendation);
			} else {
				messageRecommendationsDao.saveMessageRecommendations(messageRecommendation);
			}
		} catch (Exception e) {
			log.error("Error while saveTariff: ", e);
		}		
		loadTodo();
		return "dictionaries";			
	}
	
	/**
	 * On row select todo list.
	 *
	 * @param event the event
	 */
	public void onRowSelectTodoList(SelectEvent event) {
		this.disableRemove = false;
		this.disableEdit = false;
	}
	
	/**
	 * Downloads todo from database and prepares list for display.
	 */
	public void loadTodo(){
		
		this.messageRecommendation = new MessageRecommendations();
		this.messageRecommendationSelected = new MessageRecommendations();
		this.disableRemove = true;
		this.disableEdit = true;
		this.selectedDeviceType = 0;
		this.selectedTariff = 0;
		
		try {
			messageRecommendationsList = messageRecommendationsDao.getMessageRecommendations();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Refresh todo.
	 */
	public void refreshTodo(){
		setLoggedUserApp();
		prepareTodo();
	}
	
	/**
	 * Prepare todo.
	 */
	public void prepareTodo(){
		
		List<MessageRecommendations> nullMessageRecommendations = new ArrayList<MessageRecommendations>();
		List<MessageRecommendations> nullMessageRecommendationsConstant = new ArrayList<MessageRecommendations>();
		try {
			nullMessageRecommendations = messageRecommendationsDao.getMessageRecommendationsAllByNull(false);
			nullMessageRecommendationsConstant = messageRecommendationsDao.getMessageRecommendationsAllByNull(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		messageRecommendations = new ArrayList<MessageRecommendations>();
		if(nullMessageRecommendations.isEmpty() == false){
			for(MessageRecommendations mr : nullMessageRecommendations){			
				if(checkDate(mr)){
					messageRecommendations.add(mr);
				}
			}
		}
		if(nullMessageRecommendationsConstant.isEmpty() == false){
			for(MessageRecommendations mrc : nullMessageRecommendationsConstant){
				messageRecommendations.add(mrc);
			}
		}
		
		List<Integer> tariffIds = new ArrayList<Integer>();
		List<Integer> deviceTypeIds = new ArrayList<Integer>();
		
		try {
			List<Location> locations = locationDao.getLocationByUserApp(userApp);
			if(locations.isEmpty() == false){
				for(Location location : locations){
					List<PPE> ppes = location.getPpes();
					if(ppes.isEmpty() == false){
						for(PPE ppe : ppes){
							Tariff tariff = ppeDao.getActualTariff(ppe);
							if(tariff.getTariffId() != null){
								tariffIds.add(tariff.getTariffId());
							}
						}
					}
					List<Device> devices = location.getDevices();
					if(devices.isEmpty() == false){
						for(Device device : devices){
							deviceTypeIds.add(device.getDeviceType().getDeviceTypeId());
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(tariffIds.size() > 0){
			for(Integer tariffId : tariffIds){
				try {
					List<MessageRecommendations> tariffMessageRecommendations = messageRecommendationsDao.getMessageRecommendationsAllByTariffId(tariffId, false);
					List<MessageRecommendations> tariffMessageRecommendationsConstant = messageRecommendationsDao.getMessageRecommendationsAllByTariffId(tariffId, true);
					if(tariffMessageRecommendations.isEmpty() == false){
						for(MessageRecommendations mr : tariffMessageRecommendations){				
							if(checkDate(mr)){
								messageRecommendations.add(mr);
							}
						}
					}
					if(tariffMessageRecommendationsConstant.isEmpty() == false){
						for(MessageRecommendations mrc : tariffMessageRecommendationsConstant){
							messageRecommendations.add(mrc);
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}				
			}
		}
		
		if(deviceTypeIds.size() > 0){
			for(Integer deviceTypeId : deviceTypeIds){
				try {
					List<MessageRecommendations> deviceTypeMessageRecommendations = messageRecommendationsDao.getMessageRecommendationsAllByDeviceTypeId(deviceTypeId, false);
					List<MessageRecommendations> deviceTypeMessageRecommendationsConstant = messageRecommendationsDao.getMessageRecommendationsAllByDeviceTypeId(deviceTypeId, true);
					if(deviceTypeMessageRecommendations.isEmpty() == false){
						for(MessageRecommendations mr : deviceTypeMessageRecommendations){				
							if(checkDate(mr)){
								messageRecommendations.add(mr);
							}
						}
					}
					if(deviceTypeMessageRecommendationsConstant.isEmpty() == false){
						for(MessageRecommendations mrc : deviceTypeMessageRecommendationsConstant){
							messageRecommendations.add(mrc);
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}	
			}
		}
		
		if(deviceTypeIds.size() > 0 && tariffIds.size() > 0){
			for(Integer tariffId : tariffIds){
				for(Integer deviceTypeId : deviceTypeIds){
					try {
						List<MessageRecommendations> deviceTypeAndTariffMessageRecommendations = messageRecommendationsDao.getMessageRecommendationsAllByDeviceTypeIdAndTariffId(deviceTypeId, tariffId, false);
						List<MessageRecommendations> deviceTypeAndTariffMessageRecommendationsConstant = messageRecommendationsDao.getMessageRecommendationsAllByDeviceTypeIdAndTariffId(deviceTypeId, tariffId, true);
						if(deviceTypeAndTariffMessageRecommendations.isEmpty() == false){
							for(MessageRecommendations mr : deviceTypeAndTariffMessageRecommendations){				
								if(checkDate(mr)){
									messageRecommendations.add(mr);
								}
							}
						}
						if(deviceTypeAndTariffMessageRecommendationsConstant.isEmpty() == false){
							for(MessageRecommendations mrc : deviceTypeAndTariffMessageRecommendationsConstant){
								messageRecommendations.add(mrc);
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		
		//5 = wielkosc listy
		messageRecommendations = randomMessageRecommendations(messageRecommendations, 5);
		
	}
	
	
	/**
	 * Random message recommendations.
	 *
	 * @param mr the mr
	 * @param size the size
	 * @return the list
	 */
	private List<MessageRecommendations> randomMessageRecommendations(List<MessageRecommendations> mr, Integer size){
		
		List<MessageRecommendations> messageRecommendationsList = new ArrayList<MessageRecommendations>();
		
		Collections.shuffle(mr);
		
		for(int i=0;i<mr.size();i++){
			if(i >= size){
				break;
			}else{
				messageRecommendationsList.add(mr.get(i));
			}
		}
		
		return messageRecommendationsList;
		
	}
	
	/**
	 * Check date.
	 *
	 * @param mr the mr
	 * @return the boolean
	 */
	@SuppressWarnings("deprecation")
	private Boolean checkDate(MessageRecommendations mr){
		
		Date now = new Date();
		Integer month = now.getMonth();
		Integer day = now.getDay();
		
		Date from = mr.getDateFrom();
		Integer monthFrom = from.getMonth();
		Integer dayFrom = from.getDay();
		
		Date to = mr.getDateTo();
		Integer monthTo = to.getMonth();
		Integer dayTo = to.getDay();
		
		Boolean allowedAdd = false;
		
		if(monthFrom >= month && monthTo <= month){
			if(monthFrom.equals(month) || monthTo.equals(month)){
				if(dayFrom >= day && dayTo <= day){
					allowedAdd = true;
				}
			} else {
				allowedAdd = true;
			}
		}
		
		return allowedAdd;
		
	}

	/**
	 * Sets the logged user app.
	 */
	public void setLoggedUserApp() {
		FacesContext ctx = FacesContext.getCurrentInstance();
		AdminBean adminBean = (AdminBean) ctx.getApplication().getELResolver()
				.getValue(ctx.getELContext(), null, "op.adminBean");

		try {
			setUserApp(adminBean.getUserLog());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public UserApp getUserApp() {
		return userApp;
	}

	public void setUserApp(UserApp userApp) {
		this.userApp = userApp;
	}

	public List<MessageRecommendations> getMessageRecommendations() {
		return messageRecommendations;
	}

	public void setMessageRecommendations(List<MessageRecommendations> messageRecommendations) {
		this.messageRecommendations = messageRecommendations;
	}

	public List<MessageRecommendations> getMessageRecommendationsList() {
		return messageRecommendationsList;
	}

	public void setMessageRecommendationsList(
			List<MessageRecommendations> messageRecommendationsList) {
		this.messageRecommendationsList = messageRecommendationsList;
	}

	public MessageRecommendations getMessageRecommendation() {
		return messageRecommendation;
	}

	public void setMessageRecommendation(MessageRecommendations messageRecommendation) {
		this.messageRecommendation = messageRecommendation;
	}

	public MessageRecommendations getMessageRecommendationSelected() {
		return messageRecommendationSelected;
	}

	public void setMessageRecommendationSelected(
			MessageRecommendations messageRecommendationSelected) {
		this.messageRecommendationSelected = messageRecommendationSelected;
	}

	public Boolean getDisableRemove() {
		return disableRemove;
	}

	public void setDisableRemove(Boolean disableRemove) {
		this.disableRemove = disableRemove;
	}

	public Boolean getDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(Boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isEdit() {
		return edit;
	}

	public void setEdit(boolean edit) {
		this.edit = edit;
	}

	public List<SelectItem> getSelectTariff() {
		return selectTariff;
	}

	public void setSelectTariff(List<SelectItem> selectTariff) {
		this.selectTariff = selectTariff;
	}

	public List<SelectItem> getSelectDeviceType() {
		return selectDeviceType;
	}

	public void setSelectDeviceType(List<SelectItem> selectDeviceType) {
		this.selectDeviceType = selectDeviceType;
	}

	public Integer getSelectedTariff() {
		return selectedTariff;
	}

	public void setSelectedTariff(Integer selectedTariff) {
		this.selectedTariff = selectedTariff;
	}

	public Integer getSelectedDeviceType() {
		return selectedDeviceType;
	}

	public void setSelectedDeviceType(Integer selectedDeviceType) {
		this.selectedDeviceType = selectedDeviceType;
	}
}