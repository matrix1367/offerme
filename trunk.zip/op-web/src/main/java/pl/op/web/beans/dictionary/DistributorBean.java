package pl.op.web.beans.dictionary;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.DistributorDao;
import pl.op.model.dict.Distributor;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class DistributorBean. This class manages the distributors. Can
 * add/edit/delete data from database table named "tb_distributor".
 */
@Name("op.distributorBean")
@Scope(ScopeType.SESSION)

public class DistributorBean implements Serializable{

	private static final long serialVersionUID = 5779077752809080711L;

	private Logger log = LoggerFactory.getLogger(DistributorBean.class);
	
	private List<Distributor> distributorsList;
	private Distributor newDistributor;
	private Distributor selectedDistributor;
	
	private boolean edit;
	private boolean disableShow = true;
	private boolean disableEdit = true;
	private boolean disableRemove = true;
	
	private DistributorDao distributorDao;
	
	public DistributorBean() {
		log.info("DistributorBean constructor");
		initialize();
	}
	
	/**
	 * Initialize the DistributorBean.
	 */
	private void initialize() {
		notAvailableAction();
		
		distributorDao = GuiceSingleton.getInstance().getInstance(DistributorDao.class);
		
		distributorsList = new ArrayList<Distributor>();
	}
	
	/**
	 * Downloads distributors from database and prepares list for display.
	 */
	public void refreshDistributorList() {
		try {
			distributorsList = distributorDao.getDistributors();
		} catch (Exception e) {
			log.error("error while getting distributors: ", e);
		}
	}

	/**
	 * Prepares the data for XHTML template to add new distributor.
	 *
	 * @return the string
	 */
	public String addDistributor() {
		edit = false;
		selectedDistributor = new Distributor();
		newDistributor = new Distributor();
		return "distributors";
	}

	/**
	 * Cancel add distributor.
	 *
	 * @return the string
	 */
	public String cancelAddDistributor() {
		notAvailableAction();
		return "dictionaries";
	}

	/**
	 * Saves distributor defined in XHTML template.
	 *
	 * @return the string
	 */
	public String saveDistributor() {
		try {
			if (edit) {
				distributorDao.updateDistributor(selectedDistributor);
			} else {
				distributorDao.saveDistributor(newDistributor);
			}
		} catch (Exception e) {
			log.error("Error while saveDistributor: ", e);
		}
		refreshDistributorList();
		return "dictionaries";
	}

	/**
	 * Deletes distributor form database.
	 */
	public void deleteDistributor() {
		try {
			distributorDao.deleteDistributor(selectedDistributor);
		} catch (Exception e) {
			log.error("Error while deleteDistributor: ", e);
		}
		refreshDistributorList();
		notAvailableAction();
	}

	/**
	 * Edits the distributor selected from XHTML template.
	 *
	 * @return the string
	 */
	public String editDistributor() {
		edit = true;
		newDistributor = selectedDistributor;
		return "distributors";
	}
	
	/**
	 * On row select dictionaries list.
	 *
	 * @param event the event
	 */
	public void onRowSelectDictionariesList(SelectEvent event) {
		availableAction();
	}

	/**
	 * On row unselect dictionaries list.
	 *
	 * @param event the event
	 */
	public void onRowUnselectDictionariesList(UnselectEvent event) {
		notAvailableAction();
	}

	/**
	 * Activates if action on selected element is available.
	 */
	public void availableAction() {
		disableShow = false;
		disableEdit = false;
		disableRemove = false;
	}
	
	/**
	 * Activates if action on selected element is not available.
	 */
	public void notAvailableAction() {
		selectedDistributor = new Distributor();
		
		disableShow = true;
		disableEdit = true;
		disableRemove = true;
	}
	
	public Distributor getNewDistributor() {
		return newDistributor;
	}

	public void setNewDistributor(Distributor newDistributor) {
		this.newDistributor = newDistributor;
	}
	
	public List<Distributor> getDistributorsList() {
		return distributorsList;
	}

	public void setDistributorList(List<Distributor> distributorsList) {
		this.distributorsList = distributorsList;
	}
	
	public Distributor getSelectedDistributor() {
		return selectedDistributor;
	}

	public void setSelectedDistributor(Distributor selectedDistributor) {
		this.selectedDistributor = selectedDistributor;
	}
	
	public boolean isDisableShow() {
		return disableShow;
	}

	public void setDisableShow(boolean disableShow) {
		this.disableShow = disableShow;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}

	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}
}