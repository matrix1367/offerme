package pl.op.web.common;

import java.util.Locale;
import java.util.ResourceBundle;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

/** 
 * Generic Enum Type converter. Converts an enum value to a language specific and display-friendly 
 * label. The label should be defined in a messagebundle with the following convention. 
 * 
 * [Full enum classname].[Enum field]=Enter displaylabel here. 
 * 
 * i.e. 
 * 
 * nl.jwse.sample.enumsample.type.Card.HEARTS=Harten 
 * 
 * @author Jeroen Wolsink 
 * 
 */  

@FacesConverter(value = "op.LocalizedEnumConverter")
public class LocalizedEnumConverter implements Converter {  
	  
    @SuppressWarnings("unchecked")  
    public Object getAsObject(FacesContext fc, UIComponent comp,  
            String value) {  
        Class enumType = comp.getValueExpression("value").getType(fc.getELContext());  
        return Enum.valueOf(enumType, value);  
    }  
  
    public String getAsString(FacesContext fc, UIComponent component,  
            Object object) {  
        if (object == null) {  
            return null;  
        }  
        Enum<?> type = (Enum<?>) object;  
  
        return getEnumLabel(type, fc);  
    }  
  
    /** 
     * Creates a localized label for the enum type. The label must be 
     * defined in the resource bundle, or else the toString() value will 
     * bee returned. 
     * @param type EnumType 
     * @param fc FacesContext 
     * @return The label for the enumerated type 
     */  
    private String getEnumLabel(Enum<?> type, FacesContext fc) {
        Locale locale = fc.getExternalContext().getRequestLocale(); 
        
        String label = null;  
        
        ResourceBundle rb = ResourceBundle.getBundle("messages", locale);  
        try {  
            String key = generateKey(type);  
            label = rb.getString(key);  
        } catch (Exception e) {  
            label = type.toString();  
        }  
        
       return label;     
    }  
  
    /** 
     * Generates a message bundle key based on an Enum Type. 
     * @param type EnumType 
     * @return Message bundle key 
     */  
    private String generateKey(Enum<?> type) {  
  
        String className = type.getClass().getName();  
        String key = className + '.' + type.toString();  
  
        return key;  
    }  
}  