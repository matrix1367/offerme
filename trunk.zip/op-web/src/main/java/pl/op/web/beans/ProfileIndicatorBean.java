package pl.op.web.beans;

import java.io.IOException;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.ProfileDao;
import pl.op.model.dict.Tariff;
import pl.op.model.profile.DayType;
import pl.op.model.profile.ProfileIndicator;
import pl.op.model.profile.ProfileValue;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class ProfileIndicatorBean.
 */
@Name("op.profileIndicatorBean")
@Scope(ScopeType.SESSION)
public class ProfileIndicatorBean {

    private Logger log = LoggerFactory.getLogger(ProfileIndicatorBean.class);

    private UploadedFile profileIndicatorFile;
    private Tariff tariff;
    private Integer tariffId;

    private ProfileDao profileDao;

    /**
     * Instantiates a new profile indicator bean.
     */
    public ProfileIndicatorBean() {
        log.info("ProfileIndicatorBean constructor");
        initialize();
    }

    /**
     * Initialize.
     */
    public void initialize() {
        profileDao = GuiceSingleton.getInstance().getInstance(ProfileDao.class);
        tariff = new Tariff();
    }

    /**
     * Read.
     */
    public void read() {
        tariff = new Tariff();
        tariff.setTariffId(tariffId);

        deleteProfileToTariff(tariffId);

        Workbook w;
        try {
            w = Workbook.getWorkbook(profileIndicatorFile.getInputstream());
            Sheet sheet = w.getSheet(0);

            log.info("start parse sheet");
            ProfileIndicator profileIndicator = null;
            String month = "";
            for(int i = 3; i < 39; i++) {
                for(int j = 0; j < sheet.getColumns() - 1; j++) {

                    Cell cell = sheet.getCell(j, i);

                    if(j == 0) {
                        if(cell.getContents().length() > 0)
                            month = cell.getContents();

                        profileIndicator = new ProfileIndicator();
                        profileIndicator.setProfileName(sheet.getCell(0, 0).getContents());
                        profileIndicator.setTariff(tariff);
                        profileIndicator.setMonth(month);
                    }

                    if(j == 1) {
                        String dayTypeString = cell.getContents().toUpperCase().replaceAll("\\s+", "");
                        DayType dayType = null;

                        if(dayTypeString.equals("PON-PT")) {
                            dayType = DayType.MONDAY_FRIDAY;
                        } else if(dayTypeString.equals("SB")) {
                            dayType = DayType.SATURDAY;
                        } else if(dayTypeString.equals("ND")) {
                            dayType = DayType.SUNDAY;
                        }

                        if(dayType == null)
                            log.info("dzien to =" + dayTypeString);

                        profileIndicator.setDayType(dayType);

                        log.info("saveProfileIndicator");
                        profileDao.saveProfileIndicator(profileIndicator);
                    }

                    if(j > 1 && j < 26) {
                        ProfileValue profileValue = new ProfileValue();

                        profileValue.setValue(Double.parseDouble(cell.getContents().replace(",", ".")));
                        profileValue.setProfileIndicator(profileIndicator);
                        profileValue.setHour(j - 1);
                        log.info("saveProfileValue");
                        profileDao.saveProfileValue(profileValue);
                    }

                    if(j == 26) {
                        profileIndicator.setDayQuantity(Integer.parseInt(cell.getContents()));

                        profileDao.updateProfileIndicator(profileIndicator);
                    }
                }
            }
            log.info("end parse sheet");
        } catch (BiffException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Delete profile to tariff.
     * 
     * @param tariffId
     *            the tariff id
     */
    public void deleteProfileToTariff(Integer tariffId) {
        log.info("deleteProfileToTariff");
        try {
            profileDao.deleteProfileValueToTariff(tariffId);
            profileDao.deleteProfileIndicatorToTariff(tariffId);
        } catch (Exception e) {
            log.error("Problem while delete profileIndicator to tariff: ", e);
        }
    }

    /**
     * Gets the profile indicator file.
     * 
     * @return the profile indicator file
     */
    public UploadedFile getProfileIndicatorFile() {
        return profileIndicatorFile;
    }

    /**
     * Sets the profile indicator file.
     * 
     * @param profileIndicatorFile
     *            the new profile indicator file
     */
    public void setProfileIndicatorFile(UploadedFile profileIndicatorFile) {
        this.profileIndicatorFile = profileIndicatorFile;
    }

    /**
     * Gets the tariff.
     * 
     * @return the tariff
     */
    public Tariff getTariff() {
        return tariff;
    }

    /**
     * Sets the tariff.
     * 
     * @param tariff
     *            the new tariff
     */
    public void setTariff(Tariff tariff) {
        this.tariff = tariff;
    }

    /**
     * Gets the tariff id.
     * 
     * @return the tariff id
     */
    public Integer getTariffId() {
        return tariffId;
    }

    /**
     * Sets the tariff id.
     * 
     * @param tariffId
     *            the new tariff id
     */
    public void setTariffId(Integer tariffId) {
        this.tariffId = tariffId;
    }
}
