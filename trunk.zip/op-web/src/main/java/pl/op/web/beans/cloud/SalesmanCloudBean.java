package pl.op.web.beans.cloud;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.DualListModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.op.dao.AreaDao;
import pl.op.dao.CityDao;
import pl.op.dao.CloudDao;
import pl.op.dao.SalesmanDao;
import pl.op.dao.StereotypeDao;
import pl.op.dao.StreetDao;
import pl.op.dao.UserDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionStatus;
import pl.op.model.auction.ZoneType;
import pl.op.model.cloud.Cloud;
import pl.op.model.cloud.CloudFilter;
import pl.op.model.cloud.CloudVolume;
import pl.op.model.cloud.VolumeEnum;
import pl.op.model.contract.PPE;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Street;
import pl.op.model.dict.Tariff;
import pl.op.model.salesman.Salesman;
import pl.op.model.stereotype.Sector;
import pl.op.model.stereotype.Stereotype;
import pl.op.model.user.UserApp;
import pl.op.util.CloudUtil;
import pl.op.util.DictUtil;
import pl.op.util.LocationUtil;
import pl.op.util.MessageUtil;
import pl.op.util.UserUtil;
import pl.op.web.beans.AdminBean;
import pl.op.web.beans.auction.AuctionOfferBean;
import pl.op.web.beans.auction.AuctionOfferMultiBean;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.beans.log.SalesmanBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class SalesmanCloudBean.
 */
@Name("op.salesmanCloudBean")
@Scope(ScopeType.SESSION)
public class SalesmanCloudBean {

    private Logger log = LoggerFactory.getLogger(SalesmanCloudBean.class);

    private FacesContext facesContext;
    private ExternalContext ectx;

    private boolean buttonDisabled = true;
    private boolean buttonMultiDisabled = true;
    private boolean streetDisabled = true;
    private boolean userButtons = true;
    private boolean cloudCompare = false;
    private boolean locationSaved = false;
    private boolean galleryView = false;

    private Cloud cloud;
    private Cloud selectedCloud;
    private UserApp user;

    private List<Cloud> clouds;
    private List<City> cities;
    private List<Area> areas;
    private List<Street> streets;
    private List<Tariff> tariffs;
    private List<Stereotype> stereotypes;
    private List<Salesman> salesmans;
    private List<VolumeEnum> volumes;
    private List<PPE> ppeList = new ArrayList<PPE>();
    private DualListModel<City> dualCities = new DualListModel<City>();
    private DualListModel<Area> dualAreas = new DualListModel<Area>();
    private DualListModel<UserApp> dualUsers = new DualListModel<UserApp>();
    private List<String> cloudStreets;
    private List<Sector> sectors;
    private List<ZoneType> zoneType;
    private Sector sector;
    private List<UserApp> potentialUsers;
    private Auction cloudActualAuction;

    private CloudDao cloudDao;
    private StereotypeDao stereotypeDao;
    private SalesmanDao salesmanDao;
    private UserDao userDao;
    private CityDao cityDao;
    private StreetDao streetDao;
    private AreaDao areaDao;

    private Cloud[] cloudsMulti;

    // Filters
    private CloudFilter cloudFilter;

    Integer areasSize = 0;
    Integer citiesSize = 0;
    private String streetName;
    private String cityName;
    private String cityAreaName;

    private AuctionOfferBean auctionOfferBean;
    private AuctionOfferMultiBean auctionOfferMultiBean;
    private DictionaryBean dictionaryBean;

    // cloudProfability
    private Date now;
    private Date profabilityDate;
    private Map<ZoneType, Double> profabilityVolumes;
    private Map<ZoneType, Double> profabilityVolumesValue;
    private Double profabilityValue;
    private boolean profabilityShow;

    /**
     * Instantiates a new salesman cloud bean.
     */
    public SalesmanCloudBean() {
        log.info("SalesmanCloudBean constructor");
        initializeDao();
        initializeVars();
    }

    /**
     * Initialize dao.
     */
    private void initializeDao() {
        log.info("initializeDao");

        cityDao = GuiceSingleton.getInstance().getInstance(CityDao.class);
        streetDao = GuiceSingleton.getInstance().getInstance(StreetDao.class);
        cloudDao = GuiceSingleton.getInstance().getInstance(CloudDao.class);
        stereotypeDao = GuiceSingleton.getInstance().getInstance(StereotypeDao.class);
        salesmanDao = GuiceSingleton.getInstance().getInstance(SalesmanDao.class);
        userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);
        areaDao = GuiceSingleton.getInstance().getInstance(AreaDao.class);
    }

    /**
     * Initialize vars.
     */
    private void initializeVars() {
        log.info("initializeVars");

        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();
        dictionaryBean = ComponentLookup.lookupComponent("op.dictionaryBean");
        auctionOfferBean = ComponentLookup.lookupComponent("op.auctionOfferBean");
        auctionOfferMultiBean = ComponentLookup.lookupComponent("op.auctionOfferMultiBean");

        user = UserUtil.getLoggedUserInstance();
    }

    /**
     * Initialize on load.
     */
    public void initializeOnLoad() {
        log.info("initializeOnLoad");

        try {
            if (!isInitializedDicts()) {
                initializeDicts();
            }
            tariffs = dictionaryBean.getTariffsList();
            sectors = dictionaryBean.getSectorList();
            stereotypes = dictionaryBean.getStereotypesList();

            salesmans = salesmanDao.getAllSalesmans();

            clearFilter();
            clearCloud();
            clearSelectedCloud();
            searchClouds();
        } catch (Exception e) {
            log.error("Problem while initialize on load: ", e);
        }
    }

    /**
     * Checks if is initialized dicts.
     *
     * @return true, if is initialized dicts
     */
    public boolean isInitializedDicts() {
        if (areas == null || cities == null || streets == null) {
            return false;
        }

        if (areas.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Checks if is initialized.
     *
     * @return true, if is initialized
     */
    public boolean isInitialized() {
        if (isInitializedDicts()) {
            return true;
        }

        if (tariffs == null || sectors == null || stereotypes == null || salesmans == null) {
            return false;
        }

        if (tariffs.isEmpty() || sectors.isEmpty() || stereotypes.isEmpty() || salesmans.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Initialize dicts.
     */
    private void initializeDicts() {
        areas = dictionaryBean.getAreasList();
        cities = new ArrayList<City>();
        streets = new ArrayList<Street>();
    }

    /**
     * Clear selected cloud.
     */
    public void clearSelectedCloud() {
        selectedCloud = new Cloud();
        selectedCloud.setStereotype(new Stereotype());
        selectedCloud.setTariff(new Tariff());
        selectedCloud.setAreas(new ArrayList<Area>());
        selectedCloud.setCities(new ArrayList<City>());
        selectedCloud.setStreets(new ArrayList<Street>());
        selectedCloud.setSalesman(new Salesman());
        selectedCloud.setIsCompany(false);
        selectedCloud.setUsers(new ArrayList<UserApp>());
    }

    /**
     * Clear clouds multi.
     */
    public void clearCloudsMulti() {
        cloudsMulti = new Cloud[0];
    }

    /**
     * Clear cloud.
     */
    public void clearCloud() {
        cloud = new Cloud();
        cloud.setStereotype(new Stereotype());
        cloud.setTariff(new Tariff());
        cloud.setAreas(new ArrayList<Area>());
        cloud.setCities(new ArrayList<City>());
        cloud.setStreets(new ArrayList<Street>());
        cloud.setSalesman(new Salesman());
        cloud.setIsCompany(false);
        cloud.setUsers(new ArrayList<UserApp>());
        user = new UserApp();

        dualAreas = new DualListModel<Area>(areas, new ArrayList<Area>());
        dualCities = new DualListModel<City>(cities, new ArrayList<City>());
        cloudStreets = new ArrayList<String>();
        streetName = "";
        cityName = "";

        sector = new Sector();
    }

    /**
     * Clear filter.
     */
    public void clearFilter() {
        cloudFilter = new CloudFilter();

        Cloud tempCloud = new Cloud();
        tempCloud.setStereotype(new Stereotype());
        tempCloud.setTariff(new Tariff());
        tempCloud.setAreas(new ArrayList<Area>());
        tempCloud.setCities(new ArrayList<City>());
        tempCloud.setStreets(new ArrayList<Street>());
        tempCloud.setSalesman(new Salesman());

        cityName = "";
        streetName = "";

        cloudFilter.setCloud(tempCloud);

    }

    /**
     * Search clouds.
     */
    public void searchClouds() {
        log.info("searchClouds");
        clearSelectedCloud();
        clearCloudsMulti();
        prepareCloudButtons();

        try {
            log.info("cityName: " + cityName);

            if (!"".equals(cityName) && null != cityName) {
                if (null == cloudFilter.getCity()) {
                    cloudFilter.setCity(new City());
                    cloudFilter.getCity().setCityId(0);
                }
                cloudFilter.setCity(LocationUtil.getCity(cityName, cloudFilter.getArea()));
            } else {
                cloudFilter.setCity(new City());
            }

            if (!"".equals(streetName) && null != streetName) {
                onStreetSelect();

                if (null == cloudFilter.getStreet()) {
                    cloudFilter.setStreet(new Street());
                    cloudFilter.getStreet().setStreetId(0);
                }
            } else {
                cloudFilter.setStreet(new Street());
            }

            clouds = cloudDao.getClouds(cloudFilter);

            if (isCloudsInList(clouds)) {
                log.info("find " + clouds.size() + " clouds");
            }
        } catch (Exception e) {
            log.error("problem while search clouds: ", e);
        }
    }

    /**
     * Checks if is clouds in list.
     *
     * @param clouds the clouds
     * @return true, if is clouds in list
     */
    private boolean isCloudsInList(List<Cloud> clouds) {
        if (clouds == null) {
            return false;
        }

        if (clouds.isEmpty()) {
            return false;
        }

        if (clouds.size() == 1) {
            if (clouds.get(0).getCloudId() == null) {
                return false;
            }
        }

        return true;
    }

    /**
     * Save cloud.
     *
     * @return the string
     */
    /*    not use
     public String saveCloud() {
     RequestContext context = RequestContext.getCurrentInstance();
     try {
     if(dualAreas.getTarget().size() == 0) {
     info("warning.area.required");
     return "";
     }

     List<Street> streetsSave = new ArrayList<Street>();
     for(String s : cloudStreets) {
     Street street = new Street();
     street.setStreetName(s);
     street.setCity(dualCities.getTarget().get(0));

     Street checkStreet = streetDao.getStreet(street);

     if(checkStreet == null) {
     streetDao.saveStreet(street);
     streetsSave.add(street);
     } else {
     streetsSave.add(checkStreet);
     }
     }

     cloud.setAreas(dualAreas.getTarget());
     cloud.setCities(dualCities.getTarget());
     cloud.setStreets(streetsSave);

     CloudFilter cF = new CloudFilter();
     cF.setCloud(cloud);
     List<Cloud> similarCloud = cloudDao.getClouds(cF);
     if(similarCloud != null) {
     if(similarCloud.size() > 0) {
     context.execute("cloudExistsDlg.show()");
     return "";
     }
     }

     cloud.setCreationDate(new Date());
     cloud.setIsManual(true);
     cloudDao.saveCloud(cloud);

     cloud.genereateName();
     cloudDao.updateCloud(cloud);

     cloudDao.saveCloudAreas(cloud, dualAreas.getTarget());
     cloudDao.saveCloudCities(cloud, dualCities.getTarget());
     cloudDao.saveCloudStreets(cloud, streetsSave);

     } catch (Exception e) {
     log.error("Problem while save cloud: ", e);
     }

     context.execute("cloudSaveDlg.show()");
     info("message.cloud.added");

     return "";
     }
     */
    /**
     * Cloud save message.
     *
     * @return the string
     */
    public String cloudSaveMessage() {
        Object[] param = new Object[1];
        param[0] = cloud.getName();

        return BundlesUtils.getMessageResourceString("messages", "cloud.save.message", param, Locale.getDefault());
    }

    /**
     * Clouds count.
     *
     * @return the integer
     */
    public Integer cloudsCount() {
        Integer cloudsCount = null;

        try {
            cloudsCount = cloudDao.getCloudsCount();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return cloudsCount;
    }

    /**
     * Change street state.
     */
    public void changeStreetState() {
        if (cloud.getCities() != null) {
            streetDisabled = false;
        } else {
            streetDisabled = true;
        }
    }

    /**
     * Adds the street.
     */
    public void addStreet() {
        if (streetName.length() > 0) {
            cloudStreets.add(streetName);
            streetName = "";
        }
    }

    /**
     * Cloud exists action.
     *
     * @return the string
     */
    public String cloudExistsAction() {
        cloudFilter.setCloud(cloud);
        return "clouds";
    }

    /**
     * Assign users.
     */
    public void assignUsers() {
        try {
            Integer cloudUserCount = 0;
            if (cloud.getUsers() != null) {
                cloudUserCount = cloud.getUsers().size();
            }

            log.info("Search matched user to cloud # " + cloud.getCloudId());
            List<UserApp> matchedUsers = userDao.getUsersMatchToCloud(cloud);

            if (!matchedUsers.isEmpty()) {
                log.info("Find " + matchedUsers.size() + " matched user to cloud # " + cloud.getCloudId());
                cloudUserCount += matchedUsers.size();

                cloud.setUsers(matchedUsers);

                for (UserApp user : cloud.getUsers()) {
                    user.setCloudId(cloud.getCloudId());
                    cloudDao.saveUserCloud(user);
                    log.info("Add user(#" + user.getUserId() + ") to cloud #" + cloud.getCloudId());
                }
            }

            log.info("Find 0 matched user to cloud # " + cloud.getCloudId());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Assign user to cloud.
     *
     * @param cloud the cloud
     * @param user the user
     */
    public void assignUserToCloud(Cloud cloud, UserApp user) {
        try {
            Integer cloudUserCount = 0;
            if (cloud.getUsers() != null) {
                if (!cloud.getUsers().isEmpty()) {
                    cloudUserCount = cloud.getUsers().size();
                }
            }

            log.info("actual cloud #" + cloud.getCloudId() + " memnerNo: " + cloudUserCount);

            cloudUserCount++;

            user.setCloudId(cloud.getCloudId());
            log.info("Add user(#" + user.getUserId() + ") to cloud #" + cloud.getCloudId());
            cloudDao.saveUserCloud(user);
            log.info("added");

            log.info("Update cloud #" + cloud.getCloudId() + " number user to " + cloudUserCount);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * User assign message.
     *
     * @return the string
     */
    public String userAssignMessage() {
        Object[] param = new Object[1];
        param[0] = cloud.getUsers().size();

        return BundlesUtils.getMessageResourceString("messages", "cloud.users.message", param, Locale.getDefault());
    }

    /**
     * On cloud select.
     *
     * @param event the event
     */
    public void onCloudSelect(SelectEvent event) {
        clearSelectedCloud();
        prepareCloudButtons();
    }

    /**
     * Prepare cloud buttons.
     */
    private void prepareCloudButtons() {
        switch (cloudsMulti.length) {
            case 1:
                buttonDisabled = suitableCloud(null);
                buttonMultiDisabled = true;
                selectedCloud = cloudsMulti[0];
                break;
            case 2:
                buttonDisabled = true;
                buttonMultiDisabled = false;
                break;
            default:
                buttonDisabled = true;
                buttonMultiDisabled = true;
                break;
        }
    }

    /**
     * Save cloud location.
     */
    public void saveCloudLocation() {
        locationSaved = true;
    }

    /**
     * Metoda sprawdza czy chmura posiada otwartą aukcje.
     *
     * @param cloud the cloud
     * @return true, if successful
     */
    public boolean haveCloudActiveAuction(Cloud cloud) {
        log.info("haveCloudActiveAuction");

        if (cloud != null) {
            if (haveCloudAuctions(cloud)) {
                log.info("cloud.getAuctions().size(): " + cloud.getAuctions().size());
                return true;
            } else {
                cloudActualAuction = null;
            }
        } else {
            log.info("cloud is null");
        }

        return false;
    }

    /**
     * Have cloud auctions.
     *
     * @param cloud the cloud
     * @return true, if successful
     */
    private boolean haveCloudAuctions(Cloud cloud) {
        if (cloud.getAuctions() == null) {
            log.info("Cloud auctions is null");
            return false;
        }
        if (cloud.getAuctions().size() == 0) {
            log.info("Cloud haven't auctions");
            return false;
        }
        if (cloud.getAuctions().get(0).getAuctionId() == null) {
            log.info("Cloud haven't auctions");
            return false;
        }

        return true;
    }

    /**
     * Update cloud actual auction.
     *
     * @param cloud the cloud
     * @return true, if successful
     */
    private boolean updateCloudActualAuction(Cloud cloud) {
        for (int i = 0; i < cloud.getAuctions().size(); i++) {
            if (isAuctionActual(cloud.getAuctions().get(i))) {
                cloudActualAuction = cloud.getAuctions().get(i);
                return true;
            }
        }

        return false;
    }

    /**
     * Checks if is auction actual.
     *
     * @param auction the auction
     * @return true, if is auction actual
     */
    private boolean isAuctionActual(Auction auction) {
        if (AuctionStatus.INPROGRESS.equals(auction.getStatus())) {
            return true;
        }

        return false;
    }

    /**
     * Back to clouds.
     *
     * @return the string
     */
    public String backToClouds() {
        searchClouds();
        return "salesmanClouds";
    }

    /**
     * Metoda zwraca aktualną instancje salesmanBean. Metoda używana do
     * zawężenia podpowiadania nazw ulic
     *
     * @return SalesmanBean|null
     */
    public SalesmanBean getActualSalesmanBean() {
        FacesContext ctx = FacesContext.getCurrentInstance();
        return (SalesmanBean) ctx.getApplication().getELResolver()
                .getValue(ctx.getELContext(), null, "op.salesmanBean");
    }

    /**
     * Autocomplete city.
     *
     * @param query the query
     * @return the list
     */
    public List<String> autocompleteCity(String query) {
        return LocationUtil.autoCompleteCity(query, cloudFilter.getArea().getAreaId());
    }

    /**
     * On city select.
     */
    public void onCitySelect() {
        try {
            City selectedCity = LocationUtil.getCity(cityName, cloudFilter.getArea());
            cloudFilter.setCity(selectedCity);
        } catch (Exception e) {
            log.error("Problem while search selected city: ", e);
        }
    }

    /**
     * On street select.
     */
    public void onStreetSelect() {
        try {
            Street selectedStreet = LocationUtil.getStreet(streetName, cloudFilter.getCity(), cloudFilter.getArea());
            cloudFilter.setStreet(selectedStreet);
        } catch (Exception e) {
            log.error("Problem while search selected street: ", e);
        }
    }

    /**
     * Checks if is button disabled.
     *
     * @return true, if is button disabled
     */
    public boolean isButtonDisabled() {
        return buttonDisabled;
    }

    /**
     * Sets the button disabled.
     *
     * @param buttonDisabled the new button disabled
     */
    public void setButtonDisabled(boolean buttonDisabled) {
        this.buttonDisabled = buttonDisabled;
    }

    /**
     * Gets the clouds.
     *
     * @return the clouds
     */
    public List<Cloud> getClouds() {
        return clouds;
    }

    /**
     * Sets the clouds.
     *
     * @param clouds the new clouds
     */
    public void setClouds(List<Cloud> clouds) {
        this.clouds = clouds;
    }

    /**
     * Gets the cloud.
     *
     * @return the cloud
     */
    public Cloud getCloud() {
        return cloud;
    }

    /**
     * Sets the cloud.
     *
     * @param cloud the new cloud
     */
    public void setCloud(Cloud cloud) {
        this.cloud = cloud;
    }

    /**
     * Gets the cities.
     *
     * @return the cities
     */
    public List<City> getCities() {
        if (cloudFilter.getCloud().getAreas() != null) {
            try {
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (selectedCloud.getAreas() != null) {
            try {
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return cities;
    }

    /**
     * Sets the cities.
     *
     * @param cities the new cities
     */
    public void setCities(List<City> cities) {
        this.cities = cities;
    }

    /**
     * Gets the areas.
     *
     * @return the areas
     */
    public List<Area> getAreas() {
        return areas;
    }

    /**
     * Sets the areas.
     *
     * @param areas the new areas
     */
    public void setAreas(List<Area> areas) {
        this.areas = areas;
    }

    /**
     * Gets the cloud filter.
     *
     * @return the cloud filter
     */
    public CloudFilter getCloudFilter() {
        if (!isInitialized()) {
            initializeOnLoad();
        }
        return cloudFilter;
    }

    /**
     * Sets the cloud filter.
     *
     * @param cloudFilter the new cloud filter
     */
    public void setCloudFilter(CloudFilter cloudFilter) {
        this.cloudFilter = cloudFilter;
    }

    /**
     * Gets the streets.
     *
     * @return the streets
     */
    public List<Street> getStreets() {
        if (cloudFilter.getCloud().getCities() != null) {
            try {
                for (int i = 0; i < cloudFilter.getCloud().getCities().size(); i++) {
                    City city = cloudFilter.getCloud().getCities().get(i);
                    Street street = new Street();
                    street.setCity(city);
                    streets.addAll(streetDao.getStreets(street));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return streets;
    }

    /**
     * Sets the streets.
     *
     * @param streets the new streets
     */
    public void setStreets(List<Street> streets) {
        this.streets = streets;
    }

    /**
     * Gets the tariffs.
     *
     * @return the tariffs
     */
    public List<Tariff> getTariffs() {
        return tariffs;
    }

    /**
     * Sets the tariffs.
     *
     * @param tariffs the new tariffs
     */
    public void setTariffs(List<Tariff> tariffs) {
        this.tariffs = tariffs;
    }

    /**
     * Gets the stereotypes.
     *
     * @return the stereotypes
     */
    public List<Stereotype> getStereotypes() {
        try {
            if (sector.getSectorId() != null) {
                cloud.setStereotype(stereotypeDao.getStereotypeBySector(sector));
            }

            Sector s = new Sector();
            if (cloud.getIsCompany()) {

                s.setIsHidden(false);

                stereotypes = stereotypeDao.getStereotypes(s);
            } else {
                s.setIsHidden(true);
                stereotypes = stereotypeDao.getStereotypes(new Sector());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return stereotypes;
    }

    /**
     * Sets the stereotypes.
     *
     * @param stereotypes the new stereotypes
     */
    public void setStereotypes(List<Stereotype> stereotypes) {
        this.stereotypes = stereotypes;
    }

    /**
     * Gets the salesmans.
     *
     * @return the salesmans
     */
    public List<Salesman> getSalesmans() {
        return salesmans;
    }

    /**
     * Sets the salesmans.
     *
     * @param salesmans the new salesmans
     */
    public void setSalesmans(List<Salesman> salesmans) {
        this.salesmans = salesmans;
    }

    /**
     * Checks if is street disabled.
     *
     * @return true, if is street disabled
     */
    public boolean isStreetDisabled() {
        return streetDisabled;
    }

    /**
     * Sets the street disabled.
     *
     * @param streetDisabled the new street disabled
     */
    public void setStreetDisabled(boolean streetDisabled) {
        this.streetDisabled = streetDisabled;
    }

    /**
     * Gets the volumes.
     *
     * @return the volumes
     */
    public List<VolumeEnum> getVolumes() {
        volumes = new ArrayList<VolumeEnum>();

        for (VolumeEnum a : VolumeEnum.values()) {
            a.setLabel(BundlesUtils.getMessageResourceString("messages", "cloud.volume." + a, null, Locale.getDefault()));

            volumes.add(a);
        }

        return volumes;
    }

    /**
     * Compare clouds.
     */
    public void compareClouds() {
        cloudCompare = true;
    }

    /**
     * Sets the volumes.
     *
     * @param volumes the new volumes
     */
    public void setVolumes(List<VolumeEnum> volumes) {
        this.volumes = volumes;
    }

    /**
     * Gets the user.
     *
     * @return the user
     */
    public UserApp getUser() {
        return user;
    }

    /**
     * Sets the user.
     *
     * @param userId the new user
     */
    public void setUser(Integer userId) {
        try {
            this.user = userDao.getUserAppbyId(userId);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Checks if is user buttons.
     *
     * @return true, if is user buttons
     */
    public boolean isUserButtons() {
        return userButtons;
    }

    /**
     * Sets the user buttons.
     *
     * @param userButtons the new user buttons
     */
    public void setUserButtons(boolean userButtons) {
        this.userButtons = userButtons;
    }

    /**
     * Gets the dual cities.
     *
     * @return the dual cities
     */
    public DualListModel<City> getDualCities() {
        if (dualAreas.getTarget().size() == 1) {
            City city = new City();
            city.setArea(dualAreas.getTarget().get(0));
            try {
                cities = cityDao.getCities(city);
            } catch (Exception e) {
                e.printStackTrace();
            }

            dualCities = new DualListModel<City>(cities, new ArrayList<City>());
        }
        return dualCities;
    }

    /**
     * Sets the dual cities.
     *
     * @param dualCities the new dual cities
     */
    public void setDualCities(DualListModel<City> dualCities) {
        this.dualCities = dualCities;
    }

    /**
     * Gets the dual areas.
     *
     * @return the dual areas
     */
    public DualListModel<Area> getDualAreas() {
        return dualAreas;
    }

    /**
     * Sets the dual areas.
     *
     * @param dualAreas the new dual areas
     */
    public void setDualAreas(DualListModel<Area> dualAreas) {
        this.dualAreas = dualAreas;
    }

    /**
     * Gets the street name.
     *
     * @return the street name
     */
    public String getStreetName() {
        return streetName;
    }

    /**
     * Sets the street name.
     *
     * @param streetName the new street name
     */
    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    /**
     * Gets the sectors.
     *
     * @return the sectors
     */
    public List<Sector> getSectors() {
        return sectors;
    }

    /**
     * Sets the sectors.
     *
     * @param sectors the new sectors
     */
    public void setSectors(List<Sector> sectors) {
        this.sectors = sectors;
    }

    /**
     * Checks if is button multi disabled.
     *
     * @return true, if is button multi disabled
     */
    public boolean isButtonMultiDisabled() {
        return buttonMultiDisabled;
    }

    /**
     * Sets the button multi disabled.
     *
     * @param buttonMultiDisabled the new button multi disabled
     */
    public void setButtonMultiDisabled(boolean buttonMultiDisabled) {
        this.buttonMultiDisabled = buttonMultiDisabled;
    }

    /**
     * Gets the clouds multi.
     *
     * @return the clouds multi
     */
    public Cloud[] getCloudsMulti() {
        return cloudsMulti;
    }

    /**
     * Sets the clouds multi.
     *
     * @param cloudsMulti the new clouds multi
     */
    public void setCloudsMulti(Cloud[] cloudsMulti) {
        this.cloudsMulti = cloudsMulti;
    }

    /**
     * Checks if is cloud compare.
     *
     * @return true, if is cloud compare
     */
    public boolean isCloudCompare() {
        return cloudCompare;
    }

    /**
     * Sets the cloud compare.
     *
     * @param cloudCompare the new cloud compare
     */
    public void setCloudCompare(boolean cloudCompare) {
        this.cloudCompare = cloudCompare;
    }

    /**
     * Gets the cloud streets.
     *
     * @return the cloud streets
     */
    public List<String> getCloudStreets() {
        return cloudStreets;
    }

    /**
     * Sets the cloud streets.
     *
     * @param cloudStreets the new cloud streets
     */
    public void setCloudStreets(List<String> cloudStreets) {
        this.cloudStreets = cloudStreets;
    }

    /**
     * Checks if is location saved.
     *
     * @return true, if is location saved
     */
    public boolean isLocationSaved() {
        return locationSaved;
    }

    /**
     * Sets the location saved.
     *
     * @param locationSaved the new location saved
     */
    public void setLocationSaved(boolean locationSaved) {
        this.locationSaved = locationSaved;
    }

    private String ConvertNameAreaToCondeArea(String nameArea) {
        if ("dolnośląskie".equals(nameArea.toLowerCase())) {
            return "DS";
        }
        if ("kujawsko-pomorskie".equals(nameArea.toLowerCase())) {
            return "KP";
        }
        if ("lubelskie".equals(nameArea.toLowerCase())) {
            return "LU";
        }
        if ("lubuskie".equals(nameArea.toLowerCase())) {
            return "LB";
        }
        if ("łódzkie".equals(nameArea.toLowerCase())) {
            return "LD";
        }
        if ("małopolskie".equals(nameArea.toLowerCase())) {
            return "MA";
        }
        if ("mazowieckie".equals(nameArea.toLowerCase())) {
            return "MZ";
        }
        if ("opolskie".equals(nameArea.toLowerCase())) {
            return "OP";
        }
        if ("podkarpackie".equals(nameArea.toLowerCase())) {
            return "PK";
        }
        if ("podlaskie".equals(nameArea.toLowerCase())) {
            return "PD";
        }
        if ("pomorskie".equals(nameArea.toLowerCase())) {
            return "PM";
        }
        if ("śląskie".equals(nameArea.toLowerCase())) {
            return "SL";
        }
        if ("świętokrzyskie".equals(nameArea.toLowerCase())) {
            return "SK";
        }
        if ("warmińsko-mazurskie".equals(nameArea.toLowerCase())) {
            return "WN";
        }
        if ("wielkopolskie".equals(nameArea.toLowerCase())) {
            return "WP";
        }
        if ("zachodniopomorskie".equals(nameArea.toLowerCase())) {
            return "ZP";
        }
        return "not support iso 3166";
    }
    /*   
     public String dualAreasMessageCode() {
     if ( dualAreas.getTarget().size() == 1) {
     return dualAreas.getTarget().get(0).getAreaName();
     } else if ( dualAreas.getTarget().size() == 2) {
     return dualAreas.getTarget().get(0).getAreaName() + ", \n" + dualAreas.getTarget().get(1).getAreaName();
     } else if ( dualAreas.getTarget().size() == 3) {
     return dualAreas.getTarget().get(0).getAreaName() + ", \n" + dualAreas.getTarget().get(1).getAreaName() + ", \n"+ dualAreas.getTarget().get(2).getAreaName() ;
     } else {
     String namesAreas = ConvertNameAreaToCondeArea(dualAreas.getTarget().get(0).getAreaName());;
     for (int i = 1; i < dualAreas.getTarget().size(); i++) {
     namesAreas +=  ", "+ConvertNameAreaToCondeArea(dualAreas.getTarget().get(i).getAreaName());
     }
     return namesAreas;
     }
     }
     */

    /**
     * Dual areas message.
     *
     * @return the string
     */
    /*    public String dualAreasMessage() {
     if(dualAreas.getTarget().size() == 1)
     return dualAreas.getTarget().get(0).getAreaName();

     if(dualAreas.getTarget().size() > 1) {
     Object[] params = new Object[2];
     params[0] = dualAreas.getTarget().get(0).getAreaName();
     params[1] = dualAreas.getTarget().size() - 1;
     return BundlesUtils.getMessageResourceString("messages", "message.and.more", params, Locale.getDefault());
     }

     return "";
     }
     */
    /**
     * Dual cities message.
     *
     * @return the string
     */
    /*   public String dualCitiesMessage() {
     if(dualAreas.getTarget().size() == 1) {
     if(dualCities.getTarget().size() == 1)
     return dualCities.getTarget().get(0).getCityName();

     if(dualCities.getTarget().size() > 1) {
     Object[] params = new Object[2];
     params[0] = dualCities.getTarget().get(0).getCityName();
     params[1] = dualCities.getTarget().size() - 1;
     return BundlesUtils.getMessageResourceString("messages", "message.and.more", params,
     Locale.getDefault());
     }
     } else {
     dualCities = new DualListModel<City>(this.cities, new ArrayList<City>());
     }
     return "";
     }
     */
    /**
     * Dual streets message.
     *
     * @return the string
     */
    /*   public String dualStreetsMessage() {
     if(dualCities.getTarget().size() == 1) {
     if(cloudStreets.size() == 1)
     return cloudStreets.get(0);

     if(cloudStreets.size() > 1) {
     Object[] params = new Object[2];
     params[0] = cloudStreets.get(0);
     params[1] = cloudStreets.size() - 1;
     return BundlesUtils.getMessageResourceString("messages", "message.and.more", params,
     Locale.getDefault());
     }
     } else {
     cloudStreets = new ArrayList<String>();
     }
     return "";
     }
     */
    public String areasMessageCode() {
        if (selectedCloud.getAreas().isEmpty()) {
            return "";
        }
        if (selectedCloud.getAreas().size() == 1) {
            return selectedCloud.getAreas().get(0).getAreaName();
        } else if (selectedCloud.getAreas().size() == 2) {
            return selectedCloud.getAreas().get(0).getAreaName() + ", \n" + selectedCloud.getAreas().get(1).getAreaName();
        } else if (selectedCloud.getAreas().size() == 3) {
            return selectedCloud.getAreas().get(0).getAreaName() + ", \n" + selectedCloud.getAreas().get(1).getAreaName() + ",\n" + selectedCloud.getAreas().get(2).getAreaName();
        } else {
            String namesAreas = ConvertNameAreaToCondeArea(selectedCloud.getAreas().get(0).getAreaName());;
            for (int i = 1; i < selectedCloud.getAreas().size(); i++) {
                namesAreas += ", \n" + ConvertNameAreaToCondeArea(selectedCloud.getAreas().get(i).getAreaName());
            }
            return namesAreas;
        }
    }

    /**
     * Areas message.
     *
     * @return the string
     */
    public String areasMessage() {
        if (selectedCloud.getAreas().size() == 1) {
            return selectedCloud.getAreas().get(0).getAreaName();
        }

        if (selectedCloud.getAreas().size() > 1) {
            Object[] params = new Object[2];
            params[0] = selectedCloud.getAreas().get(0).getAreaName();
            params[1] = selectedCloud.getAreas().size() - 1;
            return BundlesUtils.getMessageResourceString("messages", "message.and.more", params, Locale.getDefault());
        }

        return "";
    }

    /**
     * Cities message.
     *
     * @return the string
     */
    public String citiesMessage() {

        if (selectedCloud.getCities().size() == 1) {
            return selectedCloud.getCities().get(0).getCityName();
        }

        if (selectedCloud.getCities().size() > 1) {
            Object[] params = new Object[2];
            params[0] = selectedCloud.getCities().get(0).getCityName();
            params[1] = selectedCloud.getCities().size() - 1;
            return BundlesUtils.getMessageResourceString("messages", "message.and.more", params, Locale.getDefault());
        }
        return "";
    }

    /**
     * City area.
     */
    public void cityArea() {
        Area area = new Area();

        try {
            if (hasCloudCities(selectedCloud)) {
                area = areaDao.getAreaByCityId(selectedCloud.getCities().get(0).getCityId());
            }
        } catch (Exception e) {
            log.error("Error while getting Auction city area: ", e);
            e.printStackTrace();
        }

        cityAreaName = area.getAreaName();
    }

    /**
     * Checks for cloud cities.
     *
     * @param cloud the cloud
     * @return true, if successful
     */
    private boolean hasCloudCities(Cloud cloud) {
        if (null == cloud) {
            return false;
        }
        if (null == cloud.getCities()) {
            return false;
        }
        if (cloud.getCities().isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Streets message.
     *
     * @return the string
     */
    public String streetsMessage() {
        if (selectedCloud.getStreets().size() == 1) {
            return selectedCloud.getStreets().get(0).getStreetName();
        }

        if (selectedCloud.getStreets().size() > 1) {
            Object[] params = new Object[2];
            params[0] = selectedCloud.getStreets().get(0).getStreetName();
            params[1] = selectedCloud.getStreets().size() - 1;
            return BundlesUtils.getMessageResourceString("messages", "message.and.more", params, Locale.getDefault());
        }

        return "";
    }

    /**
     * Info.
     *
     * @param message_code the message_code
     */
    @SuppressWarnings({"deprecation"})
    private void info(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_INFO,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    /**
     * Warning.
     *
     * @param message_code the message_code
     */
    @SuppressWarnings({"unused", "deprecation"})
    private void warning(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_WARN,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    /**
     * Gets the zone type.
     *
     * @return the zone type
     */
    public List<ZoneType> getZoneType() {
        zoneType = new ArrayList<ZoneType>();

        for (ZoneType a : ZoneType.values()) {
            a.setLabel(BundlesUtils.getMessageResourceString("messages", "zone.type." + a, null, Locale.getDefault()));

            zoneType.add(a);
        }

        return zoneType;
    }

    /**
     * Sets the zone type.
     *
     * @param zoneType the new zone type
     */
    public void setZoneType(List<ZoneType> zoneType) {
        this.zoneType = zoneType;
    }

    /**
     * Cloud volume.
     *
     * @param cloud the cloud
     * @return the double
     */
    public Double cloudVolume(Cloud cloud) {
          log.info("cloudVolume - Selesman");
        Double volume = 0.0;
        if (cloud != null) {
            if (cloud.getStereotype() == null || cloud.getStereotype().getStereotypeId() == null) {
                volume = CloudUtil.updateCloudVolumeByManual(cloud.getCloudId());
            } else {
                volume = CloudUtil.updateCloudVolume(cloud.getCloudId());
            }
        }

        return volume;
    }

    public String cloudVolumeStr(Cloud cloud) {
         log.info("cloudVolumeStr - Selesman");
        Double volume = 0.0000;
        if (cloud != null) {
            if (cloud.getStereotype() == null || cloud.getStereotype().getStereotypeId() == null) {
                volume = CloudUtil.updateCloudVolumeByManual(cloud.getCloudId());
            } else {
                volume = CloudUtil.updateCloudVolume(cloud.getCloudId());
            }

            DecimalFormat decimalFormat = new DecimalFormat("#0.0000");

            if (volume > 10000) {
                return decimalFormat.format(volume / 1000.0)
                        + " "
                        + BundlesUtils.getMessageResourceString("messages", "cloud.volume.MWH", null,
                                ectx.getRequestLocale());
            } else {
                return decimalFormat.format(volume)
                        + " "
                        + BundlesUtils.getMessageResourceString("messages", "cloud.volume.KWH", null,
                                ectx.getRequestLocale());
            }

        }
        return volume
                + " "
                + BundlesUtils.getMessageResourceString("messages", "cloud.volume.KWH", null,
                        ectx.getRequestLocale());
    }

    /**
     * Cloud volume by type.
     *
     * @param cloud the cloud
     * @param pcType the pc type
     * @return the string
     */
    public String cloudVolumeByType(Cloud cloud, String pcType) {
        log.info("cloudVolumeByType");

        for (CloudVolume cV : cloud.getCloudVolume()) {
            if (cV.getZoneType() == ZoneType.valueOf(pcType)) {
                return cV.getVolume().toString();
            }
        }

        return "-";
    }

    /**
     * Ppe count.
     *
     * @param cloud the cloud
     * @return the integer
     */
    public Integer ppeCount(Cloud cloud) {
        Integer ppeCount = 0;

        try {
            ppeCount = cloudDao.getPPECount(cloud);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ppeCount;
    }

    /**
     * Initialize cloud details.
     *
     * @param cloud the cloud
     * @return the string
     */
    public String initializeCloudDetails(Cloud cloud) {
        this.selectedCloud = cloud;
        CloudUtil.checkCloudAuctionList(this.selectedCloud);

        updateCloudVolumePerZone(this.selectedCloud);
        return "salesmanCloudDetails";
    }

    public void updateCloudVolumePerZone(Cloud cloud) {
        log.info("updateCloudVolumePerZone");

        try {
            List<PPE> ppes;
            
            if (cloud.getStereotype() == null || cloud.getStereotype().getStereotypeId() == null) 
                ppes = cloudDao.getPpeByCloudIdNoStereotype(cloud); 
            else
                ppes = cloudDao.getPpeByCloudId(cloud);
            
            if (isPpes(ppes)) {
                log.info("ppes size: " + ppes.size());
                Map<ZoneType, Double> volumes = CloudUtil.getYearVolumeMapsForAllPPEs(ppes);

                List<CloudVolume> cloudVolumes = new ArrayList<CloudVolume>();
                if (volumes != null) {
                    for (ZoneType zoneType : volumes.keySet()) {
                        CloudVolume vol = new CloudVolume();
                        vol.setVolume(Double.valueOf(volumes.get(zoneType).intValue()));
                        vol.setZoneType(zoneType);

                        cloudVolumes.add(vol);
                    }
                    cloud.setCloudVolume(cloudVolumes);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Initialize cloud profability.
     *
     * @param cloud the cloud
     * @return the string
     */
    public String initializeCloudProfability(Cloud cloud) {
        this.selectedCloud = cloud;
        CloudUtil.checkCloudAuctionList(this.selectedCloud);

        this.now = new Date();
        this.profabilityDate = null;
        this.profabilityVolumes = new HashMap<ZoneType, Double>();
        this.profabilityVolumesValue = new HashMap<ZoneType, Double>();
        this.profabilityShow = false;
        this.profabilityValue = 0.00;

        return "salesmanCloudProfability";
    }

    /**
     * Prepare profability volume.
     */
    public void prepareProfabilityVolume() {
        log.info("change prepareProfabilityVolume");

        if (this.profabilityDate != null) {
            try {
                List<PPE> ppes = CloudUtil.getPPEsCanJoinToAuctionByCloud(this.selectedCloud, this.profabilityDate);
                if (isPpes(ppes)) {
                    log.info("ppes size: " + ppes.size());
                    this.profabilityVolumes = CloudUtil.getYearVolumeMapsForAllPPEs(ppes);
                    log.info("profabilityVolumes size: " + this.profabilityVolumes.size());
                    if (this.profabilityVolumes != null) {
                        for (ZoneType zoneType : this.profabilityVolumes.keySet()) {
                            this.profabilityVolumesValue.put(zoneType, 0.00);
                        }
                        this.profabilityShow = true;
                    }
                } else {
                    MessageUtil.displayMessageInfo("count.profitability.empty");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    /**
     * Checks if is ppes.
     *
     * @param ppes the ppes
     * @return true, if is ppes
     */
    private boolean isPpes(List<PPE> ppes) {
        if (null == ppes) {
            log.info("ppes id null");
            return false;
        }
        if (ppes.isEmpty()) {
            log.info("pppes is empty");
            return false;
        }
        if (0 == ppes.size()) {
            log.info("ppes size is equal 0");
            return false;
        }
        if (null == ppes.get(0)) {
            log.info("ppes[0] is null");
            return false;
        }
        if (null == ppes.get(0).getPpeId()) {
            log.info("ppes[0].ppeid is null");
            return false;
        }

        return true;
    }

    /**
     * Update profability volumes value.
     *
     * @param zoneType the zone type
     * @param value the value
     */
    public void updateProfabilityVolumesValue(ZoneType zoneType, String value) {

        value = value.replace(",", ".");
        this.profabilityVolumesValue.put(zoneType, Double.valueOf(value));

    }

    /**
     * Calc profability.
     */
    public void calcProfability() {

        Double sum = 0.00;

        for (ZoneType zoneType : this.profabilityVolumesValue.keySet()) {
            Double value = this.profabilityVolumes.get(zoneType);
            Double price = this.profabilityVolumesValue.get(zoneType);

            sum += (value * price);
        }

        log.info("calcProfability(): sum = " + sum);

        this.profabilityValue = sum;

    }

    /**
     * Initialize add offer.
     *
     * @param cloud the cloud
     * @return the string
     */
    public String initializeAddOffer(Cloud cloud) {
        selectedCloud = cloud;
        CloudUtil.checkCloudAuctionList(selectedCloud);

        return initializeAddOffer();
    }

    /**
     * Initialize add offer.
     *
     * @return the string
     */
    public String initializeAddOffer() {
        try {
            Auction auction = null;

            if (haveCloudActiveAuction(selectedCloud)) {
                updateCloudActualAuction(selectedCloud);
                auction = cloudActualAuction;
                auction.setCloud(selectedCloud);
            } else {
                auction = new Auction();
                auction.setCloud(selectedCloud);
                auction.setSalesmans(new ArrayList<Salesman>());
                auction.getSalesmans().add(user.getSalesman());
                auction.setStatus(AuctionStatus.INPROGRESS);
            }

            auctionOfferBean.initializeAuctionOffer(auction, user.getSalesman());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "createOffer";
    }

    /**
     * Initialize add offer.
     *
     * @return the string
     */
    public String initializeAddOfferMulti() {
        try {
//            Auction auction = null;
//
//            if(haveCloudActiveAuction(selectedCloud)) {
//                updateCloudActualAuction(selectedCloud);
//                auction = cloudActualAuction;
//                auction.setCloud(selectedCloud);
//            } else {
//                auction = new Auction();
//                auction.setCloud(selectedCloud);
//                auction.setSalesmans(new ArrayList<Salesman>());
//                auction.getSalesmans().add(user.getSalesman());
//                auction.setStatus(AuctionStatus.INPROGRESS);
//            }

           // auctionOfferMultiBean.initializeAuctionOffer(auction, user.getSalesman());
            auctionOfferMultiBean.initializeAuctionOffer(selectedCloud, user.getSalesman());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "createOfferMulti";
    }

    /**
     * Update cloud users.
     *
     * @return the string
     */
    public String updateCloudUsers() {
        try {
            cloudDao.deleteCloudUsers(selectedCloud);
            for (UserApp user : dualUsers.getTarget()) {
                cloudDao.saveUserCloud(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        searchClouds();

        return "clouds";
    }

    /**
     * Checks if is gallery view.
     *
     * @return true, if is gallery view
     */
    public boolean isGalleryView() {
        return galleryView;
    }

    /**
     * Sets the gallery view.
     *
     * @param galleryView the new gallery view
     */
    public void setGalleryView(boolean galleryView) {
        this.galleryView = galleryView;
    }

    /**
     * Change gallery view.
     */
    public void changeGalleryView() {
        galleryView = !galleryView;
        if (galleryView) {
            buttonDisabled = true;
            selectedCloud = null;
            cloudsMulti = null;
        }
    }

    /**
     * Gets the selected cloud.
     *
     * @return the selected cloud
     */
    public Cloud getSelectedCloud() {
        return selectedCloud;
    }

    /**
     * Sets the selected cloud.
     *
     * @param selectedCloud the new selected cloud
     */
    public void setSelectedCloud(Cloud selectedCloud) {
        this.selectedCloud = selectedCloud;
        CloudUtil.checkCloudAuctionList(this.selectedCloud);
    }

    /**
     * Gets the sector.
     *
     * @return the sector
     */
    public Sector getSector() {
        return sector;
    }

    /**
     * Sets the sector.
     *
     * @param sector the new sector
     */
    public void setSector(Sector sector) {
        this.sector = sector;
    }

    /**
     * Gets the potential users.
     *
     * @return the potential users
     */
    public List<UserApp> getPotentialUsers() {
        return potentialUsers;
    }

    /**
     * Sets the potential users.
     *
     * @param potentialUsers the new potential users
     */
    public void setPotentialUsers(List<UserApp> potentialUsers) {
        this.potentialUsers = potentialUsers;
    }

    /**
     * Gets the dual users.
     *
     * @return the dual users
     */
    public DualListModel<UserApp> getDualUsers() {
        return dualUsers;
    }

    /**
     * Sets the dual users.
     *
     * @param dualUsers the new dual users
     */
    public void setDualUsers(DualListModel<UserApp> dualUsers) {
        this.dualUsers = dualUsers;
    }

    /**
     * Gets the cloud actual auction.
     *
     * @return the cloud actual auction
     */
    public Auction getCloudActualAuction() {
        return cloudActualAuction;
    }

    /**
     * Sets the cloud actual auction.
     *
     * @param cloudActualAuction the new cloud actual auction
     */
    public void setCloudActualAuction(Auction cloudActualAuction) {
        this.cloudActualAuction = cloudActualAuction;
    }

    /**
     * Gets the city name.
     *
     * @return the city name
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * Sets the city name.
     *
     * @param cityName the new city name
     */
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    /**
     * Gets the ppe list.
     *
     * @return the ppe list
     */
    public List<PPE> getPpeList() {
        return ppeList;
    }

    /**
     * Sets the ppe list.
     *
     * @param ppeList the new ppe list
     */
    public void setPpeList(List<PPE> ppeList) {
        this.ppeList = ppeList;
    }

    /**
     * Gets the now.
     *
     * @return the now
     */
    public Date getNow() {
        return now;
    }

    /**
     * Sets the now.
     *
     * @param now the new now
     */
    public void setNow(Date now) {
        this.now = now;
    }

    /**
     * Gets the profability date.
     *
     * @return the profability date
     */
    public Date getProfabilityDate() {
        return profabilityDate;
    }

    /**
     * Sets the profability date.
     *
     * @param profabilityDate the new profability date
     */
    public void setProfabilityDate(Date profabilityDate) {
        this.profabilityDate = profabilityDate;
    }

    /**
     * Gets the profability volumes.
     *
     * @return the profability volumes
     */
    public Map<ZoneType, Double> getProfabilityVolumes() {
        return profabilityVolumes;
    }

    /**
     * Sets the profability volumes.
     *
     * @param profabilityVolumes the profability volumes
     */
    public void setProfabilityVolumes(Map<ZoneType, Double> profabilityVolumes) {
        this.profabilityVolumes = profabilityVolumes;
    }

    /**
     * Gets the profability volumes value.
     *
     * @return the profability volumes value
     */
    public Map<ZoneType, Double> getProfabilityVolumesValue() {
        return profabilityVolumesValue;
    }

    /**
     * Sets the profability volumes value.
     *
     * @param profabilityVolumesValue the profability volumes value
     */
    public void setProfabilityVolumesValue(Map<ZoneType, Double> profabilityVolumesValue) {
        this.profabilityVolumesValue = profabilityVolumesValue;
    }

    /**
     * Gets the profability value.
     *
     * @return the profability value
     */
    public Double getProfabilityValue() {
        return profabilityValue;
    }

    /**
     * Sets the profability value.
     *
     * @param profabilityValue the new profability value
     */
    public void setProfabilityValue(Double profabilityValue) {
        this.profabilityValue = profabilityValue;
    }

    /**
     * Checks if is profability show.
     *
     * @return true, if is profability show
     */
    public boolean isProfabilityShow() {
        return profabilityShow;
    }

    /**
     * Sets the profability show.
     *
     * @param profabilityShow the new profability show
     */
    public void setProfabilityShow(boolean profabilityShow) {
        this.profabilityShow = profabilityShow;
    }

    /**
     * Checks for auction.
     *
     * @param cloud the cloud
     * @return true, if successful
     */
    public boolean hasAuction(Cloud cloud) {
        selectedCloud = cloud;
        CloudUtil.checkCloudAuctionList(cloud);
        return hasAuction();
    }

    /**
     * Checks for auction.
     *
     * @return true, if successful
     */
    public boolean hasAuction() {
        try {
            if (null == selectedCloud) {
                return false;
            }
            if (null == selectedCloud.getCloudId()) {
                return false;
            }
            if (haveCloudActiveAuction(selectedCloud)) {
                updateCloudActualAuction(selectedCloud);
                return true;
            }
        } catch (Exception e) {
            log.error("Problem while hasAuction in salesmanCoudBean: ", e);
        }
        return false;
    }

    /**
     * Gets the sector list.
     *
     * @return the sector list
     */
    public List<Sector> getSectorList() {
        if (null == cloudFilter) {
            return new ArrayList<Sector>();
        }
        if (null == cloudFilter.getCloud()) {
            return new ArrayList<Sector>();
        }

        return DictUtil.getSectorListByType(cloudFilter.getCloud().getIsCompany());
    }

    public Boolean suitableCloud(Cloud cloud) {
        log.info("[suitableCloud]");
        try {
            FacesContext ctx = FacesContext.getCurrentInstance();
            AdminBean adminBean = (AdminBean) ctx.getApplication().getELResolver()
                    .getValue(ctx.getELContext(), null, "op.adminBean");
            UserApp userApp = adminBean.getUserLog();
            
            if (userApp != null) {
                 log.info("[suitableCloud] userApp != null");
                if (userApp.getUserId() != null) {
                     log.info("[suitableCloud] userApp.getUserId() != null, uid:" + userApp.getUserId() );
                     if (userApp.getSalesman() != null)
                     {
                         log.info("[suitableCloud] userApp.getSalesman() != null");
                         if (userApp.getSalesman().getSalesmanId() != null) {
                             log.info("[suitableCloud] userApp.getSalesman().getSalesmanId() != null, sid: " + userApp.getSalesman().getSalesmanId());
                         }
                     }
                }
            }
            
            

            if (cloud == null) {
//                if (cloudsMulti == null) {
//                    return false;
//                }
//                if (cloudsMulti.length != 1) {
//                    return false;
//                }

//                log.info("suitableCloud");
//
//                 if (cloudsMulti[0] != null) {
//                     log.info("[suitableCloud] cloudsMulti[0] != null");
//                     if (cloudsMulti[0].getIsManual()) {
//                         log.info("[suitableCloud]  cloudsMulti[0].getIsManual()");
//                     }
////                     CloudFilter cloudFilter = new CloudFilter();
////                     cloudFilter.setCloud(cloudsMulti[0]);
////                     List<Cloud> cloudSearch = cloudDao.getClouds(cloudFilter);
////                     if (cloudSearch.size() > 0) {
////                         log.info ( ": : : " + cloudSearch.get(0).toString() );
////                     } else log.info ("dupa");
//                     if (cloudsMulti[0].getSalesman() != null) {
//                         log.info("[suitableCloud] cloudsMulti[0].getSalesman() != null");
//                         if (cloudsMulti[0].getSalesman().getSalesmanId() != null) {
//                             log.info("[suitableCloud] cloudsMulti[0].getSalesman().getSalesmanId() != null ,sid:" + cloudsMulti[0].getSalesman().getSalesmanId());
//                         }
//                     }
//                 }
                

                if (cloudsMulti[0].getIsManual()) {
                    
                    if (cloudsMulti[0].getSalesman() != null && cloudsMulti[0].getSalesman().getSalesmanId() != userApp.getSalesman().getSalesmanId()) {
                        log.info("suitableCloud  - true :: " + cloudsMulti[0].getSalesman().getSalesmanId() + " : " + userApp.getSalesman().getSalesmanId());
                        return true;
                    } else {
                        log.info("suitableCloud  - false");
                        return false;
                    }
                     
                } else {
                    log.info("suitableCloud - false");
                    return false;
                }
            } else {
                if (cloud.getIsManual()  && cloud.getSalesman() != null && cloud.getSalesman().getSalesmanId() != null && cloud.getSalesman().getSalesmanId() != userApp.getSalesman().getSalesmanId()) {
                    log.info("cloud::suitableCloud  - false");
                    return false;
                } else {
                    log.info("cloud::suitableCloud - true");
                    return true;
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }    
        
         if (cloud == null) {  return false; } else { return true; }
    }
}
