package pl.op.web.common;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.primefaces.component.picklist.PickList;
import org.primefaces.model.DualListModel;

import pl.op.model.dict.Area;

@FacesConverter("AreaConverter")
public class AreaConverter implements Converter {

	private Log log = LogFactory.getLog(AreaConverter.class);

	public Area getAsObject(FacesContext facesContext, UIComponent component,
			String submittedValue) {
		if (component instanceof PickList) {
			DualListModel<Area> dualList = (DualListModel) ((PickList) component)
					.getValue();

			for (Object o : dualList.getSource()) {
				String id = "" + ((Area) o).getAreaId();
				if (submittedValue.equals(id)) {
					return (Area) o;
				}
			}
			
			for (Object o : dualList.getTarget()) {
				String id = "" + ((Area) o).getAreaId();
				if (submittedValue.equals(id)) {
					return (Area) o;
				}
			}
		}

		return null;
	}

	public String getAsString(FacesContext facesContext, UIComponent component,
			Object value) {
		return (value).toString();
	}

}
