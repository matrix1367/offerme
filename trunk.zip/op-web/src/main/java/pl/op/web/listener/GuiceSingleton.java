package pl.op.web.listener;

import org.slf4j.LoggerFactory;

import pl.op.module.OgarniamPradModule;

import com.google.inject.Guice;
import com.google.inject.Injector;

public class GuiceSingleton {
	
	private static Injector oSingletonClass;

	private GuiceSingleton() {
		
	}
	
	public static Injector getInstance() {		
		if (oSingletonClass == null) {
			LoggerFactory.getLogger(GuiceSingleton.class).info("Creating guice context...");
			
			oSingletonClass = Guice.createInjector(new OgarniamPradModule());
			
			if (oSingletonClass == null){
				LoggerFactory.getLogger(GuiceSingleton.class).error("guice context is null!!!!!!!!!!!!!!!!!!!!!!!!!!!");
				 
			}
		}
		return oSingletonClass;
	}

}
