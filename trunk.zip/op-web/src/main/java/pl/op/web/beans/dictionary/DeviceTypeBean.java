package pl.op.web.beans.dictionary;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.DeviceCategoryDao;
import pl.op.dao.DeviceTypeDao;
import pl.op.model.device.ConsumptionLevelEnum;
import pl.op.model.device.DeviceCategory;
import pl.op.model.device.DeviceType;
import pl.op.model.device.DeviceTypeEnum;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class DeviceTypeBean. This class manages the device type. Can
 * add/edit/delete data from database table named "tb_devicetype".
 */
@Name("op.deviceTypeBean")
@Scope(ScopeType.SESSION)
public class DeviceTypeBean implements Serializable {

	private static final long serialVersionUID = -2514925823072269662L;

	private Logger log = LoggerFactory.getLogger(DeviceTypeBean.class);

	private List<DeviceType> deviceTypesList;
	private List<ConsumptionLevelEnum> consumptionLevelEnum;
	private Map<String, ConsumptionLevelEnum> enumMap;

	private String selectedConsumptionLevel;

	private DeviceType newDeviceType;
	private DeviceType selectedDeviceType;

	@SuppressWarnings("unused")
	private List<DeviceTypeEnum> deviceTypeEnum;

	private boolean edit;
	private boolean disableShow = true;
	private boolean disableEdit = true;
	private boolean disableRemove = true;

	private DeviceTypeDao deviceTypeDao;
	private DeviceCategoryDao deviceCategoryDao;

	private DeviceCategoryBean deviceCategoryBean;

	public DeviceTypeBean() {
		log.info("DeviceTypeBean constructor");
		initialize();
	}

	/**
	 * Initialize the DeviceTypeBean.
	 */
	private void initialize() {
		notAvailableAction();
		deviceTypeDao = GuiceSingleton.getInstance().getInstance(
				DeviceTypeDao.class);
		deviceCategoryDao = GuiceSingleton.getInstance().getInstance(
				DeviceCategoryDao.class);

		deviceCategoryBean = ComponentLookup
				.lookupComponent("op.deviceCategoryBean");

		deviceTypesList = new ArrayList<DeviceType>();

		consumptionLevelEnum = new ArrayList<ConsumptionLevelEnum>();

		enumMap = new HashMap<String, ConsumptionLevelEnum>();

		for (ConsumptionLevelEnum c : ConsumptionLevelEnum.values()) {
			consumptionLevelEnum.add(c);

			enumMap.put(c.name(), c);

			log.info("Name : " + c.name());
		}
	}

	/**
	 * Downloads device types from database and prepares list for display.
	 */
	public void refreshDeviceTypeList() {
		try {
			deviceTypesList = deviceTypeDao.getDeviceTypes();
		} catch (Exception e) {
			log.error("error while getting devicesTypes: ", e);
		}
	}

	/**
	 * Prepares the data for XHTML template to add new device type.
	 *
	 * @return the string
	 */
	public String addDeviceType() {
		edit = false;
		selectedDeviceType = new DeviceType();
		newDeviceType = new DeviceType();
		newDeviceType.setDeviceCategory(new DeviceCategory());
		deviceCategoryBean.refreshDeviceCategoriesList();
		selectedConsumptionLevel = "";
		return "deviceTypes";
	}

	/**
	 * Cancel add device type.
	 *
	 * @return the string
	 */
	public String cancelAddDeviceType() {
		notAvailableAction();
		return "dictionaries";
	}

	/**
	 * Saves device type defined in XHTML template.
	 *
	 * @return the string
	 */
	public String saveDeviceType() {
		deviceCategoryBean.refreshDeviceCategoriesList();
		DeviceCategory deviceCategory = null;

		newDeviceType
				.setConsumptionLevel(enumMap.get(selectedConsumptionLevel));
		try {
			deviceCategory = deviceCategoryDao
					.getDevicesCategoriesById(newDeviceType.getDeviceCategory()
							.getDeviceCategoryId());
		} catch (Exception e) {
			log.error(
					"Error while getDevicesCategoryById(newDeviceCategory.getDeviceCategoryId(): ",
					e);
		}
		try {
			if (edit) {
				selectedDeviceType.setDeviceCategory(deviceCategory);
				deviceTypeDao.updateDeviceType(selectedDeviceType);
			} else {
				newDeviceType.setDeviceCategory(deviceCategory);
				deviceTypeDao.saveDeviceType(newDeviceType);
			}
		} catch (Exception e) {
			log.error("Error while saveDeviceType: ", e);
		}
		refreshDeviceTypeList();
		return "dictionaries";
	}

	/**
	 * Deletes device type form database.
	 */
	public void deleteDeviceType() {
		try {
			deviceTypeDao.deleteDeviceType(selectedDeviceType);
		} catch (Exception e) {
			log.error("Error while deleteDeviceType: ", e);
		}
		refreshDeviceTypeList();
		notAvailableAction();
	}

	/**
	 * Edits the device type selected from XHTML template.
	 *
	 * @return the string
	 */
	public String editDeviceType() {
		edit = true;
		newDeviceType = selectedDeviceType;
		return "deviceTypes";
	}

	/**
	 * On row select dictionaries list.
	 *
	 * @param event the event
	 */
	public void onRowSelectDictionariesList(SelectEvent event) {
		availableAction();
	}

	/**
	 * On row unselect dictionaries list.
	 *
	 * @param event the event
	 */
	public void onRowUnselectDictionariesList(UnselectEvent event) {
		notAvailableAction();
	}

	/**
	 * Activates if action on selected element is available.
	 */
	public void availableAction() {
		disableShow = false;
		disableEdit = false;
		disableRemove = false;
	}

	/**
	 * Activates if action on selected element is not available.
	 */
	public void notAvailableAction() {
		selectedDeviceType = new DeviceType();

		disableShow = true;
		disableEdit = true;
		disableRemove = true;
	}

	public DeviceType getNewDeviceType() {
		return newDeviceType;
	}

	public void setNewDeviceType(DeviceType newDeviceType) {
		this.newDeviceType = newDeviceType;
	}

	public List<DeviceType> getDeviceTypesList() {
		return deviceTypesList;
	}

	public void setDeviceTypesList(List<DeviceType> deviceTypesList) {
		this.deviceTypesList = deviceTypesList;
	}

	public DeviceType getSelectedDeviceType() {
		return selectedDeviceType;
	}

	public void setSelectedDeviceType(DeviceType selectedDeviceType) {
		this.selectedDeviceType = selectedDeviceType;
	}

	public boolean isDisableShow() {
		return disableShow;
	}

	public void setDisableShow(boolean disableShow) {
		this.disableShow = disableShow;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}

	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}

	public String getSelectedConsumptionLevel() {
		return selectedConsumptionLevel;
	}

	public void setSelectedConsumptionLevel(String selectedConsumptionLevel) {
		this.selectedConsumptionLevel = selectedConsumptionLevel;
	}

	public List<ConsumptionLevelEnum> getConsumptionLevelEnum() {
		return consumptionLevelEnum;
	}

	public void setConsumptionLevelEnum(
			List<ConsumptionLevelEnum> consumptionLevelEnum) {
		this.consumptionLevelEnum = consumptionLevelEnum;
	}

	public Map<String, ConsumptionLevelEnum> getEnumMap() {
		return enumMap;
	}

	public void setEnumMap(Map<String, ConsumptionLevelEnum> enumMap) {
		this.enumMap = enumMap;
	}

	/**
	 * Gets the device type enum list.
	 *
	 * @return the device type enum
	 */
	public List<DeviceTypeEnum> getDeviceTypeEnum() {
		
		List<DeviceTypeEnum> deviceTypeEnum = new ArrayList<DeviceTypeEnum>();

		for (DeviceTypeEnum e : DeviceTypeEnum.values()) {
			deviceTypeEnum.add(e);
			log.debug("DeviceTypeEnum: "+e.getLabel());
		}
		return deviceTypeEnum;
	}

	public void setDeviceTypeEnum(List<DeviceTypeEnum> deviceTypeEnum) {
		this.deviceTypeEnum = deviceTypeEnum;
	}
}
