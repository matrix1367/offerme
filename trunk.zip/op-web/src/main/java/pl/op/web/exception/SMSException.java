package pl.op.web.exception;

public class SMSException extends Exception {
	private static final long serialVersionUID = -4742492379516925899L;

	public SMSException(String message) {
		super(message);
	}
}
