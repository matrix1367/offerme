package pl.op.web.listener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContextEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.StereotypeDao;
import pl.op.model.stereotype.Sector;
import pl.op.model.stereotype.Stereotype;

public class StereotypeImage implements javax.servlet.ServletContextListener {

	public final String SAVE_PATH = "/images/stereotypes/";

	private Logger log = LoggerFactory.getLogger(StereotypeImage.class);

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void contextInitialized(ServletContextEvent event) {
		saveFiles(event);
	}

	public void saveFiles(ServletContextEvent event) {
		List<Stereotype> stereotypes = getStereotypes();

		if (stereotypes != null) {
			for (int i = 0; i < stereotypes.size(); i++) {
				Stereotype stereotype = stereotypes.get(i);
				if (stereotype.getIconPath() != null
						&& stereotype.getIconContent() != null) {
					File file = new File(event.getServletContext().getRealPath(
							SAVE_PATH + stereotype.getIconPath()));

					if (!file.exists()) 				
					{
						log.info("Obrazek o nazwie " + stereotype.getIconPath()
								+ " nie istnieje w lokalizacji " + SAVE_PATH
								+ ". Dodawanie obrazku do danej lokalizacji...");
						saveFile(stereotype, file);
					}
				}
			}
		}
	}

	private List<Stereotype> getStereotypes() {
		StereotypeDao stereotypeDao = GuiceSingleton.getInstance().getInstance(
				StereotypeDao.class);
		List<Stereotype> stereotypes = new ArrayList<Stereotype>();

		try {
			stereotypes = stereotypeDao.getStereotypes(new Sector());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return stereotypes;
	}

	public void saveFile(Stereotype stereotype, File result) {
		try {
			FileOutputStream fileOutputStream = new FileOutputStream(result);

			fileOutputStream.write(stereotype.getIconContent());
			fileOutputStream.flush();
			fileOutputStream.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
