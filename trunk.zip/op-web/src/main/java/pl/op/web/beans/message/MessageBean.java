package pl.op.web.beans.message;

import java.io.ByteArrayInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.MessageAttachmentDao;
import pl.op.dao.MessageDao;
import pl.op.model.msg.Message;
import pl.op.model.msg.MessageAttachment;
import pl.op.model.msg.MessageSender;
import pl.op.model.msg.UserToMessage;
import pl.op.model.user.UserApp;
import pl.op.web.beans.AdminBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

// TODO: Auto-generated Javadoc
/**
 * The Class MessageBean.
 */
@Name("op.messageBean")
@Scope(ScopeType.SESSION)
public class MessageBean implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -359760113249087964L;

	/** The log. */
	private Logger log = LoggerFactory.getLogger(MessageBean.class);

	/** The inbox message list. */
	private List<Message> inboxMessageList;
	
	/** The outbox message list. */
	private List<Message> outboxMessageList;
	
	/** The new message. */
	private Message newMessage;
	
	/** The selected inbox message. */
	private Message selectedInboxMessage;
	
	/** The selected outbox message. */
	private Message selectedOutboxMessage;
	
	/** The message attachments list. */
	private List<MessageAttachment> messageAttachmentsList;
	
	/** The message attachment. */
	private MessageAttachment messageAttachment;
	
	/** The selected message attachment. */
	private MessageAttachment selectedMessageAttachment;

	/** The uploaded file. */
	private UploadedFile uploadedFile;
	
	/** The attachment download. */
	private StreamedContent attachmentDownload;

	/** The users list. */
	private List<UserApp> usersList;
	
	/** The operators id list. */
	private List<Integer> operatorsIdList;
	
	/** The selected users. */
	private List<Integer> selectedUsers;

	/** The user id. */
	private Integer userId;
	
	/** The sender id. */
	private Integer senderId;
	
	/** The unread messages. */
	private Integer unreadMessages;	
	
	/** The attachment name. */
	private String attachmentName;
	
	/** The selected receivers. */
	private String selectedReceivers;
	
	/** The message receivers. */
	private String messageReceivers;
	
	/** The selected outbox receivers. */
	private String selectedOutboxReceivers;
	
	/** The message topic. */
	private String messageTopic;

	/** The message type inbox. */
	private boolean messageTypeInbox;
	
	/** The message type outbox. */
	private boolean messageTypeOutbox;
	
	/** The attachment table visible. */
	private boolean attachmentTableVisible = false;
	
	/** The disable show inbox. */
	private Boolean disableShowInbox = true;
	
	/** The disable remove inbox. */
	private Boolean disableRemoveInbox = true;
	
	/** The disable show outbox. */
	private Boolean disableShowOutbox = true;
	
	/** The disable remove outbox. */
	private Boolean disableRemoveOutbox = true;

	/** The user map. */
	private Map<Integer, UserApp> userMap;
	
	/** The message dao. */
	private MessageDao messageDao;
	
	/** The message attachment dao. */
	private MessageAttachmentDao messageAttachmentDao;

	/** The admin bean. */
	AdminBean adminBean = ComponentLookup.lookupComponent("op.adminBean");

	/**
	 * Instantiates a new message bean.
	 */
	public MessageBean() {
		log.info("MessageBean constructor");
		initialize();
	}

	/**
	 * Initialize method of message handling module.
	 */
	
	private void initialize() {
		notAvailableActionInbox();
		notAvailableActionOutbox();

		messageDao = GuiceSingleton.getInstance().getInstance(MessageDao.class);
		messageAttachmentDao = GuiceSingleton.getInstance().getInstance(
				MessageAttachmentDao.class);

		inboxMessageList = new ArrayList<Message>();
		outboxMessageList = new ArrayList<Message>();

		newMessage = new Message();
		newMessage.setSelectedReceivers(new ArrayList<UserToMessage>());
		newMessage.setMessageSender(new MessageSender());
		messageAttachmentsList = new ArrayList<MessageAttachment>();
		usersList = new ArrayList<UserApp>();

		selectedOutboxReceivers = "";
		
		messageTopic = BundlesUtils.getMessageResourceString("messages",
				"mailBox.newMessage.faqTopic", null, Locale.getDefault());
	}

	/**
	 * Preparing method of new messages window.
	 *
	 * @author michalz
	 * @version 1.0
	 */
	
	public void clearMessage() {
		newMessage = new Message();
		messageAttachmentsList = new ArrayList<MessageAttachment>();
		selectedUsers = new ArrayList<Integer>();
		usersList = new ArrayList<UserApp>();
		outboxMessageList = new ArrayList<Message>();
		selectedReceivers = "";
	}

	/**
	 * Preparing list of inbox mails.
	 *
	 * @author michalz
	 * @version 1.0
	 */
	
	private void prepareInboxMessageList() {
		userId = adminBean.getUserLog().getUserId();

		try {
			messageAttachmentsList = messageAttachmentDao
					.getAttachmentsList(new ArrayList<MessageAttachment>());
		} catch (Exception e) {
			log.error("error while getting inboxMessageAttachmentList", e);
			e.printStackTrace();
		}

		try {
			inboxMessageList = messageDao.getInboxMessageList(new Message(),
					userId);
			log.info("Receiver userId: " + userId);
		} catch (Exception e1) {
			log.error("error while getting Inbox messages: ", e1);
			e1.printStackTrace();
		}

		try {
			unreadMessages = messageDao.unreadMessagesCounter(userId);
		} catch (Exception e2) {
			log.error("error while counting unread messages : ", e2);
			e2.printStackTrace();
		}
	}

	/**
	 * Preparing list of outbox mails.
	 *
	 * @author michalz
	 * @version 1.0
	 */
	
	private void prepareOutboxMessageList() {
		userId = adminBean.getUserLog().getUserId();

		try {
			messageAttachmentsList = messageAttachmentDao
					.getAttachmentsList(new ArrayList<MessageAttachment>());
		} catch (Exception e1) {
			log.error("error while getting outboxMessageAttachmentList", e1);
		}

		try {
			outboxMessageList = messageDao.getOutboxMessageList(new Message(),
					userId);
			log.info("Sender userId: " + userId);
		} catch (Exception e) {
			log.error("error while getting Outbox messages: ", e);
		}
	}

	/**
	 * Method that create and add the new message to database.
	 *
	 * @author michalz
	 * @version 1.0
	 */
	
	public void addMessage() {
		newMessage.setSender(new UserApp());

		senderId = adminBean.getUserLog().getUserId();
		newMessage.getSender().setUserId(senderId);

		try {
			messageDao.newMessage(newMessage, senderId);
		} catch (Exception e) {
			log.error("error while adding newMessage: ", e);
		}

		for (int i = 0; i < selectedUsers.size(); i++) {
			try {
				messageDao.assignMessagesToUsers(selectedUsers.get(i),
						newMessage.getMessageId());
			} catch (Exception e) {
				log.error("Error while adding message to users :", e);
				e.printStackTrace();
			}
		}

		try {
			messageDao.assignMessageSenderToUsers(senderId,
					newMessage.getMessageId());

		} catch (Exception e1) {
			log.error("Error while adding sender to message: ", e1);
			e1.printStackTrace();
		}

		if (!messageAttachmentsList.isEmpty()) {
			messageAttachment.setMessage(new Message());

			messageAttachment.getMessage().setMessageId(
					newMessage.getMessageId());
			log.info("messageAttachment - messageId : "
					+ messageAttachment.getMessage().getMessageId());

			addMessageAttachment();
		}
		prepareInboxMessageList();
		prepareOutboxMessageList();
	}

	/**
	 * Method that sends message to all users with role "operator".
	 *
	 * @author michalz
	 * @version 1.0
	 */
	
	public void addMessageToOperators() {
		newMessage.setSender(new UserApp());
		refreshOperatorsList();

		senderId = adminBean.getUserLog().getUserId();
		newMessage.getSender().setUserId(senderId);

		try {
			messageDao.newMessage(newMessage, senderId);
		} catch (Exception e) {
			log.error("error while adding newMessage: ", e);
		}

		for (int i = 0; i < operatorsIdList.size(); i++) {
			try {
				messageDao.assignMessagesToUsers(operatorsIdList.get(i),
						newMessage.getMessageId());
			} catch (Exception e) {
				log.error("Error while adding message to users :", e);
				e.printStackTrace();
			}
		}

		try {
			messageDao.assignMessageSenderToUsers(senderId,
					newMessage.getMessageId());

		} catch (Exception e1) {
			log.error("Error while adding sender to message: ", e1);
			e1.printStackTrace();
		}

		if (!messageAttachmentsList.isEmpty()) {
			messageAttachment.setMessage(new Message());

			for (int i = 0; i < messageAttachmentsList.size(); i++) {
				messageAttachmentsList.get(i).getMessage()
						.setMessageId(newMessage.getMessageId());
				log.info("Id for : "
						+ messageAttachmentsList.get(i).getDisplayName()
						+ " is " + newMessage.getMessageId());
			}

			log.info("messageAttachment - messageId : "
					+ messageAttachment.getMessage().getMessageId());

			addMessageAttachment();
		}

		prepareInboxMessageList();
		prepareOutboxMessageList();
	}

	/**
	 * Method that add message to question asked trough option "Ask Question".
	 *
	 * @author michalz
	 * @version 1.0
	 */
	
	public void addMessageToFaq() {
		newMessage.setSender(new UserApp());
		refreshOperatorsList();

		senderId = adminBean.getUserLog().getUserId();
		log.info("SenderId "+senderId);
		newMessage.getSender().setUserId(senderId);

		try {
			messageDao.newMessage(newMessage, senderId);
		} catch (Exception e) {
			log.error("error while adding newMessage: ", e);
		}

		for (int i = 0; i < operatorsIdList.size(); i++) {
			try {
				messageDao.assignMessagesToUsers(operatorsIdList.get(i),
						newMessage.getMessageId());
			} catch (Exception e) {
				log.error("Error while adding message to users :", e);
				e.printStackTrace();
			}
		}

		try {
			messageDao.assignMessageSenderToUsers(senderId,
					newMessage.getMessageId());

		} catch (Exception e1) {
			log.error("Error while adding sender to message: ", e1);
			e1.printStackTrace();
		}
	}
	
	
	/**
	 * Reply message.
	 *
	 * @param newMessage the new message
	 */
	
	public void replyMessage(Message newMessage) {
		newMessage.setSender(new UserApp());

		senderId = adminBean.getUserLog().getUserId();
		newMessage.getSender().setUserId(senderId);

		try {
			messageDao.newMessage(newMessage, senderId);
		} catch (Exception e) {
			log.error("error while adding newMessage: ", e);
		}

		for (int i = 0; i < selectedUsers.size(); i++) {
			try {
				messageDao.assignMessagesToUsers(selectedUsers.get(i),
						newMessage.getMessageId());
			} catch (Exception e) {
				log.error("Error while adding message to users :", e);
				e.printStackTrace();
			}
		}

		try {
			messageDao.assignMessageSenderToUsers(senderId,
					newMessage.getMessageId());

		} catch (Exception e1) {
			log.error("Error while adding sender to message: ", e1);
			e1.printStackTrace();
		}
	}

	/**
	 * Method that allows to delete message from inbox list.
	 *
	 * @author michalz
	 * @version 1.0
	 */
	
	public void deleteInboxMessage() {
		try {
			messageDao.deleteInboxMessage(selectedInboxMessage, adminBean
					.getUserLog().getUserId());
		} catch (Exception e) {
			log.error("error while delete InboxMessage: ", e);
		}

		prepareInboxMessageList();
	}

	/**
	 * Method that allows to delete message from outbox list.
	 *
	 * @author michalz
	 * @version 1.0
	 */
	
	public void deleteOutboxMessage() {
		try {
			messageDao.deleteOutboxMessage(selectedOutboxMessage, adminBean
					.getUserLog().getUserId());
		} catch (Exception e) {
			log.error("error while delete OutboxMessage: ", e);
		}

		prepareOutboxMessageList();
	}

	/**
	 * Method that allow to mark message as read.
	 *
	 * @author michalz
	 * @version 1.0
	 */
	
	public void markAsRead() {
		try {
			messageDao.markAsRead(selectedInboxMessage, adminBean.getUserLog()
					.getUserId());
		} catch (Exception e) {
			log.error("Error while setting message as read : ", e);
			e.printStackTrace();
		}

		try {
			unreadMessages = messageDao.unreadMessagesCounter(userId);
		} catch (Exception e) {
			log.error("error while counting unread messages : ", e);
			e.printStackTrace();
		}

		checkMessageRead(selectedInboxMessage);
		prepareInboxMessageList();
	}

	/**
	 * Method that allow to mark message as unread.
	 *
	 * @author michalz
	 * @version 1.0
	 */
	public void markAsUnread() {
		try {
			messageDao.markAsUnread(selectedInboxMessage, adminBean
					.getUserLog().getUserId());
		} catch (Exception e) {
			log.error("Error while setting message as unread : ", e);
			e.printStackTrace();
		}

		try {
			unreadMessages = messageDao.unreadMessagesCounter(userId);
		} catch (Exception e) {
			log.error("error while counting unread messages : ", e);
			e.printStackTrace();
		}

		checkMessageRead(selectedInboxMessage);
		prepareInboxMessageList();
	}

	/**
	 * Update receivers label.
	 */
	public void updateReceiversLabel() {
		selectedReceivers = "";
		for (int i = 0; i < selectedUsers.size(); i++) {
			selectedReceivers += userMap.get(selectedUsers.get(i))
					.getFirstName()
					+ " "
					+ userMap.get(selectedUsers.get(i)).getSurname() + ", ";
		}
	}

	/**
	 * Update outbox receivers.
	 *
	 * @param message the message
	 * @return the string
	 */
	public String updateOutboxReceivers(Message message) {
		if (!adminBean.getUserLog().getUserRole().name().equals("operator")) {
			selectedOutboxReceivers = BundlesUtils.getMessageResourceString("messages",
					"mailBox.outbox.receivers", null, Locale.getDefault());
		} else {
			selectedOutboxReceivers = "";

			for (UserToMessage msg : message.getSelectedReceivers()) {
					selectedOutboxReceivers += msg.getUser().getFirstName() + " " 
							+ msg.getUser().getSurname() + ", ";

					log.info("messageList receivers : "
							+ selectedOutboxReceivers);
				}
			}
		return selectedOutboxReceivers;
	}

	/**
	 * Update message receivers.
	 *
	 * @param message the message
	 * @return the string
	 */
	public String updateMessageReceivers(Message message) {

		if (1 < message.getSelectedReceivers().size()) {
			for (int i = 0; i < message.getSelectedReceivers().size(); i++) {
				messageReceivers += message.getSelectedReceivers().get(i)
						.getUser().getFirstName()
						+ " "
						+ message.getSelectedReceivers().get(i).getUser()
								.getSurname() + ", ";

				log.info("message receivers : " + messageReceivers);
			}
		} else {
			for (int i = 0; i < message.getSelectedReceivers().size(); i++) {
				messageReceivers += message.getSelectedReceivers().get(i)
						.getUser().getFirstName()
						+ " "
						+ message.getSelectedReceivers().get(i).getUser()
								.getSurname();

				log.info("message receivers : " + messageReceivers);
			}
		}
		return messageReceivers;
	}

	/**
	 * Method that allow to check that is selected message is read or not.
	 *
	 * @param message the message
	 * @return the string
	 */
	public String checkMessageRead(Message message) {
		boolean isRead = false;
		String style = "";

		for (int z = 0; z < message.getSelectedReceivers().size(); z++) {

			isRead = message.getSelectedReceivers().get(z).getRead();
		}
		if (isRead) {
			style = "messageRead";
		} else {
			style = "messageUnread";
		}
		return style;
	}

	/**
	 * Refresh users list.
	 *
	 * @return the list
	 */
	public List<UserApp> refreshUsersList() {
		userMap = new HashMap<Integer, UserApp>();

		adminBean.listUsers();
		usersList = adminBean.getUsers();

		for (UserApp u : usersList) {
			userMap.put(u.getUserId(), u);
		}
		return usersList;
	}
	
	
	/**
	 * Gets the user name and put it into the label.
	 *
	 * @param user the user object from XHTML template
	 * @return the user name and surname string
	 */
	public String getUserName(UserApp user) {
		if (user.getFirstName() != null  && user.getSurname() != null) {
			return user.getFirstName() +" "+ user.getSurname();
		} else {
			return user.getLogin();
		}
	}

	/**
	 * Refresh operators list.
	 *
	 * @return the list
	 */
	public List<Integer> refreshOperatorsList() {
		operatorsIdList = adminBean.listOperators();

		return operatorsIdList;
	}

	/**
	 * Refresh inbox message list.
	 */
	public void refreshInboxMessageList() {
		selectedInboxMessage = new Message();
		notAvailableActionInbox();
		prepareInboxMessageList();
	}

	/**
	 * Refresh outbox message list.
	 */
	public void refreshOutboxMessageList() {
		selectedOutboxMessage = new Message();
		notAvailableActionOutbox();
		prepareOutboxMessageList();
	}

	/**
	 * Delete attachment from list.
	 *
	 * @param messageAttachment the message attachment
	 */
	public void deleteAttachmentFromList(MessageAttachment messageAttachment) {
		log.info("Deleting file !");
		log.info("messageAttachmentsList.size() "+ messageAttachmentsList.size());
		messageAttachmentsList.remove(messageAttachment);
		log.info("File deleted !");
		log.info("messageAttachmentsList.size() "+ messageAttachmentsList.size());
	}
		
	/**
	 * Upload file.
	 *
	 * @param event the event
	 */
	public void uploadFile(FileUploadEvent event) {
		uploadedFile = event.getFile();

		messageAttachment = new MessageAttachment();
		messageAttachment.setMessage(new Message());
		messageAttachment.setFileBlob(new byte[0]);

		messageAttachment.setDisplayName(uploadedFile.getFileName());
		messageAttachment.setFileBlob(uploadedFile.getContents());

		log.info("uploaded File : " + uploadedFile.getFileName());
		log.info("uploadedFile.getContents : "
				+ uploadedFile.getContents().length);

		messageAttachmentsList.add(messageAttachment);
		
		attachmentTableVisible = true;
	}

	/**
	 * Download file.
	 *
	 * @param messageAttachment the message attachment
	 * @return the streamed content
	 */
	public StreamedContent downloadFile(MessageAttachment messageAttachment) {
		log.info("***************************** downloadFile *****************************");

		try {
			messageAttachment = messageAttachmentDao
					.getSelectedAttachment(messageAttachment
							.getMessageAttachmentId());
		} catch (Exception e) {
			log.error("error while getting messageAttachment :", e);
			e.printStackTrace();
		}

		byte[] fileBlob = messageAttachment.getFileBlob();

		log.info("messageAttachment : " + messageAttachment.getDisplayName());
		log.info("fileBlob : " + fileBlob);
		log.info("fileBlob Length : " + fileBlob.length);

		ByteArrayInputStream bais = new ByteArrayInputStream(fileBlob);

		attachmentDownload = new DefaultStreamedContent(bais,
				"application/octet-stream", messageAttachment.getDisplayName());

		return attachmentDownload;
	}

	/**
	 * Adds the message attachment.
	 */
	public void addMessageAttachment() {
		for (int i = 0; i < messageAttachmentsList.size(); i++) {
			messageAttachment = messageAttachmentsList.get(i);

			try {
				messageAttachmentDao.newAttachment(messageAttachment);
			} catch (Exception e) {
				log.error("error while addMessageAttachment : ", e);
			}
			log.info("--> Attachment " + messageAttachment.getDisplayName()
					+ " saved ! <-- ");
		}

		log.info("Message attachments : " + messageAttachmentsList.size());

		for (int i = 0; i < messageAttachmentsList.size(); i++) {
			attachmentName = messageAttachmentsList.get(i).getDisplayName();

			log.info("Message attachment Name : " + attachmentName);
			log.info("Message Attachment.getFileBlob : "
					+ messageAttachment.getFileBlob().length);
		}
	}

	/**
	 * On row select inbox message list.
	 *
	 * @param event the event
	 */
	public void onRowSelectInboxMessageList(SelectEvent event) {
		if (!selectedInboxMessage.getTopic().equals(messageTopic)) {
			messageTypeInbox = true;
		} else {
			messageTypeInbox = false;
		}
		availableActionInbox();
	}

	/**
	 * On row unselect inbox message list.
	 *
	 * @param event the event
	 */
	public void onRowUnselectInboxMessageList(UnselectEvent event) {
		notAvailableActionInbox();
	}

	/**
	 * On row select outbox message list.
	 *
	 * @param event the event
	 */
	public void onRowSelectOutboxMessageList(SelectEvent event) {
		if (!selectedOutboxMessage.getTopic().equals(messageTopic)) {
			messageTypeOutbox = true;
		} else {
			messageTypeOutbox = false;
		}
		availableActionOutbox();
	}

	/**
	 * On row unselect outbox message list.
	 *
	 * @param event the event
	 */
	public void onRowUnselectOutboxMessageList(UnselectEvent event) {
		notAvailableActionOutbox();
	}

	/**
	 * Available action inbox.
	 */
	private void availableActionInbox() {
		disableShowInbox = false;
		disableRemoveInbox = false;
	}

	/**
	 * Not available action inbox.
	 */
	private void notAvailableActionInbox() {
		disableShowInbox = true;
		disableRemoveInbox = true;
	}

	/**
	 * Available action outbox.
	 */
	private void availableActionOutbox() {
		disableShowOutbox = false;
		disableRemoveOutbox = false;
	}

	/**
	 * Not available action outbox.
	 */
	private void notAvailableActionOutbox() {
		disableShowOutbox = true;
		disableRemoveOutbox = true;
	}

	/**
	 * Gets the new message.
	 *
	 * @return the new message
	 */
	public Message getNewMessage() {
		return newMessage;
	}

	/**
	 * Sets the new message.
	 *
	 * @param newMessage the new new message
	 */
	public void setNewMessage(Message newMessage) {
		this.newMessage = newMessage;
	}

	/**
	 * Gets the unread messages.
	 *
	 * @return the unread messages
	 */
	public Integer getUnreadMessages() {
		return unreadMessages;
	}

	/**
	 * Sets the unread messages.
	 *
	 * @param unreadMessages the new unread messages
	 */
	public void setUnreadMessages(Integer unreadMessages) {
		this.unreadMessages = unreadMessages;
	}

	/**
	 * Gets the inbox message list.
	 *
	 * @return the inbox message list
	 */
	public List<Message> getInboxMessageList() {
		return inboxMessageList;
	}

	/**
	 * Sets the inbox message list.
	 *
	 * @param inboxMessageList the new inbox message list
	 */
	public void setInboxMessageList(List<Message> inboxMessageList) {
		this.inboxMessageList = inboxMessageList;
	}

	/**
	 * Gets the outbox message list.
	 *
	 * @return the outbox message list
	 */
	public List<Message> getOutboxMessageList() {
		return outboxMessageList;
	}

	/**
	 * Sets the outbox message list.
	 *
	 * @param outboxMessageList the new outbox message list
	 */
	public void setOutboxMessageList(List<Message> outboxMessageList) {
		this.outboxMessageList = outboxMessageList;
	}

	/**
	 * Gets the selected inbox message.
	 *
	 * @return the selected inbox message
	 */
	public Message getSelectedInboxMessage() {
		return selectedInboxMessage;
	}

	/**
	 * Sets the selected inbox message.
	 *
	 * @param selectedMessage the new selected inbox message
	 */
	public void setSelectedInboxMessage(Message selectedMessage) {
		this.selectedInboxMessage = selectedMessage;
	}

	/**
	 * Gets the selected outbox message.
	 *
	 * @return the selected outbox message
	 */
	public Message getSelectedOutboxMessage() {
		return selectedOutboxMessage;
	}

	/**
	 * Sets the selected outbox message.
	 *
	 * @param selectedOutboxMessage the new selected outbox message
	 */
	public void setSelectedOutboxMessage(Message selectedOutboxMessage) {
		this.selectedOutboxMessage = selectedOutboxMessage;
	}

	/**
	 * Gets the selected users.
	 *
	 * @return the selected users
	 */
	public List<Integer> getSelectedUsers() {
		return selectedUsers;
	}

	/**
	 * Sets the selected users.
	 *
	 * @param selectedUsers the new selected users
	 */
	public void setSelectedUsers(List<Integer> selectedUsers) {
		this.selectedUsers = selectedUsers;
	}

	/**
	 * Gets the selected receivers.
	 *
	 * @return the selected receivers
	 */
	public String getSelectedReceivers() {
		return selectedReceivers;
	}

	/**
	 * Sets the selected receivers.
	 *
	 * @param selectedReceivers the new selected receivers
	 */
	public void setSelectedReceivers(String selectedReceivers) {
		this.selectedReceivers = selectedReceivers;
	}

	/**
	 * Gets the message attachments list.
	 *
	 * @return the message attachments list
	 */
	public List<MessageAttachment> getMessageAttachmentsList() {
		return messageAttachmentsList;
	}

	/**
	 * Sets the message attachments list.
	 *
	 * @param messageAttachmentsList the new message attachments list
	 */
	public void setMessageAttachmentsList(
			List<MessageAttachment> messageAttachmentsList) {
		this.messageAttachmentsList = messageAttachmentsList;
	}

	/**
	 * Gets the attachment download.
	 *
	 * @return the attachment download
	 */
	public StreamedContent getAttachmentDownload() {
		return attachmentDownload;
	}

	/**
	 * Sets the attachment download.
	 *
	 * @param attachmentDownload the new attachment download
	 */
	public void setAttachmentDownload(StreamedContent attachmentDownload) {
		this.attachmentDownload = attachmentDownload;
	}

	/**
	 * Gets the disable show inbox.
	 *
	 * @return the disable show inbox
	 */
	public Boolean getDisableShowInbox() {
		return disableShowInbox;
	}

	/**
	 * Sets the disable show inbox.
	 *
	 * @param disableShowInbox the new disable show inbox
	 */
	public void setDisableShowInbox(Boolean disableShowInbox) {
		this.disableShowInbox = disableShowInbox;
	}

	/**
	 * Gets the disable remove inbox.
	 *
	 * @return the disable remove inbox
	 */
	public Boolean getDisableRemoveInbox() {
		return disableRemoveInbox;
	}

	/**
	 * Sets the disable remove inbox.
	 *
	 * @param disableRemoveInbox the new disable remove inbox
	 */
	public void setDisableRemoveInbox(Boolean disableRemoveInbox) {
		this.disableRemoveInbox = disableRemoveInbox;
	}

	/**
	 * Gets the disable show outbox.
	 *
	 * @return the disable show outbox
	 */
	public Boolean getDisableShowOutbox() {
		return disableShowOutbox;
	}

	/**
	 * Sets the disable show outbox.
	 *
	 * @param disableShowOutbox the new disable show outbox
	 */
	public void setDisableShowOutbox(Boolean disableShowOutbox) {
		this.disableShowOutbox = disableShowOutbox;
	}

	/**
	 * Gets the disable remove outbox.
	 *
	 * @return the disable remove outbox
	 */
	public Boolean getDisableRemoveOutbox() {
		return disableRemoveOutbox;
	}

	/**
	 * Sets the disable remove outbox.
	 *
	 * @param disableRemoveOutbox the new disable remove outbox
	 */
	public void setDisableRemoveOutbox(Boolean disableRemoveOutbox) {
		this.disableRemoveOutbox = disableRemoveOutbox;
	}

	/**
	 * Checks if is message type inbox.
	 *
	 * @return true, if is message type inbox
	 */
	public boolean isMessageTypeInbox() {
		return messageTypeInbox;
	}

	/**
	 * Sets the message type inbox.
	 *
	 * @param messageTypeInbox the new message type inbox
	 */
	public void setMessageTypeInbox(boolean messageTypeInbox) {
		this.messageTypeInbox = messageTypeInbox;
	}

	/**
	 * Checks if is message type outbox.
	 *
	 * @return true, if is message type outbox
	 */
	public boolean isMessageTypeOutbox() {
		return messageTypeOutbox;
	}

	/**
	 * Sets the message type outbox.
	 *
	 * @param messageTypeOutbox the new message type outbox
	 */
	public void setMessageTypeOutbox(boolean messageTypeOutbox) {
		this.messageTypeOutbox = messageTypeOutbox;
	}

	/**
	 * Checks if is attachment table visible.
	 *
	 * @return true, if is attachment table visible
	 */
	public boolean isAttachmentTableVisible() {
		return attachmentTableVisible;
	}

	/**
	 * Sets the attachment table visible.
	 *
	 * @param attachmentTableVisible the new attachment table visible
	 */
	public void setAttachmentTableVisible(boolean attachmentTableVisible) {
		this.attachmentTableVisible = attachmentTableVisible;
	}

	/**
	 * Gets the selected message attachment.
	 *
	 * @return the selected message attachment
	 */
	public MessageAttachment getSelectedMessageAttachment() {
		return selectedMessageAttachment;
	}

	/**
	 * Sets the selected message attachment.
	 *
	 * @param selectedMessageAttachment the new selected message attachment
	 */
	public void setSelectedMessageAttachment(MessageAttachment selectedMessageAttachment) {
		this.selectedMessageAttachment = selectedMessageAttachment;
	}
}