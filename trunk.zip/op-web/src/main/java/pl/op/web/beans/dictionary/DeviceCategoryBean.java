package pl.op.web.beans.dictionary;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.DeviceCategoryDao;
import pl.op.model.device.DeviceCategory;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class DeviceCategoryBean. This class manages the devices categories.
 * Can add/edit/delete data from database table named "tb_devicecategory".
 */
@Name("op.deviceCategoryBean")
@Scope(ScopeType.SESSION)
public class DeviceCategoryBean implements Serializable {

	private static final long serialVersionUID = 4893021520692519468L;

	private Logger log = LoggerFactory.getLogger(DeviceCategoryBean.class);

	private List<DeviceCategory> deviceCategoriesList;
	private DeviceCategory newDeviceCategory;
	private DeviceCategory selectedDeviceCategory;

	private boolean edit;
	private boolean disableShow = true;
	private boolean disableEdit = true;
	private boolean disableRemove = true;

	private DeviceCategoryDao deviceCategoryDao;

	public DeviceCategoryBean() {
		log.info("DeviceCategoryBean constructor");
		initialize();
	}

	/**
	 * Initialize the DeviceCategoryBean.
	 */
	private void initialize() {
		notAvailableAction();
		deviceCategoryDao = GuiceSingleton.getInstance().getInstance(
				DeviceCategoryDao.class);

		deviceCategoriesList = new ArrayList<DeviceCategory>();
	}

	/**
	 * Downloads device categories from database and prepares list for display.
	 */
	public void refreshDeviceCategoriesList() {
		try {
			deviceCategoriesList = deviceCategoryDao.getDeviceCategories();
		} catch (Exception e) {
			log.error("error while getting devicesCategories: ", e);
		}
	}

	/**
	 * Prepares the data for XHTML template to add new device category.
	 * 
	 * @return the string
	 */
	public String addDeviceCategory() {
		edit = false;
		selectedDeviceCategory = new DeviceCategory();
		newDeviceCategory = new DeviceCategory();
		return "deviceCategories";
	}

	/**
	 * Cancels add device category.
	 * 
	 * @return the string
	 */
	public String cancelAddDeviceCategory() {
		notAvailableAction();
		return "dictionaries";
	}

	/**
	 * Saves device category defined in XHTML template.
	 * 
	 * @return the string
	 */
	public String saveDeviceCategory() {
		try {
			if (edit) {
				deviceCategoryDao.updateDeviceCategory(selectedDeviceCategory);
			} else {
				deviceCategoryDao.saveDeviceCategory(newDeviceCategory);
			}
		} catch (Exception e) {
			log.error("Error while saveDeviceCategory: ", e);
		}
		refreshDeviceCategoriesList();;
		return "dictionaries";
	}

	/**
	 * Deletes device category form database.
	 */
	public void deleteDeviceCategory() {
		try {
			deviceCategoryDao.deleteDeviceCategory(selectedDeviceCategory);
		} catch (Exception e) {
			log.error("Error while deleteDeviceCategory: ", e);
		}
		refreshDeviceCategoriesList();
		notAvailableAction();
	}

	/**
	 * Edits the device category selected from XHTML template.
	 * 
	 * @return the string
	 */
	public String editDeviceCategory() {
		edit = true;
		newDeviceCategory = selectedDeviceCategory;
		return "deviceCategories";
	}

	/**
	 * On row select dictionaries list.
	 * 
	 * @param event
	 *            the event
	 */
	public void onRowSelectDictionariesList(SelectEvent event) {
		availableAction();
	}

	/**
	 * On row unselect dictionaries list.
	 * 
	 * @param event
	 *            the event
	 */
	public void onRowUnselectDictionariesList(UnselectEvent event) {
		notAvailableAction();
	}

	/**
	 * Activates if action on selected element is available.
	 */
	public void availableAction() {
		disableShow = false;
		disableEdit = false;
		disableRemove = false;
	}

	/**
	 * Activates if action on selected element is not available.
	 */
	public void notAvailableAction() {
		selectedDeviceCategory = new DeviceCategory();

		disableShow = true;
		disableEdit = true;
		disableRemove = true;
	}

	public DeviceCategory getNewDeviceCategory() {
		return newDeviceCategory;
	}

	public void setNewDeviceCategory(DeviceCategory newDeviceCategory) {
		this.newDeviceCategory = newDeviceCategory;
	}

	public List<DeviceCategory> getDeviceCategoriesList() {
		return deviceCategoriesList;
	}

	public void setDeviceCategoriesList(
			List<DeviceCategory> deviceCategoriesList) {
		this.deviceCategoriesList = deviceCategoriesList;
	}

	public DeviceCategory getSelectedDeviceCategory() {
		return selectedDeviceCategory;
	}

	public void setSelectedDeviceCategory(DeviceCategory selectedDeviceCategory) {
		this.selectedDeviceCategory = selectedDeviceCategory;
	}

	public boolean isDisableShow() {
		return disableShow;
	}

	public void setDisableShow(boolean disableShow) {
		this.disableShow = disableShow;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}

	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}
}