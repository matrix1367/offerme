package pl.op.web.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.CloudDao;
import pl.op.dao.PPEDao;
import pl.op.model.cloud.Cloud;
import pl.op.model.cloud.CloudFilter;
import pl.op.model.contract.Location;
import pl.op.model.contract.PPE;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Street;
import pl.op.model.dict.Tariff;
import pl.op.model.salesman.Salesman;
import pl.op.model.user.UserApp;
import pl.op.util.CloudUtil;
import pl.op.web.beans.cloud.CloudBean;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class AutoCloudGenerator.
 */
public class AutoCloudGenerator {

    private Logger log = LoggerFactory.getLogger(AutoCloudGenerator.class);
    private List<PPE> ppeList;
    private UserApp user;
    private List<Area> areas = new ArrayList<Area>();
    private List<City> cities = new ArrayList<City>();
    private List<Street> streets = new ArrayList<Street>();
    private CloudFilter cloudFilter = new CloudFilter();
    private List<Cloud> searchResult = new ArrayList<Cloud>();
    private int findClouds;
    private int newClouds;
    private Cloud tempCloud = new Cloud();
    private Tariff actualTariff;

    private PPEDao ppeDao;
    private CloudDao cloudDao;

    private CloudBean cloudBean;

    /**
     * Instantiates a new auto cloud generator.
     * 
     * @param userInstance
     *            the user instance
     */
    private AutoCloudGenerator(UserApp userInstance) {
        user = userInstance;

        initializeDao();
        initializeBeans();
    }

    /**
     * Auto cloud generate for new user.
     * 
     * @param userInstance
     *            the user instance
     * @param locations
     *            the locations
     */
    public static void autoCloudGenerateForNewUser(UserApp userInstance, List<Location> locations) {
        AutoCloudGenerator autoCloudGenerator = new AutoCloudGenerator(userInstance);
        autoCloudGenerator.preparePpeListByLocation(locations);
        autoCloudGenerator.runGenerator();
        
        for(Location location : locations) {
            for(PPE ppe : location.getPpes()) {
                CloudUtil.updateCloudVolumeByPpeId(ppe.getPpeId());
            }
        }
    }

    /**
     * Auto cloud generate for new ppe.
     * 
     * @param userInstance
     *            the user instance
     * @param ppe
     *            the ppe
     */
    public static void autoCloudGenerateForNewPpe(UserApp userInstance, PPE ppe) {
        AutoCloudGenerator autoCloudGenerator = new AutoCloudGenerator(userInstance);
        autoCloudGenerator.addPpeToList(ppe);
        autoCloudGenerator.runGenerator();
        
        CloudUtil.updateCloudVolumeByPpeId(ppe.getPpeId());
    }

    /**
     * Initialize dao.
     */
    private void initializeDao() {
        ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);
        cloudDao = GuiceSingleton.getInstance().getInstance(CloudDao.class);
    }

    /**
     * Initialize beans.
     */
    private void initializeBeans() {
        cloudBean = ComponentLookup.lookupComponent("op.cloudBean");
    }

    /**
     * Adds the ppe to list.
     * 
     * @param ppe
     *            the ppe
     */
    private void addPpeToList(PPE ppe) {
        if(!hasPpeInProcess()) {
            ppeList = new ArrayList<PPE>();
        }

        ppeList.add(ppe);
    }

    /**
     * Prepare ppe list by location.
     * 
     * @param locationList
     *            the location list
     */
    private void preparePpeListByLocation(List<Location> locationList) {
        if(hasLocationOnList(locationList)) {
            reviewLocationList(locationList);
        }
    }

    /**
     * Checks for location on list.
     * 
     * @param locationList
     *            the location list
     * @return true, if successful
     */
    private boolean hasLocationOnList(List<Location> locationList) {
        if(null == locationList) {
            return false;
        }
        if(locationList.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Checks for ppe in location.
     * 
     * @param location
     *            the location
     * @return true, if successful
     */
    private boolean hasPpeInLocation(Location location) {
        if(null == location.getPpes()) {
            return false;
        }
        if(location.getPpes().isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Review location list.
     * 
     * @param locationList
     *            the location list
     */
    private void reviewLocationList(List<Location> locationList) {
        for(Location location : locationList) {
            if(hasPpeInLocation(location)) {
                getPpeFromLocation(location);
            }
        }
    }

    /**
     * Gets the ppe from location.
     * 
     * @param location
     *            the location
     * @return the ppe from location
     */
    private void getPpeFromLocation(Location location) {
        if(!hasPpeInProcess()) {
            ppeList = new ArrayList<PPE>();
        }

        ppeList.addAll(location.getPpes());
    }

    /**
     * Checks for ppe in process.
     * 
     * @return true, if successful
     */
    private boolean hasPpeInProcess() {
        if(null == ppeList) {
            return false;
        }
        if(ppeList.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Run generator.
     */
    public void runGenerator() {
        try {
            generateCloud();
        } catch (Exception e) {
            log.error("Problem while auto generate clouds for ppes: ", e);
        }

    }

    /**
     * Generate cloud.
     * 
     * @throws Exception
     *             the exception
     */
    private void generateCloud() throws Exception {
        if(hasPpeInProcess()) {
            log.info("autoCloudGenerate - Count user ppe: " + ppeList.size());
            for(PPE ppe : ppeList) {
                clearLocationData();
                prepareLocationData(ppe);
                getActualTariff(ppe);

                generateCloudForPpe(ppe);
            }

            log.info("Result - find clouds: " + findClouds + "; new clouds: " + newClouds);
        } else {
            log.info("autoCloudGenerate - Count user ppe: 0");
        }
    }

    /**
     * Clear location data.
     */
    private void clearLocationData() {
        areas = new ArrayList<Area>();
        cities = new ArrayList<City>();
        streets = new ArrayList<Street>();
    }

    /**
     * Prepare location data.
     * 
     * @param ppe
     *            the ppe
     */
    private void prepareLocationData(PPE ppe) {
        areas.add(ppe.getLocation().getStreet().getCity().getArea());
        cities.add(ppe.getLocation().getStreet().getCity());
        streets.add(ppe.getLocation().getStreet());
    }

    /**
     * Gets the actual tariff.
     * 
     * @param ppe
     *            the ppe
     * @return the actual tariff
     * @throws Exception
     *             the exception
     */
    private void getActualTariff(PPE ppe) throws Exception {
        log.info("search actual tarif for ppe #" + ppe.getPpeId());

        actualTariff = ppeDao.getActualTariff(ppe);
    }

    /**
     * Generate cloud for ppe.
     * 
     * @param ppe
     *            the ppe
     * @throws Exception
     *             the exception
     */
    private void generateCloudForPpe(PPE ppe) throws Exception {
        prepareTempCloud();
        updateHelpersBeforeSearchForAreas();
        searchClouds();
        renderSearchResult("area: " + getAreasId());
        
        //dodawanie użytkownika do chmury z kreatoa
        updateHelpersBeforeSearchForAreasCreator();
        searchCloudsForCreator();
        renderSearchResultCreate();

        updateHelpersBeforeSearchForCities();
        searchClouds();
        renderSearchResult("city: " + getCitiesId());
    }

    /**
     * Initialize search helpers.
     */
    private void initializeSearchHelpers() {
        cloudFilter = new CloudFilter();
        searchResult = new ArrayList<Cloud>();
    }

    /**
     * Prepare temp cloud.
     */
    private void prepareTempCloud() {
        tempCloud = new Cloud();
        tempCloud.setCreationDate(new Date());
        tempCloud.setSalesman(new Salesman());
        tempCloud.setIsCompany(user.getIsCompany());
        log.info(">>>>>>>>>>>> Tworze nowa chmure z stereotypem <<<<<<<<<<<<");
        if (user.getSector() != null) {
            log.info(">>>>>>>>>>>> Tworze nowa chmure z sector stereotypem : " + user.getSector().getStereotype().getStereotypeName());
            tempCloud.setStereotype(user.getSector().getStereotype());
        } else {
            log.info(">>>>>>>>>>>> Tworze nowa chmure z sector stereotypem : user.getSector() != null");
        }       
    }

    /**
     * Update helpers before search for areas.
     */
    private void updateHelpersBeforeSearchForAreas() {
        initializeSearchHelpers();

        tempCloud.setTariff(actualTariff);
        tempCloud.setAreas(areas);
        tempCloud.setIsManual(false);

        cloudFilter.setCloud(tempCloud);
        cloudFilter.setSearchType("forArea");
    }
    
        /**
     * Update helpers before search for areas.
     */
    private void updateHelpersBeforeSearchForAreasCreator() {
        initializeSearchHelpers();

        tempCloud.setTariff(actualTariff);
        tempCloud.setAreas(areas);
        tempCloud.setIsManual(true);

        cloudFilter.setCloud(tempCloud);
        cloudFilter.setSearchType("forArea");
    }

    /**
     * Update helpers before search for cities.
     */
    private void updateHelpersBeforeSearchForCities() {
        updateHelpersBeforeSearchForAreas();
        tempCloud.setCities(cities);
        tempCloud.setIsManual(false);
        cloudFilter.setSearchType("forCity");

    }

    /**
     * Search clouds.
     * 
     * @throws Exception
     *             the exception
     */
    private void searchClouds() throws Exception {
        searchResult = cloudDao.getClouds(cloudFilter);
        log.info("[searchClouds]:" + searchResult.size());
    }
    
        /**
     * Search clouds.
     * 
     * @throws Exception
     *             the exception
     */
    private void searchCloudsForCreator() throws Exception {
        log.info("[searchCloudsForCreator]");
        
     
        log.info(cloudFilter.toString());
        
        searchResult = cloudDao.getCloudsForCreator(cloudFilter);
        log.info("[searchCloudsForCreator]:" + searchResult.size());
    }


    /**
     * Gets the areas id.
     * 
     * @return the areas id
     */
    private String getAreasId() {
        String res = "";
        for(Area area : areas) {
            res += "| " + area.getAreaId();
        }

        return res;
    }

    /**
     * Gets the cities id.
     * 
     * @return the cities id
     */
    private String getCitiesId() {
        String res = "";
        for(City city : cities) {
            res += "| " + city.getCityId();
        }

        return res;
    }

    /**
     * Render search result.
     * 
     * @param resultType
     *            the result type
     * @throws Exception
     *             the exception
     */
    private void renderSearchResult(String resultType) throws Exception {
        if(foundClouds()) {
            assignUserToFoundClouds();
        } else {
            createNewCloud(resultType);
        }
    }
    
    /**
     * Render search result.     
     * @throws Exception
     *             the exception
     */
    private void renderSearchResultCreate() throws Exception {
        if(foundClouds()) {
            assignUserToFoundClouds();
        } 
    }    

    /**
     * Found clouds.
     * 
     * @return true, if successful
     */
    private boolean foundClouds() {
        if(null == searchResult) {
            return false;
        }
        if(searchResult.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Assign user to found clouds.
     * 
     * @throws Exception
     *             the exception
     */
    private void assignUserToFoundClouds() throws Exception {
        findClouds += searchResult.size();
        log.info("find cloud(" + searchResult.size() + ") for areas: #" + getAreasId());

        for(Cloud cloud : searchResult) {
            cloudBean.assignUserToCloud(cloud, user);
        }
    }

    /**
     * Creates the new cloud.
     * 
     * @param cloudType
     *            the cloud type
     * @throws Exception
     *             the exception
     */
    private void createNewCloud(String cloudType) throws Exception {
        log.info("createNewCloud to: " + cloudType);

        Cloud newUserCloud = tempCloud;
        newUserCloud.setIsManual(false);

        cloudDao.saveCloud(newUserCloud);
        newUserCloud.genereateName();
        newUserCloud.setVolume(0.0);
        cloudDao.updateCloud(newUserCloud);

        assignUsersToNewCloud(newUserCloud);
        newClouds++;
    }

    /**
     * Assign users to new cloud.
     * 
     * @param cloud
     *            the cloud
     */
    private void assignUsersToNewCloud(Cloud cloud) {
        cloudBean.assignUserToCloud(cloud, user);
        cloudBean.setCloud(cloud);
        cloudBean.assignUsers();
    }
}
