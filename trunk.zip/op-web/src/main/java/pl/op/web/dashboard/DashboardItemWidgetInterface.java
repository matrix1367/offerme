package pl.op.web.dashboard;

public interface DashboardItemWidgetInterface {

	public String getContent();
	
}
