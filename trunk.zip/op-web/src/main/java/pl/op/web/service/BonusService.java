package pl.op.web.service;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.imageio.ImageIO;

import org.imgscalr.Scalr;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.EventDao;
import pl.op.dao.PointsRulesDao;
import pl.op.dao.UserPointsDao;
import pl.op.model.bonus.Event;
import pl.op.model.bonus.PointsRules;
import pl.op.model.bonus.UserPoints;
import pl.op.model.user.UserApp;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class BonusService.
 */
public class BonusService {

    private static Logger log = LoggerFactory.getLogger(BonusService.class);

    /**
     * Run.
     * 
     * @param codeName
     *            - the code name of event
     * @param userApp
     *            - the user instance
     * @return (integer) the number of points add for a event
     */
    public static Integer run(String codeName, UserApp userApp) {

        if(codeName.isEmpty()) {
            return 0;
        }
        if(userApp == null) {
            return 0;
        }

        codeName = codeName.toLowerCase();
        BonusService bonus = GuiceSingleton.getInstance().getInstance(BonusService.class);
        Integer pointsAdd = 0;

        Date now = new Date();

        log.info(codeName);
        Event event = bonus.getEvent(codeName);
        if(event != null) {
            List<PointsRules> pointsRules = bonus.getPointsRules(event);
            if(pointsRules.isEmpty() == false) {
                Integer userAppId = userApp.getUserId();
                UserPointsDao userPointsDao = GuiceSingleton.getInstance().getInstance(UserPointsDao.class);
                for(PointsRules pointsRule : pointsRules) {
                    log.info("Bonus try: " + codeName + "(" + pointsRule.getBonusName() + ")");
                    Integer pointsRulesId = pointsRule.getPointsRulesId();
                    UserPoints userPointsLastGranted = null;
                    UserPoints userPointsLastNotGranted = null;
                    UserPoints userPoint = null;

                    try {
                        log.info("check start");
                        userPointsLastGranted = userPointsDao.getUserPointsLastGrantedByPointsRulesAndUserApp(
                                pointsRulesId, userAppId);
                        userPointsLastNotGranted = userPointsDao.getUserPointsLastNotGrantedByPointsRulesAndUserApp(
                                pointsRulesId, userAppId);
                        log.info("check complete");

                        if(userPointsLastGranted != null) {
                            log.info("userPointsLastGranted id: " + userPointsLastGranted.getUserPointsId());
                        } else {
                            log.info("userPointsLastGranted is null");
                        }
                        if(userPointsLastNotGranted != null) {
                            log.info("userPointsLastNotGranted id: " + userPointsLastNotGranted.getUserPointsId());
                        } else {
                            log.info("userPointsLastNotGranted is null");
                        }
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }

                    Boolean isNew = false;
                    Boolean isGranted = false;
                    Integer noRepeats = 1;

                    if(pointsRule.getIsRepeatable() == false && pointsRule.getRepeatsNeed() == 1) {
                        if(userPointsLastGranted == null) {
                            log.info("is new LastGranted");
                            isNew = true;
                        } else {
                            log.info("continue pointsRule.getIsRepeatable() == false && pointsRule.getRepeatsNeed() == 1");
                            continue;
                        }
                    }
                    if(userPointsLastNotGranted == null) {
                        log.info("is new NotGranted");
                        isNew = true;
                    }
                    if(isNew) {
                        if(userPointsLastGranted != null) {
                            userPoint = userPointsLastGranted;
                            if(pointsRule.getIsOncePerDay() == true) {
                                if(bonus.checkIsSameDay(now, userPoint.getUpdatedAt())) {
                                    log.info("continue now day == updatedAt day");
                                    continue;
                                }
                            }
                        }
                        userPoint = new UserPoints();
                    } else {
                        userPoint = userPointsLastNotGranted;
                        noRepeats = userPoint.getNoRepeats() + 1;
                        if(pointsRule.getIsOncePerDay() == true) {
                            if(bonus.checkIsSameDay(now, userPoint.getUpdatedAt())) {
                                log.info("continue now day == updatedAt day");
                                continue;
                            }
                        }
                    }

                    if(pointsRule.getRepeatsNeed() == 1) {
                        isGranted = true;
                    } else {
                        if(pointsRule.getRepeatsNeed() == noRepeats) {
                            isGranted = true;
                        }
                    }
                    userPoint.setIsGranted(isGranted);
                    userPoint.setNoRepeats(noRepeats);
                    userPoint.setPointsRules(pointsRule);
                    userPoint.setUpdatedAt(now);
                    userPoint.setUser(userApp);
                    try {
                        if(isNew) {
                            log.info("save");
                            userPointsDao.saveUserPoints(userPoint);
                        } else {
                            log.info("update");
                            userPointsDao.updateUserPoints(userPoint);
                        }
                        if(isGranted) {
                            log.info("Bonus save and is granted: " + codeName + "(" + pointsRule.getBonusName() + ")");
                        } else {
                            log.info("Bonus save and is not granted: " + codeName + "(" + pointsRule.getBonusName()
                                    + ")");
                        }
                        pointsAdd += pointsRule.getPointsAmount();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        return pointsAdd;

    }

    /**
     * Upload photo.
     * 
     * @param file
     *            - the file (image) to upload
     * @param fileName
     *            - the filename
     * @param ext
     *            - the extension of file
     * @return the boolean
     */
    public static Boolean uploadPhoto(UploadedFile file, String fileName, String ext) {

        Boolean result = false;
        String path = UploadService.UPLOAD_DIR + "bonus/";
        Integer size = 200;

        ExternalContext extContext = FacesContext.getCurrentInstance().getExternalContext();
        File uploadFile = new File(extContext.getRealPath(path + fileName));

        try {
            log.info("upload " + fileName + "(ext: " + ext + ")");
            Boolean uploadResult = UploadService.upload(file, "bonus", fileName);
            if(uploadFile.exists() && uploadResult) {
                BufferedImage originalImage = ImageIO.read(uploadFile);
                BufferedImage resizeImage = Scalr.resize(originalImage, size);
                if(ext.equals("jpg")) {
                    log.info("save resize jpg");
                    ImageIO.write(resizeImage, "jpg", uploadFile);
                }
                if(ext.equals("png")) {
                    log.info("save resize png");
                    ImageIO.write(resizeImage, "png", uploadFile);
                }
            }
            result = true;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return result;

    }

    /**
     * Gets the event.
     * 
     * @param codeName
     *            - the code name
     * @return the event
     */
    private Event getEvent(String codeName) {

        Event event = null;
        EventDao eventDao = GuiceSingleton.getInstance().getInstance(EventDao.class);

        try {
            event = eventDao.getEventByCodeName(codeName);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return event;

    }

    /**
     * Gets the points rules.
     * 
     * @param event
     *            - the event
     * @return the points rules
     */
    private List<PointsRules> getPointsRules(Event event) {

        List<PointsRules> pointsRules = new ArrayList<PointsRules>();
        PointsRulesDao pointsRulesDao = GuiceSingleton.getInstance().getInstance(PointsRulesDao.class);

        try {
            pointsRules = pointsRulesDao.getPointsRulesByEventActive(event);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return pointsRules;

    }

    /**
     * Check is same day.
     * 
     * @param date1
     *            - the date from
     * @param date2
     *            - the date to
     * @return the boolean
     */
    private Boolean checkIsSameDay(Date date1, Date date2) {

        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        cal1.setTime(date1);
        cal2.setTime(date2);

        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR)
                && cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
    }

}
