package pl.op.web.beans.log;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.OperatorInvoiceDao;
import pl.op.model.contract.OperatorInvoice;
import pl.op.web.beans.CustomerBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

@Name("op.operatorInvoiceBean")
@Scope(ScopeType.SESSION)
public class OperatorInvoiceBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private Logger log = LoggerFactory.getLogger(OperatorInvoiceBean.class);

    private OperatorInvoice operatorInvoiceFilter;

    private List<OperatorInvoice> operatorInvoices;

    private OperatorInvoiceDao operatorInvoiceDao;
    private OperatorInvoice operatorInvoice;
    private UploadedFile invoiceFile;

    private boolean invoiceButtonsDisabled;

    private SalesmanBean salesmanBean;
    private CustomerBean customerBean;

    private Boolean salesmanInvoice;

    public OperatorInvoiceBean() {
        log.info("OperatorInvoiceBean constructor");
        initialize();
    }

    private void initialize() {
        operatorInvoiceDao = GuiceSingleton.getInstance().getInstance(OperatorInvoiceDao.class);

        salesmanBean = ComponentLookup.lookupComponent("op.salesmanBean");
        customerBean = ComponentLookup.lookupComponent("op.customerBean");

        operatorInvoices = new ArrayList<OperatorInvoice>();
    }

    public void clearOperatorInvoice() {
        clearInvoiceFilter();
        operatorInvoice = new OperatorInvoice();
        operatorInvoice.setInvoiceDate(new Date());
        invoiceButtonsDisabled = true;
    }

    public void searchInvoices() {
        try {
            if (salesmanInvoice) {
                operatorInvoiceFilter.setSalesman(salesmanBean.getSalesman());
            } else {
                operatorInvoiceFilter.setUser(customerBean.getCustomer());
                log.info("INVOICES FOR CUSTOMER: " + operatorInvoiceFilter.getUser());
            }

            operatorInvoices = operatorInvoiceDao.getOperatorInvoices(operatorInvoiceFilter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addOperatorInvoice() {
        try {
            if (operatorInvoice.getOperatorInvoiceId() == null) {
                if (salesmanInvoice)
                    operatorInvoice.setSalesman(salesmanBean.getSalesman());
                else
                    operatorInvoice.setUser(customerBean.getCustomer());

                if (invoiceFile != null)
                    operatorInvoice.setFile(invoiceFile.getContents());

                operatorInvoice.setRemoved(false);

                operatorInvoiceDao.saveOperatorInvoice(operatorInvoice);
            } else {
                if (invoiceFile != null)
                    operatorInvoice.setFile(invoiceFile.getContents());

                operatorInvoiceDao.updateOperatorInvoice(operatorInvoice);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        searchInvoices();
        operatorInvoice = new OperatorInvoice();
        invoiceButtonsDisabled = true;

        displayMessage("messages.save.complete");

        // log.info("DODANO FAKTURE!");
    }

    public void calculateGross() {

        BigDecimal netto = operatorInvoice.getAmountNet();
        BigDecimal tax = new BigDecimal(operatorInvoice.getAmountTax().toString().trim().replace("%", ""))
                .divide(BigDecimal.valueOf(100));
        tax = tax.add(BigDecimal.valueOf(1.0));

        if (netto != null && tax != null) {
            log.info("TAX: " + tax);
            BigDecimal gross = netto.multiply(tax);
            gross.setScale(2, RoundingMode.CEILING);
            operatorInvoice.setAmountGross(gross);
        }
    }

    public void removeOperatorInvoice() {
        try {
            operatorInvoiceDao.deleteOperatorInvoice(operatorInvoice);
        } catch (Exception e) {
            e.printStackTrace();
        }

        searchInvoices();
        operatorInvoice = new OperatorInvoice();
        invoiceButtonsDisabled = true;
    }

    private void displayMessage(String key) {
        String message = BundlesUtils.getMessageResourceString("messages", key, null, Locale.getDefault());
        FacesMessages.instance().add(message);
    }

    public void clearInvoices() {
        operatorInvoices = new ArrayList<OperatorInvoice>();
    }

    public void clearInvoiceFilter() {
        operatorInvoiceFilter = new OperatorInvoice();
    }

    public OperatorInvoice getOperatorInvoiceFilter() {
        return operatorInvoiceFilter;
    }

    public void setOperatorInvoiceFilter(OperatorInvoice operatorInvoiceFilter) {
        this.operatorInvoiceFilter = operatorInvoiceFilter;
    }

    public List<OperatorInvoice> getOperatorInvoices() {
        return operatorInvoices;
    }

    public void setOperatorInvoices(List<OperatorInvoice> operatorInvoices) {
        this.operatorInvoices = operatorInvoices;
    }

    public OperatorInvoice getOperatorInvoice() {
        return operatorInvoice;
    }

    public void setOperatorInvoice(OperatorInvoice operatorInvoice) {
        this.operatorInvoice = operatorInvoice;
    }

    public boolean isInvoiceButtonsDisabled() {
        return invoiceButtonsDisabled;
    }

    public void setInvoiceButtonsDisabled(boolean invoiceButtonsDisabled) {
        this.invoiceButtonsDisabled = invoiceButtonsDisabled;
    }

    public void onInvoiceSelect(SelectEvent event) {
        invoiceButtonsDisabled = false;
    }

    public void onInvoiceUnselect(UnselectEvent event) {
        invoiceButtonsDisabled = true;
        operatorInvoice = new OperatorInvoice();
    }

    public UploadedFile getInvoiceFile() {
        return invoiceFile;
    }

    public void setInvoiceFile(UploadedFile invoiceFile) {
        this.invoiceFile = invoiceFile;
    }

    public Boolean getSalesmanInvoice() {
        return salesmanInvoice;
    }

    public void setSalesmanInvoice(Boolean salesmanInvoice) {
        this.salesmanInvoice = salesmanInvoice;
    }

}
