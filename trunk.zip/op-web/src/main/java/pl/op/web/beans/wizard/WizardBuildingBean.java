package pl.op.web.beans.wizard;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.*;
import org.jboss.seam.faces.FacesMessages;

import pl.op.model.contract.Location;
import pl.op.model.stereotype.AcType;
import pl.op.model.stereotype.Building;
import pl.op.model.stereotype.BuildingType;
import pl.op.model.stereotype.HeatingBuildingType;
import pl.op.model.stereotype.HeatingWaterType;
import pl.op.model.stereotype.IsolationBuildingTime;
import pl.op.model.stereotype.WarmBuildingOutside;
import pl.op.model.stereotype.WindowsType;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;

@Name("op.wizardBuildingBean")
@ManagedBean
@Scope(ScopeType.SESSION)
public class WizardBuildingBean implements Serializable {

	private static final long serialVersionUID = 7657279753756327544L;

	private WizardLocationBean wizardLocationBean;

	private List<Location> locationList;
	private Location location;
	private Integer locationId;
	
	private List<IsolationBuildingTime> isolationBuildingTime = new ArrayList<IsolationBuildingTime>();
	private List<WindowsType> windowsType = new ArrayList<WindowsType>();
	private List<WarmBuildingOutside> warmBuildingOutside = new ArrayList<WarmBuildingOutside>();
	private List<HeatingBuildingType> heatingBuildingType = new ArrayList<HeatingBuildingType>();
	private List<HeatingWaterType> heatingWaterType = new ArrayList<HeatingWaterType>();
	private List<BuildingType> buildingType = new ArrayList<BuildingType>();
	private List<AcType> acType = new ArrayList<AcType>();

	public WizardBuildingBean() {
		log.info("WizardBuildingBean constructor");
		initialize();
	}

	private Logger log = LoggerFactory.getLogger(WizardBuildingBean.class);

	private void initialize() {
		wizardLocationBean = ComponentLookup
				.lookupComponent("op.wizardLocationBean");
		
		Building building = new Building();
		building.setProperty(true);
		
		location = new Location();
		location.setBuilding(building);
		locationList = wizardLocationBean.getLocationList();
	}

	public void onLocationSelect(AjaxBehaviorEvent ev) {
		log.info("select: " + locationId);
		if (locationId == null) {
			log.info("locationId is null");
			location = new Location();
		} else {
			log.info("locationList: " + locationList.toString());
			for (Location locationItem : locationList) {			
				if (locationId == locationItem.getLocationId()) {                              
					location = locationItem;
					break;
				}
			}
		}
		log.info("Location : " + location.getLocationId());
		if (location.getBuilding() == null){	
                        log.info("select Location empty Builds: ");
			Building building = new Building();
			building.setProperty(true);
			location.setBuilding(building);
		}
	}

	
	public void clearBuilding(){		
		Building building = new Building();
		building.setProperty(true);
		location.setBuilding(building);
	}
	
	public void addBuilding(){
		for (int i = 0; i < locationList.size(); i++) {
			if (locationList.get(i).getLocationId() == location.getLocationId()) {
				locationList.set(i,location);
				displayMessage("messages.save.complete");
				break;
			}
		}
	}

	private void displayMessage(String key) {
		String message = BundlesUtils.getMessageResourceString("messages", key,
				null, Locale.getDefault());
		FacesMessages.instance().add(message);
	}
	
	public List<IsolationBuildingTime> getIsolationBuildingTime() {
		isolationBuildingTime = new ArrayList<IsolationBuildingTime>();

		for (IsolationBuildingTime t : IsolationBuildingTime.values()) {
			t.setLabel(BundlesUtils.getMessageResourceString("messages",
					"isolation.building.time." + t, null, Locale.getDefault()));

			isolationBuildingTime.add(t);
		}

		return isolationBuildingTime;
	}

	public void setIsolationBuildingTime(
			List<IsolationBuildingTime> isolationBuildingTime) {
		this.isolationBuildingTime = isolationBuildingTime;
	}

	public List<WindowsType> getWindowsType() {
		windowsType = new ArrayList<WindowsType>();

		for (WindowsType t : WindowsType.values()) {
			t.setLabel(BundlesUtils.getMessageResourceString("messages",
					"windows.type." + t, null, Locale.getDefault()));

			windowsType.add(t);
		}

		return windowsType;
	}

	public void setWindowsType(List<WindowsType> windowsType) {
		this.windowsType = windowsType;
	}

	public List<WarmBuildingOutside> getWarmBuildingOutside() {
		warmBuildingOutside = new ArrayList<WarmBuildingOutside>();

		for (WarmBuildingOutside t : WarmBuildingOutside.values()) {
			t.setLabel(BundlesUtils.getMessageResourceString("messages",
					"warm.building.outside." + t, null, Locale.getDefault()));

			warmBuildingOutside.add(t);
		}

		return warmBuildingOutside;
	}

	public void setWarmBuildingOutside(
			List<WarmBuildingOutside> warmBuildingOutside) {
		this.warmBuildingOutside = warmBuildingOutside;
	}

	public List<HeatingBuildingType> getHeatingBuildingType() {
		heatingBuildingType = new ArrayList<HeatingBuildingType>();

		for (HeatingBuildingType t : HeatingBuildingType.values()) {
			t.setLabel(BundlesUtils.getMessageResourceString("messages",
					"heating.building.type." + t, null, Locale.getDefault()));

			heatingBuildingType.add(t);
		}

		return heatingBuildingType;
	}

	public void setHeatingBuildingType(
			List<HeatingBuildingType> heatingBuildingType) {
		this.heatingBuildingType = heatingBuildingType;
	}

	public List<HeatingWaterType> getHeatingWaterType() {
		heatingWaterType = new ArrayList<HeatingWaterType>();

		for (HeatingWaterType t : HeatingWaterType.values()) {
			t.setLabel(BundlesUtils.getMessageResourceString("messages",
					"heating.water.type." + t, null, Locale.getDefault()));

			heatingWaterType.add(t);
		}

		return heatingWaterType;
	}

	public void setHeatingWaterType(List<HeatingWaterType> heatingWaterType) {
		this.heatingWaterType = heatingWaterType;
	}

	public List<BuildingType> getBuildingType() {
		buildingType = new ArrayList<BuildingType>();

		for (BuildingType t : BuildingType.values()) {
			t.setLabel(BundlesUtils.getMessageResourceString("messages",
					"building.type." + t, null, Locale.getDefault()));

			buildingType.add(t);
		}

		return buildingType;
	}

	public void setBuildingType(List<BuildingType> buildingType) {
		this.buildingType = buildingType;
	}

	public List<AcType> getAcType() {
		acType = new ArrayList<AcType>();

		for (AcType t : AcType.values()) {
			t.setLabel(BundlesUtils.getMessageResourceString("messages",
					"ac.type." + t, null, Locale.getDefault()));

			acType.add(t);
		}

		return acType;
	}

	public void setAcType(List<AcType> acType) {
		this.acType = acType;
	}

	public List<Location> getLocationList() {
		return locationList;
	}

	public void setLocationList(List<Location> locationList) {
		this.locationList = locationList;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public Integer getLocationId() {
		if (locationList.size() > 0){
			if(locationId == null){
				locationId = locationList.get(0).getLocationId();
				location = locationList.get(0);
			}
		}

		return locationId;
	}

	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}


}