package pl.op.web.beans;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.op.dao.AuctionDao;
import pl.op.model.auction.Auction;
import pl.op.model.comment.File;
import pl.op.model.user.UserApp;
import pl.op.rating.RatingUtil;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class HomeBean.
 */
@Name("op.homeBean")
@Scope(ScopeType.SESSION)
public class HomeBean implements Serializable {

	private static final long serialVersionUID = 7816743076622929715L;
	
	private Logger log = LoggerFactory.getLogger(HomeBean.class);

	private UserApp userApp;
	
	private AuctionDao auctionDao;
        

        
     
	public HomeBean() {
		log.info("HomeBean::HomeBean");
		initialize();
	}

	/**
	 * Initialize.
	 */
	public void initialize() {
		log.info("HomeBean::initialize");
		auctionDao = GuiceSingleton.getInstance().getInstance(AuctionDao.class);
	}

	/**
	 * Counts the saving value.
	 *
	 * @return the double
	 */
	public Integer counterSaving() {
                log.info("HomeBean::counterSaving");
		double resultDouble = Double.valueOf(RatingUtil.ZERO_INIT);
		int result = (int)resultDouble;
		
		try {                        
                        List<Auction> auctionss =  auctionDao.getFinishedAuctions();
                        
                        log.info("HomeBean::getFinishedAuctions" + auctionss.size());
			resultDouble = auctionDao.getCounterSaving();
			log.info(String.valueOf(resultDouble));
                        result = (int)resultDouble;

			if (result == 0) {
				result = 0;
			}

		} catch (Exception e) {
			log.error("EXCEPTION:", e);
		}
		log.info("counterSaving = " + result);

		return result;
	}
	
	public UserApp getUserApp() {
		return userApp;
	}

	public void setUserApp(UserApp userApp) {
		this.userApp = userApp;
	}
}