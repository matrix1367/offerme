package pl.op.web.beans.bonus;

import java.io.Serializable;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.commons.io.FilenameUtils;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.EventDao;
import pl.op.dao.PointsRulesDao;
import pl.op.dao.UserPointsDao;
import pl.op.model.bonus.Event;
import pl.op.model.bonus.PointsRules;
import pl.op.model.bonus.UserPoints;
import pl.op.model.user.UserApp;
import pl.op.web.beans.AdminBean;
import pl.op.web.beans.dashboard.DashboardBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;
import pl.op.web.service.BonusService;

@Name("op.pointsBean")
@Scope(ScopeType.SESSION)
public class PointsBean implements Serializable {

    private static final long serialVersionUID = 9123356626462737390L;

    private Logger log = LoggerFactory.getLogger(PointsBean.class);

    private EventDao eventDao;
    private PointsRulesDao pointsRulesDao;
    private UserPointsDao userPointsDao;

    private UserApp userApp;
    private UserPoints userPoints;
    private List<UserPoints> userPointsBuyList;

    private PointsRules pointsRules;
    private PointsRules selectedBonus;
    private List<PointsRules> bonusList;
    private List<PointsRules> bonusFiltered;

    private Integer totalPoints;

    public PointsBean() {
        log.info("PointsBean Constructor");
        initialize();
    }

    private void initialize() {

        eventDao = GuiceSingleton.getInstance().getInstance(EventDao.class);
        pointsRulesDao = GuiceSingleton.getInstance().getInstance(PointsRulesDao.class);
        userPointsDao = GuiceSingleton.getInstance().getInstance(UserPointsDao.class);

    }

    private void calcTotalPoints() {

        try {
            Integer total = 0;
            List<UserPoints> allUserPoints = userPointsDao.getUserPointsByUserApp(userApp);
            for(UserPoints userPoint : allUserPoints) {
                if(userPoint.getIsGranted()) {
                    total += userPoint.getPointsRules().getPointsAmount();
                }
            }
            setTotalPoints(total);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void prepareBonusList() {

        try {
            if(userApp.getIsCompany()) {
                setBonusList(pointsRulesDao.getBonusRulesByUser(userApp));
            } else {
                setBonusList(pointsRulesDao.getBonusRulesActive());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void prepareMyBuyList() {

        try {
            if(bonusList != null && !bonusList.isEmpty()) {
                setUserPointsBuyList(userPointsDao.getUserPointsByUserAppIsBuy(bonusList, userApp.getUserId()));
            } else {
                setUserPointsBuyList(new ArrayList<UserPoints>());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void displayMessage(String id, String key) {
        String message = BundlesUtils.getMessageResourceString("messages", key, null, Locale.getDefault());
        FacesContext context = FacesContext.getCurrentInstance();
        FacesMessage facesMessage = new FacesMessage(message);
        context.addMessage(id, facesMessage);
    }

    public void bonusDetails() {
        setPointsRules(selectedBonus);
    }

    public void bonusBuy() {
        setPointsRules(selectedBonus);
    }

    public void bonusBuyAccept() {

        UserPoints userPoints = new UserPoints();
        if(pointsRules.getIsAccepted()) {
            userPoints.setIsGranted(true);
        } else {
            userPoints.setIsGranted(false);
        }
        userPoints.setNoRepeats(1);
        userPoints.setPointsRules(pointsRules);
        userPoints.setUser(userApp);
        userPoints.setUpdatedAt(new Date());
        try {
            userPointsDao.saveUserPoints(userPoints);
            displayMessage("messagesBonus", "messages.pointsRules.buyComplete");

            BonusService.run("payBack", userApp);

            DashboardBean dashboardBean = ComponentLookup.lookupComponent("op.dashboardBean");
            dashboardBean.refreshPointsCounter();

            loadPoints();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public Boolean canBuy(Integer pointsAmount) {

        Boolean canBuy = true;

        if(getTotalPoints() < (pointsAmount * -1)) {
            canBuy = false;
        }

        return canBuy;

    }

    public void addBonus() {
        pointsRules = new PointsRules();
        pointsRules.setIsOncePerDay(false);
        pointsRules.setIsRepeatable(false);
        pointsRules.setIsAccepted(false);
        pointsRules.setIsActive(false);
        pointsRules.setRepeatsNeed(1);
        pointsRules.setPointsAmount(1);
        pointsRules.setUser(userApp);
        pointsRules.setIsDeleted(false);
        pointsRules.setCreatedAt(new Date());
    }

    public void handleFileUpload(FileUploadEvent event) {

        UploadedFile file = event.getFile();
        SecureRandom random = new SecureRandom();
        String randomName = new BigInteger(130, random).toString(32);
        String ext = FilenameUtils.getExtension(file.getFileName());
        String fileName = randomName + '.' + ext;
        if(BonusService.uploadPhoto(file, fileName, ext)) {
            pointsRules.setPhotoLink(fileName);
        }

    }

    public void saveBonus() {
        Event event = null;
        try {
            Integer pointsAmount = pointsRules.getPointsAmount() * -1;
            pointsRules.setPointsAmount(pointsAmount);
            event = eventDao.getEventByCodeName("bonus");
            pointsRules.setEvent(event);
            pointsRulesDao.savePointsRules(pointsRules);
            displayMessage("messagesPointsRules", "messages.pointsRules.addComplete");
            loadPoints();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadPoints() {

        setLoggedUserApp();
        prepareBonusList();
        prepareMyBuyList();
        calcTotalPoints();

        setPointsRules(new PointsRules());

    }

    public void setLoggedUserApp() {
        FacesContext ctx = FacesContext.getCurrentInstance();
        AdminBean adminBean = (AdminBean) ctx.getApplication().getELResolver()
                .getValue(ctx.getELContext(), null, "op.adminBean");

        try {
            setUserApp(adminBean.getUserLog());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public UserApp getUserApp() {
        return userApp;
    }

    public void setUserApp(UserApp userApp) {
        this.userApp = userApp;
    }

    public UserPoints getUserPoints() {
        return userPoints;
    }

    public void setUserPoints(UserPoints userPoints) {
        this.userPoints = userPoints;
    }

    public PointsRules getPointsRules() {
        return pointsRules;
    }

    public void setPointsRules(PointsRules pointsRules) {
        this.pointsRules = pointsRules;
    }

    public List<PointsRules> getBonusList() {
        return bonusList;
    }

    public void setBonusList(List<PointsRules> bonusList) {
        this.bonusList = bonusList;
    }

    public List<PointsRules> getBonusFiltered() {
        return bonusFiltered;
    }

    public void setBonusFiltered(List<PointsRules> bonusFiltered) {
        this.bonusFiltered = bonusFiltered;
    }

    public Integer getTotalPoints() {
        return totalPoints;
    }

    public void setTotalPoints(Integer totalPoints) {
        this.totalPoints = totalPoints;
    }

    public PointsRules getSelectedBonus() {
        return selectedBonus;
    }

    public void setSelectedBonus(PointsRules selectedBonus) {
        this.selectedBonus = selectedBonus;
    }

    public List<UserPoints> getUserPointsBuyList() {
        return userPointsBuyList;
    }

    public void setUserPointsBuyList(List<UserPoints> userPointsBuyList) {
        this.userPointsBuyList = userPointsBuyList;
    }

}