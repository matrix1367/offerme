package pl.op.web.common;

import javax.faces.context.FacesContext;

public final class ComponentLookup {
	private ComponentLookup(){}
	
	public static  <T> T lookupComponent(String name){
		FacesContext ctx = FacesContext.getCurrentInstance();
		
		@SuppressWarnings("unchecked")
		T bean = (T) ctx.getApplication().getELResolver().getValue(ctx.getELContext(), null, name);
		return 	bean;
		
	}
}
