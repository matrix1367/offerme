package pl.op.web.comparator;

import java.util.Comparator;

import pl.op.model.auction.PriceComponentValue;

public class PriceComponentComparator implements Comparator<PriceComponentValue> {

    @Override
    public int compare(PriceComponentValue pcv, PriceComponentValue pcv2) {
        if(pcv.getPriceComponent().isConstant()) {
            return 1;
        }

        return 0;
    }
}
