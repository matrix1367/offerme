package pl.op.web.beans.dictionary;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Synchronized;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AreaDao;
import pl.op.dao.CityDao;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class CityBean. This class manages the cities of the country. Can
 * add/edit/delete data from database table named "tb_city".
 */
@Name("op.cityBean")
@Scope(ScopeType.SESSION)
@Synchronized(timeout = 100000)
public class CityBean implements Serializable {

	private static final long serialVersionUID = 4089977328308014054L;

	/** The area bean. */
	@In(value = "op.areaBean")
	AreaBean areaBean;

	private Logger log = LoggerFactory.getLogger(CityBean.class);

	private List<City> citiesList;
	private City newCity;
	private City selectedCity;
	private City filterCity;

	private boolean edit;
	private boolean disableShow = true;
	private boolean disableEdit = true;
	private boolean disableRemove = true;

	private CityDao cityDao;
	private AreaDao areaDao;

	public CityBean() {
		log.info("CityBean constructor");
		initialize();
	}

	/**
	 * Initialize the CityBean.
	 */
	private void initialize() {
		notAvailableAction();
		cityDao = GuiceSingleton.getInstance().getInstance(CityDao.class);
		areaDao = GuiceSingleton.getInstance().getInstance(AreaDao.class);

		citiesList = new ArrayList<City>();
		filterCity = new City();
		filterCity.setArea(new Area());
	}

	/**
	 * Downloads cities from database and prepares list for display.
	 */
	public void refreshCitiesList() {
		filterCity = new City();
		filterCity.setArea(new Area());
		try {
			//citiesList = cityDao.getCitiesList();
                        //optymailzacja wczytywania slownikow
		} catch (Exception e) {
			log.error("error while getting cities: ", e);
		}
	}

	/**
	 * Prepares the data for XHTML template to add new City
	 * 
	 * @return the string
	 */
	public String addCity() {
		edit = false;
		selectedCity = new City();
		newCity = new City();
		newCity.setArea(new Area());
		refreshCitiesList();
		return "cities";
	}

	/**
	 * Cancel add city.
	 * 
	 * @return the string
	 */
	public String cancelAddCity() {
		notAvailableAction();
		refreshCitiesList();
		return "dictionaries";
	}

	/**
	 * Saves city defined in XHTML template.
	 * 
	 * @return the string
	 */
	public String saveCity() {
		Area area = null;
		try {
			area = areaDao.getAreaById(newCity.getArea().getAreaId());
		} catch (Exception e) {
			log.error(
					"Error while getAreaById(newCity.getArea().getAreaId()): ",
					e);
		}
		try {
			if (edit) {
				selectedCity.setArea(area);
				cityDao.updateCity(selectedCity);
			} else {
				newCity.setArea(area);
				cityDao.saveCity(newCity);
			}
		} catch (Exception e) {
			log.error("Error while saveCity: ", e);
		}
		areaBean.refreshAreasList();
		refreshCitiesList();
		return "dictionaries";
	}

	/**
	 * Deletes city form database.
	 */
	public void deleteCity() {
		try {
			cityDao.deleteCity(selectedCity);
		} catch (Exception e) {
			log.error("Error while deleteCity: ", e);
		}
		refreshCitiesList();
		notAvailableAction();
	}

	/**
	 * Edits the city selected from XHTML template
	 * 
	 * @return the string
	 */
	public String editCity() {
		edit = true;
		newCity = selectedCity;
		areaBean.refreshAreasList();
		return "cities";
	}

	/**
	 * Search city by name in database.
	 */
	public void searchCity() {
		try {
			citiesList = cityDao.getCitiesByName(filterCity.getCityName());
		} catch (Exception e) {
			log.error("Error while searchCity: ", e);
		}
	}

	/**
	 * Cleans city search.
	 */
	public void cleanCitySearch() {
		filterCity = new City();
		filterCity.setArea(new Area());

		try {
			citiesList = cityDao.getCitiesList();
		} catch (Exception e) {
			log.error("Error while searchCity: ", e);
		}
	}

	/**
	 * On row select dictionaries list.
	 * 
	 * @param event
	 *            the event
	 */
	public void onRowSelectDictionariesList(SelectEvent event) {
		availableAction();
	}

	/**
	 * On row unselect dictionaries list.
	 * 
	 * @param event
	 *            the event
	 */
	public void onRowUnselectDictionariesList(UnselectEvent event) {
		notAvailableAction();
	}

	/**
	 * Activates if action on selected element is available.
	 */
	public void availableAction() {
		disableShow = false;
		disableEdit = false;
		disableRemove = false;
	}

	/**
	 * Activates if action on selected element is not available.
	 */
	public void notAvailableAction() {
		selectedCity = new City();

		disableShow = true;
		disableEdit = true;
		disableRemove = true;
	}

	public City getNewCity() {
		return newCity;
	}

	public void setNewCity(City newCity) {
		this.newCity = newCity;
	}

	public City getFilterCity() {
		return filterCity;
	}

	public void setFilterCity(City filterCity) {
		this.filterCity = filterCity;
	}

	public List<City> getCitiesList() {
		return citiesList;
	}

	public void setCitiesList(List<City> citiesList) {
		this.citiesList = citiesList;
	}

	public City getSelectedCity() {
		return selectedCity;
	}

	public void setSelectedCity(City selectedCity) {
		this.selectedCity = selectedCity;
	}

	public boolean isDisableShow() {
		return disableShow;
	}

	public void setDisableShow(boolean disableShow) {
		this.disableShow = disableShow;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}
        
        public boolean getDisableEdit() {
            return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}
        
	public boolean getDisableRemove() {
		return disableRemove;
	}        

	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}
}
