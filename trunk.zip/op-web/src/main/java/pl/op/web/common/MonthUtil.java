package pl.op.web.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import pl.op.model.dict.Month;



public class MonthUtil {
	public static List<Month> getMonths(){
		List<Month> months = new ArrayList<Month>();

		Month month1 = new Month();
		month1.setNumberofMonth(1);
		month1.setName(BundlesUtils.getMessageResourceString("messages", "ppe.contract.power.contract.months.jan", null, Locale.getDefault()));
		months.add(month1);
		
		Month month2 = new Month();
		month2.setNumberofMonth(2);
		month2.setName(BundlesUtils.getMessageResourceString("messages", "ppe.contract.power.contract.months.feb", null, Locale.getDefault()));
		months.add(month2);
		
		Month month3 = new Month();
		month3.setNumberofMonth(3);
		month3.setName(BundlesUtils.getMessageResourceString("messages", "ppe.contract.power.contract.months.mar", null, Locale.getDefault()));
		months.add(month3);
		
		Month month4 = new Month();
		month4.setNumberofMonth(4);
		month4.setName(BundlesUtils.getMessageResourceString("messages", "ppe.contract.power.contract.months.apr", null, Locale.getDefault()));
		months.add(month4);
		
		Month month5 = new Month();
		month5.setNumberofMonth(5);
		month5.setName(BundlesUtils.getMessageResourceString("messages", "ppe.contract.power.contract.months.may", null, Locale.getDefault()));
		months.add(month5);
		
		Month month6 = new Month();
		month6.setNumberofMonth(6);
		month6.setName(BundlesUtils.getMessageResourceString("messages", "ppe.contract.power.contract.months.jun", null, Locale.getDefault()));
		months.add(month6);
		
		Month month7 = new Month();
		month7.setNumberofMonth(7);
		month7.setName(BundlesUtils.getMessageResourceString("messages", "ppe.contract.power.contract.months.jul", null, Locale.getDefault()));
		months.add(month7);
		
		Month month8 = new Month();
		month8.setNumberofMonth(8);
		month8.setName(BundlesUtils.getMessageResourceString("messages", "ppe.contract.power.contract.months.aug", null, Locale.getDefault()));
		months.add(month8);
		
		Month month9 = new Month();
		month9.setNumberofMonth(9);
		month9.setName(BundlesUtils.getMessageResourceString("messages", "ppe.contract.power.contract.months.sep", null, Locale.getDefault()));
		months.add(month9);
		
		Month month10 = new Month();
		month10.setNumberofMonth(10);
		month10.setName(BundlesUtils.getMessageResourceString("messages", "ppe.contract.power.contract.months.oct", null, Locale.getDefault()));
		months.add(month10);
		
		Month month11 = new Month();
		month11.setNumberofMonth(11);
		month11.setName(BundlesUtils.getMessageResourceString("messages", "ppe.contract.power.contract.months.nov", null, Locale.getDefault()));
		months.add(month11);
		
		Month month12 = new Month();
		month12.setNumberofMonth(12);
		month12.setName(BundlesUtils.getMessageResourceString("messages", "ppe.contract.power.contract.months.dec", null, Locale.getDefault()));
		months.add(month12);
		
		return months;
	}
}