package pl.op.web.beans.user;

import java.util.Locale;
import java.util.UUID;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.UserDao;
import pl.op.model.user.UserApp;
import pl.op.web.beans.MailBean;
import pl.op.web.common.ActivateUtil;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.common.LoginUtil;
import pl.op.web.listener.GuiceSingleton;

@Name("op.sendEmailBean")
@Scope(ScopeType.SESSION)
public class SendEmailBean {
    
    public final String SERVER_URL = "serverURL";
    private String activationUrl = BundlesUtils.getMessageResourceString("seam", "activation.url", null,
            Locale.getDefault()).trim();

    private Logger log = LoggerFactory.getLogger(SendEmailBean.class);
    private UserApp userRegistration;
    private Boolean resetNonActiveUser;
    private UserDao bdUser;
    private FacesContext facesContext;
    private ExternalContext ectx;
    private String login;
    private UserApp userApp;
    private String passwordCode;
    private String activationCode;

    public SendEmailBean() {
        initialize();
    }

    private void initialize() {
        bdUser = GuiceSingleton.getInstance().getInstance(UserDao.class);
        userRegistration = new UserApp();
        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();
    }

    public String remindAction() {
        userRegistration = new UserApp();
        log.info("remind password action...");
        resetNonActiveUser = false;
        return "remind";
    }

    public String backToLoginAction() {
        log.info("back to login action...");
        return "login";
    }
    
    
  
    public String sendRemindEmailAction() {
        boolean isMailSent = false;
        resetNonActiveUser = false;
        log.info("sent email with password reset");

        boolean userExist;

        try {
            userExist = bdUser.checkLocalUserExist(userRegistration.getLogin());
        } catch (Exception e1) {
            log.error(e1.getMessage(), e1);

            String loginError = BundlesUtils.getMessageResourceString("messages", "login_exist_error", null,
                    ectx.getRequestLocale());
            FacesMessages.instance().add(loginError);
            return "";

        }

        if(userExist) {
            try {
                userApp = bdUser.getUserByLogin(userRegistration.getLogin());
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                String loginError = BundlesUtils.getMessageResourceString("messages", "user_data_error", null,
                        ectx.getRequestLocale());
                FacesMessages.instance().add(loginError);
                return "";
            }

            if(!userApp.getActive()) {
                log.info("!userApp.getActiv");
                resetNonActiveUser = true;   
                String loginError = BundlesUtils.getMessageResourceString("messages", "message.not.yet.active", null,
                        ectx.getRequestLocale());
                FacesMessages.instance().add(loginError);
                 sendFromResetActiveCode();
                return "";
            }

            MailBean mailBean = ComponentLookup.lookupComponent("op.mailBean");
            this.passwordCode = UUID.randomUUID().toString().substring(0, 8);

            try {
                mailBean.sendReminderEmail(userApp, passwordCode);
                isMailSent = true;
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                isMailSent = false;
                String mailFail = BundlesUtils.getMessageResourceString("messages", "user.reminder.mail.fail", null,
                        ectx.getRequestLocale());
                FacesMessages.instance().add(mailFail);
                return "";
            }

        } else {
            String userNotExist = BundlesUtils.getMessageResourceString("messages", "user.not.exist", null,
                    ectx.getRequestLocale());
            FacesMessages.instance().add(userNotExist);
            return "";
        }

        String password = null;
        if(isMailSent) {
            try {
                password = LoginUtil.generatePasswordHash(this.passwordCode, userRegistration.getLogin());
                userApp.setPassword(password);
                bdUser.updatePassword(userApp);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                String message = BundlesUtils.getMessageResourceString("messages", "change.password.error", null,
                        ectx.getRequestLocale());
                FacesMessages.instance().add(message);
                return "";
            }
        }

        return "password";
    }

    public String sendFromResetActiveCode() {

        resetNonActiveUser = false;

        return sendAgainActivationCode(userRegistration.getLogin(), "");
    }

    public String sendFromActivationCode() {
        log.info("Wybrane....." + login);
        return sendAgainActivationCode(login, "activateConfirm");
    }

    public String sendAgainActivationCode(String login, String key) {
        boolean exist;
        UserApp user;
        
        activationUrl = System.getProperty(SERVER_URL) + "/op-web";
        if (activationUrl == null || activationUrl.isEmpty())
			activationUrl = BundlesUtils.getMessageResourceString("seam",
					"activation.url", null, Locale.getDefault()).trim();
        // sprawdzenie czy ponownie istnieje user
        try {
            exist = bdUser.checkLocalUserExist(login);
        } catch (Exception e1) {
            log.error(e1.getMessage(), e1);

            String loginError = BundlesUtils.getMessageResourceString("messages", "login_exist_error", null,
                    ectx.getRequestLocale());
            FacesMessages.instance().add(loginError);
            return key;

        }

        // login istnieje sprawdzamy czy aktywny
        if(exist) {
            try {
                user = bdUser.getUserByLogin(login);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                String loginError = BundlesUtils.getMessageResourceString("messages", "user_data_error", null,
                        ectx.getRequestLocale());
                FacesMessages.instance().add(loginError);
                return key;
            }

            String oldKey;
            // jezeli nieaktywny to wysylamy ponownie linik aktywacyjny
            if(!user.getActive()) {

                oldKey = user.getActivateKey();
                log.info("User old activation code" + user.getActivateKey());

                user.setActivateKey(ActivateUtil.getActivationCode(user.getLogin()));

                this.activationCode = ActivateUtil.getActivationCode(user.getLogin());

                log.info("user activation code: " + activationCode);
                log.info("user login: " + user.getLogin());

                // aktualuzjemy kod aktywacyjny w bazie
                try {
                    bdUser.updateActivationCode(user);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                    String addUserFail = BundlesUtils.getMessageResourceString("messages", "user.register.mail.fail",
                            null, ectx.getRequestLocale());
                    FacesMessages.instance().add(addUserFail);

                    return key;
                }

                try {

                    userRegistration.setLogin(user.getLogin());
                    userRegistration.setActivateKey(user.getActivateKey());

                    sentEmail();
                } catch (Exception e) {

                    log.error(e.getMessage(), e);
                    String mailFail = BundlesUtils.getMessageResourceString("messages", "user.register.mail.fail",
                            null, ectx.getRequestLocale());

                    FacesMessages.instance().add(mailFail);

                    // w przypadku nie wyslania maila usatwiamy stary kod
                    // aktywacyjny
                    user.setActivateKey(oldKey);

                    try {
                        bdUser.updateActivationCode(user);
                    } catch (Exception e1) {
                        log.error(e1.getMessage(), e1);
                        String addUserFail = BundlesUtils.getMessageResourceString("messages", "add_error", null,
                                ectx.getRequestLocale());
                        FacesMessages.instance().add(addUserFail);
                        return key;
                    }

                    return key;
                }

                String newKey = BundlesUtils.getMessageResourceString("messages", "new.active.key", null,
                        ectx.getRequestLocale());
                FacesMessages.instance().add(newKey);
                return key;
            }

        } else {
            String userNotExist = BundlesUtils.getMessageResourceString("messages", "user.not.exist", null,
                    ectx.getRequestLocale());
            FacesMessages.instance().add(userNotExist);
        }

        return key;
    }

    public void sentEmail() throws Exception {

        MailBean mailBean = ComponentLookup.lookupComponent("op.mailBean");

        log.info("sent email confirmation");
        log.info(activationUrl + "/activate.seam?code=" + userRegistration.getActivateKey() + "&login="
                + userRegistration.getLogin());

        try {
            log.info("getting template...");
            //if (activationUrl.indexOf("op-web") != -1) activationUrl+= "op-web";
            mailBean.sendRegistrationEmail(userRegistration,
                    activationUrl + "/activate.seam?code=" + userRegistration.getActivateKey() + "&login="
                            + userRegistration.getLogin());

        } catch (Exception e) {
            log.error("EXCEPTION:", e);
            throw new Exception();
        }
    }

    public void sendWizardEmail() throws Exception {

        MailBean mailBean = ComponentLookup.lookupComponent("op.mailBean");

        log.info("sent wizard registration");

        try {
            log.info("getting template...");
            mailBean.sendWizardRegistrationEmail(userApp);

        } catch (Exception e) {
            log.error("Problem while send wizard email: ", e);
        }
    }
    
    public void sendWizardEmailUserHome() throws Exception {

        MailBean mailBean = ComponentLookup.lookupComponent("op.mailBean");

        log.info("sent wizard registration");

        try {
            log.info("getting template...");
            mailBean.sendWizardRegistrationEmailUserHome(userApp);

        } catch (Exception e) {
            log.error("Problem while send wizard email: ", e);
        }
    }

    public Boolean getResetNonActiveUser() {
        return resetNonActiveUser;
    }

    public void setResetNonActiveUser(Boolean resetNonActiveUser) {
        this.resetNonActiveUser = resetNonActiveUser;
    }

    public UserApp getUserRegistration() {
        return userRegistration;
    }

    public void setUserRegistration(UserApp userRegistration) {
        this.userRegistration = userRegistration;
    }

    public String getActivationUrl() {
        return activationUrl;
    }

    public void setActivationUrl(String activationUrl) {
        this.activationUrl = activationUrl;
    }

    public String getActivationCode() {
        return activationCode;
    }

    public void setActivationCode(String activationCode) {
        this.activationCode = activationCode;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPasswordCode() {
        return passwordCode;
    }

    public void setPasswordCode(String passwordCode) {
        this.passwordCode = passwordCode;
    }

    public void setUserApp(UserApp userApp) {
        this.userApp = userApp;
    }
}
