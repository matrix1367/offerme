package pl.op.web.common;

import static org.jboss.seam.annotations.Install.BUILT_IN;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.faces.context.FacesContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Install;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.PerNestedConversation;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.intercept.BypassInterceptors;
import org.jboss.seam.navigation.Pages;

import pl.op.model.user.UserApp;
import pl.op.web.beans.AdminBean;

@Name("op.redirector")
@BypassInterceptors
@Scope(ScopeType.SESSION)
@Install(precedence = BUILT_IN, classDependencies = "javax.faces.context.FacesContext")
@PerNestedConversation
public class Redirector {

	private Logger log = LoggerFactory.getLogger(Redirector.class);

	String viewId;
	String defaultViewId = BundlesUtils.getMessageResourceString("seam",
			"default.viewId", null, Locale.getDefault()).trim();

	private Map<String, Object> parameters = new HashMap<String, Object>();
	private AdminBean adminBean;
	
	public void captureCurrentView() {
		FacesContext context = FacesContext.getCurrentInstance();

		if (context == null)
			return;

		parameters
				.putAll(context.getExternalContext().getRequestParameterMap());
		parameters.putAll(Pages.instance().getStringValuesFromPageContext(
				context));

		viewId = Pages.getViewId(context);

		log.debug("Redirector capture: " + viewId);

	}

	public String condition() {

		log.debug("Redirector condition: " + viewId);

		adminBean = ComponentLookup.lookupComponent("op.adminBean");
		
		UserApp userLog = adminBean.getUserLog();
		
		if(userLog.getFirstLogin() != null && userLog.getFirstLogin())
			return "/pages/wizard/wizardSimple.xhtml";
		
		if (viewId != null && !viewId.isEmpty())
			return viewId;

		log.debug("Redirector view id null...");
		return defaultViewId;
	}

}
