package pl.op.web.common;

public class ChartUtil {
	public static String getFileName(String url){		
		String file = url.substring(url.lastIndexOf('/')+1, url.lastIndexOf('.'));
		return file;
	}
}