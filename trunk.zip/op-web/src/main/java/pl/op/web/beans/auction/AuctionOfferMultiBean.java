package pl.op.web.beans.auction;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AuctionDao;
import pl.op.dao.CloudDao;
import pl.op.dao.PPEDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.auction.AuctionStatus;
import pl.op.model.auction.PriceComponent;
import pl.op.model.auction.PriceComponentValue;
import pl.op.model.auction.VolumeProfitability;
import pl.op.model.cloud.Cloud;
import pl.op.model.dict.Tariff;
import pl.op.model.salesman.Salesman;
import pl.op.model.user.UserApp;
import pl.op.util.MessageUtil;
import pl.op.web.beans.AdminBean;
import pl.op.web.beans.cloud.SalesmanCloudBean;
import pl.op.web.beans.dashboard.DashboardBean;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;
import pl.op.web.service.BonusService;

/**
 * The Class AuctionOfferBean.
 */
@Name("op.auctionOfferMultiBean")
@Scope(ScopeType.SESSION)
public class AuctionOfferMultiBean {

    private Logger log = LoggerFactory.getLogger(AuctionOfferBean.class);

    private AuctionDao auctionDao;
    private CloudDao cloudDao;
    private PPEDao ppeDao;

    private Cloud currentCloud;
    private Auction auction1;
    private Auction auction2;
    private Auction auction3;

    private AuctionOffer auctionOffer1;
    private AuctionOffer auctionOffer2;
    private AuctionOffer auctionOffer3;

    private Boolean addAuction1;
    private Boolean addAuction2;
    private Boolean addAuction3;

    private FacesContext facesContext;
    private ExternalContext ectx;

    private AuctionOffer auctionOffer;
    private Integer fillMeasure;

    private List<VolumeProfitability> volumeProfitabilities;
    private List<Auction> auctionsForCloud;
    private Date minBeginContractDate;

    @In(value = "#{op.adminBean}", scope = ScopeType.SESSION, required = true)
    private AdminBean adminBean;

    /**
     * Instantiates a new auction offer bean.
     */
    public AuctionOfferMultiBean() {
        log.info("AuctionOfferMultiBean constructor");
        initialize();
    }

    /**
     * Initialize.
     */
    public void initialize() {
        auctionDao = GuiceSingleton.getInstance().getInstance(AuctionDao.class);
        cloudDao = GuiceSingleton.getInstance().getInstance(CloudDao.class);
        ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);

        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();

        addAuction1 = true;
        addAuction2 = true;
        addAuction3 = true;

        //  clearAuctionOffer();
    }

    /**
     * Prepare auctions for cloud.
     */
    public void prepareAuctionsForCloud() {

        SalesmanCloudBean salesmanCloudBean = ComponentLookup.lookupComponent("op.salesmanCloudBean");

        auctionsForCloud = salesmanCloudBean.getSelectedCloud().getAuctions();
    }

//    /**
//     * Initialize auction offer.
//     * 
//     * @param auction
//     *            the auction
//     * @param salesman
//     *            the salesman
//     */
//    public void initializeAuctionOffer(Auction auction, Salesman salesman) {
//        auctionOffer = new AuctionOffer();
//        auctionOffer.setAuction(auction);
//        auctionOffer.setSalesman(salesman);
//
//        initializePriceComponents();
//        countFillMeasure();
//
//        prepareAuctionsForCloud();
//    }
    public void initializeAuctionOffer(Cloud cloud, Salesman salesman) {
        currentCloud = cloud;

        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.set(Calendar.DATE, 1);
        c.add(Calendar.MONTH, 1);

        Calendar c2 = Calendar.getInstance();
        c2.setTime(c.getTime());
        c2.add(Calendar.YEAR, 1);

        Date nextMonthtBeginContractDate = c.getTime();
        Date endAuction1 = c2.getTime();
        c2.add(Calendar.YEAR, 1);

        Date endAuction2 = c2.getTime();
        c2.add(Calendar.YEAR, 1);

        Date endAuction3 = c2.getTime();

        auction1 = new Auction();
        auction1.setCloud(currentCloud);
        auction1.setSalesmans(new ArrayList<Salesman>());
        auction1.getSalesmans().add(salesman);
        auction1.setStatus(AuctionStatus.INPROGRESS);
        auction1.setBeginContractDate(nextMonthtBeginContractDate);
        auction1.setEndContractDate(endAuction1);

        auction2 = new Auction();
        auction2.setCloud(currentCloud);
        auction2.setSalesmans(new ArrayList<Salesman>());
        auction2.getSalesmans().add(salesman);
        auction2.setStatus(AuctionStatus.INPROGRESS);
        auction2.setBeginContractDate(nextMonthtBeginContractDate);
        auction2.setEndContractDate(endAuction2);

        auction3 = new Auction();
        auction3.setCloud(currentCloud);
        auction3.setSalesmans(new ArrayList<Salesman>());
        auction3.getSalesmans().add(salesman);
        auction3.setStatus(AuctionStatus.INPROGRESS);
        auction3.setBeginContractDate(nextMonthtBeginContractDate);
        auction3.setEndContractDate(endAuction3);

        auctionOffer1 = new AuctionOffer();
        auctionOffer1.setAuction(auction1);
        auctionOffer1.setSalesman(salesman);

        auctionOffer2 = new AuctionOffer();
        auctionOffer2.setAuction(auction2);
        auctionOffer2.setSalesman(salesman);

        auctionOffer3 = new AuctionOffer();
        auctionOffer3.setAuction(auction3);
        auctionOffer3.setSalesman(salesman);

        initializePriceComponents(auctionOffer1);
        initializePriceComponents(auctionOffer2);
        initializePriceComponents(auctionOffer3);

    }

//    /**
//     * Initialize bid auction offer.
//     * 
//     * @param auction
//     *            the auction
//     */
//    public void initializeBidAuctionOffer(Auction auction) {
//        log.info("initializeBidAuctionOffer: #" + auction.getAuctionId());
//
//        SalesmanCloudBean bean = ComponentLookup.lookupComponent("op.salesmanCloudBean");
//        auction.setCloud(bean.getSelectedCloud());
//
//        initializeAuctionOffer(auction, adminBean.getUserLog().getSalesman());
//    }
//    /**
//     * Initialize new auction offer.
//     */
//    public void initializeNewAuctionOffer() {
//
//        SalesmanCloudBean salesmanCloudBean = ComponentLookup.lookupComponent("op.salesmanCloudBean");
//
//        Auction auction = new Auction();
//        auction.setCloud(salesmanCloudBean.getSelectedCloud());
//        auction.setSalesmans(new ArrayList<Salesman>());
//        auction.getSalesmans().add(adminBean.getUserLog().getSalesman());
//        auction.setStatus(AuctionStatus.INPROGRESS);
//
//        initializeAuctionOffer(auction, adminBean.getUserLog().getSalesman());
//
//    }
    /**
     * Count fill measure.
     */
    private void countFillMeasure() {
        try {
            Integer joined = auctionDao.getJoinedUsers(auctionOffer.getAuction());
            Integer ready = auctionDao.getReadyUsers(auctionOffer.getAuction());

            if (ready == 0) {
                fillMeasure = 0;
            } else {
                fillMeasure = (int) ((double) joined / (double) ready);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//    /**
//     * Clear auction offer.
//     */
//    public void clearAuctionOffer() {
//
//        auctionOffer = new AuctionOffer();
//
//        Auction a = new Auction();
//
//        Cloud c = new Cloud();
//        c.setUsers(new ArrayList<UserApp>());
//
//        Tariff t = new Tariff();
//
//        c.setTariff(t);
//        a.setCloud(c);
//
//        Salesman s = new Salesman();
//
//        auctionOffer.setAuction(a);
//        auctionOffer.setSalesman(s);
//
//        initializePriceComponents();
//        countFillMeasure();
//    }
    /**
     * Clear auction offer2.
     */
    public void clearAuctionOffer2() {
        log.info("clearAuctionOffer2 - start");

        if (!isAuctionExist()) {
            auctionOffer.getAuction().setEndContractDate(null);
            auctionOffer.getAuction().setBeginContractDate(null);
            auctionOffer.getAuction().setPriceGuarantee(null);
            auctionOffer.setIsSalesmanVisible(null);
        }

        for (PriceComponentValue pCv : auctionOffer.getPriceComponentValues()) {
            pCv.setValue(0.0);
        }
        log.info("clearAuctionOffer2 - end");
    }

    /**
     * Ppe count.
     *
     * @return the int
     */
    public int ppeCount() {
        int ppeCount = 0;

        try {
            ppeCount = getPpeCount();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ppeCount;
    }

    /**
     * Gets the ppe count.
     *
     * @return the ppe count
     * @throws Exception the exception
     */
    private Integer getPpeCount() throws Exception {
        if (currentCloud != null) {
            return cloudDao.getPPECount(currentCloud);
        } else {
            return 0;
        }
    }

    /**
     * Count profitability.
     */
    public void countProfitability() {
        try {
            Calendar cal = Calendar.getInstance();
            cal.setTime(new Date());

            int numOfDays = cal.getActualMaximum(Calendar.DAY_OF_YEAR);

            ppeDao.updatePPEStatus();

            volumeProfitabilities = new ArrayList<VolumeProfitability>();
            List<VolumeProfitability> vPl = auctionDao.getVolumeProfitability(auctionOffer.getAuction());

            for (VolumeProfitability vP : vPl) {
                if (volumeProfitabilities.size() > 0
                        && volumeProfitabilities.get(volumeProfitabilities.size() - 1).getType().equals(vP.getType())) {
                    volumeProfitabilities.get(volumeProfitabilities.size() - 1).setValue2(vP.getValue() * numOfDays);
                } else {
                    vP.setValue(vP.getValue() * numOfDays);
                    volumeProfitabilities.add(vP);
                }
            }
        } catch (Exception e) {
            log.error("Problem while count profitability: ", e);
        }
    }

    /**
     * Gets the price component value from actual auction offer.
     *
     * @param auction the auction
     * @return the price component value from actual auction offer
     * @throws Exception the exception
     */
    private List<PriceComponentValue> getPriceComponentValueFromActualAuctionOffer(Auction auction) throws Exception {
        log.info("getPriceComponentValueFromActualAuctionOffer - " + auction.getAuctionId());

        return auctionDao.getOfferPriceComponentValues(auction);
    }

    /**
     * Submit offer.
     *
     * @return the string
     */
    public String submitOffer() {
        try {

            auctionOffer2.getAuction().setPriceGuarantee(auctionOffer1.getAuction().getPriceGuarantee());
            auctionOffer3.getAuction().setPriceGuarantee(auctionOffer1.getAuction().getPriceGuarantee());

            auctionOffer2.getAuction().setProecological(auctionOffer1.getAuction().getProecological());
            auctionOffer3.getAuction().setProecological(auctionOffer1.getAuction().getProecological());

            auctionOffer2.setIsSalesmanVisible(auctionOffer1.getIsSalesmanVisible());
            auctionOffer3.setIsSalesmanVisible(auctionOffer1.getIsSalesmanVisible());


//            log.info(">>> Auction id" + auctionOffer1.getAuction().getAuctionId());
//            log.info(">>> Auction begincontractdate " + auctionOffer1.getAuction().getBeginContractDate());
//            log.info(">>> Auction endcontractdate " + auctionOffer1.getAuction().getEndContractDate());
//            log.info(">>> Auction finishdate " + auctionOffer1.getAuction().getFinishDate());
//            log.info(">>> Auction startdate " + auctionOffer1.getAuction().getStartDate());
//            log.info(">>> Auction status " + auctionOffer1.getAuction().getStatus());
//            log.info(">>> Auction cloudid " + auctionOffer1.getAuction().getCloud().getCloudId());
//            log.info(">>> Auction priceguarantee " + auctionOffer1.getAuction().getPriceGuarantee());
//            log.info(">>> Auction proecological  " + auctionOffer1.getAuction().getProecological());
//            log.info(">>>> AuctionOffer status " + auctionOffer1.getStatus());
//
//            log.info(">>> Auction id" + auctionOffer2.getAuction().getAuctionId());
//            log.info(">>> Auction begincontractdate " + auctionOffer2.getAuction().getBeginContractDate());
//            log.info(">>> Auction endcontractdate " + auctionOffer2.getAuction().getEndContractDate());
//            log.info(">>> Auction finishdate " + auctionOffer2.getAuction().getFinishDate());
//            log.info(">>> Auction startdate " + auctionOffer2.getAuction().getStartDate());
//            log.info(">>> Auction status " + auctionOffer2.getAuction().getStatus());
//            log.info(">>> Auction cloudid " + auctionOffer2.getAuction().getCloud().getCloudId());
//            log.info(">>> Auction priceguarantee " + auctionOffer2.getAuction().getPriceGuarantee());
//            log.info(">>> Auction proecological  " + auctionOffer2.getAuction().getProecological());
//            log.info(">>>> AuctionOffer status " + auctionOffer2.getStatus());
//
//            log.info(">>> Auction id" + auctionOffer3.getAuction().getAuctionId());
//            log.info(">>> Auction begincontractdate " + auctionOffer3.getAuction().getBeginContractDate());
//            log.info(">>> Auction endcontractdate " + auctionOffer3.getAuction().getEndContractDate());
//            log.info(">>> Auction finishdate " + auctionOffer3.getAuction().getFinishDate());
//            log.info(">>> Auction startdate " + auctionOffer3.getAuction().getStartDate());
//            log.info(">>> Auction status " + auctionOffer3.getAuction().getStatus());
//            log.info(">>> Auction cloudid " + auctionOffer3.getAuction().getCloud().getCloudId());
//            log.info(">>> Auction priceguarantee " + auctionOffer3.getAuction().getPriceGuarantee());
//            log.info(">>> Auction proecological  " + auctionOffer3.getAuction().getProecological());
//            log.info(">>>> AuctionOffer status " + auctionOffer3.getStatus());

            if (!isAuctionExist() && addAuction1) {
                if (!isValidAgreementDate(auctionOffer1.getAuction())) {
                    MessageUtil.displayMessageWarn("invalid.agreement.date");
                    return "";
                }
                saveAuction(auctionOffer1);
                saveAuctionOffer(auctionOffer1);
                saveOfferPriceComponent(auctionOffer1);
                 calculateScore(auctionOffer1.getAuction());
            }

            if (!isAuctionExist() && addAuction2) {
                if (!isValidAgreementDate(auctionOffer2.getAuction())) {
                    MessageUtil.displayMessageWarn("invalid.agreement.date");
                    return "";
                }
                saveAuction(auctionOffer2);
                saveAuctionOffer(auctionOffer2);
                saveOfferPriceComponent(auctionOffer2);
                calculateScore(auctionOffer2.getAuction());
            }

            if (!isAuctionExist() && addAuction3) {
                if (!isValidAgreementDate(auctionOffer3.getAuction())) {
                    MessageUtil.displayMessageWarn("invalid.agreement.date");
                    return "";
                }
                saveAuction(auctionOffer3);
                saveAuctionOffer(auctionOffer3);
                saveOfferPriceComponent(auctionOffer3);
                 calculateScore(auctionOffer3.getAuction());
            }

            if (addAuction1 || addAuction2 || addAuction3) {
                BonusService.run("offerAuction", adminBean.getUserLog());
                MessageUtil.displayMessageInfo("offer.add.successfully");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return backToCloud();

    }

    /**
     * Checks if is valid agreement date.
     *
     * @param auction the auction
     * @return true, if is valid agreement date
     */
    private boolean isValidAgreementDate(Auction auction) {
        if (null == auction.getBeginContractDate()) {
            return false;
        }
        if (null == auction.getEndContractDate()) {
            return false;
        }
        if (auction.getBeginContractDate().compareTo(minBeginContractDate) <= 0) {
            return false;
        }
        if (!auction.getEndContractDate().after(auction.getBeginContractDate())) {
            return false;
        }

        return true;
    }

    /**
     * Save auction.
     *
     * @throws Exception the exception
     */
    private void saveAuction(AuctionOffer _auctionOffer) throws Exception {
        _auctionOffer.getAuction().setStartDate(new Date());
        _auctionOffer.getAuction().setFinishDate(getEndOfferDay());

        auctionDao.saveAuction(_auctionOffer.getAuction());

        DashboardBean dashboard = ComponentLookup.lookupComponent("op.dashboardBean");
        dashboard.refreshAuctionCount();
    }

    /**
     * Gets the end offer day.
     *
     * @return the end offer day
     */
    private Date getEndOfferDay() {
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, offerEndDays());

        return c.getTime();
    }

    /**
     * Offer end days.
     *
     * @return the integer
     */
    public Integer offerEndDays() {
        DictionaryBean dictionaryBean = ComponentLookup.lookupComponent("op.dictionaryBean");
        return dictionaryBean.getAuctionDurationDays().intValue();
    }

    /**
     * Checks if is offer better than last.
     *
     * @return true, if is offer better than last
     * @throws Exception the exception
     */
    private boolean isOfferBetterThanLast() throws Exception {
        log.info("isOfferBetterThanLast");

        List<PriceComponentValue> actualOfferPriceComponentValue = getPriceComponentValueFromActualAuctionOffer(auctionOffer
                .getAuction());

        int testOk = 0;

        for (int i = 0; i < actualOfferPriceComponentValue.size(); i++) {
            if (null == auctionOffer.getPriceComponentValues().get(i).getValue()) {
                auctionOffer.getPriceComponentValues().get(i).setValue(0.0);
            }
            if (actualOfferPriceComponentValue.get(i).getValue().doubleValue() < auctionOffer.getPriceComponentValues()
                    .get(i).getValue().doubleValue()) {
                return false;
            }

            if (actualOfferPriceComponentValue.get(i).getValue().doubleValue() > auctionOffer.getPriceComponentValues()
                    .get(i).getValue().doubleValue()) {
                testOk += 2;
            } else {
                testOk++;
            }
        }

        return (testOk > actualOfferPriceComponentValue.size());
    }

    /**
     * Save auction offer.
     *
     * @throws Exception the exception
     */
    private void saveAuctionOffer(AuctionOffer _auctionOffer) throws Exception {
        _auctionOffer.setStatus(AuctionStatus.INPROGRESS);
        _auctionOffer.setCreatedAt(new Date());
        _auctionOffer.setSalesman(adminBean.getUserLog().getSalesman());

        auctionDao.saveAuctionOffer(_auctionOffer);
    }

    /**
     * Save offer price component.
     *
     * @throws Exception the exception
     */
    private void saveOfferPriceComponent(AuctionOffer _auctionOffer) throws Exception {
        log.info("saveOfferPriceComponent");

        for (PriceComponentValue pCv : _auctionOffer.getPriceComponentValues()) {
            pCv.setAuctionOffer(_auctionOffer);
            if (null == pCv.getValue()) {
                pCv.setValue(0.0);
            }
            auctionDao.savePriceComponentValue(pCv);
        }
    }

    /**
     * Calculate score.
     *
     * @param auction the auction
     */
    private void calculateScore(Auction auction) {
        log.info("calculateScore");

        Double totalValue = 0.00;
        Double totalLoopValue = 0.00;
        Double score = 0.00;
        Double maxScore = 0.00;
        Integer counter = 0;
        Map<Integer, Double> totalAuctionOffersValue = new HashMap<Integer, Double>();
        Map<Integer, Double> scoreCollection = new HashMap<Integer, Double>();

        try {
            List<AuctionOffer> allAuctionOffer = auctionDao.getAuctionOffers(auction);
            log.info("allAuctionOffer - " + allAuctionOffer.size());
            for (AuctionOffer auctionOffer : allAuctionOffer) {
                totalLoopValue = auctionOffer.getConstantPricesValue() + auctionOffer.getNotConstantPricesValue();
                totalAuctionOffersValue.put(auctionOffer.getAuctionOfferId(), totalLoopValue);
                totalValue += totalLoopValue;
                counter++;
            }
            int i = 0;
            for (AuctionOffer auctionOffer : allAuctionOffer) {
                score = (totalValue / counter) / totalAuctionOffersValue.get(auctionOffer.getAuctionOfferId());
                log.info("totalValue (auctionOffer#" + auctionOffer.getAuctionOfferId() + "): "
                        + totalAuctionOffersValue.get(auctionOffer.getAuctionOfferId()));
                scoreCollection.put(auctionOffer.getAuctionOfferId(), score);
                if (i == 0) {
                    maxScore = score;
                } else {
                    if (score > maxScore) {
                        maxScore = score;
                    }
                }
                i++;
            }
            log.info("maxScore: " + maxScore);
            i = 0;
            for (AuctionOffer auctionOffer : allAuctionOffer) {
                score = scoreCollection.get(auctionOffer.getAuctionOfferId());
                log.info("score (auctionOffer#" + auctionOffer.getAuctionOfferId() + "): " + score);
                score = (score / maxScore) * 10;
                while (score < 1) {
                    score = score * 10;
                }
                log.info("score/maxscore (auctionOffer#" + auctionOffer.getAuctionOfferId() + "): " + score);
                score = score - 1.0;
                log.info("score-1 (auctionOffer#" + auctionOffer.getAuctionOfferId() + "): " + score);

                long diff;
                diff = auction.getEndContractDate().getTime() - auction.getBeginContractDate().getTime();
                double days = ((double) diff) / (86400.0 * 1000.0);

                double reduce = Double.valueOf(days / 366);
                log.info("reduce: " + reduce);
                if (reduce > 1) {
                    score = score - reduce;
                } else {
                    score = score + reduce;
                }
                log.info("after reduce score (auctionOffer#" + auctionOffer.getAuctionOfferId() + "): " + score);

                score = Math.round(score * 100.0) / 100.0;
                log.info("format score (auctionOffer#" + auctionOffer.getAuctionOfferId() + "): " + score);

                auctionOffer.setScore(score);
                auctionDao.updateAuctionOffer(auctionOffer);

                i++;
            }
        } catch (Exception e) {
            log.error("Problem while calculate score: ", e);
        }

    }

    /**
     * Initialize price components.
     *
     * @param auctionOfferMulti
     */
    public void initializePriceComponents(AuctionOffer auctionOfferMulti) {
        List<PriceComponentValue> priceComponentValues = new ArrayList<PriceComponentValue>();

        try {
            if (isAuctionExist()) {
                priceComponentValues = getPriceComponentValueFromActualAuctionOffer(auctionOfferMulti.getAuction());
            } else {
                List<PriceComponent> priceComponents = new ArrayList<PriceComponent>();

                priceComponents = auctionDao.getPriceComponents(auctionOfferMulti.getAuction().getCloud().getTariff());
                for (PriceComponent pC : priceComponents) {
                    PriceComponentValue pCv = new PriceComponentValue();
                    pCv.setPriceComponent(pC);
                    priceComponentValues.add(pCv);
                }
            }
        } catch (Exception e) {
            log.error("problem while initialize price components: ", e);
        }

        auctionOfferMulti.setPriceComponentValues(priceComponentValues);
    }

    /**
     * Checks if is auction exist.
     *
     * @return true, if is auction exist
     */
    public boolean isAuctionExist() {
        log.info("isAuctionExist");

        if (auctionOffer == null) {
            return false;
        }
        if (auctionOffer.getAuction() == null) {
            return false;
        }
        if (auctionOffer.getAuction().getAuctionId() == null) {
            return false;
        }

        return true;
    }

    /**
     * Calculate volume.
     *
     * @return the string
     */
    public String calculateVolume() {

        if (null == currentCloud) {
            return "";
        }

        try {
            Double vol = currentCloud.getVolume();

            DecimalFormat decimalFormat = new DecimalFormat("#");

            if (vol != null) {
                if (vol > 10000) {
                    return decimalFormat.format(vol / 1000.0).toString()
                            + " "
                            + BundlesUtils.getMessageResourceString("messages", "cloud.volume.MWH", null,
                                    ectx.getRequestLocale());
                } else {
                    return decimalFormat.format(vol).toString()
                            + " "
                            + BundlesUtils.getMessageResourceString("messages", "cloud.volume.KWH", null,
                                    ectx.getRequestLocale());
                }
            }
        } catch (Exception e) {
            log.error("Problem while calulateVolume: ", e);
        }

        return "";
    }

    /**
     * Gets the auction offer.
     *
     * @return the auction offer
     */
    public AuctionOffer getAuctionOffer() {
        return auctionOffer;
    }

    /**
     * Sets the auction offer.
     *
     * @param auctionOffer the new auction offer
     */
    public void setAuctionOffer(AuctionOffer auctionOffer) {
        this.auctionOffer = auctionOffer;
    }

    /**
     * Gets the fill measure.
     *
     * @return the fill measure
     */
    public Integer getFillMeasure() {
        return fillMeasure;
    }

    /**
     * Sets the fill measure.
     *
     * @param fillMeasure the new fill measure
     */
    public void setFillMeasure(Integer fillMeasure) {
        this.fillMeasure = fillMeasure;
    }

    /**
     * Gets the volume profitabilities.
     *
     * @return the volume profitabilities
     */
    public List<VolumeProfitability> getVolumeProfitabilities() {
        return volumeProfitabilities;
    }

    /**
     * Sets the volume profitabilities.
     *
     * @param volumeProfitabilities the new volume profitabilities
     */
    public void setVolumeProfitabilities(List<VolumeProfitability> volumeProfitabilities) {
        this.volumeProfitabilities = volumeProfitabilities;
    }

    /**
     * Gets the auctions for cloud.
     *
     * @return the auctions for cloud
     */
    public List<Auction> getAuctionsForCloud() {
        return auctionsForCloud;
    }

    /**
     * Sets the auctions for cloud.
     *
     * @param auctionsForCloud the new auctions for cloud
     */
    public void setAuctionsForCloud(List<Auction> auctionsForCloud) {
        this.auctionsForCloud = auctionsForCloud;
    }

    /**
     * Back to cloud.
     *
     * @return the string
     */
    public String backToCloud() {
        SalesmanCloudBean salesmanCloudBean = ComponentLookup.lookupComponent("op.salesmanCloudBean");
        salesmanCloudBean.searchClouds();

        return "salesmanClouds";
    }

    /**
     * Gets the min begin contract date.
     *
     * @return the min begin contract date
     */
    public Date getMinBeginContractDate() {
        minBeginContractDate = new Date();
        minBeginContractDate = new Date(minBeginContractDate.getTime() + (1000 * 3600 * 24 * offerEndDays()));

        return minBeginContractDate;
    }

    public String getAddOfferButtonVal() {
        if (isAuctionExist()) {
            return "link.bid.auction";
        }

        return "button.submit.offer";
    }

    public Cloud getCurrentCloud() {
        return currentCloud;
    }

    public void setCurrentCloud(Cloud cloud) {
        currentCloud = cloud;
    }

    public Auction getAuction1() {
        return auction1;
    }

    public void setAuction1(Auction auction) {
        auction1 = auction;
    }

    public Auction getAuction2() {
        return auction2;
    }

    public void setAuction2(Auction auction) {
        auction2 = auction;
    }

    public Auction getAuction3() {
        return auction3;
    }

    public void setAuction3(Auction auction) {
        auction3 = auction;
    }

    public AuctionOffer getAuctionOffer1() {
        return auctionOffer1;
    }

    public AuctionOffer getAuctionOffer2() {
        return auctionOffer2;
    }

    public AuctionOffer getAuctionOffer3() {
        return auctionOffer3;
    }

    public void setAuctionOffer1(AuctionOffer _auctionOffer) {
        auctionOffer1 = _auctionOffer;
    }

    public void setAuctionOffer2(AuctionOffer _auctionOffer) {
        auctionOffer2 = _auctionOffer;
    }

    public void setAuctionOffer3(AuctionOffer _auctionOffer) {
        auctionOffer3 = _auctionOffer;
    }

    public boolean isAddAuction1() {
        return addAuction1;
    }

    public boolean isAddAuction2() {
        return addAuction2;
    }

    public boolean isAddAuction3() {
        return addAuction3;
    }
    
    public void setAddAuction1(boolean _addAuction)
    {
        this.addAuction1 = _addAuction;
    }
    
    public void setAddAuction2(boolean _addAuction)
    {
        this.addAuction2 = _addAuction;
    }
    
    public void setAddAuction3(boolean _addAuction)
    {
        this.addAuction3 = _addAuction;
    }
    
}
