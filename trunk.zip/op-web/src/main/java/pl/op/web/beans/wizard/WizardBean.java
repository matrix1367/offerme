package pl.op.web.beans.wizard;

import java.io.IOException;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.application.NavigationHandler;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.security.Identity;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FlowEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.op.dao.AgreementDao;
import pl.op.dao.BuildingDao;
import pl.op.dao.CloudDao;
import pl.op.dao.DeviceDao;
import pl.op.dao.DistributorDao;
import pl.op.dao.InvoiceDao;
import pl.op.dao.LocationDao;
import pl.op.dao.MeasureDao;
import pl.op.dao.PPEDao;
import pl.op.dao.PrefQuestDao;
import pl.op.dao.QuestValueDao;
import pl.op.dao.SalesmanDao;
import pl.op.dao.StreetDao;
import pl.op.dao.TariffDao;
import pl.op.dao.UserDao;
import pl.op.model.cloud.VolumeEnum;
import pl.op.model.contract.Agreement;
import pl.op.model.contract.Invoice;
import pl.op.model.contract.InvoicePriceComponentValue;
import pl.op.model.contract.Location;
import pl.op.model.contract.Measure;
import pl.op.model.contract.PPE;
import pl.op.model.contract.PPEStatus;
import pl.op.model.contract.Priority;
import pl.op.model.device.Device;
import pl.op.model.dict.Obis;
import pl.op.model.dict.PPETariff;
import pl.op.model.question.PreferenceQuestion;
import pl.op.model.question.QuestionValue;
import pl.op.model.user.UserApp;
import pl.op.model.user.UserRole;
import pl.op.util.PpeUtil;
import pl.op.validation.Validations;
import pl.op.web.beans.AdminBean;
import pl.op.web.beans.MailBean;
import pl.op.web.beans.cloud.CloudBean;
import pl.op.web.beans.user.SendEmailBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.common.WizardStepEnum;
import pl.op.web.listener.GuiceSingleton;
import pl.op.web.service.AutoCloudGenerator;
import pl.op.web.service.BonusService;

@Name("op.wizardBean")
@Scope(ScopeType.SESSION)
public class WizardBean implements Serializable {

    private static final long serialVersionUID = 7657279753756327544L;

    public WizardBean() {
        log.info("WizardBean constructor");
        initialize();
    }

    @In
    Identity identity;

    private final Logger log = LoggerFactory.getLogger(WizardBean.class);

    private FacesContext facesContext;
    private ExternalContext ectx;

    private WizardUserBean wizardUserBean;
    private WizardLocationBean wizardLocationBean;
    private WizardInvoiceBean wizardInvoiceBean;
    private WizardPreferenceQuestionBean wizardPrefQuestionBean;
    private WizardDeviceBean wizardDeviceBean;
    private CloudBean cloudBean;

    private PPEDao ppeDao;
    private UserDao userDao;
    private BuildingDao buildingDao;
    private DeviceDao deviceDao;
    private InvoiceDao invoiceDao;
    private LocationDao locationDao;
    private QuestValueDao questionValueDao;
    private AdminBean adminBean;

    @SuppressWarnings("unused")
    private PrefQuestDao prefQuestDao;

    private AgreementDao agreementDao;
    private StreetDao streetDao;
    private DistributorDao distributorDao;
    private TariffDao tariffDao;
    private SalesmanDao salesmanDao;

    @SuppressWarnings("unused")
    private CloudDao cloudDao;

    private MeasureDao measureDao;
    private Integer progress = 15;
    private boolean simple;

    private UserApp user;
    public static final String deleteRole = "user";
    
    private boolean warningConsumptionProfile;
    private boolean checkConsumptionProfile;
    private Double _consumptionProfile;
    private boolean onlyOneComplet;

    private void initialize() {
        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();
        simple = true;

        wizardUserBean = ComponentLookup.lookupComponent("op.wizardUserBean");
        wizardLocationBean = ComponentLookup.lookupComponent("op.wizardLocationBean");
        wizardInvoiceBean = ComponentLookup.lookupComponent("op.wizardInvoiceBean");
        wizardPrefQuestionBean = ComponentLookup.lookupComponent("op.wizardPreferenceQuestionBean");
        wizardDeviceBean = ComponentLookup.lookupComponent("op.wizardDeviceBean");
        adminBean = ComponentLookup.lookupComponent("op.adminBean");

        this.cloudBean = ComponentLookup.lookupComponent("op.cloudBean");

        ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);
        userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);
        buildingDao = GuiceSingleton.getInstance().getInstance(BuildingDao.class);
        deviceDao = GuiceSingleton.getInstance().getInstance(DeviceDao.class);
        invoiceDao = GuiceSingleton.getInstance().getInstance(InvoiceDao.class);
        locationDao = GuiceSingleton.getInstance().getInstance(LocationDao.class);
        prefQuestDao = GuiceSingleton.getInstance().getInstance(PrefQuestDao.class);
        questionValueDao = GuiceSingleton.getInstance().getInstance(QuestValueDao.class);
        agreementDao = GuiceSingleton.getInstance().getInstance(AgreementDao.class);
        streetDao = GuiceSingleton.getInstance().getInstance(StreetDao.class);
        distributorDao = GuiceSingleton.getInstance().getInstance(DistributorDao.class);
        tariffDao = GuiceSingleton.getInstance().getInstance(TariffDao.class);
        salesmanDao = GuiceSingleton.getInstance().getInstance(SalesmanDao.class);
        cloudDao = GuiceSingleton.getInstance().getInstance(CloudDao.class);
        measureDao = GuiceSingleton.getInstance().getInstance(MeasureDao.class);

        user = new UserApp();
        warningConsumptionProfile = false;
        checkConsumptionProfile = true;
        _consumptionProfile = 0.0;
        onlyOneComplet = false;
    }
    
    public boolean getWarningConsumptionProfile() {
        return warningConsumptionProfile;
    }
    
    public void setWarningConsumptionProfile(boolean _warningConsumptionProfile) {
        warningConsumptionProfile = _warningConsumptionProfile;
    }
    
    public boolean isWarningConsumptionProfile() {
        return warningConsumptionProfile;
    }

    public String onFlowProcess(FlowEvent event) {
        user = wizardUserBean.getUserApp();
        wizardLocationBean.setLocation(new Location());

        WizardStepEnum step;
        step = WizardStepEnum.valueOf(event.getNewStep().toUpperCase());
        switch (step) {
            case STEPTWO:
            	if(user.getBirthDate() != null) {
            		checkUserAge();
            	}
                if(!validatePesel(user)) {
                    return event.getOldStep();
                }
                if(wizardUserBean.getStereotype().getStereotypeId() == null) {
                    warning("warning.stereotype");
                    return event.getOldStep();
                }
                if(!user.getIsCompany() && user.getBirthDate().after(new Date())) {
                    warning("warning.date");
                    return event.getOldStep();
                }
                if(user.getIsCompany() && !Validations.validNip(user.getNip())) {
                    warning("warning.nip");
                    return event.getOldStep();
                }
                if(user.getIsCompany() && !Validations.validRegon(user.getRegon())) {
                    warning("warning.regon");
                    return event.getOldStep();
                }

                break;
            case STEPTHREE:
                if(wizardLocationBean.getLocationList().size() == 0) {
                    warning("warning.location.list.empty");
                    return event.getOldStep();
                }
                break;
        }

        RequestContext.getCurrentInstance().update("wizardForm:progessBar");

        return event.getNewStep();
    }

    private boolean validatePesel(UserApp user) {
        boolean valid = false;
        Integer result = null;

        if(user.getIsCompany()) {
            return true;
        }

        try {
            result = pl.op.validation.Validations.validPesel(user.getPesel(), user.getBirthDate());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        if(result != null) {
            switch (result) {
                case 0:
                    valid = true;
                    break;
                default:
                    warning("invalid.pesel." + result);
            }
        }
        return valid;
    }

    public void changeWizard(AjaxBehaviorEvent ev) {
        log.info("simple wizard: " + simple);
        String redirect = "/pages/wizard/wizard.xhtml";

        if(simple)
            redirect = "/pages/wizard/wizardSimple.xhtml";

        FacesContext facesContext = FacesContext.getCurrentInstance();
        NavigationHandler myNav = facesContext.getApplication().getNavigationHandler();
        myNav.handleNavigation(facesContext, null, redirect);
    }

    public boolean isSimple() {
        return simple;
    }

    public void setSimple(boolean simple) {
        this.simple = simple;
    }
    
    private void addCallback(boolean result) {
            RequestContext.getCurrentInstance().addCallbackParam(
                            "consumpcionProfileWarring", result);              
    }
    
    public boolean validConsumptionProfile() {                
        
        if (checkConsumptionProfile && !wizardUserBean.getUserApp().getIsCompany()) {

        Double globalAmount = 0.0;
        int globalDeys = 0;
        int lc = Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_YEAR);
        Double maxNorm = wizardUserBean.getStereotypeUser().getMediumYearConsumption() * 1.5;
        Double minNorm = wizardUserBean.getStereotypeUser().getMediumYearConsumption() * 0.5;
        
         for(Invoice invoice : wizardInvoiceBean.getInvoices()) {
            int deys =  (int) (((invoice.getDateTo().getTime() - invoice.getDateFrom().getTime())/(1000 * 60 * 60 * 24))+1);
            //log.info ("data To :" + invoice.getDateTo().toString() + ", data from :" + invoice.getDateFrom().toString());
            log.info("deys:: " + deys);
            if (deys >= 0) globalDeys += deys;  else return false;
             for(InvoicePriceComponentValue priceValue : invoice.getInvoicePriceComponentValue()) {
                  if(!priceValue.getPriceComponent().isConstant()) {
                       //Double priceComponentValue = priceValue.getValue();
                       Double priceComponentAmount = priceValue.getAmount();
                       if(invoice.getVolumeEnum().equals(VolumeEnum.KWH)) {
                         //   priceComponentValue = priceComponentValue * 1000.0;
                            priceComponentAmount = priceComponentAmount / 1000.0;                           
                        }
                       globalAmount +=priceComponentAmount;
                       log.info("globalAmount+=:" + priceValue.getAmount().toString());
                  }
                 
             }
             log.info("deys: " + lc + ", globalAmound:" +globalAmount.toString() + ", globalDeys:" + globalDeys );
             Double consumptionProfile = (lc * globalAmount) / globalDeys;
                           
            if (consumptionProfile > maxNorm || consumptionProfile < minNorm) {
                log.warn("Validacja wolumenu: wolumen przekracza srednia norme " +minNorm.toString() + " < " + consumptionProfile.toString() + " < " + maxNorm.toString());
                _consumptionProfile = consumptionProfile;
                return false;
            } else log.info("Validacja wolumenu:" +consumptionProfile.toString());           
         }                              
        }
                       
        return true; //true
    }
    
    public void sentEmail() throws Exception {

            MailBean mailBean = ComponentLookup.lookupComponent("op.mailBean");

            log.info("sent email to operator : walidacja wymuszona");
            

            try {
                    log.info("getting template...");
                    mailBean.sendValidationForceOperation(wizardUserBean.getUserApp() ,_consumptionProfile);
            } catch (Exception e) {
                    log.error("EXCEPTION:", e);
                    throw new Exception();
            }
    }

     public String completeWizardForce() throws Exception {
         checkConsumptionProfile =false;
          try {
            sentEmail();
           } catch (Exception e) {
                    log.error("EXCEPTION:", e);
                    throw new Exception();
           }
         return completeWizard();
     }
    
    public String completeWizard() {        
        log.info(">>>>>>> completeWizard >>>>>>");
        if(!validPPEInvoices()) {
            warning("warning.ppe.invoice");
            log.info("warning.ppe.invoice");
            return "";
        }
        log.info("valid - consumetprofil");
        if (!validConsumptionProfile()) {            
            addCallback(true);
            return "";
        }
        log.info("completewizard ... continue");
        if (onlyOneComplet) return "";
        onlyOneComplet = true;
        try {
            // User update
            user = wizardUserBean.getUserApp();
            user.setSector(wizardUserBean.getSector());

			Date now = new Date();
			Date birthday = user.getBirthDate();
			if (birthday != null) {
				@SuppressWarnings("deprecation")
				int age = now.getYear() - birthday.getYear();
				if (age < 18) {
					BonusService.run("juniorRegister", user);
					user.setUserRole(UserRole.user_junior);
				}
				BonusService.run("fieldBirthDateRegister", user);
			}

            userDao.updateUser(user);
            
            if(user.getPhone() != null) {
                BonusService.run("fieldPhoneRegister", user);
            }
            if(user.getPesel() != null) {
                BonusService.run("fieldPeselRegister", user);
            }
            if(user.getCompanyName() != null) {
                BonusService.run("fieldCompanyNameRegister", user);
            }
            if(user.getRegon() != null) {
                BonusService.run("fieldRegonRegister", user);
            }
            if(user.getNip() != null) {
                BonusService.run("fieldNipRegister", user);
            }
            if(user.getKrs() != null) {
                BonusService.run("fieldKrsRegister", user);
            }

            // Add locations etc
            List<Location> locations = wizardLocationBean.getLocationList(); //wizardDeviceBean.getLocationList();
            List<PreferenceQuestion> preferenceQuestions = wizardPrefQuestionBean.getPreferenceQuestionList();
            List<Invoice> invoices = wizardInvoiceBean.getInvoices();

            int ppeCounter = 0;

            for(Location location : locations) {
                location.setUserApp(user);

                if(location.getStreet().getStreetId() == null)
                    streetDao.saveStreet(location.getStreet());

                buildingDao.saveBuilding(location.getBuilding());

                locationDao.saveLocation(location);

                for(Device device : location.getDevices()) {
                    device.setLocation(location);
                    deviceDao.saveDevice(device);
                }

                for(PPE ppe : location.getPpes()) {
                    ppe.setLocation(location);

                    if(ppe.getCurrentDistributor().getName() != null
                            && ppe.getCurrentDistributor().getName().length() > 0
                            && ppe.getCurrentDistributor().getDistributorId() == null) {
                        if(distributorDao.getDistributorByName(ppe.getCurrentDistributor().getName()) == null) {
                            distributorDao.saveDistributor(ppe.getCurrentDistributor());
                        }
                    }

                    ppeDao.savePPE(ppe);
                    ppeCounter++;
                    PPETariff ppeTariff = new PPETariff();
                    ppeTariff.setPpe(ppe);

                    tariffDao.savePPETariff(ppeTariff);

                    Agreement agreement = ppe.getAgreements().get(0);
                    agreement.setPpeId(ppe.getPpeId());
                    agreement.setUserApp(user);
                    if(agreement.getSalesman().getSalesmanId() == null)
                        if(salesmanDao.getSalesmanByName(agreement.getSalesman().getSalesmanName()) == null) {
                            salesmanDao.saveSalesman(agreement.getSalesman());
                        }

                    agreementDao.saveAgreement(agreement);
                    agreementDao.saveAgreementPPE(agreement);
                }

                for(PreferenceQuestion prefQuestion : preferenceQuestions) {
                    log.info("saving prefQuestion");
                    QuestionValue questionValue = prefQuestion.getQuestionValue();
                    questionValue.setPreferenceQuestion(prefQuestion);
                    questionValue.setUserApp(user);
                    questionValue.setStereotype(wizardUserBean.getStereotype());
                    if (questionValue.getQuestionValueId() == null) {
                        questionValueDao.saveQuestionValue(questionValue);
                    } else
                    {
                        questionValueDao.updateQuestionValue(questionValue);
                    }
                    log.info("saved saveQuestionValue");
                    prefQuestion.setQuestionValue(questionValue);
                    prefQuestDao.updatePreferenceQuestion(prefQuestion);

                }
            }

            if(ppeCounter > 0) {
                BonusService.run("fieldPpeRegister", user);
            }

            // Add invoices and measures
            log.info("saving invoices: " + invoices.size());
            for(Invoice invoice : invoices) {
                // invoice.setPowerConsumption(invoice.getPowerConsumption()
                // / invoice.getVolumeEnum().ordinal());
                log.info("saving invoice");
                invoiceDao.saveInvoice(invoice);
                log.info("saved invoice");

                BonusService.run("addInvoice", user);

                for(InvoicePriceComponentValue priceValue : invoice.getInvoicePriceComponentValue()) {
                    priceValue.setInvoice(invoice);

                    Double priceComponentValue = priceValue.getValue();
                    Double priceComponentAmount = priceValue.getAmount();
                    Double tempPriceComponentAmount = priceComponentAmount;
                    if(!priceValue.getPriceComponent().isConstant()) {
                        if(invoice.getVolumeEnum().equals(VolumeEnum.KWH)) {
                            priceComponentValue = priceComponentValue * 1000.0;
                            priceComponentAmount = priceComponentAmount / 1000.0;
                            priceValue.setAmount(priceComponentAmount);
                            priceValue.setValue(priceComponentValue);
                        }
                    }

                    log.info("saving price component value");
                    invoiceDao.savePriceComponentValue(priceValue);

                    if(!priceValue.getPriceComponent().isConstant()) {
                        // Obis dla measure ma zawsze byc OBIS id: 1
                        Obis obis = new Obis();
                        obis.setObisId(1);

                        Double measureValue = tempPriceComponentAmount;
                        if(invoice.getVolumeEnum().equals(VolumeEnum.KWH)) {
                            measureValue = measureValue / 1000;
                        }
                        Measure measure = new Measure();
                        measure.setDateFrom(invoice.getDateFrom());
                        measure.setInvoice(invoice);
                        measure.setDateTo(invoice.getDateTo());
                        measure.setPpe(invoice.getPpe());
                        measure.setMeasureDate(new Date());
                        measure.setValue(measureValue);
                        measure.setZoneType(priceValue.getPriceComponent().getZoneType());
                        measure.setObis(obis);
                        measure.setPriority(Priority.medium);
                        measureDao.saveMeasure(measure);

                        BonusService.run("addMeasure", user);
                    }
                }

            }

            PpeUtil.setPPEValueForAllPPEsByLocations(locations);
            
            SendEmailBean sendEmailBean = ComponentLookup.lookupComponent("op.sendEmailBean");
                sendEmailBean.setUserApp(user);

            if(user.getIsCompany()) {
                
                sendEmailBean.sendWizardEmail();

                PpeUtil.setStatusForCompanyByInvoices(invoices, locations);

                info("wizard.complete.company");
            } else {
                PpeUtil.setStatusForAllPPEs(locations, PPEStatus.READY_TO_JOIN);
                sendEmailBean.sendWizardEmailUserHome();
            }

            autoCloudGenerate(user);
            

            

        } catch (Exception e) {
            e.printStackTrace();
        }

        refreshIdentity();

        adminBean.setUserLog(user);
        return "userHome";
    }
    
	public void checkUserAge() {
		Date now = new Date();
		Date birthday = user.getBirthDate();
		if (birthday != null) {
			@SuppressWarnings("deprecation")
			int age = now.getYear() - birthday.getYear();
			if (age < 18) {				
				try {
					FacesContext.getCurrentInstance()
					   .getExternalContext().redirect("../notAdult.seam");
				} catch (IOException e) {
					log.error("Error while redirecting to notAdult.seam ",e);
					e.printStackTrace();
				}
			}
		}
	}
	
    public void refreshIdentity() {
        identity.removeRole(deleteRole);
        identity.addRole(user.getUserRole().toString());
    }

    private boolean validPPEInvoices() {
        boolean valid = true;

        for(Location l : wizardLocationBean.getLocationList()) { //wizardLocationBean
            for(PPE p : l.getPpes()) {
                boolean ppeHasInvoice = false;

                for(Invoice i : wizardInvoiceBean.getInvoices()) {
                    if(i.getPpe().getPpeId().intValue() == p.getPpeId().intValue()) {
                        ppeHasInvoice = true;
                        break;
                    }
                }
                if(!ppeHasInvoice)
                    valid = false;
            }

            if(!valid)
                break;
        }
        return valid;
    }

    /**
     * Metoda generuje chmury dla użytkownika na podstawie jego PPE. Jeśli chmury o podanych parametrach przypisuje go
     * do nich, jeśli nie, tworzy nowe i przypina pasujących użytkowników
     * 
     * @param user - user użytkownik dla którego tworzymy chmury
     */
    public void autoCloudGenerate(UserApp user) {
        AutoCloudGenerator.autoCloudGenerateForNewUser(user, wizardLocationBean.getLocationList()); //wizardLocationBean
    }

    @SuppressWarnings({ "deprecation" })
    private void warning(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_WARN,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    @SuppressWarnings({ "deprecation" })
    private void info(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_INFO,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    public CloudBean getCloudBean() {
        return cloudBean;
    }

    public void setCloudBean(CloudBean cloudBean) {
        this.cloudBean = cloudBean;
    }

    public Integer getProgress() {
        return progress;
    }

    public void setProgress(Integer progress) {
        this.progress = progress;
    }
    

    

}