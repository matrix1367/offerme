package pl.op.web.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;

import jofc2.org.json.JSONArray;
import jofc2.org.json.JSONObject;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.TabChangeEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.MeasureDao;
import pl.op.dao.PPEDao;
import pl.op.dao.ProfileDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.auction.PriceComponentValue;
import pl.op.model.auction.ZoneType;
import pl.op.model.contract.Location;
import pl.op.model.contract.Measure;
import pl.op.model.contract.MeasureFilter;
import pl.op.model.contract.PPE;
import pl.op.model.contract.Priority;
import pl.op.model.device.Device;
import pl.op.model.device.DeviceTypeEnum;
import pl.op.model.profile.DayType;
import pl.op.model.profile.ProfileIndicatorFilter;
import pl.op.util.PpeUtil;
import pl.op.web.common.BundlesUtils;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class ReportBean.
 */
@Name("op.reportBean")
@Scope(ScopeType.SESSION)
public class ReportBean implements Serializable {

    private static final long serialVersionUID = -6058836968165359312L;
    private Logger log = LoggerFactory.getLogger(ReportBean.class);

    private String chartType;

    private JSONObject locationDevicesYearConsumptionJson;
    private JSONObject ppeStereotypeUsageChartJson;
    private JSONObject ppeUsageChartJson;
    private JSONObject auctionOffersJson;

    private HashMap<Integer, String> coloursMap;
    private MeasureDao measureDao;
    private ProfileDao profileDao;

    private HashMap<Integer, HashMap<ZoneType, Integer>> workDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Integer>>();
    private HashMap<Integer, HashMap<ZoneType, Integer>> saturdayDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Integer>>();
    private HashMap<Integer, HashMap<ZoneType, Integer>> sundaysDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Integer>>();
    private HashMap<Integer, HashMap<ZoneType, Double>> extraValWorkDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Double>>();
    private HashMap<Integer, HashMap<ZoneType, Double>> extraValSaturdayDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Double>>();
    private HashMap<Integer, HashMap<ZoneType, Double>> extraValSundaysDaysPerMonth = new HashMap<Integer, HashMap<ZoneType, Double>>();
    private HashMap<ZoneType, Integer> cointainesZones = new HashMap<ZoneType, Integer>();
    private HashMap<ZoneType, String> zonesColours = new HashMap<ZoneType, String>();
    public HashMap<ZoneType, Double> measureDayValuePerZone = new HashMap<ZoneType, Double>();
    public HashMap<ZoneType, Double> extraMeasureDayValuePerZone = new HashMap<ZoneType, Double>();
    private Map<Integer, String> monthAsString = new HashMap<Integer, String>();

    private Double measureValuePerDay = Double.valueOf("0.0");

    /**
     * Instantiates a new report bean.
     */
    public ReportBean() {
        log.info("ReportBean constructor");
        initialize();
    }

    /**
     * Initialize.
     */
    private void initialize() {
        try {
            generateRandomColours(25);
            measureDao = GuiceSingleton.getInstance().getInstance(MeasureDao.class);
            profileDao = GuiceSingleton.getInstance().getInstance(ProfileDao.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Generate random colours.
     * 
     * @param count
     *            the count colors to generate
     */
    public void generateRandomColours(Integer count) {
        Random rand = new Random();
        coloursMap = new HashMap<Integer, String>();

        for(int i = 0; i < count; i++) {
            int r = rand.nextInt(255);
            int g = rand.nextInt(255);
            int b = rand.nextInt(255);

            coloursMap.put(i, String.format("#%02x%02x%02x", r, g, b));
        }

        log.info("coloursMap - " + coloursMap);
    }

    /**
     * Gets the chart type.
     * 
     * @return the chart type
     */
    public String getChartType() {
        return chartType;
    }

    /**
     * Sets the chart type.
     * 
     * @param chartType
     *            the new chart type
     */
    public void setChartType(String chartType) {
        this.chartType = chartType;
    }

    /**
     * Gets the content chart.
     * 
     * @return the content chart
     */
    public String getContentChart() {
        log.info("getContentChart - " + chartType);

        if(null == chartType) {
            return "none";
        }

        if(chartType.equals("locationDevicesYearConsumption")) {
            log.info("selected - locationDevicesYearConsumption");

            return locationDevicesYearConsumptionJson.toString();
        } else if(chartType.equals("ppeStereotypeUsageChart")) {
            log.info("selected - ppeStereotypeUsageChart");

            return ppeStereotypeUsageChartJson.toString();
        } else if(chartType.equals("ppeUsageChart")) {
            log.info("selected - ppeUsageChart");

            return ppeUsageChartJson.toString();
        } else if(chartType.equals("auctionOffersChart")) {
            log.info("selected - auctionOffersChart");

            return auctionOffersJson.toString();
        }

        return "none";
    }

    /**
     * Prepare location device chart.
     * 
     * @param location
     *            the location
     * @return the boolean
     */
    public Boolean prepareLocationDeviceChart(Location location) {
        log.info("prepareLocationDeviceChart");

        if(!hasLocationDevices(location)) {
            return false;
        }

        log.info("all OK");
        try {
            chartType = "locationDevicesYearConsumption";

            JSONArray chartColours = new JSONArray();
            JSONArray chartValues = new JSONArray();
            BigDecimal allDevicesDailyConsumption = BigDecimal.valueOf(0.0);

            for(Device device : location.getDevices()) {
                if(device.getDeviceType().getDeviceType().equals(DeviceTypeEnum.PRODUCER)) {
                    continue;
                }

                BigDecimal deviceYearConsumption = device.getDailyConsumption().multiply(BigDecimal.valueOf(365));
                String deviceName = device.getDeviceType().getName();

                JSONObject elementValue = new JSONObject();
                elementValue.put("value", deviceYearConsumption);
                elementValue.put("text", deviceName);
                chartValues.put(elementValue);

                chartColours.put(coloursMap.get(location.getDevices().indexOf(device)));

                allDevicesDailyConsumption = allDevicesDailyConsumption.add(deviceYearConsumption);
            }

            log.info("ppeSize: " + location.getPpes().size());
            Double tmpLocationValue = 0.0;
            for(PPE ppe : location.getPpes()) {
                log.info("ppe: #" + ppe.getPpeId() + "; value: " + ppe.getValue());
                if(null != ppe.getValue()) {
                    tmpLocationValue += ppe.getValue().doubleValue() * 1000.0;
                }
            }

            if(tmpLocationValue > 0) {
                log.info("allDevicesDailyConsumption: " + allDevicesDailyConsumption);
                log.info("tmpLocationValue: " + tmpLocationValue);
                if(allDevicesDailyConsumption.compareTo(BigDecimal.valueOf(tmpLocationValue)) < 0) {
                    BigDecimal locationValue = BigDecimal.valueOf(tmpLocationValue);
                    BigDecimal unsignedDevicesYearValue = allDevicesDailyConsumption.multiply(BigDecimal.valueOf(-1));
                    BigDecimal extraVal = locationValue.add(unsignedDevicesYearValue);

                    String valName = getMessage("pie.label.restDevices");

                    JSONObject elementValue = new JSONObject();
                    elementValue.put("value", extraVal);
                    elementValue.put("text", valName);
                    chartValues.put(elementValue);

                    chartColours.put(coloursMap.get(coloursMap.size() - 1));
                }
            }

            JSONObject legend = new JSONObject();
            legend.put("position", "right");
            legend.put("visible", true);
            legend.put("bg_colour", "#666666");

            JSONObject tooltip = new JSONObject();
            tooltip.put("mouse", 2);

            JSONObject element = new JSONObject();
            element.put("id", 2);
            element.put("type", "pie");
            element.put("tip", "#val# Z #total#\n#percent#\n#key#");
            element.put("start-angle", 0);
            element.put("no-labels", false);
            element.put("font-size", 15);
            element.put("alpha", 1);
            element.put("stroke", 2);
            element.put("animate", 0);
            element.put("colours", chartColours);
            element.put("values", chartValues);

            locationDevicesYearConsumptionJson = new JSONObject();
            locationDevicesYearConsumptionJson.put("bg_colour", "#666666");
            locationDevicesYearConsumptionJson.put("is_thousand_separator_disabled", true);
            locationDevicesYearConsumptionJson.put("legend", legend);
            locationDevicesYearConsumptionJson.put("tooltip", tooltip);
            locationDevicesYearConsumptionJson.put("elements", new JSONArray().put(element));
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

        return true;
    }

    /**
     * Checks for location devices.
     * 
     * @param location
     *            the location
     * @return true, if successful
     */
    private boolean hasLocationDevices(Location location) {
        if(null == location) {
            log.info("location is null");
            return false;
        }

        if(null == location.getDevices()) {
            log.info("location.getDevices is null");
            return false;
        }

        if(location.getDevices().size() == 0) {
            log.info("location.getDevices.size() == 0");
            return false;
        }

        return true;
    }

    /**
     * Prepare ppe stereotype usage chart.
     * 
     * @param ppe
     *            the ppe
     * @return true, if successful
     */
    public boolean preparePpeStereotypeUsageChart(PPE ppe) {
        log.info("preparePpeStereotypeUsageChart");

        if(!isValidPpe(ppe)) {
            return false;
        }

        log.info("all OK");
        try {
            PPEDao ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);

            chartType = "ppeStereotypeUsageChart";

            String title = null;
            String barTitle = null;
            Integer userId = ppe.getLocation().getUserApp().getUserId();
            Integer stereotypeId = ppe.getLocation().getUserApp().getSector().getStereotype().getStereotypeId();
            Integer tariffId = ppe.getTariff().getTariffId();
            Integer cityId = ppe.getLocation().getStreet().getCity().getCityId();
            Integer areaId = ppe.getLocation().getStreet().getCity().getArea().getAreaId();
            List<PPE> ppeGroup = null;

            JSONArray elementValues = new JSONArray();
            JSONObject elementValue = new JSONObject();
            JSONArray tempElement;

            log.info("sql params: " + userId + " " + stereotypeId + " " + tariffId + " " + cityId + " " + areaId);

            if(ppeDao.getPpesGroup("groupByCityCount", userId, cityId, areaId, stereotypeId, tariffId).size() > 0) {
                ppeGroup = ppeDao.getPpesGroup("groupByCity", userId, cityId, areaId, stereotypeId, tariffId);
                barTitle = ppe.getLocation().getStreet().getCity().getCityName();
                title = barTitle + ",";
                log.info("groupByCityCount: " + ppeGroup.size());
            } else if(ppeDao.getPpesGroup("groupByAreaCount", userId, cityId, areaId, stereotypeId, tariffId).size() > 0) {
                ppeGroup = ppeDao.getPpesGroup("groupByArea", userId, cityId, areaId, stereotypeId, tariffId);
                barTitle = ppe.getLocation().getStreet().getCity().getArea().getAreaName();
                title = barTitle + ", ";
                log.info("groupByAreaCount: " + ppeGroup.size());
            } else {
                barTitle = "Moje PPE";
                title = "Brak grupy referencyjnej, ";
                log.info("onlyMyPPe");
                ppeGroup = new ArrayList<PPE>();
            }

            title += ppe.getLocation().getUserApp().getSector().getStereotype().getStereotypeName();

            elementValue = new JSONObject();
            elementValue.put("left", 0);
            elementValue.put("right", ppe.getValue().doubleValue() * 1000);
            elementValue.put("text", barTitle);
            elementValue.put("colour", coloursMap.get(0));

            tempElement = new JSONArray();
            tempElement.put(elementValue);
            elementValues.put(tempElement);

            Double maxUsageValue = ppe.getValue().doubleValue();
            Double minUsageValue = ppe.getValue().doubleValue();
            Double averageUsageValue = 0.0;

            if(null == maxUsageValue) {
                maxUsageValue = 0.0;
            }
            if(0 == maxUsageValue.doubleValue()) {
                maxUsageValue = 1.0;
            }

            log.info("maxUsageValue: " + maxUsageValue);
            log.info("minUsageValue: " + minUsageValue);
            log.info("averageUsageValue: " + averageUsageValue);

            if(ppeGroup.size() > 0) {
                for(PPE p : ppeGroup) {
                    if(maxUsageValue.doubleValue() < p.getValue().doubleValue()) {
                        maxUsageValue = p.getValue().doubleValue();
                    }

                    if(minUsageValue.doubleValue() > p.getValue().doubleValue()) {
                        minUsageValue = p.getValue().doubleValue();
                    }

                    averageUsageValue += p.getValue().doubleValue();

                    log.info("ppeId: " + p.getPpeId());
                    log.info("ppeValue: " + p.getValue());
                    log.info("maxUsageValue: " + maxUsageValue);
                    log.info("minUsageValue: " + minUsageValue);
                    log.info("averageUsageValue: " + averageUsageValue);
                }

                averageUsageValue = averageUsageValue / ppeGroup.size();

                elementValue = new JSONObject();
                elementValue.put("left", 0);
                elementValue.put("right", averageUsageValue.doubleValue() * 1000);
                elementValue.put("text", barTitle);
                elementValue.put("colour", "#003C8D");

                tempElement = new JSONArray();
                tempElement.put(elementValue);
                elementValues.put(tempElement);

                elementValue = new JSONObject();
                elementValue.put("left", 0);
                elementValue.put("right", maxUsageValue.doubleValue() * 1000);
                elementValue.put("text", barTitle);
                elementValue.put("colour", "#003C8D");

                tempElement = new JSONArray();
                tempElement.put(elementValue);
                elementValues.put(tempElement);

                elementValue = new JSONObject();
                elementValue.put("left", 0);
                elementValue.put("right", minUsageValue.doubleValue() * 1000);
                elementValue.put("text", barTitle);
                elementValue.put("colour", "#003C8D");

                tempElement = new JSONArray();
                tempElement.put(elementValue);
                elementValues.put(tempElement);
            }

            log.info("after maxUsageValue: " + maxUsageValue);
            log.info("after minUsageValue: " + minUsageValue);
            log.info("after averageUsageValue: " + averageUsageValue);

            ppeStereotypeUsageChartJson = new JSONObject();

            JSONObject legend = new JSONObject();
            legend.put("position", "right");
            legend.put("visible", true);
            legend.put("bg_colour", "#666666");

            JSONObject tooltip = new JSONObject();
            tooltip.put("mouse", 2);

            JSONArray yLabels = new JSONArray();
            JSONObject tempLabel = new JSONObject();
            tempLabel.put("y", 0);
            tempLabel.put("text", getMessage("pie.label.myUsage"));
            yLabels.put(tempLabel);

            tempLabel = new JSONObject();
            tempLabel.put("y", -1);
            tempLabel.put("text", getMessage("pie.label.group.average"));
            yLabels.put(tempLabel);

            tempLabel = new JSONObject();
            tempLabel.put("y", -2);
            tempLabel.put("text", getMessage("pie.label.group.max"));
            yLabels.put(tempLabel);

            tempLabel = new JSONObject();
            tempLabel.put("y", -3);
            tempLabel.put("text", getMessage("pie.label.group.min"));
            yLabels.put(tempLabel);

            JSONObject yAxis = new JSONObject();
            yAxis.put("labels", new JSONObject());
            yAxis.getJSONObject("labels").put("colour", "#FFFFFF");
            yAxis.getJSONObject("labels").put("labels", yLabels);
            yAxis.put("min", -3);
            yAxis.put("max", 0);
            yAxis.put("offset", 1);
            yAxis.put("stroke", 2);
            yAxis.put("colour", "#666666");

            JSONObject xAxis = new JSONObject();
            xAxis.put("labels", new JSONObject());
            xAxis.getJSONObject("labels").put("colour", "#FFFFFF");
            xAxis.getJSONObject("labels").put("rotate", -45);
            xAxis.put("grid-colour", "#666666");
            xAxis.put("max", maxUsageValue * 1000);
            xAxis.put("min", 0);
            xAxis.put("steps", (maxUsageValue * 1000) / 15);

            JSONObject chartTitle = new JSONObject();
            chartTitle.put("text", title);
            chartTitle.put("style", "{font-size: 15px;}");

            JSONObject element = new JSONObject();
            element.put("id", 1);
            element.put("type", "hbar_stack");
            element.put("tip", "#val# kWh");
            element.put("font-size", 15);
            element.put("alpha", 0.9);
            element.put("barwidth", 0.5);
            element.put("animate", 0);
            element.put("stroke", 2);
            element.put("title", chartTitle);
            element.put("values", elementValues);

            ppeStereotypeUsageChartJson.put("bg_colour", "#666666");
            ppeStereotypeUsageChartJson.put("is_thousand_separator_disabled", true);
            ppeStereotypeUsageChartJson.put("legend", legend);
            ppeStereotypeUsageChartJson.put("tooltip", tooltip);
            ppeStereotypeUsageChartJson.put("y_axis", yAxis);
            ppeStereotypeUsageChartJson.put("x_axis", xAxis);
            ppeStereotypeUsageChartJson.put("elements", new JSONArray().put(element));
        } catch (Exception e) {
            log.error("There was a problem while preparing stereotype for PPE chart: ", e);
            return false;
        }
        return true;
    }

    /**
     * Checks if is valid ppe.
     * 
     * @param ppe
     *            the ppe
     * @return true, if is valid ppe
     */
    private boolean isValidPpe(PPE ppe) {
        if(ppe == null) {
            log.info("ppe is null");
            return false;
        }
        if(ppe.getLocation() == null) {
            log.info("ppe location is null");
            return false;
        }
        if(ppe.getLocation().getStreet() == null) {
            log.info("ppe location street is null");
            return false;
        }
        if(ppe.getLocation().getStreet().getCity() == null) {
            log.info("ppe location street city is null");
            return false;
        }
        if(ppe.getLocation().getStreet().getCity().getArea() == null) {
            log.info("ppe location street city area is null");
            return false;
        }
        if(ppe.getLocation().getUserApp() == null) {
            log.info("ppe location userApp is null");
            return false;
        }
        if(ppe.getLocation().getUserApp().getSector() == null) {
            log.info("ppe location userApp sector is null");
            return false;
        }
        if(ppe.getLocation().getUserApp().getSector().getStereotype() == null) {
            log.info("ppe location userApp sector stereotype is null");
            return false;
        }

        return true;
    }

    /**
     * Prepare ppe usage chart.
     * 
     * @param ppe
     *            the ppe
     * @param durationType
     *            the duration type
     * @param dateFrom
     *            the date from
     * @param dateTo
     *            the date to
     * @return true, if successful
     */
    public boolean preparePpeUsageChart(PPE ppe, String durationType, Date dateFrom, Date dateTo) {
        log.info("preparePpeUsageChart");
       
        if(ppe == null)  return false;

        log.info("all OK");

        try {
            chartType = "ppeUsageChart";
            log.info("durationType - " + durationType);
            if(durationType.equals("month")) {
                Date df = new Date(dateFrom.getTime());
                Date dt = new Date(dateTo.getTime());
                preparePpeMonthUsageChart(ppe, df, dt, durationType);
            } else if(durationType.equals("week")) {
                Date df = new Date(dateFrom.getTime());
                Date dt = new Date(dateTo.getTime());
                preparePpeWeekUsageChart(ppe, df, dt, durationType);
            } else {
                Date df = new Date(dateFrom.getTime());
                Date dt = new Date(dateTo.getTime());
                preparePpeDailyUsageChart(ppe, df, dt);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return true;
    }

    /**
     * Prepare ppe usage data.
     * 
     * @param ppe
     *            the ppe
     * @param dateFrom
     *            the date from
     * @param dateTo
     *            the date to
     * @param durationType
     *            the duration type
     */
    public void preparePpeUsageData(PPE ppe, Date dateFrom, Date dateTo, String durationType) {
        PpeUtil ppeUtil = new PpeUtil();
        ppeUtil.preparePpeUsageData(ppe, dateFrom, dateTo, durationType);

        workDaysPerMonth = ppeUtil.workDaysPerMonth;
        saturdayDaysPerMonth = ppeUtil.saturdayDaysPerMonth;
        sundaysDaysPerMonth = ppeUtil.sundaysDaysPerMonth;
        extraValWorkDaysPerMonth = ppeUtil.extraValWorkDaysPerMonth;
        extraValSaturdayDaysPerMonth = ppeUtil.extraValSaturdayDaysPerMonth;
        extraValSundaysDaysPerMonth = ppeUtil.extraValSundaysDaysPerMonth;
        cointainesZones = ppeUtil.cointainesZones;
        zonesColours = ppeUtil.zonesColours;
        measureValuePerDay = ppeUtil.getMeasureValuePerDay();
        measureDayValuePerZone = ppeUtil.getMeasureDayValuePerZone();
        extraMeasureDayValuePerZone = ppeUtil.getExtraMeasureDayValuePerZone();

    }

    /**
     * Prepare ppe month usage chart.
     * 
     * @param ppe
     *            the ppe
     * @param dateFrom
     *            the date from
     * @param dateTo
     *            the date to
     * @param durationType
     *            the duration type
     */
    public void preparePpeMonthUsageChart(PPE ppe, Date dateFrom, Date dateTo, String durationType) {
        log.info("preparePpeMonthUsageChart - dateFrom - " + dateFrom + ";  dateTo - " + dateTo);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(dateTo);
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        dateTo = calendar.getTime();

        try {
            preparePpeUsageData(ppe, dateFrom, dateTo, durationType);
            Double value, tmpSumValue = 0.0, maxValue = 0.0;
            int barCount = 0;
            Date startDate = new Date(dateFrom.getTime());
            Date endDate = new Date(dateTo.getTime());

            JSONArray values = new JSONArray();
            JSONArray elementValues;
            JSONObject tmpElementValue;
            JSONArray xLabel = new JSONArray();
            JSONObject tmpxLabel;
            for(Date start = startDate; start.compareTo(endDate) < 0; startDate.setMonth((getMonth(startDate) + 1))) {

                for(Entry<ZoneType, Integer> zone : cointainesZones.entrySet()) {
                    barCount++;
                    elementValues = new JSONArray();

                    value = workDaysPerMonth.get(getMonth(startDate)).get(zone.getKey()) * measureDayValuePerZone.get(zone.getKey());
                    value += getExtraValForWorkDays(getMonth(startDate), zone.getKey());
                    tmpSumValue = value.doubleValue();

                    tmpElementValue = new JSONObject();
                    tmpElementValue.put("val", value);
                    tmpElementValue.put("text", getMessage("bar.label.workdays"));
                    tmpElementValue.put("colour", "#0033FF");
                    elementValues.put(tmpElementValue);

                    value = saturdayDaysPerMonth.get(getMonth(startDate)).get(zone.getKey()) * measureDayValuePerZone.get(zone.getKey());
                    value += getExtraValForSaturdayDays(getMonth(startDate), zone.getKey());
                    tmpSumValue += value.doubleValue();

                    tmpElementValue = new JSONObject();
                    tmpElementValue.put("val", value);
                    tmpElementValue.put("text", getMessage("bar.label.saturday"));
                    tmpElementValue.put("colour", "#195D00");
                    elementValues.put(tmpElementValue);

                    value = sundaysDaysPerMonth.get(getMonth(startDate)).get(zone.getKey()) * measureDayValuePerZone.get(zone.getKey());
                    value += getExtraValForSundayDays(getMonth(startDate), zone.getKey());
                    tmpSumValue += value.doubleValue();

                    tmpElementValue = new JSONObject();
                    tmpElementValue.put("val", value);
                    tmpElementValue.put("text", getMessage("bar.label.sundays"));
                    tmpElementValue.put("colour", "#CC0000");
                    elementValues.put(tmpElementValue);

                    maxValue = (tmpSumValue.doubleValue() > maxValue.doubleValue()) ? tmpSumValue : maxValue;

                    values.put(elementValues);

                    tmpxLabel = new JSONObject();
                    tmpxLabel.put("x", barCount - 1);
                    tmpxLabel.put("text", getMessage("label.months." + getMonth(startDate)) + "("
                            + getMessage(zone.getKey().toString()) + ")");
                    xLabel.put(tmpxLabel);

                }
            }

            ppeUsageChartJson = new JSONObject();

            JSONObject legend = new JSONObject();
            legend.put("position", "right");
            legend.put("visible", true);
            legend.put("bg_colour", "#666666");

            JSONObject tooltip = new JSONObject();
            tooltip.put("mouse", 2);

            Double steps = maxValue / 5;
            JSONObject yAxis = new JSONObject();
            yAxis.put("labels", new JSONObject());
            yAxis.getJSONObject("labels").put("colour", "#FFFFFF");
            yAxis.put("min", 0);
            yAxis.put("max", maxValue);
            yAxis.put("steps", steps.intValue());
            yAxis.put("colour", "#666666");

            JSONObject xAxis = new JSONObject();
            xAxis.put("labels", new JSONObject());
            xAxis.getJSONObject("labels").put("colour", "#FFFFFF");
            xAxis.getJSONObject("labels").put("rotate", -45);
            xAxis.getJSONObject("labels").put("labels", xLabel);
            xAxis.put("grid-colour", "#666666");
            xAxis.put("max", barCount - 1);
            xAxis.put("min", 0);
            xAxis.put("steps", 1);

            JSONObject element = new JSONObject();
            element.put("id", 25);
            element.put("type", "bar_stack");
            element.put("tip", "#val#\n#key#");
            element.put("font-size", 15);
            element.put("alpha", 0.9);
            element.put("barwidth", 0.3);
            element.put("values", values);

            JSONObject yLegend = new JSONObject();
            yLegend.put("text", "kWh");
            yLegend.put("style", "{font-size: 18px; color: #FFFFFF}");

            JSONObject xLegend = new JSONObject();
            xLegend.put("text", "Miesiąc(Strefa)");
            xLegend.put("style", "{font-size: 18px; color: #FFFFFF}");

            ppeUsageChartJson.put("y_legend", yLegend);
            ppeUsageChartJson.put("x_legend", xLegend);
            ppeUsageChartJson.put("bg_colour", "#666666");
            ppeUsageChartJson.put("is_thousand_separator_disabled", true);
            ppeUsageChartJson.put("legend", legend);
            ppeUsageChartJson.put("tooltip", tooltip);
            ppeUsageChartJson.put("y_axis", yAxis);
            ppeUsageChartJson.put("x_axis", xAxis);
            ppeUsageChartJson.put("elements", new JSONArray().put(element));

            chartType = "ppeUsageChart";
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Prepare ppe week usage chart.
     * 
     * @param ppe
     *            the ppe
     * @param dateFrom
     *            the date from
     * @param dateTo
     *            the date to
     * @param durationType
     *            the duration type
     */
    public void preparePpeWeekUsageChart(PPE ppe, Date dateFrom, Date dateTo, String durationType) {
        try {
            preparePpeUsageData(ppe, dateFrom, dateTo, durationType);
            Double value, maxValue = 0.0;
            Integer barCount = 0;
            Date startDate = new Date(dateFrom.getTime());
            int id = 40;

            JSONArray elements = new JSONArray();
            JSONObject element = new JSONObject();
            JSONArray elementValues;
            JSONObject tmpElementValue;
            for(Entry<ZoneType, Integer> zone : cointainesZones.entrySet()) {
                barCount++;
                elementValues = new JSONArray();

                Double zoneDayVal = measureDayValuePerZone.get(zone.getKey());
                value = workDaysPerMonth.get(getMonth(startDate)).get(zone.getKey()) * zoneDayVal;
                value += getExtraValForWorkDays(getMonth(startDate), zone.getKey());
                maxValue = (value.doubleValue() > maxValue.doubleValue()) ? value.doubleValue() : maxValue;

                tmpElementValue = new JSONObject();
                tmpElementValue.put("top", value);
                tmpElementValue.put("tip", "#top# " + getMessage(zone.getKey().toString()));
                tmpElementValue.put("colour", zonesColours.get(zone.getKey()));
                elementValues.put(tmpElementValue);

                value = saturdayDaysPerMonth.get(getMonth(startDate)).get(zone.getKey()) * zoneDayVal;
                value += getExtraValForSaturdayDays(getMonth(startDate), zone.getKey());
                maxValue = (value.doubleValue() > maxValue.doubleValue()) ? value.doubleValue() : maxValue;

                tmpElementValue = new JSONObject();
                tmpElementValue.put("top", value);
                tmpElementValue.put("tip", "#top# " + getMessage(zone.getKey().toString()));
                tmpElementValue.put("colour", zonesColours.get(zone.getKey()));
                elementValues.put(tmpElementValue);

                value = sundaysDaysPerMonth.get(getMonth(startDate)).get(zone.getKey()) * zoneDayVal;
                value += getExtraValForSundayDays(getMonth(startDate), zone.getKey());
                maxValue = (value.doubleValue() > maxValue.doubleValue()) ? value.doubleValue() : maxValue;

                tmpElementValue = new JSONObject();
                tmpElementValue.put("top", value);
                tmpElementValue.put("tip", "#top# " + getMessage(zone.getKey().toString()));
                tmpElementValue.put("colour", zonesColours.get(zone.getKey()));
                elementValues.put(tmpElementValue);

                element = new JSONObject();
                element.put("id", id++);
                element.put("type", "bar_3d");
                element.put("text", getMessage(zone.getKey().toString()));
                element.put("font-size", 15);
                element.put("stroke", 4);
                element.put("animate", 1);
                element.put("alpha", 0.9);
                element.put("barwidth", 0.5);
                element.put("values", elementValues);

                elements.put(element);
            }

            ppeUsageChartJson = new JSONObject();

            JSONObject legend = new JSONObject();
            legend.put("position", "right");
            legend.put("visible", false);
            legend.put("bg_colour", "#666666");

            JSONObject tooltip = new JSONObject();
            tooltip.put("mouse", 2);

            JSONObject yAxis = new JSONObject();
            yAxis.put("labels", new JSONObject());
            yAxis.getJSONObject("labels").put("colour", "#FFFFFF");
            yAxis.put("stroke", 2);
            yAxis.put("min", 0);
            yAxis.put("max", maxValue);
            yAxis.put("steps", maxValue / 5);
            yAxis.put("offset", 1);
            yAxis.put("colour", "#666666");

            JSONObject xAxis = new JSONObject();
            xAxis.put("labels", new JSONObject());
            xAxis.getJSONObject("labels").put("colour", "#FFFFFF");
            xAxis.getJSONObject("labels").put("labels", new JSONArray());

            JSONObject xAxisLabel = new JSONObject();
            xAxisLabel.put("x", 0);
            xAxisLabel.put("text", getMessage("bar.label.workdays"));
            xAxis.getJSONObject("labels").getJSONArray("labels").put(xAxisLabel);

            xAxisLabel = new JSONObject();
            xAxisLabel.put("x", 1);
            xAxisLabel.put("text", getMessage("bar.label.saturday"));
            xAxis.getJSONObject("labels").getJSONArray("labels").put(xAxisLabel);

            xAxisLabel = new JSONObject();
            xAxisLabel.put("x", 2);
            xAxisLabel.put("text", getMessage("bar.label.sundays"));
            xAxis.getJSONObject("labels").getJSONArray("labels").put(xAxisLabel);

            xAxis.put("grid-colour", "#666666");
            xAxis.put("max", 2);
            xAxis.put("min", 0);
            xAxis.put("steps", 1);
            xAxis.put("stroke", 10);

            JSONObject yLegend = new JSONObject();
            yLegend.put("text", "kWh");
            yLegend.put("style", "{font-size: 18px; color: #FFFFFF}");

            JSONObject xLegend = new JSONObject();
            xLegend.put("text", "Typ dnia tygodnia");
            xLegend.put("style", "{font-size: 18px; color: #FFFFFF}");

            ppeUsageChartJson.put("y_legend", yLegend);
            ppeUsageChartJson.put("x_legend", xLegend);
            ppeUsageChartJson.put("bg_colour", "#666666");
            ppeUsageChartJson.put("is_thousand_separator_disabled", true);
            ppeUsageChartJson.put("legend", legend);
            ppeUsageChartJson.put("tooltip", tooltip);
            ppeUsageChartJson.put("y_axis", yAxis);
            ppeUsageChartJson.put("x_axis", xAxis);
            ppeUsageChartJson.put("elements", elements);

            chartType = "ppeUsageChart";
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Gets the extra measure day val per zone.
     * 
     * @param zone
     *            the zone
     * @return the extra measure day val per zone
     */
    private Double getExtraMeasureDayValPerZone(ZoneType zone) {
        if(null == extraMeasureDayValuePerZone) {
            return 0.0;
        }
        if(null == extraMeasureDayValuePerZone.get(zone)) {
            return 0.0;
        }

        return extraMeasureDayValuePerZone.get(zone);
    }

    /**
     * Gets the extra val for work days.
     * 
     * @param month
     *            the month
     * @param zone
     *            the zone
     * @return the extra val for work days
     */
    private Double getExtraValForWorkDays(int month, ZoneType zone) {
        if(null == extraValWorkDaysPerMonth.get(month)) {
            return 0.0;
        }
        if(null == extraValWorkDaysPerMonth.get(month).get(zone)) {
            return 0.0;
        }

        return extraValWorkDaysPerMonth.get(month).get(zone).doubleValue();
    }

    /**
     * Gets the extra val for saturday days.
     * 
     * @param month
     *            the month
     * @param zone
     *            the zone
     * @return the extra val for saturday days
     */
    private Double getExtraValForSaturdayDays(int month, ZoneType zone) {
        if(null == extraValSaturdayDaysPerMonth.get(month)) {
            return 0.0;
        }
        if(null == extraValSaturdayDaysPerMonth.get(month).get(zone)) {
            return 0.0;
        }

        return extraValSaturdayDaysPerMonth.get(month).get(zone).doubleValue();
    }

    /**
     * Gets the extra val for sunday days.
     * 
     * @param month
     *            the month
     * @param zone
     *            the zone
     * @return the extra val for sunday days
     */
    private Double getExtraValForSundayDays(int month, ZoneType zone) {
        if(null == extraValSundaysDaysPerMonth.get(month)) {
            return 0.0;
        }
        if(null == extraValSundaysDaysPerMonth.get(month).get(zone)) {
            return 0.0;
        }

        return extraValSundaysDaysPerMonth.get(month).get(zone).doubleValue();
    }

    /**
     * Prepare ppe daily usage chart.
     * 
     * @param ppe
     *            the ppe
     * @param dateFrom
     *            the date from
     * @param dateTo
     *            the date to
     */
    public void preparePpeDailyUsageChart(PPE ppe, Date dateFrom, Date dateTo) {
        log.info("preparePpeDailyUsageChart");

        monthAsString.put(0, "I");
        monthAsString.put(1, "II");
        monthAsString.put(2, "III");
        monthAsString.put(3, "IV");
        monthAsString.put(4, "V");
        monthAsString.put(5, "VI");
        monthAsString.put(6, "VII");
        monthAsString.put(7, "VIII");
        monthAsString.put(8, "IX");
        monthAsString.put(9, "X");
        monthAsString.put(10, "XI");
        monthAsString.put(11, "XII");

        Double maxValue = 0.0;
        JSONArray xLabel = new JSONArray();
        JSONObject tmpxLabel;

        try {
            Double dailyValue = getDailyValue(dateFrom, dateTo, ppe);
            DayType dayType = getDayType(dateFrom);

            JSONArray values = new JSONArray();
            for(int i = 1; i <= 24; i++) {
                Double value = getProfileValuePerDay(getMonth(dateFrom), dayType, i, i, ppe.getTariff().getTariffId(),
                        dailyValue, false);
                log.info("values1 :" + value);
                if(null == value) {
                    value = dailyValue;
                }
               log.info("values2 :" + value);
                if(value.doubleValue() > maxValue.doubleValue()) {
                    maxValue = value.doubleValue();
                }

                value *= 1000.0;
                log.info("values3 :" + value);
                JSONArray data = new JSONArray();
                data.put(value);
                //values.put(new JSONArray().put(value.doubleValue()));
                values.put(data);
              
                tmpxLabel = new JSONObject();
                tmpxLabel.put("text", "" + i);
                tmpxLabel.put("x", i);

                xLabel.put(tmpxLabel);
            }

            ppeUsageChartJson = new JSONObject();

            JSONObject legend = new JSONObject();
            legend.put("position", "right");
            legend.put("visible", false);
            legend.put("bg_colour", "#666666");

            JSONObject tooltip = new JSONObject();
            tooltip.put("mouse", 2);

            JSONObject yAxis = new JSONObject();
            yAxis.put("labels", new JSONObject());
            yAxis.getJSONObject("labels").put("colour", "#FFFFFF");
            yAxis.put("stroke", 2);
            yAxis.put("max", maxValue * 1000);
            yAxis.put("offset", 1);
            yAxis.put("colour", "#666666");

            JSONObject xAxis = new JSONObject();
            xAxis.put("labels", new JSONObject());
            xAxis.getJSONObject("labels").put("colour", "#FFFFFF");
            xAxis.getJSONObject("labels").put("labels", xLabel);
            xAxis.put("grid-colour", "#666666");
            xAxis.put("max", 24);
            xAxis.put("min", 1);
            xAxis.put("steps", 1);

            JSONObject element = new JSONObject();
            element.put("id", 35);
            element.put("type", "bar_stack");
            element.put("tip", "#val#");
            element.put("font-size", 15);
            element.put("alpha", 0.9);
            element.put("barwidth", 0.3);
            element.put("values", values);

            JSONObject yLegend = new JSONObject();
            yLegend.put("text", "kWh");
            yLegend.put("style", "{font-size: 18px; color: #FFFFFF}");

            JSONObject xLegend = new JSONObject();
            xLegend.put("text", "Godzina dnia");
            xLegend.put("style", "{font-size: 18px; color: #FFFFFF}");

            ppeUsageChartJson.put("y_legend", yLegend);
            ppeUsageChartJson.put("x_legend", xLegend);
            ppeUsageChartJson.put("bg_colour", "#666666");
            ppeUsageChartJson.put("is_thousand_separator_disabled", true);
            ppeUsageChartJson.put("legend", legend);
            ppeUsageChartJson.put("tooltip", tooltip);
            ppeUsageChartJson.put("y_axis", yAxis);
            ppeUsageChartJson.put("x_axis", xAxis);
            ppeUsageChartJson.put("elements", new JSONArray());
            ppeUsageChartJson.getJSONArray("elements").put(element);

            chartType = "ppeUsageChart";
        } catch (Exception e) {
            log.info("Problem while preparing daily ppe usage chart", e);
        }
    }

    /**
     * Gets the day type.
     * 
     * @param day
     *            the day
     * @return the day type
     */
    private DayType getDayType(Date day) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(day);

        if(cal.get(Calendar.DAY_OF_WEEK) == 1) {
            return DayType.SUNDAY;
        }
        if(cal.get(Calendar.DAY_OF_WEEK) < 7) {
            return DayType.MONDAY_FRIDAY;
        }

        return DayType.SATURDAY;
    }

    /**
     * Gets the month.
     * 
     * @param day
     *            the day
     * @return the month
     */
    private int getMonth(Date day) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(day);

        return cal.get(Calendar.MONTH);
    }

    private Date setMonth(Date date, int addMonth) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);

        cal.add(Calendar.MONTH, addMonth);

        return cal.getTime();
    }

    /**
     * Sets the day.
     * 
     * @param date
     *            the date
     * @param day
     *            the day
     * @return the date
     */
    public Date setDay(Date date, int day) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);

        cal.set(Calendar.DAY_OF_MONTH, day);

        return cal.getTime();
    }

    /**
     * Gets the daily value.
     * 
     * @param dateFrom
     *            the date from
     * @param dateTo
     *            the date to
     * @param ppe
     *            the ppe
     * @return the daily value
     * @throws Exception
     *             the exception
     */
    public Double getDailyValue(Date dateFrom, Date dateTo, PPE ppe) throws Exception {
        log.info("getDailyValue");

        Double result = getDailyValueFromMeter(dateFrom, dateTo, ppe);
        if(result.doubleValue() > 0) {
            log.info("result: " + result);
            return result;
        }

        result = getDailyValueFromInvoice(dateFrom, dateTo, ppe);
        if(result.doubleValue() > 0) {
            log.info("result: " + result);
            return result;
        }

        dateFrom = setDay(dateFrom, 1);
        dateTo = setDay(dateTo, 28);

        result = getDailyValueFromInvoice(dateFrom, dateTo, ppe);
        log.info("result: " + result);
        return result;
    }

    /**
     * Gets the daily value from invoice.
     * 
     * @param dateFrom
     *            the date from
     * @param dateTo
     *            the date to
     * @param ppe
     *            the ppe
     * @return the daily value from invoice
     * @throws Exception
     *             the exception
     */
    public Double getDailyValueFromInvoice(Date dateFrom, Date dateTo, PPE ppe) throws Exception {
        log.info("getDailyValueFromInvoice");

        MeasureFilter filter = new MeasureFilter();
        filter.setDateFrom(dateFrom);
        filter.setDateTo(dateTo);
        filter.setPpeId(ppe.getPpeId());
        filter.setPriority(Priority.medium);

        List<Measure> measureInvoiceList = measureDao.getMeasureByFilter(filter);

        log.info("measureInvoiceList.size - " + measureInvoiceList.size());

        Double measureValue = 0.0;
        long measureDays = 0;
        for(Measure measure : measureInvoiceList) {
            measureValue += measure.getValue().doubleValue();
            measureDays += (measure.getDateTo().getTime() - measure.getDateFrom().getTime()) / 1000 / 3600 / 24;
        }

        return measureValue / measureDays;
    }

    /**
     * Gets the daily value from meter.
     * 
     * @param dateFrom
     *            the date from
     * @param dateTo
     *            the date to
     * @param ppe
     *            the ppe
     * @return the daily value from meter
     * @throws Exception
     *             the exception
     */
    public Double getDailyValueFromMeter(Date dateFrom, Date dateTo, PPE ppe) throws Exception {
        log.info("getDailyValueFromMeter");

        MeasureFilter filter = new MeasureFilter();
        filter.setDateFrom(dateFrom);
        filter.setDateTo(dateTo);
        filter.setPpeId(ppe.getPpeId());
        filter.setPriority(Priority.high);

        List<Measure> measureMeterList = measureDao.getMeasureByFilter(filter);

        log.info("measureMeterList.size - " + measureMeterList.size());

        for(Measure measure : measureMeterList) {
            return measure.getValue();
        }

        return 0.0;
    }

    /**
     * Gets the profile value per day.
     * 
     * @param month
     *            the month
     * @param dayType
     *            the day type
     * @param minHour
     *            the min hour
     * @param maxHour
     *            the max hour
     * @param tariffId
     *            the tariff id
     * @param value
     *            the value
     * @param multiple
     *            the multiple
     * @return the profile value per day
     * @throws Exception
     *             the exception
     */
    public Double getProfileValuePerDay(Integer month, DayType dayType, Integer minHour, Integer maxHour,
            Integer tariffId, Double value, boolean multiple) throws Exception {
        log.info("getProfileValuePerDay");
        ProfileIndicatorFilter profileFilter = new ProfileIndicatorFilter();

        profileFilter.setTariffId(tariffId);
        profileFilter.setValue(value);
        profileFilter.setMonth(monthAsString.get(month));
        profileFilter.setMultiple(multiple);

        profileFilter.setMinHour(minHour);
        profileFilter.setMaxHour(maxHour);

        Double result = profileDao.getSumValueByFilter(profileFilter);
        log.info("month: " + month);
        log.info("dayType: " + dayType);
        log.info("minHour: " + minHour);
        log.info("maxHour: " + maxHour);
        log.info("tariffId: " + tariffId);
        log.info("value: " + value);
        log.info("multiple: " + multiple);
        log.info("result: " + result);        
        return result;
    }

    /**
     * On tab change profile.
     * 
     * @param event
     *            the event
     */
    public void onTabChangeProfile(TabChangeEvent event) {
        log.info("onTabChangeProfile");
        String tabId = event.getTab().getId();

        if(tabId.equals("profilePpeTab")) {
            chartType = "ppeUsageChart";
        } else if(tabId.equals("profileDevicesTab")) {
            chartType = "locationDevicesYearConsumption";
        }
    }

    /**
     * Prepare auction offers chart.
     * 
     * @param auction
     *            the auction
     * @return true, if successful
     */
    public boolean prepareAuctionOffersChart(Auction auction) {
        log.info("prepareAuctionOffersChart");

        log.info("auction is null ?");
        if(null == auction) {
            return false;
        }

        log.info("auctionOfferts is null ?");
        if(null == auction.getAuctionOffers()) {
            return false;
        }
        if(auction.getAuctionOffers().isEmpty()) {
            return false;
        }

        log.info("all OK");
        try {
            chartType = "auctionOffersChart";
            auctionOffersJson = new JSONObject();
            JSONObject xAxis = new JSONObject();
            JSONObject xAxisLabel = new JSONObject();
            JSONObject yAxis = new JSONObject();
            JSONArray elementsList = new JSONArray();
            JSONArray elementLabels = new JSONArray();
            JSONObject elementLabel = new JSONObject();
            JSONObject tooltip = new JSONObject();

            Map<Integer, JSONObject> elementsMap = new HashMap<Integer, JSONObject>();

            tooltip.put("shadow", false);
            tooltip.put("stroke", 1);
            tooltip.put("mouse", 1);
            tooltip.put("colour", "#000000");

            int x = 0;
            int colorIndex = 0;
            Double maxPrice = Double.valueOf(0.0);
            Double minPrice = auction.getAuctionOffers().get(0).getOfferValue();
            for(int index = auction.getAuctionOffers().size() - 1; index >= 0; index--) {
                AuctionOffer offer = auction.getAuctionOffers().get(index);
                log.info("offerId: " + offer.getAuctionOfferId());

                for(PriceComponentValue pcv : offer.getNotConstantPriceComponentValues()) {
                    if(null == elementsMap.get(pcv.getPriceComponent().getPriceComponentId())) {
                        JSONObject newElement = new JSONObject();
                        newElement.put("type", "line");
                        newElement.put("colour", coloursMap.get(++colorIndex));
                        newElement.put("text", getMessage(pcv.getPriceComponent().getZoneType().toString()));
                        newElement.put("font-size", 10);
                        newElement.put("width", 2);
                        newElement.put("animate", true);
                        newElement.put("on_show", new JSONObject());
                        newElement.getJSONObject("on_show").put("type", "explode");
                        newElement.put("dot-size", 1);
                        newElement.put("halo-size", 1);
                        newElement.put("values", new JSONArray());

                        elementsMap.put(pcv.getPriceComponent().getPriceComponentId(), newElement);
                    }

                    if(maxPrice.doubleValue() < pcv.getValue().doubleValue()) {
                        maxPrice = pcv.getValue().doubleValue();
                    }

                    if(minPrice.doubleValue() > pcv.getValue().doubleValue()) {
                        minPrice = pcv.getValue().doubleValue();
                    }

                    JSONObject tmpElement = elementsMap.get(pcv.getPriceComponent().getPriceComponentId());
                    JSONArray tmpElementValue = tmpElement.getJSONArray("values");
                    JSONObject tmp = new JSONObject();
                    tmp.put("value", pcv.getValue().doubleValue());
                    DecimalFormat format = new DecimalFormat("0.0000");
                    tmp.put("tip", "" + format.format(pcv.getValue().doubleValue()));

                    tmpElementValue.put(tmp);
                }

                elementLabel = new JSONObject();
                elementLabel.put("x", x++);

                elementLabel.put("text", new SimpleDateFormat("dd-MM HH:mm").format(offer.getCreatedAt()));

                elementLabels.put(elementLabel);

            }

            for(JSONObject element : elementsMap.values()) {
                elementsList.put(element);
            }

            xAxisLabel.put("tip", "Cena #val#");
            xAxisLabel.put("rotate", -45);
            xAxisLabel.put("labels", elementLabels);

            xAxis.put("min", 0);
            xAxis.put("max", auction.getAuctionOffers().size() - 1);
            xAxis.put("labels", xAxisLabel);
            xAxis.put("grid-colour", "#666666");
            xAxis.put("colour", "#666666");

            maxPrice = maxPrice.doubleValue() + 0.1;
            minPrice = (minPrice.doubleValue() - 0.1 > 0) ? (minPrice.doubleValue() - 0.1) : 0;
            yAxis.put("max", maxPrice);
            yAxis.put("min", minPrice);
            yAxis.put("steps", (maxPrice - minPrice) / 5);
            yAxis.put("grid-colour", "#666666");
            yAxis.put("colour", "#666666");

            JSONObject yLegend = new JSONObject();
            yLegend.put("text", ""); //Cena
            yLegend.put("style", "{font-size: 15px; color: #FFFFFF}");

            JSONObject xLegend = new JSONObject();
            xLegend.put("text", ""); //Data
            xLegend.put("style", "{font-size: 15px; color: #FFFFFF}");

            auctionOffersJson.put("y_legend", yLegend);
            auctionOffersJson.put("x_legend", xLegend);
            auctionOffersJson.put("elements", elementsList);
            auctionOffersJson.put("tooltip", tooltip);
            auctionOffersJson.put("x_axis", xAxis);
            auctionOffersJson.put("y_axis", yAxis);
            auctionOffersJson.put("bg_colour", "#666666");
            auctionOffersJson.put("is_thousand_separator_disabled", true);
        } catch (Exception e) {
            log.error("There was a problem while preparing auctionOffers chart: ", e);
            return false;
        }
        return true;
    }

    /**
     * Gets the message.
     * 
     * @param key
     *            the key
     * @return the message
     */
    private String getMessage(String key) {
        return BundlesUtils.getMessageResourceString("messages", key, null, Locale.getDefault());
    }

    /**
     * Checks if is prepare main page chart.
     * 
     * @return true, if is prepare main page chart
     */
    public boolean isPrepareMainPageChart() {
        chartType = "ppeStereotypeUsageChart";

        if(null == ppeStereotypeUsageChartJson) {
            return false;
        }

        return true;
    }
}