package pl.op.web.beans.auction;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Transient;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AgreementDao;
import pl.op.dao.AuctionDao;
import pl.op.dao.InvoiceDao;
import pl.op.dao.PPEDao;
import pl.op.dao.StereotypeDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionFilter;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.cloud.Cloud;
import pl.op.model.contract.Agreement;
import pl.op.model.contract.Invoice;
import pl.op.model.contract.PPE;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Tariff;
import pl.op.model.stereotype.Stereotype;
import pl.op.model.user.UserApp;
import pl.op.util.CloudUtil;
import pl.op.util.UserUtil;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class AuctionJoinedBean.
 */
@Name("op.auctionJoinedBean")
@Scope(ScopeType.SESSION)
public class AuctionJoinedBean {

    private Logger log = LoggerFactory.getLogger(AuctionJoinedBean.class);
    public static final long HOUR = 3600 * 1000;

    private Auction userAuction;
    private UserApp userApp;
    private Invoice lastInvoiceForPpe;
    private Agreement lastAgreementForPpe;

    private PPEDao ppeDao;
    private StereotypeDao stereotypeDao;
    private InvoiceDao invoiceDao;
    private AgreementDao agreementDao;

    // Filters
    private AuctionFilter auctionFilter;
    private List<PPE> userPpes;

    private Integer userPpeId;
    private PPE selectedPpe;
    private Integer findAuctions;

    /**
     * Instantiates a new auction joined bean.
     */
    public AuctionJoinedBean() {
        log.info("AuctionJoinedBean");

        initializeDao();
        initializeVars();
        initializeFilter();
    }

    /**
     * Initialize dao.
     */
    private void initializeDao() {
        log.info("initializeDao");

        ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);
        stereotypeDao = GuiceSingleton.getInstance().getInstance(StereotypeDao.class);
        invoiceDao = GuiceSingleton.getInstance().getInstance(InvoiceDao.class);
        agreementDao = GuiceSingleton.getInstance().getInstance(AgreementDao.class);
    }

    /**
     * Initialize vars.
     */
    private void initializeVars() {
        userApp = UserUtil.getLoggedUserInstance();

        userPpes = new ArrayList<PPE>();
        userPpeId = null;
        auctionFilter = new AuctionFilter();
    }

    /**
     * Initialize on load.
     */
    public void initializeOnLoad() {
        try {
            userPpes = ppeDao.getPPEsByUser(userApp);

            setDefaultUserPpeId();

            updateSelectePpe();
            updateUserAuction();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Checks if is initialized.
     * 
     * @return true, if is initialized
     */
    private boolean isInitialized() {
        if(null == userPpes) {
            return false;
        }
        if(userPpes.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Sets the default user ppe id.
     */
    private void setDefaultUserPpeId() {
        if(!userPpes.isEmpty()) {
            log.info("find user ppes => " + userPpes.size());
            userPpeId = userPpes.get(0).getPpeId();
        }
    }

    /**
     * Update selecte ppe.
     */
    private void updateSelectePpe() {
        log.info("updateSelectePpe");

        try {
            for(PPE ppe : userPpes) {
                if(ppe.getPpeId().intValue() == userPpeId.intValue()) {
                    selectedPpe = ppe;
                    updatePpeTariff();
                    updateLastInvoiceForPpe(userPpeId);
                    updateLastAgreementForPpe(userPpeId);

                    auctionFilter.updateLocationDataInCloud(selectedPpe, false, true);
                }
            }
        } catch (Exception e) {
            log.error("Problem while udate selected PPE in joinedToAuction: ", e);
        }
    }

    /**
     * Update ppe tariff.
     * 
     * @throws Exception
     *             the exception
     */
    private void updatePpeTariff() throws Exception {
        if(null == selectedPpe.getTariff()) {
            selectedPpe.setTariff(ppeDao.getActualTariff(selectedPpe));
        }
    }

    /**
     * Initialize filter.
     */
    public void initializeFilter() {
        clearUserAuction();
    }

    /**
     * Clear user auction.
     */
    public void clearUserAuction() {
        log.info("clearUserAuction");

        userAuction = new Auction();
        userAuction.setAuctionOffers(new ArrayList<AuctionOffer>());

        Cloud cloud = new Cloud();
        cloud.setTariff(new Tariff());
        cloud.setStereotype(new Stereotype());
        cloud.setAreas(new ArrayList<Area>());
        cloud.setCities(new ArrayList<City>());
        userAuction.setCloud(cloud);

    }

    /**
     * Update auction location.
     * 
     * @param ppeId
     *            the ppe id
     */
    public void updateAuctionLocation(Integer ppeId) {
        log.info("updateAuctionLocation");
        try {
            if(isNewUserPpeId(ppeId)) {
                userPpeId = ppeId;
            } else {
                userPpeId = 0;
            }

            if(canSearchAuction()) {
                updateSelectePpe();
                updateUserAuction();
            } else {
                clearUserAuction();
            }
        } catch (Exception e) {
            log.error("Problem while update userJoinedAuction: ", e);
        }
    }

    /**
     * Checks if is new user ppe id.
     * 
     * @param ppeId
     *            the ppe id
     * @return true, if is new user ppe id
     */
    private boolean isNewUserPpeId(Integer ppeId) {
        if(ppeId != null && ppeId > 0) {
            return true;
        }
        if(ppeId.intValue() == userPpeId.intValue()) {
            return false;
        }

        return false;
    }

    /**
     * Can search auction.
     * 
     * @return true, if successful
     */
    private boolean canSearchAuction() {
        if(null == userPpeId) {
            return false;
        }
        if(userPpeId < 1) {
            return false;
        }

        return true;
    }

    /**
     * Update user auction.
     */
    public void updateUserAuction() {
        log.info("Searching user auctions...");

        try {
            AuctionDao auctionDao = GuiceSingleton.getInstance().getInstance(AuctionDao.class);
            List<Auction> searchResult = auctionDao.getJoinedAuctionByPpe(selectedPpe);

            if(isAuctionOnList(searchResult)) {
                log.info("find " + searchResult.size() + " auctions");
                findAuctions = searchResult.size();

                if(null == selectedPpe.getActualInvoice()) {
                    updateLastInvoiceForPpe(selectedPpe.getPpeId());
                }

                this.userAuction = searchResult.get(0);
                this.userAuction.setActualUserInvoice(selectedPpe.getActualInvoice());
                if(canUpdateVloudVolumeInAuction()) {
                     if (this.userAuction.getCloud().getStereotype() == null || this.userAuction.getCloud().getStereotype().getStereotypeId() == null) {
                           this.userAuction.getCloud().setVolume(
                            CloudUtil.updateCloudVolumeByManual(this.userAuction.getCloud().getCloudId()));
                     } else {
                          this.userAuction.getCloud().setVolume(
                            CloudUtil.updateCloudVolume(this.userAuction.getCloud().getCloudId()));
                     }
                   
                }

            } else {
                clearUserAuction();
                findAuctions = 0;
                log.info("auctions not found");
            }
        } catch (Exception e) {
            log.error("Problem while update user auction: ", e);
        }
    }

    private boolean canUpdateVloudVolumeInAuction() {
        if(null == this.userAuction) {
            return false;
        }
        if(null == this.userAuction.getCloud()) {
            return false;
        }
        if(null == this.userAuction.getCloud().getCloudId()) {
            return false;
        }

        return true;
    }

    /**
     * Checks if is auction on list.
     * 
     * @param auctionList
     *            the auction list
     * @return true, if is auction on list
     */
    private boolean isAuctionOnList(List<Auction> auctionList) {
        if(null == auctionList) {
            return false;
        }

        if(auctionList.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Gets the auction filter.
     * 
     * @return the auction filter
     */
    public AuctionFilter getAuctionFilter() {
        return auctionFilter;
    }

    /**
     * Sets the auction filter.
     * 
     * @param auctionFilter
     *            the new auction filter
     */
    public void setAuctionFilter(AuctionFilter auctionFilter) {
        this.auctionFilter = auctionFilter;
    }

    /**
     * Gets the user app.
     * 
     * @return the user app
     */
    public UserApp getUserApp() {
        return userApp;
    }

    /**
     * Sets the user app.
     * 
     * @param userApp
     *            the new user app
     */
    public void setUserApp(UserApp userApp) {
        this.userApp = userApp;
    }

    /**
     * Gets the user ppe id.
     * 
     * @return the user ppe id
     */
    public Integer getUserPpeId() {
        if(!isInitialized()) {
            initializeOnLoad();
        }
        return userPpeId;
    }

    /**
     * Sets the user ppe id.
     * 
     * @param userPpeId
     *            the new user ppe id
     */
    public void setUserPpeId(Integer userPpeId) {
        this.userPpeId = userPpeId;
    }

    /**
     * Gets the user ppes.
     * 
     * @return the user ppes
     */
    public List<PPE> getUserPpes() {
        if(!isInitialized()) {
            initializeOnLoad();
        }
        return userPpes;
    }

    /**
     * Sets the user ppes.
     * 
     * @param userPpes
     *            the new user ppes
     */
    public void setUserPpes(List<PPE> userPpes) {
        this.userPpes = userPpes;
    }

    /**
     * Gets the stereotype dao.
     * 
     * @return the stereotype dao
     */
    public StereotypeDao getStereotypeDao() {
        return stereotypeDao;
    }

    /**
     * Sets the stereotype dao.
     * 
     * @param stereotypeDao
     *            the new stereotype dao
     */
    public void setStereotypeDao(StereotypeDao stereotypeDao) {
        this.stereotypeDao = stereotypeDao;
    }

    /**
     * Gets the last invoice for ppe.
     * 
     * @return the last invoice for ppe
     */
    @Transient
    public Invoice getLastInvoiceForPpe() {
        return lastInvoiceForPpe;
    }

    /**
     * Sets the last invoice for ppe.
     * 
     * @param lastInvoiceForPpe
     *            the new last invoice for ppe
     */
    public void setLastInvoiceForPpe(Invoice lastInvoiceForPpe) {
        this.lastInvoiceForPpe = lastInvoiceForPpe;
    }

    /**
     * Update last invoice for ppe.
     * 
     * @param id
     *            the id
     */
    public void updateLastInvoiceForPpe(Integer id) {
        try {
            log.info("update lastInvoceByPpeId to ppe #" + id);
            lastInvoiceForPpe = invoiceDao.getLastInvoiceByPpeId(id);
            if(lastInvoiceForPpe != null) {
                selectedPpe.updateActualInvoice(lastInvoiceForPpe);
                log.info("lastInvoceByPpeId #" + lastInvoiceForPpe.getInvoiceId());
            } else {
                log.info("lastInvoceByPpeId  is empty");
            }
        } catch (Exception e) {
            log.error("Problem while update last invoice for ppe: ", e);
        }
    }

    /**
     * Gets the last agreement for ppe.
     * 
     * @return the last agreement for ppe
     */
    public Agreement getLastAgreementForPpe() {
        return lastAgreementForPpe;
    }

    /**
     * Sets the last agreement for ppe.
     * 
     * @param lastAgreementForPpe
     *            the new last agreement for ppe
     */
    public void setLastAgreementForPpe(Agreement lastAgreementForPpe) {
        this.lastAgreementForPpe = lastAgreementForPpe;
    }

    /**
     * Update last agreement for ppe.
     * 
     * @param id
     *            the id
     */
    public void updateLastAgreementForPpe(Integer id) {
        try {
            log.info("update lastAgreementByPpeId to ppe #" + id);
            lastAgreementForPpe = agreementDao.getLastAgreementByPpeId(id);

            if(lastAgreementForPpe != null) {
                selectedPpe.updateActualAgreement(lastAgreementForPpe);
                log.info("lastAgreementByPpeId #" + lastAgreementForPpe.getAgreementId());
            }
        } catch (Exception e) {
            log.error("Problem while update last agreement for ppe: ", e);
        }
    }

    /**
     * Gets the agreement dao.
     * 
     * @return the agreement dao
     */
    public AgreementDao getAgreementDao() {
        return agreementDao;
    }

    /**
     * Sets the agreement dao.
     * 
     * @param agreementDao
     *            the new agreement dao
     */
    public void setAgreementDao(AgreementDao agreementDao) {
        this.agreementDao = agreementDao;
    }

    /**
     * Gets the user auction.
     * 
     * @return the user auction
     */
    public Auction getUserAuction() {
        return userAuction;
    }

    /**
     * Sets the user auction.
     * 
     * @param userAuction
     *            the new user auction
     */
    public void setUserAuction(Auction userAuction) {
        this.userAuction = userAuction;
    }

    /**
     * Checks if is ppe in auction.
     * 
     * @return true, if is ppe in auction
     */
    public boolean isPpeInAuction() {
        updateUserAuction();

        if(null == userAuction) {
            return false;
        }

        return true;
    }

    /**
     * Gets the find auctions.
     * 
     * @return the find auctions
     */
    public Integer getFindAuctions() {
        return findAuctions;
    }

    /**
     * Sets the find auctions.
     * 
     * @param findAuctions
     *            the new find auctions
     */
    public void setFindAuctions(Integer findAuctions) {
        this.findAuctions = findAuctions;
    }
}