package pl.op.web.beans.wizard;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.faces.event.AjaxBehaviorEvent;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.DeviceCategoryDao;
import pl.op.dao.DeviceTypeDao;
import pl.op.model.contract.Location;
import pl.op.model.device.Device;
import pl.op.model.device.DeviceCategory;
import pl.op.model.device.DeviceType;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

import com.google.common.collect.HashBasedTable;

/**
 * The Class WizardDeviceBean.
 */
@Name("op.wizardDeviceBean")
@Scope(ScopeType.SESSION)
public class WizardDeviceBean implements Serializable {

    private static final long serialVersionUID = 7657279753756327544L;

    private WizardLocationBean wizardLocationBean;

    private List<Location> locationList;
    private List<DeviceType> deviceTypes;
    private List<DeviceCategory> deviceCategories;
    private List<Integer> selectedDeviceTypes;

    private Integer locationId;
    private Location location;
    private int activeIndex;
    private com.google.common.collect.Table<Integer, Integer, Integer> deviceTypesCategory;
    private DeviceCategoryDao deviceCategoryDao;
    private DeviceTypeDao deviceTypeDao;

    /**
     * Instantiates a new wizard device bean.
     */
    public WizardDeviceBean() {
        log.info("WizardDeviceBean constructor");
        initializeDao();
        initializeVars();
    }

    private Logger log = LoggerFactory.getLogger(WizardDeviceBean.class);

    /**
     * Initialize dao.
     */
    private void initializeDao() {
        deviceCategoryDao = GuiceSingleton.getInstance().getInstance(DeviceCategoryDao.class);
        deviceTypeDao = GuiceSingleton.getInstance().getInstance(DeviceTypeDao.class);
    }

    /**
     * Initialize vars.
     */
    private void initializeVars() {
        wizardLocationBean = ComponentLookup.lookupComponent("op.wizardLocationBean");
        locationList = wizardLocationBean.getLocationList();
        location = new Location();
        location.setDevices(new ArrayList<Device>());

        deviceTypes = new ArrayList<DeviceType>();
        selectedDeviceTypes = new ArrayList<Integer>();
        deviceTypesCategory = HashBasedTable.create();
        
        activeIndex = 0;
    }

    /**
     * Initialize on load.
     */
    private void initializeOnLoad() {
        try {
            if(null == deviceCategories) {
                deviceCategories = deviceCategoryDao.getDeviceCategories();
            }
        } catch (Exception e) {
            log.error("Problem while initialize wizard device bean: ", e);
        }
    }

    /**
     * Gets the selected device types.
     * 
     * @return the selected device types
     */
    public List<Integer> getSelectedDeviceTypes() {
        return selectedDeviceTypes;
    }

    /**
     * Sets the selected device types.
     * 
     * @param selectedDeviceTypes
     *            the new selected device types
     */
    public void setSelectedDeviceTypes(List<Integer> selectedDeviceTypes) {
        this.selectedDeviceTypes = selectedDeviceTypes;
    }

    /**
     * Selected items changed.
     * 
     * @param ev
     *            the ev
     */
    public void selectedItemsChanged(AjaxBehaviorEvent ev) {
        log.info("selectedItemsChanged");
        log.info("location: #" + location.getLocationId() + "; locationId: " + locationId);

        List<Integer> oldValue = new ArrayList<Integer>(deviceTypesCategory.row(activeIndex).values());
        List<Integer> newValue = selectedDeviceTypes;
        deviceTypesCategory.row(activeIndex).values().clear();

        for(int i = 0; i < newValue.size(); i++) {
            deviceTypesCategory.put(activeIndex, i, newValue.get(i));
        }

        Integer selectedItem = 0;
        boolean selectedItemRemoved = true;
        if(oldValue.size() > newValue.size()) {
            oldValue = new ArrayList<Integer>(oldValue);
            oldValue.removeAll(newValue);
            if (!oldValue.isEmpty()) {
                selectedItem = oldValue.iterator().next();    
            } else {
                log.info("oldValue is empty");
            }           
        } else {
            newValue = new ArrayList<Integer>(newValue);
            newValue.removeAll(oldValue);
            if (!newValue.isEmpty()) {
                selectedItem = newValue.iterator().next();
            } else log.info("newValu is empty");
            selectedItemRemoved = false;
        }

        if(selectedItemRemoved) {
            for(int i = 0; i < location.getDevices().size(); i++) {
                if(location.getDevices().get(i).getDeviceType().getDeviceTypeId().intValue() == selectedItem.intValue()) {
                    location.getDevices().remove(i);
                    break;
                }
            }
        } else {
            if (!newValue.isEmpty()) {
                Device device = new Device();
                DeviceType deviceType = new DeviceType();
                try {
                    deviceType = deviceTypeDao.getDeviceTypeById(selectedItem);
                    deviceType.setTabId(activeIndex);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                device.setDeviceType(deviceType);
                location.getDevices().add(device);
            }
        }

    }

    /**
     * Count daily consumption.
     * 
     * @param id
     *            the id
     */
    public void countDailyConsumption(Integer id) {
        log.info("countDailyConsumption: #" + id);
        log.info("location: " + location.getLocationId() + "; locationId: " + locationId);

        try {
            Device device = getDeviceFromList(id);
            if(null != device) {
                if(device.getDevicePower() == null || device.getQuantity() == null) {
                    String message = BundlesUtils.getMessageResourceString("messages", "invalid.data", null,
                            Locale.getDefault());
                    FacesMessages.instance().add(message + " (" + device.getDeviceType().getName() + ")");

                    return;
                }

                setDefaultValueToDevice(device);
                BigDecimal cons = calculateDeviceDailyConsumption(device);
                device.setDailyConsumption(cons);
            }
        } catch (Exception e) {
            log.error("Problem while count daily consuption: ", e);
        }
        restoreDevices();
    }

    /**
     * Gets the device from list.
     * 
     * @param id
     *            the id
     * @return the device from list
     */
    private Device getDeviceFromList(Integer id) {
        log.info("get device(#" + id + ") from location(#" + location.getLocationId() + ") list");
        for(int i = 0; i < location.getDevices().size(); i++) {
            Device device = location.getDevices().get(i);
            if(device.getDeviceType().getDeviceTypeId().intValue() == id.intValue()) {
                return device;
            }
        }

        return null;
    }

    /**
     * Sets the default value to device.
     * 
     * @param device
     *            the new default value to device
     */
    private void setDefaultValueToDevice(Device device) {
        log.info("setDefaultValueToDevice");

        if(device.getHours() == null) {
            device.setHours(0);
        }
        if(device.getMinutes() == null) {
            device.setMinutes(0);
        }
        if(device.getQuantity() == null) {
            device.setQuantity(1);
        }
    }

    /**
     * Calculate device daily consumption.
     * 
     * @param device
     *            the device
     * @return the big decimal
     */
    private BigDecimal calculateDeviceDailyConsumption(Device device) {
        log.info("calculateDeviceDailyConsumption: #" + device.getDeviceType().getName());

        double usageHours = device.getHours().doubleValue() + (device.getMinutes().doubleValue() / 60);
        double deviceUsage = device.getDevicePower() * usageHours;
        double consumption = (deviceUsage * device.getQuantity().doubleValue()) / 1000;
        log.info("consumption:" + consumption);

        return new BigDecimal(consumption, MathContext.DECIMAL64).setScale(2, RoundingMode.HALF_DOWN);
    }

    /**
     * On location select.
     * 
     * @param ev
     *            the ev
     */
    public void onLocationSelect(AjaxBehaviorEvent ev) {
        log.info("onLocationSelect: " + locationId);
        if(locationId == null) {
            this.location = new Location();
        } else {
            updateLocationById();
        }
        if(this.location.getDevices() == null) {
            this.location.setDevices(new ArrayList<Device>());
        }

        restoreDevices();
    }

    /**
     * Update location by id.
     */
    private void updateLocationById() {
        for(int i = 0; i < locationList.size(); i++) {
            if(locationList.get(i).getLocationId().intValue() == locationId.intValue()) {
                this.location = locationList.get(i);
                log.info("Actual location: #" + this.location.getLocationId());
                break;
            }
        }
    }

    /**
     * Restore devices.
     */
    private void restoreDevices() {
        log.info("restoreDevices");

        selectedDeviceTypes = new ArrayList<Integer>();
        deviceTypesCategory.clear();

        List<Device> locationDevices = this.location.getDevices();
        log.info("locationDevices.size: " + locationDevices.size());
        for(int i = 0; i < locationDevices.size(); i++) {
            Device device = locationDevices.get(i);
            log.info("device.getDeviceType().getTabId(): " + device.getDeviceType().getTabId());
            int nexCol = deviceTypesCategory.row(device.getDeviceType().getTabId()).size() + 1;
            log.info("nexCol: " + nexCol);

            setDefaultValueToDevice(device);

            deviceTypesCategory
                    .put(device.getDeviceType().getTabId(), nexCol, device.getDeviceType().getDeviceTypeId());

            selectedDeviceTypes.add(device.getDeviceType().getDeviceTypeId());

            log.info("added deviceTypeId: " + device.getDeviceType().getDeviceTypeId());
            log.info("selectedDeviceTypes: " + selectedDeviceTypes.toString());
        }
    }

    /**
     * Clear device.
     */
    public void clearDevice() {
        log.info("clearDevice");

        //locationId = null;
        //location = new Location();
        location.setDevices(new ArrayList<Device>());
    }

    /**
     * Adds the devices.
     */
    public void addDevices() {
        if (location == null) return ;
        for(int i = 0; i < locationList.size(); i++) {
            if(locationList.get(i).getLocationId().intValue() == location.getLocationId().intValue()) {
                locationList.set(i, location);
                restoreDevices();
                displayMessage("messages.save.complete");
                break;
            }
        }
    }

    /**
     * Display message.
     * 
     * @param key
     *            the key
     */
    private void displayMessage(String key) {
        String message = BundlesUtils.getMessageResourceString("messages", key, null, Locale.getDefault());
        FacesMessages.instance().add(message);
    }

    /**
     * Gets the location list.
     * 
     * @return the location list
     */
    public List<Location> getLocationList() {
        return locationList;
    }

    /**
     * Sets the location list.
     * 
     * @param locationList
     *            the new location list
     */
    public void setLocationList(List<Location> locationList) {
        this.locationList = locationList;
    }

    /**
     * Gets the location id.
     * 
     * @return the location id
     */
    public Integer getLocationId() {
        if(locationList.size() > 0 && locationId == null) {
            locationId = locationList.get(0).getLocationId();
            location = locationList.get(0);
        }
        return locationId;
    }

    /**
     * Sets the location id.
     * 
     * @param locationId
     *            the new location id
     */
    public void setLocationId(Integer locationId) {
        this.locationId = locationId;
    }

    /**
     * Gets the location.
     * 
     * @return the location
     */
    public Location getLocation() {
        return location;
    }

    /**
     * Sets the location.
     * 
     * @param location
     *            the new location
     */
    public void setLocation(Location location) {
        this.location = location;
    }

    /**
     * Gets the device types.
     * 
     * @param deviceCategoryId
     *            the device category id
     * @return the device types
     */
    public List<DeviceType> getDeviceTypes(Integer deviceCategoryId) {
        List<DeviceType> devTypeList = new ArrayList<DeviceType>();
        try {
            devTypeList = deviceTypeDao.getDeviceTypesByCategory(deviceCategoryId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return devTypeList;
    }

    /**
     * Sets the device types.
     * 
     * @param deviceTypes
     *            the new device types
     */
    public void setDeviceTypes(List<DeviceType> deviceTypes) {
        this.deviceTypes = deviceTypes;
    }

    /**
     * Gets the device categories.
     * 
     * @return the device categories
     */
    public List<DeviceCategory> getDeviceCategories() {
        initializeOnLoad();
        return deviceCategories;
    }

    /**
     * Sets the device categories.
     * 
     * @param deviceCategories
     *            the new device categories
     */
    public void setDeviceCategories(List<DeviceCategory> deviceCategories) {
        this.deviceCategories = deviceCategories;
    }

    /**
     * Gets the active index.
     * 
     * @return the active index
     */
    public int getActiveIndex() {
        return activeIndex;
    }

    /**
     * Sets the active index.
     * 
     * @param activeIndex
     *            the new active index
     */
    public void setActiveIndex(int activeIndex) {
        this.activeIndex = activeIndex;
    }
}