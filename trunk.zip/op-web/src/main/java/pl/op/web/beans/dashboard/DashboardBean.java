package pl.op.web.beans.dashboard;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.component.dashboard.Dashboard;
import org.primefaces.context.RequestContext;
import org.primefaces.event.DashboardReorderEvent;
import org.primefaces.model.DashboardColumn;
import org.primefaces.model.DashboardModel;
import org.primefaces.model.DefaultDashboardColumn;
import org.primefaces.model.DefaultDashboardModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AgreementDao;
import pl.op.dao.DashboardItemDao;
import pl.op.dao.DistributorDao;
import pl.op.dao.MessageDao;
import pl.op.dao.PPEDao;
import pl.op.model.contract.Agreement;
import pl.op.model.contract.DurationType;
import pl.op.model.contract.PPE;
import pl.op.model.dashboard.DashboardItem;
import pl.op.model.dashboard.DashboardItemUser;
import pl.op.model.dict.Distributor;
import pl.op.model.dict.MessageRecommendations;
import pl.op.model.user.UserApp;
import pl.op.model.user.UserRole;
import pl.op.web.beans.AdminBean;
import pl.op.web.beans.ReportBean;
import pl.op.web.beans.auction.AuctionBean;
import pl.op.web.beans.auction.AuctionOfferBean;
import pl.op.web.beans.bonus.BonusBean;
import pl.op.web.beans.cloud.CloudBean;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.beans.dictionary.TodoBean;
import pl.op.web.beans.log.PPEBean;
import pl.op.web.common.ComponentLookup;
import pl.op.web.common.DateUtil;
import pl.op.web.common.DateUtil.DateUtilReturn;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class DashboardBean.
 */
@Name("op.dashboardBean")
@Scope(ScopeType.SESSION)
public class DashboardBean {

    /** The refresh interval. */
    private static int REFRESH_INTERVAL = 5; // minutes

    /** The dashboard items. */
    private List<DashboardItem> dashboardItems = new ArrayList<DashboardItem>();

    /** The active dashboard items. */
    private List<DashboardItem> activeDashboardItems = new ArrayList<DashboardItem>();

    /** The user dashboard items. */
    private List<DashboardItem> userDashboardItems = new ArrayList<DashboardItem>();

    /** The dashboard items map. */
    private Map<String, DashboardItem> dashboardItemsMap = new HashMap<String, DashboardItem>();

    /** The user dashboard items map. */
    private Map<String, DashboardItemUser> userDashboardItemsMap = new HashMap<String, DashboardItemUser>();

    /** The active dashboard items map. */
    private Map<String, DashboardItem> activeDashboardItemsMap = new HashMap<String, DashboardItem>();

    /** The ppe list. */
    private List<PPE> ppeList;

    /** The select ppe. */
    private List<SelectItem> selectPPE;

    /** The select chart ppe. */
    private List<SelectItem> selectChartPPE;

    /** The select operators. */
    private List<SelectItem> selectOperators;

    /** The selected ppe. */
    private Integer selectedPPE;

    /** The selected next auction ppe. */
    private Integer selectedNextAuctionPPE;

    /** The selected agreement ppe. */
    private Integer selectedAgreementPPE;

    /** The selected chart ppe. */
    private Integer selectedChartPPE = 0;

    /** The agreement date. */
    private String agreementDate;

    /** The next auction date. */
    private String nextAuctionDate;

    /** The chart ppe. */
    private PPE chartPPE;

    /**
     * Gets the select ppe.
     * 
     * @return the select ppe
     */
    public List<SelectItem> getSelectPPE() {
        return selectPPE;
    }

    /**
     * Sets the select ppe.
     * 
     * @param selectPPE
     *            the new select ppe
     */
    public void setSelectPPE(List<SelectItem> selectPPE) {
        this.selectPPE = selectPPE;
    }

    /** The chart date from. */
    private Date chartDateFrom = new Date();

    /** The chart date to. */
    private Date chartDateTo = new Date();

    /** The model. */
    private DashboardModel model;

    /** The model active. */
    private DashboardModel modelActive;

    /** The model list. */
    private DashboardModel modelList;

    /** The model unpinnable. */
    private DashboardModel modelUnpinnable;

    /** The dashboard. */
    private Dashboard dashboard;

    /** The dashboard item dao. */
    private DashboardItemDao dashboardItemDao;

    /** The message dao. */
    private MessageDao messageDao;

    /** The distributor dao. */
    private DistributorDao distributorDao;

    /** The agreement dao. */
    private AgreementDao agreementDao;

    /** The message count. */
    private int messageCount = 13;

    /** The auctions count. */
    private int auctionsCount = 10;

    /** The closed auctions count. */
    private int closedAuctionsCount = 8;

    /** The open auctions count. */
    private int openAuctionsCount = 7;

    /** The blocked auctions count. */
    private int blockedAuctionsCount = 9;

    /** The clouds count. */
    private int cloudsCount = 11;

    /** The users count. */
    private int usersCount = 123;

    /** The receivers count. */
    private int receiversCount = 23;

    /** The dashboard items size. */
    private int dashboardItemsSize = 0;

    /** The points count. */
    private int pointsCount = 0;

    /** The distributor. */
    private String distributor;

    /** The distributor rss url. */
    private String distributorRSSUrl;

    /** The distributors. */
    private List<Distributor> distributors = new ArrayList<Distributor>();

    /** The distributors list. */
    private List<Distributor> distributorsList = new ArrayList<Distributor>();

    /** The distributors map. */
    private Map<String, Distributor> distributorsMap = new HashMap<String, Distributor>();

    /** The todo list. */
    private List<String> todoList;

    /** The cloud list. */
    private List<String> cloudList;

    /** The offers search input text. */
    private String offersSearchInputText = "";

    /** The ppe search input text. */
    private String ppeSearchInputText = "";

    /** The seller search input text. */
    private String sellerSearchInputText = "";

    /** The user. */
    private UserApp user;

    /** The refreshable. */
    private boolean refreshable;

    /** The refreshed time. */
    private Date refreshedTime = new Date();

    /** The log. */
    private Logger log = LoggerFactory.getLogger(DashboardBean.class);

    /** The admin bean. */
    @In(value = "#{op.adminBean}", scope = ScopeType.SESSION, required = true)
    private AdminBean adminBean;

    /** The cloud bean. */
    @In(value = "#{op.cloudBean}", scope = ScopeType.SESSION, required = true)
    private CloudBean cloudBean;

    /** The auction bean. */
    @In(value = "#{op.auctionBean}", scope = ScopeType.SESSION, required = true)
    private AuctionBean auctionBean;

    /** The report bean. */
    @In(value = "#{op.reportBean}", scope = ScopeType.SESSION, required = true)
    private ReportBean reportBean;

    /** The ppe bean. */
    @In(value = "#{op.ppeBean}", scope = ScopeType.SESSION, required = true)
    private PPEBean ppeBean;

    /** The dictionary bean. */
    @In(value = "#{op.dictionaryBean}", scope = ScopeType.SESSION, required = true)
    private DictionaryBean dictionaryBean;

    /** The ppe dao. */
    private PPEDao ppeDao;

    /** The todo bean. */
    @In(value = "#{op.todoBean}", scope = ScopeType.SESSION, required = true)
    private TodoBean todoBean;

    /** The bonus bean. */
    @In(value = "#{op.bonusBean}", scope = ScopeType.SESSION, required = true)
    private BonusBean bonusBean;

    /** The auction offer bean. */
    @In(value = "#{op.auctionOfferBean}", scope = ScopeType.SESSION, required = true)
    private AuctionOfferBean auctionOfferBean;

    /**
     * Instantiates a new dashboard bean.
     */
    public DashboardBean() {
        preinitialize();
        initialize();
    }

    /**
     * Preinitialize.
     */
    private void preinitialize() {
        dashboardItemDao = GuiceSingleton.getInstance().getInstance(DashboardItemDao.class);
        messageDao = GuiceSingleton.getInstance().getInstance(MessageDao.class);
        ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);
        distributorDao = GuiceSingleton.getInstance().getInstance(DistributorDao.class);
        agreementDao = GuiceSingleton.getInstance().getInstance(AgreementDao.class);

        adminBean = ComponentLookup.lookupComponent("op.adminBean");
        cloudBean = ComponentLookup.lookupComponent("op.cloudBean");
        auctionBean = ComponentLookup.lookupComponent("op.auctionBean");
        ppeBean = ComponentLookup.lookupComponent("op.ppeBean");
        todoBean = ComponentLookup.lookupComponent("op.todoBean");
        bonusBean = ComponentLookup.lookupComponent("op.bonusBean");
        reportBean = ComponentLookup.lookupComponent("op.reportBean");
        dictionaryBean = ComponentLookup.lookupComponent("op.dictionaryBean");
    }

    /**
     * Initialize.
     */
    private void initialize() {

        try {

            user = adminBean.getUserLog();
            messageCount = messageDao.unreadMessagesCounter(user.getUserId());
            usersCount = adminBean.getUsers().size();
            auctionsCount = auctionBean.getAuctionsCount();
            closedAuctionsCount = auctionBean.getClosedAuctionsCount();
            openAuctionsCount = auctionBean.getOpenAuctionsCount();
            blockedAuctionsCount = auctionBean.getBlockedAuctionsCount();
            cloudsCount = cloudBean.cloudsCount();
            todoBean.prepareTodo();
            List<MessageRecommendations> todo = todoBean.getMessageRecommendations();
            todoList = new ArrayList<String>();
            for(MessageRecommendations mr : todo) {
                todoList.add(mr.getContent());
            }

            distributors = distributorDao.getDistributors();
            distributorsList = new ArrayList<Distributor>();
            for(Distributor di : distributors) {
                distributorsMap.put(di.getName(), di);
                if(di.getHasRSS() != null && di.getHasRSS())
                    distributorsList.add(di);
            }
            log.info("distributorsList.size(): " + distributorsList.size());
            if(distributorsList != null && distributorsList.size() > 0)
                distributorRSSUrl = distributorsList.get(0).getRSS();

            /*
             * List<Cloud> clouds = cloudBean.getClouds(); int i = 0; for (Cloud
             * cloud : clouds) { cloudList.add(cloud.getName()); i++; if (i > 4)
             * break; }
             */

            refreshPointsCounter();

            ppeList = ppeDao.getPPEsByUser(user);
            if(!user.getUserRole().equals(UserRole.admin) && !user.getUserRole().equals(UserRole.salesman)
                    && !user.getUserRole().equals(UserRole.operator)) {
                fillSelectPPES();
            }

            if(ppeList != null && ppeList.size() > 0) {
                selectedAgreementPPE = ppeList.get(0).getPpeId();
                selectedNextAuctionPPE = ppeList.get(0).getPpeId();
                refreshAgreementDate();
                refreshNextAuctionDate();
            }

        } catch (Exception e) {
            log.error("Problem while retrieving data: ", e);
        }

        /*
         * for(int i =0;i<10;i++){ DashboardItem di = new DashboardItem();
         * di.setDashboardItemName("testowy gadżet");
         * activeDashboardItems.add(di); }
         */

        model = new DefaultDashboardModel();
        modelActive = new DefaultDashboardModel();
        modelList = new DefaultDashboardModel();
        modelUnpinnable = new DefaultDashboardModel();
        setModelUnpinnable(new DefaultDashboardModel());
        DashboardColumn columnUnpinnable = new DefaultDashboardColumn();
        DashboardColumn column1 = new DefaultDashboardColumn();
        DashboardColumn column2 = new DefaultDashboardColumn();
        DashboardColumn columnList1 = new DefaultDashboardColumn();
        DashboardColumn columnList2 = new DefaultDashboardColumn();
        DashboardColumn columnActive = new DefaultDashboardColumn();

        try {
            dashboardItems = dashboardItemDao.getDashboardItems();

            setDashboardItemsSize(dashboardItems.size());

            userDashboardItems = dashboardItemDao.getUserDashboardItems(user);

            int i = 1;

            for(DashboardItem di : dashboardItems) {

                if(userDashboardItems == null) {
                    userDashboardItems = new ArrayList<DashboardItem>();
                }

                if(userDashboardItems == null || userDashboardItems.size() == 0) {
                    dashboardItemDao.saveDashboardItemUser(di.getDashboardItemId(), user.getUserId(), false);
                }
                dashboardItemsMap.put(di.getDashboardItemShortName(), di);

                // log.error("Adding dashboard item user: " +
                // di.getDashboardItemUser().getIsDashboardItemUserActive());

                if(i <= 8)
                    column1.addWidget(di.getDashboardItemShortName());
                else
                    column2.addWidget(di.getDashboardItemShortName());
                i++;
            }

            if(userDashboardItems.size() == 0)
                userDashboardItems = dashboardItemDao.getUserDashboardItems(user);

            List<DashboardItemUser> dashboardItemUsers = dashboardItemDao.getDashboardItemUsersByUserId(user
                    .getUserId());

            // log.info("dashboardItemUsers.size(): " +
            // dashboardItemUsers.size());

            for(DashboardItemUser diu : dashboardItemUsers) {

                // log.warn("putting on map: "
                // + diu.getDashboardItem().getDashboardItemShortName());

                userDashboardItemsMap.put(diu.getDashboardItem().getDashboardItemShortName(), diu);
            }

            int j = 1;
            for(DashboardItem di : dashboardItems) {
                if(!getDashboardItemUserActive(di) && checkDashboardItemPermission(di) && !di.getUnpinnable()) {
                    j++;
                }
            }

            i = 1;
            for(DashboardItem di : dashboardItems) {
                if(!getDashboardItemUserActive(di) && checkDashboardItemPermission(di) && !di.getUnpinnable()) {
                    if(i <= Math.ceil(j / 2))
                        columnList1.addWidget(di.getDashboardItemShortName());
                    else
                        columnList2.addWidget(di.getDashboardItemShortName());
                    i++;
                } else if(!getDashboardItemUserActive(di) && checkDashboardItemPermission(di) && di.getUnpinnable()) {
                    // log.warn("unpinnable: " +
                    // di.getDashboardItemShortName());
                    columnUnpinnable.addWidget("unpinnable__" + di.getDashboardItemShortName());
                }

            }

            activeDashboardItems = dashboardItemDao.getUserDashboardItems(user);

            i = 1;
            for(DashboardItem di : activeDashboardItems) {
                activeDashboardItemsMap.put(di.getDashboardItemShortName(), di);
                columnActive.addWidget(di.getDashboardItemShortName());
            }

        } catch (Exception e) {
            log.error("There was a problem while retrieving dashboardItems: ", e);
        }

        modelActive.addColumn(columnActive);

        modelUnpinnable.addColumn(columnUnpinnable);

        modelList.addColumn(columnList1);
        modelList.addColumn(columnList2);

        model.addColumn(column1);
        model.addColumn(column2);

    }

    /**
     * Refresh chart.
     */
    public void refreshChart() {

        if(ppeList != null && ppeList.size() > 0) {

            if(selectedChartPPE.intValue() > 0) {

                for(PPE ppeEntry : ppeList) {
                    if(selectedChartPPE.intValue() == ppeEntry.getPpeId())
                        chartPPE = ppeEntry;
                }

            } else {
                chartPPE = ppeList.get(0);
            }
            chartPPE = ppeBean.preparePPEForChart(chartPPE);
            reportBean.preparePpeStereotypeUsageChart(chartPPE);

            chartDateFrom.setTime(chartDateFrom.getTime() - 1000 * 60 * 60 * 24 * 365);

            Calendar c = GregorianCalendar.getInstance();
            c.set(2014, 1, 1);
            chartDateFrom = c.getTime();
            c.set(2014, 12, 31);
            chartDateTo = c.getTime();
        }

    }

    /**
     * Refresh boxes.
     */
    public void refreshBoxes() {
        try {
            log.info("refreshing boxes...");
            refreshPointsCounter();
            refreshAuctionCount();
            cloudsCount = cloudBean.cloudsCount();
        } catch (Exception e) {
            log.error("There was a problem while refreshing boxes: ", e);
        }
    }

    public void refreshAuctionCount() {
        auctionsCount = auctionBean.getAuctionsCount();
        closedAuctionsCount = auctionBean.getClosedAuctionsCount();
        openAuctionsCount = auctionBean.getOpenAuctionsCount();
        blockedAuctionsCount = auctionBean.getBlockedAuctionsCount();
    }

    /**
     * Are boxes refreshable.
     * 
     * @return true, if successful
     */
    private boolean areBoxesRefreshable() {
        if(DateUtil.timeBetween(refreshedTime, new Date(), DateUtilReturn.MINUTES) >= REFRESH_INTERVAL) {
            refreshedTime = new Date();
            refreshBoxes();
            return true;
        }
        return false;
    }

    /**
     * Refresh next auction date.
     */
    public void refreshNextAuctionDate() {

        PPE ppe = null;

        for(PPE ppeEntry : ppeList) {
            if(selectedNextAuctionPPE.intValue() == ppeEntry.getPpeId())
                ppe = ppeEntry;
        }

        if(ppe == null)
            return;

        Agreement agreement;
        try {
            agreement = agreementDao.getLastAgreementByPpeId(ppe.getPpeId());

            DurationType dt = agreement.getDurationType();
            if(!dt.equals(DurationType.fixed)) {
                nextAuctionDate = "bezterminowo";

            } else {

                Date referenceDate = agreement.getDateTo();
                Calendar c = Calendar.getInstance();
                c.setTime(referenceDate);
                c.add(Calendar.MONTH, -dictionaryBean.getNextAuctionMonthsThreshold());
                referenceDate = c.getTime();
                if(referenceDate.before(agreement.getDateFrom()))
                    nextAuctionDate = DateUtil.outputDate(agreement.getDateFrom(), "dd-MM-yyyy");
                else
                    nextAuctionDate = DateUtil.outputDate(referenceDate, "dd-MM-yyyy");
            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    /**
     * Refresh agreement date.
     */
    public void refreshAgreementDate() {

        PPE ppe = null;

        for(PPE ppeEntry : ppeList) {
            if(selectedAgreementPPE.intValue() == ppeEntry.getPpeId())
                ppe = ppeEntry;
        }

        if(ppe == null)
            return;

        Agreement agreement;
        try {
            agreement = agreementDao.getLastAgreementByPpeId(ppe.getPpeId());

            DurationType dt = agreement.getDurationType();
            if(!dt.equals(DurationType.fixed)) {
                agreementDate = "bezterminowo";

            } else {
                agreementDate = DateUtil.outputDate(agreement.getDateTo(), "dd-MM-yyyy");
            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    /**
     * Refresh pp es.
     */
    public void refreshPPEs() {
        try {
            ppeList = ppeDao.getPPEsByUser(user);
            fillSelectPPES();
        } catch (Exception e) {
            log.error("There has been an error while refreshing ppes: ", e);
        }
    }

    /**
     * Refresh points counter.
     */
    public void refreshPointsCounter() {
        pointsCount = bonusBean.getTotalPoints(user);
    }

    /**
     * Gets the model list.
     * 
     * @return the model list
     */
    public DashboardModel getModelList() {
        return modelList;
    }

    /**
     * Sets the model list.
     * 
     * @param modelList
     *            the new model list
     */
    public void setModelList(DashboardModel modelList) {
        this.modelList = modelList;
    }

    /**
     * Toggle role rule.
     * 
     * @param dashboardShortName
     *            the dashboard short name
     * @param roleName
     *            the role name
     */
    public void toggleRoleRule(String dashboardShortName, String roleName) {

        DashboardItem di = dashboardItemsMap.get(dashboardShortName);
        // di.setRole(Integer.parseInt(binaryStr, 2));
        if(roleName.equals("roleUser"))
            di.setRoleUser(!di.getRoleUser());
        if(roleName.equals("roleOperator"))
            di.setRoleOperator(!di.getRoleOperator());
        if(roleName.equals("roleSalesman"))
            di.setRoleSalesman(!di.getRoleSalesman());
        if(roleName.equals("roleUserJunior"))
            di.setRoleUserJunior(!di.getRoleUserJunior());

        // log.warn("toggleRoleRule: " + roleName);

        // di.setRoleRule(Integer.parseInt(binaryStr, 2));
        updateDashboardItem(di);

        // initialize();

    }

    /**
     * Reinit rss.
     */
    public void reinitRSS() {
        log.info(distributor);
        distributorRSSUrl = distributorsMap.get(distributor).getRSS();
    }

    /**
     * Convert role to value.
     * 
     * @param value
     *            the value
     * @param position
     *            the position
     * @return the boolean
     */
    public Boolean convertRoleToValue(Integer value, int position) {
        String valuesStr = StringUtils.leftPad(Integer.toBinaryString(value), 4, '0');

        String retStr = "";
        if(position < 3)
            retStr = valuesStr.substring(position, position + 1);
        else
            retStr = valuesStr.substring(position);
        return BooleanUtils.toBoolean(retStr, "1", "0");
    }

    /**
     * Gets the dashboard item user active.
     * 
     * @param di
     *            the di
     * @return the dashboard item user active
     */
    public Boolean getDashboardItemUserActive(DashboardItem di) {
        return userDashboardItemsMap.get(di.getDashboardItemShortName()).getIsDashboardItemUserActive();
    }

    /**
     * Fill select ppes.
     */
    private void fillSelectPPES() {
        selectPPE = new ArrayList<SelectItem>();
        for(PPE item : ppeList) {
            selectPPE.add(new SelectItem(item.getPpeId(), item.getObjectType()));
        }

        /*
         * setSelectChartPPE(new ArrayList<SelectItem>()); for (PPE item :
         * ppeList) { selectPPE.add(new SelectItem(item.getPpeId(),
         * item.getNumber())); }
         */

        refreshChart();

        // reportBean.preparePpeUsageChart(chartPPE, "month", chartDateFrom,
        // chartDateTo);

    }

    /**
     * Check dashboard item permission.
     * 
     * @param di
     *            the di
     * @return the boolean
     */
    public Boolean checkDashboardItemPermission(DashboardItem di) {

        UserRole role = user.getUserRole();

        // log.warn("user role: " + role + " " + di.getRoleUser());

        if(role.equals(UserRole.user))
            return di.getRoleUser();
        else if(role.equals(UserRole.operator))
            return di.getRoleOperator();
        else if(role.equals(UserRole.salesman))
            return di.getRoleSalesman();
        else if(role.equals(UserRole.user_junior))
            return di.getRoleUserJunior();
        else
            return false;

    }

    /**
     * Toggle is active item.
     * 
     * @param di
     *            the di
     */
    public void toggleIsActiveItem(DashboardItem di) {
        di.setIsActive(!di.getIsActive());
        // log.warn("toggleIsActiveItem(DashboardItem di): " +
        // di.getIsActive());
        updateDashboardItem(di);
        // RequestContext.getCurrentInstance().update("formListAdmin__" +
        // dashboardShortName);
    }

    /**
     * Toggle is active user item.
     * 
     * @param di
     *            the di
     * @param selected
     *            the selected
     */
    public void toggleIsActiveUserItem(DashboardItem di, Boolean selected) {
        log.info("toggleIsActiveUserItem: " + selected);
        updateDashboardUserItem(di, selected);
        initialize();
        RequestContext.getCurrentInstance().update("formList");
    }

    /**
     * Update dashboard user item.
     * 
     * @param di
     *            the di
     * @param selected
     *            the selected
     */
    private void updateDashboardUserItem(DashboardItem di, Boolean selected) {
        try {
            log.info("updateDashboardUserItem(di, selected); : " + selected);
            dashboardItemDao.updateDashboardItemUser(di.getDashboardItemId(), user.getUserId(), selected);
        } catch (Exception e) {
            log.error("There was a problem while updating dashboardItemUser: ", e);
        }
    }

    /**
     * Update dashboard item.
     * 
     * @param di
     *            the di
     */
    private void updateDashboardItem(DashboardItem di) {
        try {
            dashboardItemDao.updateDashboardItem(di);
        } catch (Exception e) {
            log.error("There was a problem while updating dashboardItem: ", e);
        }
    }

    /**
     * Gets the offers search input text.
     * 
     * @return the offers search input text
     */
    public String getOffersSearchInputText() {
        return offersSearchInputText;
    }

    /**
     * Sets the offers search input text.
     * 
     * @param offersSearchInputText
     *            the new offers search input text
     */
    public void setOffersSearchInputText(String offersSearchInputText) {
        this.offersSearchInputText = offersSearchInputText;
    }

    /**
     * Gets the ppe search input text.
     * 
     * @return the ppe search input text
     */
    public String getPpeSearchInputText() {
        return ppeSearchInputText;
    }

    /**
     * Sets the ppe search input text.
     * 
     * @param ppeSearchInputText
     *            the new ppe search input text
     */
    public void setPpeSearchInputText(String ppeSearchInputText) {
        this.ppeSearchInputText = ppeSearchInputText;
    }

    /**
     * Gets the seller search input text.
     * 
     * @return the seller search input text
     */
    public String getSellerSearchInputText() {
        return sellerSearchInputText;
    }

    /**
     * Sets the seller search input text.
     * 
     * @param sellerSearchInputText
     *            the new seller search input text
     */
    public void setSellerSearchInputText(String sellerSearchInputText) {
        this.sellerSearchInputText = sellerSearchInputText;
    }

    /**
     * Construct include url.
     * 
     * @param item
     *            the item
     * @return the string
     */
    public String constructIncludeUrl(String item) {
        return "../dashboard/items/" + item + ".xhtml";
    }

    /**
     * Gets the receivers count.
     * 
     * @return the receivers count
     */
    public int getReceiversCount() {
        return receiversCount;
    }

    /**
     * Gets the open auctions count.
     * 
     * @return the open auctions count
     */
    public int getOpenAuctionsCount() {
        return openAuctionsCount;
    }

    /**
     * Gets the clouds count.
     * 
     * @return the clouds count
     */
    public int getCloudsCount() {
        return cloudsCount;
    }

    /**
     * Gets the users count.
     * 
     * @return the users count
     */
    public int getUsersCount() {
        return usersCount;
    }

    /**
     * Gets the auctions count.
     * 
     * @return the auctions count
     */
    public int getAuctionsCount() {
        return auctionsCount;
    }

    /**
     * Gets the closed auctions count.
     * 
     * @return the closed auctions count
     */
    public int getClosedAuctionsCount() {
        return closedAuctionsCount;
    }

    /**
     * Gets the blocked auctions count.
     * 
     * @return the blocked auctions count
     */
    public int getBlockedAuctionsCount() {
        return blockedAuctionsCount;
    }

    /**
     * Gets the message count.
     * 
     * @return the message count
     */
    public Integer getMessageCount() {
        return messageCount;
    }

    /**
     * Sets the message count.
     * 
     * @param messageCount
     *            the new message count
     */
    public void setMessageCount(Integer messageCount) {
        this.messageCount = messageCount;
    }

    /**
     * Sets the model.
     * 
     * @param model
     *            the new model
     */
    public void setModel(DashboardModel model) {
        this.model = model;
    }

    /**
     * Gets the dashboard.
     * 
     * @return the dashboard
     */
    public Dashboard getDashboard() {
        return dashboard;
    }

    /**
     * Sets the dashboard.
     * 
     * @param dashboard
     *            the new dashboard
     */
    public void setDashboard(Dashboard dashboard) {
        this.dashboard = dashboard;
    }

    /**
     * Gets the model.
     * 
     * @return the model
     */
    public DashboardModel getModel() {
        return model;
    }

    /**
     * Handle reorder.
     * 
     * @param event
     *            the event
     */
    public void handleReorder(DashboardReorderEvent event) {

        int i = 0;
        for(DashboardColumn dc : model.getColumns()) {
            for(String widget_id : dc.getWidgets()) {
                i++;
                DashboardItem di = dashboardItemsMap.get(widget_id);
                di.setOrderId(i);
                updateDashboardItem(di);

            }
        }

        initialize();
    }

    /**
     * Gets the dashboard items.
     * 
     * @return the dashboard items
     */
    public List<DashboardItem> getDashboardItems() {
        return dashboardItems;
    }

    /**
     * Sets the dashboard items.
     * 
     * @param dashboardItems
     *            the new dashboard items
     */
    public void setDashboardItems(List<DashboardItem> dashboardItems) {
        this.dashboardItems = dashboardItems;
    }

    /**
     * Gets the active dashboard items.
     * 
     * @return the active dashboard items
     */
    public List<DashboardItem> getActiveDashboardItems() {
        return activeDashboardItems;
    }

    /**
     * Sets the active dashboard items.
     * 
     * @param activeDashboardItems
     *            the new active dashboard items
     */
    public void setActiveDashboardItems(List<DashboardItem> activeDashboardItems) {
        this.activeDashboardItems = activeDashboardItems;
    }

    /**
     * Gets the dashboard items size.
     * 
     * @return the dashboard items size
     */
    public int getDashboardItemsSize() {
        return dashboardItemsSize;
    }

    /**
     * Sets the dashboard items size.
     * 
     * @param dashboardItemsSize
     *            the new dashboard items size
     */
    public void setDashboardItemsSize(int dashboardItemsSize) {
        this.dashboardItemsSize = dashboardItemsSize;
    }

    /**
     * Gets the user dashboard items.
     * 
     * @return the user dashboard items
     */
    public List<DashboardItem> getUserDashboardItems() {
        return userDashboardItems;
    }

    /**
     * Sets the user dashboard items.
     * 
     * @param userDashboardItems
     *            the new user dashboard items
     */
    public void setUserDashboardItems(List<DashboardItem> userDashboardItems) {
        this.userDashboardItems = userDashboardItems;
    }

    /**
     * Gets the user dashboard items map.
     * 
     * @return the user dashboard items map
     */
    public Map<String, DashboardItemUser> getUserDashboardItemsMap() {
        return userDashboardItemsMap;
    }

    /**
     * Sets the user dashboard items map.
     * 
     * @param userDashboardItemsMap
     *            the user dashboard items map
     */
    public void setUserDashboardItemsMap(Map<String, DashboardItemUser> userDashboardItemsMap) {
        this.userDashboardItemsMap = userDashboardItemsMap;
    }

    /**
     * Gets the model unpinnable.
     * 
     * @return the model unpinnable
     */
    public DashboardModel getModelUnpinnable() {
        return modelUnpinnable;
    }

    /**
     * Sets the model unpinnable.
     * 
     * @param modelUnpinnable
     *            the new model unpinnable
     */
    public void setModelUnpinnable(DashboardModel modelUnpinnable) {
        this.modelUnpinnable = modelUnpinnable;
    }

    /**
     * Gets the ppe list.
     * 
     * @return the ppe list
     */
    public List<PPE> getPpeList() {
        return ppeList;
    }

    /**
     * Sets the ppe list.
     * 
     * @param ppeList
     *            the new ppe list
     */
    public void setPpeList(List<PPE> ppeList) {
        this.ppeList = ppeList;
    }

    /**
     * Gets the selected ppe.
     * 
     * @return the selected ppe
     */
    public Integer getSelectedPPE() {
        return selectedPPE;
    }

    /**
     * Sets the selected ppe.
     * 
     * @param selectedPPE
     *            the new selected ppe
     */
    public void setSelectedPPE(Integer selectedPPE) {
        this.selectedPPE = selectedPPE;
    }

    /**
     * Gets the selected agreement ppe.
     * 
     * @return the selected agreement ppe
     */
    public Integer getSelectedAgreementPPE() {
        return selectedAgreementPPE;
    }

    /**
     * Sets the selected agreement ppe.
     * 
     * @param selectedAgreementPPE
     *            the new selected agreement ppe
     */
    public void setSelectedAgreementPPE(Integer selectedAgreementPPE) {
        this.selectedAgreementPPE = selectedAgreementPPE;
    }

    /**
     * Gets the todo list.
     * 
     * @return the todo list
     */
    public List<String> getTodoList() {
        return todoList;
    }

    /**
     * Sets the todo list.
     * 
     * @param todoList
     *            the new todo list
     */
    public void setTodoList(List<String> todoList) {
        this.todoList = todoList;
    }

    /**
     * Gets the points count.
     * 
     * @return the points count
     */
    public int getPointsCount() {
        return pointsCount;
    }

    /**
     * Sets the points count.
     * 
     * @param pointsCount
     *            the new points count
     */
    public void setPointsCount(int pointsCount) {
        this.pointsCount = pointsCount;
    }

    /**
     * Gets the cloud list.
     * 
     * @return the cloud list
     */
    public List<String> getCloudList() {
        return cloudList;
    }

    /**
     * Sets the cloud list.
     * 
     * @param cloudList
     *            the new cloud list
     */
    public void setCloudList(List<String> cloudList) {
        this.cloudList = cloudList;
    }

    /**
     * Gets the selected chart ppe.
     * 
     * @return the selected chart ppe
     */
    public Integer getSelectedChartPPE() {
        return selectedChartPPE;
    }

    /**
     * Sets the selected chart ppe.
     * 
     * @param selectedChartPPE
     *            the new selected chart ppe
     */
    public void setSelectedChartPPE(Integer selectedChartPPE) {
        this.selectedChartPPE = selectedChartPPE;
    }

    /**
     * Gets the chart ppe.
     * 
     * @return the chart ppe
     */
    public PPE getChartPPE() {
        return chartPPE;
    }

    /**
     * Sets the chart ppe.
     * 
     * @param chartPPE
     *            the new chart ppe
     */
    public void setChartPPE(PPE chartPPE) {
        this.chartPPE = chartPPE;
    }

    /**
     * Gets the select chart ppe.
     * 
     * @return the select chart ppe
     */
    public List<SelectItem> getSelectChartPPE() {
        return selectChartPPE;
    }

    /**
     * Sets the select chart ppe.
     * 
     * @param selectChartPPE
     *            the new select chart ppe
     */
    public void setSelectChartPPE(List<SelectItem> selectChartPPE) {
        this.selectChartPPE = selectChartPPE;
    }

    /**
     * Gets the chart date to.
     * 
     * @return the chart date to
     */
    public Date getChartDateTo() {
        return chartDateTo;
    }

    /**
     * Sets the chart date to.
     * 
     * @param chartDateTo
     *            the new chart date to
     */
    public void setChartDateTo(Date chartDateTo) {
        this.chartDateTo = chartDateTo;
    }

    /**
     * Gets the chart date from.
     * 
     * @return the chart date from
     */
    public Date getChartDateFrom() {
        return chartDateFrom;
    }

    /**
     * Sets the chart date from.
     * 
     * @param chartDateFrom
     *            the new chart date from
     */
    public void setChartDateFrom(Date chartDateFrom) {
        this.chartDateFrom = chartDateFrom;
    }

    /**
     * Gets the select operators.
     * 
     * @return the select operators
     */
    public List<SelectItem> getSelectOperators() {
        return selectOperators;
    }

    /**
     * Sets the select operators.
     * 
     * @param selectOperators
     *            the new select operators
     */
    public void setSelectOperators(List<SelectItem> selectOperators) {
        this.selectOperators = selectOperators;
    }

    /**
     * Gets the distributors.
     * 
     * @return the distributors
     */
    public List<Distributor> getDistributors() {
        return distributors;
    }

    /**
     * Sets the distributors.
     * 
     * @param distributors
     *            the new distributors
     */
    public void setDistributors(List<Distributor> distributors) {
        this.distributors = distributors;
    }

    /**
     * Gets the distributors list.
     * 
     * @return the distributors list
     */
    public List<Distributor> getDistributorsList() {
        return distributorsList;
    }

    /**
     * Sets the distributors list.
     * 
     * @param distributorsList
     *            the new distributors list
     */
    public void setDistributorsList(List<Distributor> distributorsList) {
        this.distributorsList = distributorsList;
    }

    /**
     * Gets the distributor.
     * 
     * @return the distributor
     */
    public String getDistributor() {
        return distributor;
    }

    /**
     * Sets the distributor.
     * 
     * @param distributor
     *            the new distributor
     */
    public void setDistributor(String distributor) {
        this.distributor = distributor;
    }

    /**
     * Gets the distributor rss url.
     * 
     * @return the distributor rss url
     */
    public String getDistributorRSSUrl() {
        return distributorRSSUrl;
    }

    /**
     * Sets the distributor rss url.
     * 
     * @param distributorRSSUrl
     *            the new distributor rss url
     */
    public void setDistributorRSSUrl(String distributorRSSUrl) {
        this.distributorRSSUrl = distributorRSSUrl;
    }

    /**
     * Checks if is refreshable.
     * 
     * @return true, if is refreshable
     */
    public boolean isRefreshable() {
        return areBoxesRefreshable();
    }

    /**
     * Sets the refreshable.
     * 
     * @param refreshable
     *            the new refreshable
     */
    public void setRefreshable(boolean refreshable) {
        this.refreshable = refreshable;
    }

    /**
     * Gets the model active.
     * 
     * @return the model active
     */
    public DashboardModel getModelActive() {
        return modelActive;
    }

    /**
     * Sets the model active.
     * 
     * @param modelActive
     *            the new model active
     */
    public void setModelActive(DashboardModel modelActive) {
        this.modelActive = modelActive;
    }

    /**
     * Gets the agreement date.
     * 
     * @return the agreement date
     */
    public String getAgreementDate() {
        return agreementDate;
    }

    /**
     * Sets the agreement date.
     * 
     * @param agreementDate
     *            the new agreement date
     */
    public void setAgreementDate(String agreementDate) {
        this.agreementDate = agreementDate;
    }

    /**
     * Gets the next auction date.
     * 
     * @return the next auction date
     */
    public String getNextAuctionDate() {
        return nextAuctionDate;
    }

    /**
     * Sets the next auction date.
     * 
     * @param nextAuctionDate
     *            the new next auction date
     */
    public void setNextAuctionDate(String nextAuctionDate) {
        this.nextAuctionDate = nextAuctionDate;
    }

    /**
     * Gets the selected next auction ppe.
     * 
     * @return the selected next auction ppe
     */
    public Integer getSelectedNextAuctionPPE() {
        return selectedNextAuctionPPE;
    }

    /**
     * Sets the selected next auction ppe.
     * 
     * @param selectedNextAuctionPPE
     *            the new selected next auction ppe
     */
    public void setSelectedNextAuctionPPE(Integer selectedNextAuctionPPE) {
        this.selectedNextAuctionPPE = selectedNextAuctionPPE;
    }

}
