package pl.op.web.beans;

import java.io.File;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletContext;
import org.apache.velocity.app.VelocityEngine;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.ui.velocity.VelocityEngineUtils;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.dict.Email;
import pl.op.model.newsletter.Newsletter;
import pl.op.model.salesman.Salesman;
import pl.op.model.user.UserApp;
import pl.op.web.common.ApplicationContextProvider;
import pl.op.web.common.BundlesUtils;

@Name("op.mailBean")
@Scope(ScopeType.APPLICATION)
@AutoCreate
public class MailBean implements Serializable {

    private static final long serialVersionUID = -8081400535764189151L;

    private static final String USER_SENDER_NAME = "ogarniamprad";
    private Logger log = LoggerFactory.getLogger(MailBean.class);
    private JavaMailSenderImpl mailSender;
    private VelocityEngine velocityEngine;
    private SimpleMailMessage simpleMessage;
    private SimpleMailMessage simpleMessageToOperator;

    private ExternalContext ectx;
    private FacesContext facesContext;
    private ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
    private String deploymentDirectoryPath = ctx.getRealPath("/");
    
    /** The server url. */
    public final String SERVER_URL = "serverURL";

    public MailBean() {
        ApplicationContext ctx = ApplicationContextProvider.getApplicationContext();
        mailSender = (JavaMailSenderImpl) ctx.getBean("mailSender");
        velocityEngine = (VelocityEngine) ctx.getBean("velocityEngine");
        simpleMessage = (SimpleMailMessage) ctx.getBean("templateMessage");
        simpleMessageToOperator = (SimpleMailMessage) ctx.getBean("templatMessageOperator");
        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();
    }
    
    public boolean sendRegistrationWithOperation(final String phone, final String email) {
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {
                MimeMessageHelper message = new MimeMessageHelper(mimeMessage);

                message.setFrom(simpleMessage.getFrom(), USER_SENDER_NAME);
                message.setTo(simpleMessageToOperator.getFrom());
                
                log.info("simpleMessage:" + simpleMessage.getFrom());
                log.info("simpleMessageToOperator:" + simpleMessageToOperator.getFrom());
                log.info("simpleMessageToOperator: to" + simpleMessageToOperator.getTo());

                String subject = BundlesUtils.getMessageResourceString("messages", "user.email.subject_reg", null,
                        ectx.getRequestLocale());

                message.setSubject(subject);
              
                String text = "Phone : " + phone + ", Email : " + email;
                message.setText(text, true);
            }
        };
        try {
            this.mailSender.send(preparator);
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
            return false;
        }
        return true;
    }
    
    public boolean sendValidationForceOperation(final UserApp user , final Double amount) {
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {
                MimeMessageHelper message = new MimeMessageHelper(mimeMessage);

                message.setFrom(simpleMessage.getFrom(), USER_SENDER_NAME);
                message.setTo(simpleMessageToOperator.getFrom());
                
                log.info("simpleMessage:" + simpleMessage.getFrom());
                log.info("simpleMessageToOperator:" + simpleMessageToOperator.getFrom());
                log.info("simpleMessageToOperator: to" + simpleMessageToOperator.getTo());

                String subject = BundlesUtils.getMessageResourceString("messages", "user.email.subject_consumpcionProfile", null,
                        ectx.getRequestLocale());

                message.setSubject(subject);
              
                String text = "Zużycie : " + amount.toString() + "MWh;\n " + 
                                "Telefon : " + user.getPhone() + ";\n" +
                                "Login : " + user.getLogin()+ ";\n" +                                
                                "Nazwa : " + user.getFullName() + ";\n" +
                                "Firma : " + user.getIsCompany() + ";\n" ;
                message.setText(text, true);
            }
        };
        try {
            this.mailSender.send(preparator);
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
            return false;
        }
        return true;
    }

    public void sendRegistrationEmail(final UserApp userApp, final String url) {
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {
                MimeMessageHelper message = new MimeMessageHelper(mimeMessage);

                message.setFrom(simpleMessage.getFrom(), USER_SENDER_NAME);
                message.setTo(userApp.getLogin());

                String subject = BundlesUtils.getMessageResourceString("messages", "user.email.subject", null,
                        ectx.getRequestLocale());

                message.setSubject(subject);

                Map<String, Object> model = new HashMap<String, Object>();
                model.put("user", userApp);
                model.put("url", url);

                String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine,
                        "pl/op/web/template/registration_pl.vm", "UTF-8", model);
                message.setText(text, true);
            }
        };
        this.mailSender.send(preparator);

    }

    public void sendWizardRegistrationEmail(final UserApp userApp) {
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {

                MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true);

                message.setFrom(simpleMessage.getFrom(), USER_SENDER_NAME);
                message.setTo(userApp.getLogin());

                String subject = BundlesUtils.getMessageResourceString("messages", "user.email.subject", null,
                        ectx.getRequestLocale());

                message.setSubject(subject);

                Map<String, Object> model = new HashMap<String, Object>();
                model.put("user", userApp);

                String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine,
                        "pl/op/web/template/wizard_registration_pl.vm", "UTF-8", model);
               // message.addAttachment("umowa_o_posrednictwo.pdf", new File(deploymentDirectoryPath
               //         + "resources/files/umowa_o_posrednictwo.pdf")); 
                message.setText(text, true);

            }
        };
        this.mailSender.send(preparator);
    }
    
    
        public void sendWizardRegistrationEmailUserHome(final UserApp userApp) {
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {

                MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true);

                message.setFrom(simpleMessage.getFrom(), USER_SENDER_NAME);
                message.setTo(userApp.getLogin());

                String subject = BundlesUtils.getMessageResourceString("messages", "user.email.subject", null,
                        ectx.getRequestLocale());

                message.setSubject(subject);

                Map<String, Object> model = new HashMap<String, Object>();
                

                String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine,
                        "pl/op/web/template/wizard_registration_finish.vm", "UTF-8", model);

                message.setText(text, true);
            }
        };
        this.mailSender.send(preparator);
    }

    public void sendReminderEmail(final UserApp userApp, final String password) {
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {
                MimeMessageHelper message = new MimeMessageHelper(mimeMessage);

                message.setFrom(simpleMessage.getFrom(), USER_SENDER_NAME);
                message.setTo(userApp.getLogin());

                String subject = BundlesUtils.getMessageResourceString("messages", "user.reminder.subject", null,
                        ectx.getRequestLocale());

                message.setSubject(subject);

                Map<String, Object> model = new HashMap<String, Object>();
                model.put("user", userApp);
                model.put("password", password);

                String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine,
                        "pl/op/web/template/reminder_pl.vm", "UTF-8", model);
                message.setText(text, true);
            }
        };
        this.mailSender.send(preparator);

    }

    public void sendNotificationEmail(final UserApp userApp, final String password) {
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {
                MimeMessageHelper message = new MimeMessageHelper(mimeMessage);

                message.setFrom(simpleMessage.getFrom(), USER_SENDER_NAME);
                message.setTo(userApp.getLogin());

                String subject = BundlesUtils.getMessageResourceString("messages", "user.email.subject", null,
                        ectx.getRequestLocale());

                message.setSubject(subject);

                Map<String, Object> model = new HashMap<String, Object>();
                model.put("user", userApp);
                model.put("password", password);

                String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine,
                        "pl/op/web/template/notification_pl.vm", "UTF-8", model);
                message.setText(text, true);
            }
        };
        this.mailSender.send(preparator);

    }

    public void sendAuctionFinishEmail(final UserApp userApp, final Auction auction) {
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {
                MimeMessageHelper message = new MimeMessageHelper(mimeMessage);

                message.setFrom(simpleMessage.getFrom(), USER_SENDER_NAME);
                message.setTo(userApp.getLogin());

                Object[] params = new Object[1];
                params[0] = auction.getAuctionId();
                params[1] = System.getProperty(SERVER_URL)+"/op-web";

                String subject = BundlesUtils.getMessageResourceString("messages", "auction.email.block", params,
                        ectx.getRequestLocale());

                message.setSubject(subject);

                Map<String, Object> model = new HashMap<String, Object>();
                model.put("auction", auction);
                model.put("url", System.getProperty(SERVER_URL)+ "/op-web");

                String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine,
                        "pl/op/web/template/auction_finish_pl.vm", "UTF-8", model);
                message.setText(text, true);
            }
        };
        this.mailSender.send(preparator);

    }

    public void sendAuctionFinishEmail(final Salesman salesman, final Auction auction) {
        UserApp user = new UserApp();
        user.setLogin(salesman.getEmail());
        sendAuctionFinishEmail(user, auction);
    }

    public void sendAuctionBlockEmail(final UserApp userApp, final AuctionOffer auctionOffer) {
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {
                MimeMessageHelper message = new MimeMessageHelper(mimeMessage);

                message.setFrom(simpleMessage.getFrom(), USER_SENDER_NAME);
                message.setTo(userApp.getLogin());

                Object[] params = new Object[2];
                params[0] = auctionOffer.getAuctionOfferId();
                params[1] = auctionOffer.getUpdatedAt();

                String subject = BundlesUtils.getMessageResourceString("messages", "auction.email.block", params,
                        ectx.getRequestLocale());

                message.setSubject(subject);

                Map<String, Object> model = new HashMap<String, Object>();
                model.put("auctionOffer", auctionOffer);

                String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine,
                        "pl/op/web/template/auction_block_pl.vm", "UTF-8", model);
                message.setText(text, true);
            }
        };
        this.mailSender.send(preparator);

    }
    
    public void sendMailingEmail(final List<Email> sEmails, final Newsletter newsletter) {        
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {
                MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
                List<String> emails = new ArrayList<String>();

                for(Email e : sEmails) {
                    emails.add(e.getEmail());
                }

                message.setFrom(simpleMessage.getFrom(), USER_SENDER_NAME);
                // message.setTo(emails.toArray(new String[emails.size()]));
                message.setBcc(emails.toArray(new String[emails.size()]));

                String subject = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(newsletter.getCreatedAt());

                message.setSubject(subject);

                message.setText(newsletter.getContent(), true);
            }
        };
        this.mailSender.send(preparator);

    }

    public void sendNewsletterEmail(final List<UserApp> users, final Newsletter newsletter) {
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {
                MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
                List<String> emails = new ArrayList<String>();

                for(UserApp u : users) {
                    emails.add(u.getLogin());
                }

                message.setFrom(simpleMessage.getFrom(), USER_SENDER_NAME);
                // message.setTo(emails.toArray(new String[emails.size()]));
                message.setBcc(emails.toArray(new String[emails.size()]));

                String subject = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(newsletter.getCreatedAt());

                message.setSubject(subject);

                message.setText(newsletter.getContent(), true);
            }
        };
        this.mailSender.send(preparator);

    }
    
    public void sendZadajPytanie(final UserApp user, String typ, String message)
    {
        
    }
}
