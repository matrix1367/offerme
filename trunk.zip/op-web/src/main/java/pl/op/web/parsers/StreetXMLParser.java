package pl.op.web.parsers;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.FileUploadEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import pl.op.dao.CityDao;
import pl.op.dao.StreetDao;
import pl.op.model.dict.City;
import pl.op.model.dict.Street;
import pl.op.web.listener.GuiceSingleton;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Name("op.streetXMLParser")
@Scope(ScopeType.SESSION)
public class StreetXMLParser extends DefaultHandler {

	private Logger log = LoggerFactory.getLogger(StreetXMLParser.class);

	private InputStream uploadedStreetFile;

	private String areaId;
	private String districtId;
	private String communityId;
	private String unitTypeId;
	private String cityId;
	private String streetId;
	private String streetType;
	private String streetName1;
	private String streetName2;
	private String date;

	private Street streetFromXML;
	private City cityFromDB;

	private CityDao cityDao;
	private StreetDao streetDao;

	private HashMap<String, String> streetMap;

	private Boolean isAreaId = false;
	private Boolean isDistrictId = false;
	private Boolean isCommunityId = false;
	private Boolean isUnityTypeId = false;
	private Boolean isCityId = false;
	private Boolean isStreetId = false;
	private Boolean isStreetType = false;
	private Boolean isStreetName1 = false;
	private Boolean isStreetName2 = false;
	private Boolean isDate = false;

	private Map<String, City> cityMap = new HashMap<String, City>();

	public StreetXMLParser() {
		log.info("AreaXMLParser constructor");
		initialize();
	}

	private void initialize() {
		streetDao = GuiceSingleton.getInstance().getInstance(StreetDao.class);
		cityDao = GuiceSingleton.getInstance().getInstance(CityDao.class);

		streetFromXML = new Street();

		streetMap = new HashMap<String, String>();

		try {
			List<City> cityList = cityDao.getCities(null);

			for (City city : cityList) {
				cityMap.put(city.getSymbol(), city);
			}
		} catch (Exception e) {
			log.error("Error while getting Cities : ", e);
			e.printStackTrace();
		}
	}

	public void uploadStreetXML(FileUploadEvent event) {
		try {
			uploadedStreetFile = event.getFile().getInputstream();
		} catch (IOException e) {
			log.error("error while getting StreetXML : ", e);
			e.printStackTrace();
		}
	}

	private boolean streetsAreEqual(Street street1, Street street2) {
		if (street1.getSymbol().equals(street2.getSymbol())) {
			return true;
		}
		return false;
	}

	public void importStreetXml() throws Exception {

		try {
			SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserFactory.newSAXParser();

			DefaultHandler defaultHandler = new DefaultHandler() {

				public void startElement(String uri, String localName,
						String qName, Attributes attributes)
						throws SAXException {

					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equalsIgnoreCase("WOJ")) {
							isAreaId = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equalsIgnoreCase("POW")) {
							isDistrictId = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equalsIgnoreCase("GMI")) {
							isCommunityId = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equalsIgnoreCase("RODZ_GMI")) {
							isUnityTypeId = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equalsIgnoreCase("SYM")) {
							isCityId = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equalsIgnoreCase("SYM_UL")) {
							isStreetId = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equalsIgnoreCase("CECHA")) {
							isStreetType = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equalsIgnoreCase("NAZWA_1")) {
							isStreetName1 = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equalsIgnoreCase("NAZWA_2")) {
							isStreetName2 = true;
					}
					if (qName.equalsIgnoreCase("col") && attributes.getValue("name").equalsIgnoreCase("STAN_NA")) {
							isDate = true;
					}
				}

				public void characters(char ch[], int start, int length)
						throws SAXException {

					if (isAreaId) {
						areaId = new String(ch, start, length);
						log.info("WOJ : " + areaId);

						streetMap.put("areaId", areaId);
					}
					if (isDistrictId) {
						districtId = new String(ch, start, length);
						log.info("POW : " + districtId);

						streetMap.put("districtId", districtId);
					}
					if (isCommunityId) {
						communityId = new String(ch, start, length);
						log.info("GMI : " + communityId);

						streetMap.put("communityId", communityId);
					}
					if (isUnityTypeId) {
						unitTypeId = new String(ch, start, length);
						log.info("RODZ_GMI : " + unitTypeId);

						streetMap.put("unitTypeId", unitTypeId);
					}
					if (isCityId) {
						cityId = new String(ch, start, length);
						log.info("SYM : " + cityId);

						streetMap.put("cityId", cityId);
					}
					if (isStreetId) {
						streetId = new String(ch, start, length);
						log.info("SYM_UL : " + streetId);

						streetMap.put("streetId", streetId);
					}
					if (isStreetType) {
						streetType = new String(ch, start, length);
						log.info("CECHA : " + streetType);

						streetMap.put("streetType", streetType);
					}
					if (isStreetName1) {
						streetName1 = new String(ch, start, length);
						log.info("NAZWA_1 : " + streetName1);

						streetMap.put("streetName1", streetName1);
					}
					if (isStreetName2) {
						streetName2 = new String(ch, start, length);
						log.info("NAZWA_2 : " + streetName2);

						streetMap.put("streetName2", streetName2);
					}
					if (isDate) {
						date = new String(ch, start, length);
						log.info("STAN_NA : " + date);

						if (streetMap.size() == 10) {
							
							try {
								streetFromXML.setCity(new City());								
								Street streetFromDB = streetDao.getStreetBySymbol(streetMap.get("streetId"));
								cityFromDB = cityMap.get(cityId);
								streetFromXML = new Street();
								streetFromXML.setSymbol(streetMap.get("streetId"));
								
								if(streetFromDB == null || !streetsAreEqual(streetFromXML,streetFromDB)) {
								
									streetFromXML.setStreetName(streetMap.get("streetType")+" "+streetMap.get("streetName2")+" "+streetMap.get("streetName1"));
									streetFromXML.setCity(cityFromDB);
													
								streetDao.saveStreetWithCityId(streetFromXML, cityFromDB.getCityId());
								}
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
						streetMap.clear();
						
						streetMap.put("date", date);
					}				
				}

				public void endElement(String uri, String localName,
						String qName) throws SAXException {

					if (qName.contains("col")) {
							isAreaId = false;
					}
					if (qName.contains("col")) {
							isDistrictId = false;
					}
					if (qName.contains("col")) {
							isCommunityId = false;
					}
					if (qName.contains("col")) {
							isUnityTypeId = false;
					}
					if (qName.contains("col")) {
							isCityId = false;
					}
					if (qName.contains("col")) {
							isStreetId = false;
					}
					if (qName.contains("col")) {
							isStreetType = false;
					}
					if (qName.contains("col")) {
							isStreetName1 = false;
					}
					if (qName.contains("col")) {
							isStreetName2 = false;
					}
					if (qName.contains("col")) {
							isDate = false;
					}
				}
			};

			saxParser.parse(uploadedStreetFile, defaultHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}