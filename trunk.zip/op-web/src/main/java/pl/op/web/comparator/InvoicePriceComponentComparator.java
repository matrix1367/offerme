package pl.op.web.comparator;

import java.util.Comparator;

import pl.op.model.contract.InvoicePriceComponentValue;

public class InvoicePriceComponentComparator implements Comparator<InvoicePriceComponentValue> {

    @Override
    public int compare(InvoicePriceComponentValue pcv, InvoicePriceComponentValue pcv2) {
        if(pcv.getPriceComponent().isConstant()) {
            return 1;
        }

        return 0;
    }
}
