package pl.op.web.listener;

import javax.servlet.ServletContextEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.web.thread.AuctionStatusThread;

public class Runner implements javax.servlet.ServletContextListener {

	private Logger log = LoggerFactory.getLogger(Runner.class);

	public Runner() {

	}

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		
		log.info(">>>>>>>>>>>>>>>>>> STARTING AUCTION STATUS THREAD");
		AuctionStatusThread thread = new AuctionStatusThread();
		thread.start();
		log.info(">>>>>>>>>>>>>>>>>> AUCTION STATUS THREAD STARTED");

	}
}
