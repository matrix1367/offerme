package pl.op.web.beans.comment;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.CommentModuleDao;
import pl.op.model.comment.CommentModule;
import pl.op.model.comment.CommentTypeEnum;
import pl.op.util.MessageUtil;
import pl.op.web.beans.AdminBean;
import pl.op.web.listener.GuiceSingleton;
import pl.op.web.service.BonusService;

/**
 * The Class CommentModuleBean.
 */
@Name("op.commentModuleBean")
@Scope(ScopeType.SESSION)
public class CommentModuleBean {

    private Logger log = LoggerFactory.getLogger(CommentModuleBean.class);
    private FacesContext facesContext;
    private ExternalContext ectx;

    private CommentModule comment;
    private List<CommentModule> comments;
    private List<String> selectedOpinion;

    private CommentModuleDao commentModuleDao;

    @In(value = "#{op.adminBean}", scope = ScopeType.SESSION, required = true)
    private AdminBean adminBean;

    /**
     * Instantiates a new comment module bean.
     */
    public CommentModuleBean() {
        log.info("CommentModuleBean - initilize");

        initialize();
    }

    /**
     * Initialize.
     */
    public void initialize() {
        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();

        commentModuleDao = GuiceSingleton.getInstance().getInstance(CommentModuleDao.class);

        comment = new CommentModule();
    }

    /**
     * Initialize comment module.
     * 
     * @param objectId
     *            the object id
     * @param commentType
     *            the comment type
     */
    public void initializeCommentModule(Integer objectId, String commentType) {
        log.info("initializeCommentModule - " + objectId + "; " + commentType);

        String author;

        author = adminBean.getUserLog().getFullName();
        author += ", " + adminBean.getUserLog().getLogin();

        comment = new CommentModule();
        selectedOpinion = new ArrayList<String>();

        if(commentType.equals("auction") || commentType.equals("AUCTION"))
            comment.setCommentType(CommentTypeEnum.AUCTION);
        else if(commentType.equals("auctionOffer") || commentType.equals("AUCTIONOFFER"))
            comment.setCommentType(CommentTypeEnum.AUCTIONOFFER);
        else if(commentType.equals("ppe") || commentType.equals("PPE"))
            comment.setCommentType(CommentTypeEnum.PPE);
        else if(commentType.equals("website") || commentType.equals("WEBSITE"))
            comment.setCommentType(CommentTypeEnum.WEBSITE);

        comment.setObjectId(objectId);
        comment.setRemoved(false);

        try {
            comments = commentModuleDao.getComments(1, CommentTypeEnum.WEBSITE);
            log.info("comments - " + comments);
            if(comments == null) {
                log.info("comments - null");
            } else {
                log.info("comments.size() - " + comments.size());
            }
            log.info("initializeDialog - " + comment.getObjectId() + "; " + comment.getCommentType());
        } catch (Exception e) {
            log.info("Problem while initialize CommentModule", e);
        }
    }

    /**
     * Save comment.
     */
    public void saveComment() {
        log.info("saveComment");
        try {
            comment.setDateComment(new Date());
            comment.setUserOpinion(selectedOpinion);

            commentModuleDao.saveComment(comment);
            MessageUtil.displayMessageInfo("commentModule", "comment.save.success");
            BonusService.run("comment", adminBean.getUserLog());
            initializeCommentModule(comment.getObjectId(), comment.getCommentType().toString());
        } catch (Exception e) {
            log.error("Problem while save comment", e);
            MessageUtil.displayMessageWarn("commentModule", "comment.save.error");
        }
    }

    /**
     * Gets the comment.
     * 
     * @return the comment
     */
    public CommentModule getComment() {
        return comment;
    }

    /**
     * Sets the comment.
     * 
     * @param comment
     *            the new comment
     */
    public void setComment(CommentModule comment) {
        this.comment = comment;
    }

    /**
     * Gets the comment module dao.
     * 
     * @return the comment module dao
     */
    public CommentModuleDao getCommentModuleDao() {
        return commentModuleDao;
    }

    /**
     * Sets the comment module dao.
     * 
     * @param commentModuleDao
     *            the new comment module dao
     */
    public void setCommentModuleDao(CommentModuleDao commentModuleDao) {
        this.commentModuleDao = commentModuleDao;
    }

    /**
     * Gets the comments.
     * 
     * @param objectId
     *            the object id
     * @param type
     *            the type
     * @return the comments
     */
    public List<CommentModule> getComments(Integer objectId, String type) {
        CommentTypeEnum commentType = null;
        if(type.equals("auction"))
            commentType = CommentTypeEnum.AUCTION;
        else if(type.equals("auctionOffer"))
            commentType = CommentTypeEnum.AUCTIONOFFER;
        else if(type.equals("ppe"))
            commentType = CommentTypeEnum.PPE;
        else if(type.equals("website"))
            commentType = CommentTypeEnum.WEBSITE;

        return getComments(objectId, commentType);
    }

    /**
     * Gets the comments.
     * 
     * @param objectId
     *            the object id
     * @param commentType
     *            the comment type
     * @return the comments
     */
    public List<CommentModule> getComments(Integer objectId, CommentTypeEnum commentType) {
        try {
            return commentModuleDao.getComments(objectId, commentType);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Gets the comments.
     * 
     * @return the comments
     */
    public List<CommentModule> getComments() {
        return comments;
    }

    /**
     * Sets the comments.
     * 
     * @param comments
     *            the new comments
     */
    public void setComments(List<CommentModule> comments) {
        this.comments = comments;
    }

    /**
     * Gets the selected opinion.
     * 
     * @return the selected opinion
     */
    public List<String> getSelectedOpinion() {
        return selectedOpinion;
    }

    /**
     * Sets the selected opinion.
     * 
     * @param selectedOpinion
     *            the new selected opinion
     */
    public void setSelectedOpinion(List<String> selectedOpinion) {
        this.selectedOpinion = selectedOpinion;
    }
}
