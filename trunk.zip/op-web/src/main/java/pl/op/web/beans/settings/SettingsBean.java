package pl.op.web.beans.settings;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.SettingsDao;
import pl.op.settings.Settings;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

@Name("op.settingsBean")
@Scope(ScopeType.SESSION)
public class SettingsBean implements Serializable {

	private static final long serialVersionUID = -8760076414560548708L;
	
	private Logger log = LoggerFactory.getLogger(SettingsBean.class);
	
	private List<Settings> settingsList;
	private Settings selectedSetting;

	// buttons disable
	private boolean disableEdit = true;
	private boolean disableRemove = true;
	
	private SettingsDao settingsDao;
	
	private DictionaryBean dictionaryBean;
	
	public SettingsBean () {
		log.info("SettingsBean Constructor");
		initialize();
	}
	
	private void initialize () {
		notAvailableAction();
		settingsDao = GuiceSingleton.getInstance().getInstance(SettingsDao.class);
		dictionaryBean = ComponentLookup.lookupComponent("op.dictionaryBean");
		
		settingsList = new ArrayList<Settings>();
	}
	
	private void prepareSettingsList(){
		try {
			settingsList = settingsDao.getSettingsList(new Settings());
		} catch (Exception e) {
			log.error("Error while getting SettingsList : ",e);
			e.printStackTrace();
		}
	}
	
	public void refreshSettingsList(){
		prepareSettingsList();
	}
	
	public String saveSetting() {
		log.info("saveSetting");
		try {
			settingsDao.updateSetting(selectedSetting);
			if(selectedSetting.getSettingType().equals("auctionDurationDays")) {
				dictionaryBean.refreshAuctionDurationDays();
			}
		} catch (Exception e) {
			log.error("Error while saveSetting : ",e);
			e.printStackTrace();
		}
		prepareSettingsList();
		return "settingsList";
	}
	
	public String cancelEditSetting() {
		notAvailableAction();
		return "settingsList";
	}
	
	public String editSetting() {
		return "settingsEdit";
	}
	
	public void onRowSelectSettingsList(SelectEvent event) {
		availableAction();
	}
	
	public void onRowUnselectSettingsList(UnselectEvent event) {
		notAvailableAction();
	}
	
	public void availableAction() {
		disableEdit = false;
		disableRemove = false;
	}
	
	public void notAvailableAction() {
		selectedSetting = new Settings();
		
		disableEdit = true;
		disableRemove = true;
	}

	public List<Settings> getSettingsList() {
		return settingsList;
	}

	public void setSettingsList(List<Settings> settingsList) {
		this.settingsList = settingsList;
	}

	public Settings getSelectedSetting() {
		return selectedSetting;
	}

	public void setSelectedSetting(Settings selectedSetting) {
		this.selectedSetting = selectedSetting;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}

	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}
}