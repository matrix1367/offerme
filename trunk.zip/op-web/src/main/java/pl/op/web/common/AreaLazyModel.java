package pl.op.web.common;

import java.util.List;
import java.util.Map;

import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.model.dict.Area;

public class AreaLazyModel extends LazyDataModel<Area> {

	private static final long serialVersionUID = -1251530102364674057L;
	
	private Logger log = LoggerFactory.getLogger(AreaLazyModel.class);

	@Override
	public List<Area> load(int first, int pageSize, String sortField,
			SortOrder sortOrder, Map<String, String> filters) {
		return null;
	}
		
}