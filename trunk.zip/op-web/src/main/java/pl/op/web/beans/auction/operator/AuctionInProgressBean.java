package pl.op.web.beans.auction.operator;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionAttributesEnum;
import pl.op.model.auction.AuctionFilter;
import pl.op.model.auction.AuctionStatus;
import pl.op.model.dict.City;
import pl.op.util.LocationUtil;
import pl.op.web.common.ComponentLookup;

/**
 * The Class AuctionInProgressBean.
 */
@Name("op.operatorAuctionInProgressBean")
@Scope(ScopeType.SESSION)
public class AuctionInProgressBean {

    private Logger log = LoggerFactory.getLogger(AuctionInProgressBean.class);
    public static final long HOUR = 3600 * 1000;

    private List<Auction> auctions;
    private Auction auction;

    private AuctionBean auctionBean;

    // Filters
    private AuctionFilter auctionFilter;
    private String cityName;

    private boolean buttonsDisabled = true;
    private boolean galleryView = false;

    /**
     * Instantiates a new auction in progress bean.
     */
    public AuctionInProgressBean() {
        log.info("AuctionInProgressBean constructor");

        initializeVars();
        initializeFilter();
    }

    /**
     * Initialize vars.
     */
    public final void initializeVars() {
        auctionBean = ComponentLookup.lookupComponent("op.operatorAuctionBean");
    }

    /**
     * Initialize filter.
     */
    public final void initializeFilter() {
        clearFilter();
        searchAuctions();
    }

    /**
     * Clear filter.
     */
    public void clearFilter() {
        auctionFilter = new AuctionFilter();
        cityName = "";
    }

    /**
     * Assign auction offer attribute.
     * 
     * @return the string
     */
    public String assignAuctionOfferAttribute() {
        auctionFilter.setAuctionAttribute(AuctionAttributesEnum.NUMBER);
        searchAuctions();
        return "operatorAuctions";
    }

    /**
     * Search auctions.
     */
    public void searchAuctions() {
        clearSelectedAuction();

        if(!"".equals(cityName) && null != cityName) {
            log.info("cityName: " + cityName);
            auctionFilter.setCity(LocationUtil.getCity(cityName, auctionFilter.getArea()));

            if(null == auctionFilter.getCity()) {
                auctionFilter.setCity(new City());
                auctionFilter.getCity().setCityId(0);
            }
        } else {
            auctionFilter.setCity(new City());
        }

        auctionFilter.getAuction().setStatus(AuctionStatus.INPROGRESS);
        auctions = auctionBean.searchAuctions(auctionFilter);

        //log.info("LISTA");
       // for(Auction auction : auctions) {
       //     log.info("ID: " + auction.getAuctionId());
       // }
    }

    /**
     * Clear selected auction.
     */
    private void clearSelectedAuction() {
        auction = null;
        buttonsDisabled = true;
    }

    /**
     * Initialize auction.
     */
    public void initializeAuction() {
        auctionBean.setAuctionComponents(auction);
    }

    /**
     * On auction select.
     * 
     * @param event
     *            the event
     */
    public void onAuctionSelect(SelectEvent event) {
        buttonsDisabled = false;
    }

    /**
     * Autocomplete city.
     * 
     * @param query
     *            the query
     * @return the list
     */
    public List<String> autocompleteCity(String query) {
        return LocationUtil.autoCompleteCity(query, auctionFilter.getArea().getAreaId());
    }

    /**
     * Gets the auctions.
     * 
     * @return the auctions
     */
    public List<Auction> getAuctions() {
        return auctions;
    }

    /**
     * Sets the auctions.
     * 
     * @param auctions
     *            the new auctions
     */
    public void setAuctions(List<Auction> auctions) {
        this.auctions = auctions;
    }

    /**
     * Gets the auction.
     * 
     * @return the auction
     */
    public Auction getAuction() {
        return auction;
    }

    /**
     * Sets the auction.
     * 
     * @param auction
     *            the new auction
     */
    public void setAuction(Auction auction) {
        this.auction = auction;
    }

    /**
     * Gets the auction filter.
     * 
     * @return the auction filter
     */
    public AuctionFilter getAuctionFilter() {
        return auctionFilter;
    }

    /**
     * Sets the auction filter.
     * 
     * @param auctionFilter
     *            the new auction filter
     */
    public void setAuctionFilter(AuctionFilter auctionFilter) {
        this.auctionFilter = auctionFilter;
    }

    /**
     * Checks if is buttons disabled.
     * 
     * @return true, if is buttons disabled
     */
    public boolean isButtonsDisabled() {
        return buttonsDisabled;
    }

    /**
     * Sets the buttons disabled.
     * 
     * @param buttonsDisabled
     *            the new buttons disabled
     */
    public void setButtonsDisabled(boolean buttonsDisabled) {
        this.buttonsDisabled = buttonsDisabled;
    }

    /**
     * Checks if is gallery view.
     * 
     * @return true, if is gallery view
     */
    public boolean isGalleryView() {
        return galleryView;
    }

    /**
     * Sets the gallery view.
     * 
     * @param galleryView
     *            the new gallery view
     */
    public void setGalleryView(boolean galleryView) {
        this.galleryView = galleryView;
    }

    /**
     * Change view.
     */
    public void changeView() {
        galleryView = !galleryView;
        if (galleryView) {
            buttonsDisabled = true;
        }
    }

    /**
     * Gets the city name.
     * 
     * @return the city name
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * Sets the city name.
     * 
     * @param cityName
     *            the new city name
     */
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }
    
    public String auctDetails() {
        
         return "operatorAuctionDetails";
    }
}