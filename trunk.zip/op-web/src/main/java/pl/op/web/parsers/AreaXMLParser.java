package pl.op.web.parsers;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.FileUploadEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import pl.op.dao.AreaDao;
import pl.op.model.dict.Area;
import pl.op.web.listener.GuiceSingleton;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

@Name("op.areaXMLParser")
@Scope(ScopeType.SESSION)
public class AreaXMLParser extends DefaultHandler {

	private Logger log = LoggerFactory.getLogger(AreaXMLParser.class);

	private InputStream uploadedAreaFile;

	private String areaId;
	private String districtId;
	private String communityId;
	private String unitTypeId;
	private String areaName;
	private String unitTypeName;
	private String date;

	private Area areaFromXML;

	private AreaDao areaDao;

	private HashMap<String, String> areaMap;

	private Boolean isAreaId = false;
	private Boolean isDistrictId = false;
	private Boolean isCommunityId = false;
	private Boolean isUnityTypeId = false;
	private Boolean isAreaName = false;
	private Boolean isUnityTypeName = false;
	private Boolean isDate = false;

	public AreaXMLParser() {
		log.info("AreaXMLParser constructor");
		initialize();
	}

	private void initialize() {
		areaDao = GuiceSingleton.getInstance().getInstance(AreaDao.class);

		areaFromXML = new Area();

		areaMap = new HashMap<String, String>();
	}

	public void uploadAreaXML(FileUploadEvent event) {
		try {
			uploadedAreaFile = event.getFile().getInputstream();
		} catch (IOException e) {
			log.error("error while getting AreaXML : ", e);
			e.printStackTrace();
		}
	}

	public void importAreaXml() throws Exception {

		try {
			SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserFactory.newSAXParser();

			DefaultHandler defaultHandler = new DefaultHandler() {

				public void startElement(String uri, String localName,
						String qName, Attributes attributes)
						throws SAXException {

					if (qName.equalsIgnoreCase("col")) {
						if (attributes.getValue("name").equalsIgnoreCase("WOJ")) {
							isAreaId = true;
						}
					}
					if (qName.equalsIgnoreCase("col")) {
						if (attributes.getValue("name").equalsIgnoreCase("POW")) {
							isDistrictId = true;
						}
					}
					if (qName.equalsIgnoreCase("col")) {
						if (attributes.getValue("name").equalsIgnoreCase("GMI")) {
							isCommunityId = true;
						}
					}
					if (qName.equalsIgnoreCase("col")) {
						if (attributes.getValue("name").equalsIgnoreCase("RODZ")) {
							isUnityTypeId = true;
						}
					}
					if (qName.equalsIgnoreCase("col")) {
						if (attributes.getValue("name").equalsIgnoreCase("NAZWA")) {
							isAreaName = true;
						}
					}
					if (qName.equalsIgnoreCase("col")) {
						if (attributes.getValue("name").equalsIgnoreCase("NAZDOD")) {
							isUnityTypeName = true;
						}
					}
					if (qName.equalsIgnoreCase("col")) {
						if (attributes.getValue("name").equalsIgnoreCase("STAN_NA")) {
							isDate = true;
						}
					}
				}

				public void characters(char ch[], int start, int length)
						throws SAXException {

					if (isAreaId) {
						areaId = new String(ch, start, length);
						log.info("WOJ : " + areaId);

						if (areaMap.size() == 4) {
							try {
								Area areaDBName = areaDao.getAreaByName(areaName);

								if (areaDBName == null) {
									areaFromXML.setAreaName(areaMap.get("areaName"));
									areaFromXML.setAreaSymbol(areaMap.get("areaId"));
									areaDao.saveArea(areaFromXML);
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
						areaMap.clear();

						areaMap.put("areaId", areaId);
					}
					if (isDistrictId) {
						districtId = new String(ch, start, length);
						log.info("POW : " + districtId);

						areaMap.put("districtId", districtId);
					}
					if (isCommunityId) {
						communityId = new String(ch, start, length);
						log.info("GMI : " + communityId);

						areaMap.put("communityId", communityId);
					}
					if (isUnityTypeId) {
						unitTypeId = new String(ch, start, length);
						log.info("RODZ : " + unitTypeId);

						areaMap.put("unitTypeId", unitTypeId);
					}
					if (isAreaName) {
						areaName = new String(ch, start, length);
						log.info("NAZWA : " + areaName);

						areaMap.put("areaName", areaName);
					}
					if (isUnityTypeName) {
						unitTypeName = new String(ch, start, length);
						log.info("NAZDOD : " + unitTypeName);

						areaMap.put("unitTypeName", unitTypeName);
					}
					if (isDate) {
						date = new String(ch, start, length);
						log.info("STAN_NA : " + date);

						areaMap.put("date", date);
					}
				}

				public void endElement(String uri, String localName,
						String qName) throws SAXException {

					if (qName.contains("col")) {
						isAreaId = false;
					}
					if (qName.equalsIgnoreCase("col")) {
						isDistrictId = false;
					}
					if (qName.equalsIgnoreCase("col")) {
						isCommunityId = false;
					}
					if (qName.equalsIgnoreCase("col")) {
						isUnityTypeId = false;
					}
					if (qName.equalsIgnoreCase("col")) {
						isAreaName = false;
					}
					if (qName.equalsIgnoreCase("col")) {
						isUnityTypeName = false;
					}
					if (qName.equalsIgnoreCase("col")) {
						isDate = false;
					}
				}
			};

			saxParser.parse(uploadedAreaFile, defaultHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}