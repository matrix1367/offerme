package pl.op.web.common;

public class Consts {

	public static String YES 	= "Tak";
	public static String NO 	= "Nie";
	
}
