package pl.op.web.beans.auction.operator;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.TabChangeEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.op.dao.AuctionDao;
import pl.op.dao.CityDao;
import pl.op.dao.CloudDao;
import pl.op.dao.PPEDao;
import pl.op.dao.UserDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionAttributesEnum;
import pl.op.model.auction.AuctionEndEnum;
import pl.op.model.auction.AuctionFilter;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.auction.AuctionStatus;
import pl.op.model.auction.AuctionUser;
import pl.op.model.auction.PriceComponent;
import pl.op.model.auction.PriceComponentValue;
import pl.op.model.cloud.Cloud;
import pl.op.model.cloud.VolumeEnum;
import pl.op.model.contract.PPE;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Tariff;
import pl.op.model.salesman.Salesman;
import pl.op.model.stereotype.Stereotype;
import pl.op.model.user.UserApp;
import pl.op.web.beans.MailBean;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class AuctionBean.
 */
@Name("op.operatorAuctionBean")
@Scope(ScopeType.SESSION)
public class AuctionBean {

    private Logger log = LoggerFactory.getLogger(AuctionBean.class);
    public static final long HOUR = 3600 * 1000;

    private FacesContext facesContext;
    private ExternalContext ectx;

    private Auction auction;
    private Auction auctionDetails;
    private AuctionOffer auctionOffer;

    private List<Area> areas;
    private List<City> cities;
    private List<AuctionEndEnum> auctionEnd;
    private List<AuctionAttributesEnum> auctionAttributes;
    private List<Tariff> tariffs;
    private List<Stereotype> stereotypes;
    private List<VolumeEnum> volumes;

    private CityDao cityDao;
    private AuctionDao auctionDao;

    private DictionaryBean dictionaryBean;

    private boolean auctionOfferButtons = true;
    private String actualTab;

    public void PrintAuctionDetails()
    {
        if (auctionDetails != null)
        {
            List<AuctionUser> auctionUsers = auctionDetails.getAuctionUsers();
            for ( AuctionUser auctionUser : auctionUsers)
            {
                log.info("-------------------");
                log.info("au_ID:" + auctionUser.getAuctionUserId());
                UserApp userAppAuctionUser = auctionUser.getUserApp();
                log.info("userAppAuctionUser: " + userAppAuctionUser.getLogin());
                
                log.info("PPE_ID: " + auctionUser.getPpe().getPpeId());
                log.info("PPE_VOLUMEN: " + auctionUser.getPpe().getValue());
            }
            
            
        }
        else
        {
            log.info(">>>>> AUCTION_DETEILS ID NULL <<<<");
        }
    }
    
    /**
     * Instantiates a new auction bean.
     */
    public AuctionBean() {
        log.info("AuctionBean constructor");
        initializeDao();
        initializeVars();
    }

    /**
     * Initialize dao.
     */
    private void initializeDao() {
        cityDao = GuiceSingleton.getInstance().getInstance(CityDao.class);
        auctionDao = GuiceSingleton.getInstance().getInstance(AuctionDao.class);
    }

    /**
     * Initialize vars.
     */
    private void initializeVars() {
        log.info("initializeVars");
        dictionaryBean = ComponentLookup.lookupComponent("op.dictionaryBean");

        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();

        auction = new Auction();
        auction.setCloud(new Cloud());
    }

    /**
     * Initialize on load.
     */
    public void initializeOnLoad() {
        log.info("initializeOnLoad");
        try {
            if(!isInitializedDicts()) {
                initializeDicts();
            }
            tariffs = dictionaryBean.getTariffsList();
            stereotypes = dictionaryBean.getStereotypesList();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * Initialize dicts.
     */
    public void initializeDicts() {
        areas = dictionaryBean.getAreasList();
        cities = new ArrayList<City>();
    }

    /**
     * Checks if is initialized dicts.
     * 
     * @return true, if is initialized dicts
     */
    private boolean isInitializedDicts() {
        if(null == areas || null == cities) {
            return false;
        }
        if(areas.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Checks if is initialized.
     * 
     * @return true, if is initialized
     */
    private boolean isInitialized() {
        if(!isInitializedDicts()) {
            return false;
        }
        if(null == tariffs || null == stereotypes) {
            return false;
        }
        if(tariffs.isEmpty() || stereotypes.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Search auctions.
     * 
     * @param auctionFilter
     *            the auction filter
     * @return the list
     */
    public List<Auction> searchAuctions(AuctionFilter auctionFilter) {
        List<Auction> auctions = new ArrayList<Auction>();

        if(auctionFilter.getEndTime() != null) {
            Date finishDate = new Date();
            auctionFilter.getAuction().setFinishDate(
                    new Date((long) (finishDate.getTime() + auctionFilter.getEndTime() * HOUR)));
        }

        try {
            auctions = auctionDao.getAuctions(auctionFilter);

            for(int i = 0; i < auctions.size(); i++) {
                auctions.get(i).setPotentialUsers(auctionDao.getPotentialUsers(auctions.get(i)));
                auctions.get(i).setSalesmans(auctionDao.getAuctionSalesmans(auctions.get(i)));
            }

        } catch (Exception e) {
            log.error("Problem while search operator auctions: ", e);
        }

        return auctions;
    }

    /**
     * Not constant prices.
     * 
     * @param auctionOfferId
     *            the auction offer id
     * @return the double
     */
    public Double notConstantPrices(Integer auctionOfferId) {
        Double price = null;
        PriceComponentValue priceComponentValue = initializePriceComponentValue();
        priceComponentValue.getAuctionOffer().setAuctionOfferId(auctionOfferId);
        priceComponentValue.getPriceComponent().setConstant(false);

        try {
            price = auctionDao.getPriceComponentValuesByConstant(priceComponentValue);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return price;
    }

    /**
     * Initialize price component value.
     * 
     * @return the price component value
     */
    private PriceComponentValue initializePriceComponentValue() {
        PriceComponentValue priceComponentValue = new PriceComponentValue();
        priceComponentValue.setAuctionOffer(new AuctionOffer());
        priceComponentValue.setPriceComponent(new PriceComponent());

        return priceComponentValue;
    }

    /**
     * Constant prices.
     * 
     * @param auctionOfferId
     *            the auction offer id
     * @return the double
     */
    public Double constantPrices(Integer auctionOfferId) {
        Double price = null;
        PriceComponentValue priceComponentValue = initializePriceComponentValue();
        priceComponentValue.getAuctionOffer().setAuctionOfferId(auctionOfferId);
        priceComponentValue.getPriceComponent().setConstant(true);

        try {
            price = auctionDao.getPriceComponentValuesByConstant(priceComponentValue);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return price;
    }

    /**
     * Contract date.
     * 
     * @return the string
     */
    public String contractDate() {

        String ret1 = "", ret = "";

        if(auction.getBeginContractDate() != null) {
            ret = new SimpleDateFormat("dd-MM-yyyy").format(auction.getBeginContractDate());
        }
        if(auction.getEndContractDate() != null) {
            ret1 = new SimpleDateFormat("dd-MM-yyyy").format(auction.getEndContractDate());
        }

        return BundlesUtils.getMessageResourceString("messages", "from", null, Locale.getDefault()) + " " + ret + " "
                + BundlesUtils.getMessageResourceString("messages", "to", null, Locale.getDefault()) + " " + ret1;
    }

    /**
     * Auction status.
     * 
     * @return the string
     */
    public String auctionStatus() {
        if(auction.getStatus() != null)
            return BundlesUtils.getMessageResourceString("messages", "auction.status." + auction.getStatus(), null,
                    Locale.getDefault());
        else
            return "";
    }

    /**
     * Change auction offer status.
     */
    public void changeAuctionOfferStatus() {
        if(auctionOffer.getStatus() == AuctionStatus.INPROGRESS)
            auctionOffer.setStatus(AuctionStatus.SUSPENDED);
        else
            auctionOffer.setStatus(AuctionStatus.INPROGRESS);
    }

    /**
     * Edits the auction action.
     * 
     * @return the string
     */
    public String editAuctionAction() {
        return "operatorAuctionEdit";
    }

    /**
     * Sets the auction components.
     * 
     * @param auction
     *            the new auction components
     */
    public void setAuctionComponents(Auction auction) {
        this.auction = auction;

        try {
            this.auction.setAuctionOffers(auctionDao.getAuctionOffers(auction));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * Lock message.
     * 
     * @return the string
     */
    public String lockMessage() {
        if(auctionOffer != null) {
            Object[] param = new Object[1];
            param[0] = auctionOffer.getAuctionOfferId();

            if(auctionOffer.getStatus() == AuctionStatus.INPROGRESS)
                return BundlesUtils.getMessageResourceString("messages", "label.offer.block", param,
                        Locale.getDefault());
            else
                return BundlesUtils.getMessageResourceString("messages", "label.offer.unblock", param,
                        Locale.getDefault());
        } else
            return "";
    }

    /**
     * Auction offer tariff.
     */
    public void auctionOfferTariff() {
        auctionOffer.setAuction(auction);
        try {
            log.info("cloudID: "+auction.getCloud().getCloudId()+", auctionOffe: " + auctionOffer.getAuctionOfferId());
            auctionOffer.setPriceComponentValues(auctionDao.getAuctionOfferTariff(auctionOffer));
            log.info("princesComponents size:" + auctionOffer.getPriceComponentValues().size());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * On auction offer select.
     * 
     * @param event
     *            the event
     */
    public void onAuctionOfferSelect(SelectEvent event) {
        auctionOfferButtons = false;
    }

    /**
     * Change auction status.
     */
    public void changeAuctionStatus() {
        try {
            if(auction.getStatus() == AuctionStatus.INPROGRESS) {
                auction.setStatus(AuctionStatus.SUSPENDED);

                auctionDao.updateAuction(auction);

                for(int i = 0; i < auction.getAuctionOffers().size(); i++) {
                    auction.getAuctionOffers().get(i).setStatus(AuctionStatus.SUSPENDED);

                    auctionDao.updateAuctionOffer(auction.getAuctionOffers().get(i));
                }

                removeUsersFromAuction();

            } else {
                auction.setStatus(AuctionStatus.INPROGRESS);

                auctionDao.updateAuction(auction);

                for(int i = 0; i < auction.getAuctionOffers().size(); i++) {
                    auction.getAuctionOffers().get(i).setStatus(AuctionStatus.INPROGRESS);

                    auctionDao.updateAuctionOffer(auction.getAuctionOffers().get(i));
                }
            }
        } catch (Exception e1) {
            log.error("Problem while change auction status: ", e1);
        }
    }

    /**
     * Update auction.
     */
    public void updateAuction() {
        try {
            auctionDao.updateAuction(auction);

            for(int i = 0; i < auction.getAuctionOffers().size(); i++) {
                auctionDao.updateAuctionOffer(auction.getAuctionOffers().get(i));
            }

            // removeUsersFromAuction();
        } catch (Exception e1) {
            e1.printStackTrace();
        }

        info("message.auction.updated");

    }

    /**
     * Removes the users from auction.
     */
    private void removeUsersFromAuction() {
        try {
            List<UserApp> auctionUsers = auctionDao.getAuctionUsersToDelete(auction);
            auctionDao.deleteUsersFromAuction(auction);

            for(int i = 0; i < auctionUsers.size(); i++) {
                AuctionUser auctionUsr = new AuctionUser();
                auctionUsr.setUserApp(auctionUsers.get(i));
                auctionUsr.setAuction(auction);

                sendEmail(auctionDao.getUserOffer(auctionUsr), auctionUsers.get(i));
                // TO-DO wysylac wiadomosc na messanger z komunikatem usuniecia
                // z aukcji
            }

            log.info("Removed " + auctionUsers.size() + " users from auction with id= " + auction.getAuctionId());

        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    /**
     * Send email.
     * 
     * @param auctionOffer
     *            the auction offer
     * @param user
     *            the user
     */
    private void sendEmail(AuctionOffer auctionOffer, UserApp user) {
        MailBean mailBean = ComponentLookup.lookupComponent("op.mailBean");

        try {
            mailBean.sendAuctionBlockEmail(user, auctionOffer);
        } catch (Exception e) {
            log.error("EXCEPTION:", e);
        }

    }

    /**
     * Auction ends.
     * 
     * @param endDate
     *            the end date
     * @return the string
     */
    public String auctionEnds(Date endDate) {
        String result = "";
        long diffrence = endDate.getTime() - System.currentTimeMillis();
        if(diffrence / 1000 % 60 > 1)
            result = diffrence / 1000 % 60 + "s";

        if(diffrence / 1000 / 60 % 60 > 1)
            result = diffrence / 1000 / 60 % 60 + "m " + result;

        if(diffrence / 1000 / 60 / 60 % 60 > 1)
            result = diffrence / 1000 / 60 / 60 % 24 + "h " + result;

        if(diffrence / 1000 / 60 / 60 / 24 % 24 > 1)
            result = diffrence / 1000 / 60 / 60 / 24 + "d " + result;

        return result;
    }

    /**
     * Price component const.
     * 
     * @param isConst
     *            the is const
     * @param value
     *            the value
     * @param pConst
     *            the const
     * @return the string
     */
    public String priceComponentConst(boolean isConst, Double value, boolean pConst) {
        if(isConst == pConst)
            return value.toString();
        else
            return "-";
    }

    /**
     * Cloud data.
     * 
     * @return the string
     */
    public String cloudData() {
        String result = "";

        try {
            if(auction.getCloud().getCities() != null) {
                for(int i = 0; i < auction.getCloud().getCities().size(); i++) {
                    result += auction.getCloud().getCities().get(i).getCityName();
                    if((i + 1) < auction.getCloud().getCities().size())
                        result += ", ";
                }
            }

            if(auction.getCloud().getStreets() != null) {
                result += " ";
                for(int i = 0; i < auction.getCloud().getStreets().size(); i++) {
                    result += auction.getCloud().getStreets().get(i).getStreetName();
                    if((i + 1) < auction.getCloud().getStreets().size()) {
                        result += ", ";
                    }
                }
            }

            result += " " + auction.getCloud().getTariff().getTariffName();
            if(auction.getCloud().getStereotype() != null) {
                result += " " + auction.getCloud().getStereotype().getStereotypeName();
            }

        } catch (Exception e) {
            log.info("Problem while initialize edit auction: ", e);
        }

        return result;
    }

    /**
     * Gets the areas.
     * 
     * @return the areas
     */
    public List<Area> getAreas() {
        if(!isInitialized()) {
            initializeOnLoad();
        }
        return areas;
    }

    /**
     * Sets the areas.
     * 
     * @param areas
     *            the new areas
     */
    public void setAreas(List<Area> areas) {
        this.areas = areas;
    }

    /**
     * Gets the cities.
     * 
     * @return the cities
     */
    public List<City> getCities() {
        if(!isInitialized()) {
            initializeOnLoad();
        }
        return cities;
    }

    /**
     * Sets the cities.
     * 
     * @param cities
     *            the new cities
     */
    public void setCities(List<City> cities) {
        this.cities = cities;
    }

    /**
     * Gets the tariffs.
     * 
     * @return the tariffs
     */
    public List<Tariff> getTariffs() {
        if(!isInitialized()) {
            initializeOnLoad();
        }
        return tariffs;
    }

    /**
     * Sets the tariffs.
     * 
     * @param tariffs
     *            the new tariffs
     */
    public void setTariffs(List<Tariff> tariffs) {
        this.tariffs = tariffs;
    }

    /**
     * Gets the stereotypes.
     * 
     * @return the stereotypes
     */
    public List<Stereotype> getStereotypes() {
        if(!isInitialized()) {
            initializeOnLoad();
        }
        return stereotypes;
    }

    /**
     * Sets the stereotypes.
     * 
     * @param stereotypes
     *            the new stereotypes
     */
    public void setStereotypes(List<Stereotype> stereotypes) {
        this.stereotypes = stereotypes;
    }

    /**
     * Gets the auction attributes.
     * 
     * @return the auction attributes
     */
    public List<AuctionAttributesEnum> getAuctionAttributes() {
        auctionAttributes = new ArrayList<AuctionAttributesEnum>();

        for(AuctionAttributesEnum a : AuctionAttributesEnum.values()) {
            a.setLabel(BundlesUtils.getMessageResourceString("messages", "auction.attribute." + a, null,
                    Locale.getDefault()));

            auctionAttributes.add(a);
        }

        return auctionAttributes;
    }

    /**
     * Sets the auction attributes.
     * 
     * @param auctionAttributes
     *            the new auction attributes
     */
    public void setAuctionAttributes(List<AuctionAttributesEnum> auctionAttributes) {
        this.auctionAttributes = auctionAttributes;
    }

    /**
     * Gets the auction end.
     * 
     * @return the auction end
     */
    public List<AuctionEndEnum> getAuctionEnd() {
        auctionEnd = new ArrayList<AuctionEndEnum>();

        for(AuctionEndEnum a : AuctionEndEnum.values()) {
            a.setLabel(BundlesUtils.getMessageResourceString("messages", "auction.end." + a, null, Locale.getDefault()));

            auctionEnd.add(a);
        }

        return auctionEnd;
    }

    /**
     * Sets the auction end.
     * 
     * @param auctionEnd
     *            the new auction end
     */
    public void setAuctionEnd(List<AuctionEndEnum> auctionEnd) {
        this.auctionEnd = auctionEnd;
    }

    /**
     * Gets the auction.
     * 
     * @return the auction
     */
    public Auction getAuction() {
        return auction;
    }

    /**
     * Sets the auction.
     * 
     * @param auction
     *            the new auction
     */
    public void setAuction(Auction auction) {
        this.auction = auction;
    }

    /**
     * Gets the auction offer.
     * 
     * @return the auction offer
     */
    public AuctionOffer getAuctionOffer() {
        return auctionOffer;
    }

    /**
     * Sets the auction offer.
     * 
     * @param auctionOffer
     *            the new auction offer
     */
    public void setAuctionOffer(AuctionOffer auctionOffer) {
        this.auctionOffer = auctionOffer;
    }

    /**
     * Checks if is auction offer buttons.
     * 
     * @return true, if is auction offer buttons
     */
    public boolean isAuctionOfferButtons() {
        return auctionOfferButtons;
    }

    /**
     * Sets the auction offer buttons.
     * 
     * @param auctionOfferButtons
     *            the new auction offer buttons
     */
    public void setAuctionOfferButtons(boolean auctionOfferButtons) {
        this.auctionOfferButtons = auctionOfferButtons;
    }

    /**
     * Gets the volumes.
     * 
     * @return the volumes
     */
    public List<VolumeEnum> getVolumes() {
        volumes = new ArrayList<VolumeEnum>();

        for(VolumeEnum a : VolumeEnum.values()) {
            a.setLabel(BundlesUtils.getMessageResourceString("messages", "cloud.volume." + a, null, Locale.getDefault()));

            volumes.add(a);
        }

        return volumes;
    }

    /**
     * Sets the volumes.
     * 
     * @param volumes
     *            the new volumes
     */
    public void setVolumes(List<VolumeEnum> volumes) {
        this.volumes = volumes;
    }

    /**
     * Success.
     * 
     * @param message_code
     *            the message_code
     */
    public void success(String message_code) {
        FacesMessages.instance().add(
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    /**
     * Info.
     * 
     * @param message_code
     *            the message_code
     */
    @SuppressWarnings({ "deprecation" })
    public void info(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_INFO,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    /**
     * Users percentage.
     * 
     * @param auction
     *            the auction
     * @return the double
     */
    public double usersPercentage(Auction auction) {

        double result = 0;

        try {
            result = ((double) ((double) auction.getUserCount() / ((double) auction.getPotentialUsers())) * 100);
            if (result > 100) result = 0.0;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    /**
     * Salesmans print.
     * 
     * @param auction
     *            the auction
     * @return the string
     */
    public String salesmansPrint(Auction auction) {
        List<Salesman> salesmans = auction.getSalesmans();
        String result = "";

        try {
            for(int i = 0; i < salesmans.size(); i++) {
                if(!result.equals("")) {
                    result += ", ";
                }

                result += salesmans.get(i).getSalesmanName();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    /**
     * Gets the city.
     * 
     * @param filterCity
     *            the filter city
     * @return the city
     */
    public City getCity(City filterCity) {

        City city = null;

        try {
            city = cityDao.getCity(filterCity);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return city;
    }

    public void onTabChange(TabChangeEvent event) {
        actualTab = event.getTab().getId();
        log.info("change to tab: " + actualTab);
    }

    public Auction getAuctionDetails() throws Exception {
        //log.info("[getAuctionDetails]");
        if(null == actualTab || "inProgressAuctionBox".equals(actualTab)) {
            AuctionInProgressBean bean = ComponentLookup.lookupComponent("op.operatorAuctionInProgressBean");
            auctionDetails = bean.getAuction();
        } else if ("finishedAuctionBox".equals(actualTab)) {
            AuctionFinishedBean bean = ComponentLookup.lookupComponent("op.operatorAuctionFinishedBean");
            auctionDetails = bean.getAuction();
        } else {
            AuctionSuspendedBean bean = ComponentLookup.lookupComponent("op.operatorAuctionSuspendedBean");
            auctionDetails = bean.getAuction();
        }
        
        if ( auctionDetails != null && auctionDetails.getAuctionId() != null) {
             //log.info("[getAuctionDetails] auctionDetails != null");
            UserDao userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);
            PPEDao ppeDao =GuiceSingleton.getInstance().getInstance(PPEDao.class);
            for ( AuctionUser user : auctionDetails.getAuctionUsers()) {
                
                if (user.getUserApp() != null && user.getUserApp().getUserId() != null) {
                   // log.info ("uiser ID " + user.getUserApp().getUserId());
                     UserApp userFull = userDao.getUserAppbyId(user.getUserApp().getUserId());
                     user.setUserApp(userFull);
                } //else {
                 //     log.info ("uiser ID is null!!");
                //}
               
                if (user.getPpe() != null && user.getPpe().getPpeId() != null) {
                   // log.info ("PPE ID " + user.getPpe().getPpeId());
                    PPE ppeFull = ppeDao.getPPEById(user.getPpe().getPpeId().longValue());
                    user.setPpe(ppeFull);
                }// else {
                //    log.info ("PPE ID is null!!");
                //}
            }
            
            //CloudDao cloudDao =  GuiceSingleton.getInstance().getInstance(CloudDao.class);
           // Cloud cloudFull = cloudDao.get
            
        
        }

        return auctionDetails;
    }
}