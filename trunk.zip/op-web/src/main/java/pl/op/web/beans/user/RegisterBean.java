package pl.op.web.beans.user;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Begin;
import org.jboss.seam.annotations.End;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.faces.FacesMessages;
import org.primefaces.context.RequestContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.UserDao;
import pl.op.model.dict.Month;
import pl.op.model.user.UserApp;
import pl.op.model.user.UserRole;
import pl.op.web.beans.MailBean;
import pl.op.web.beans.auction.operator.AuctionBean;
import pl.op.web.common.ActivateUtil;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.common.LoginUtil;
import pl.op.web.common.MonthUtil;
import pl.op.web.listener.GuiceSingleton;
import pl.op.web.service.BonusService;

@Name("op.registerBean")
@Scope(ScopeType.CONVERSATION)
public class RegisterBean {

	public final String SERVER_URL = "serverURL";

	public RegisterBean() {
		initialize();
	}

	private UserDao bdUser;
	private UserApp userRegistration;
	private UserApp activatePasswordUser;
	private FacesContext facesContext;
	private ExternalContext ectx;
	private String password;

	private boolean regulationAccepted;
        private boolean personalData;
        private boolean marketingData;
	private boolean executionAgree;
	private String activationUrl;

	private Logger log = LoggerFactory.getLogger(RegisterBean.class);

	@RequestParameter("code")
	private String activationCode;

	private void initialize() {
		activationUrl = System.getProperty(SERVER_URL);

		if (activationUrl == null || activationUrl.isEmpty())
			activationUrl = BundlesUtils.getMessageResourceString("seam",
					"activation.url", null, Locale.getDefault()).trim();

		bdUser = GuiceSingleton.getInstance().getInstance(UserDao.class);
		userRegistration = new UserApp();
		activatePasswordUser = new UserApp();
		facesContext = FacesContext.getCurrentInstance();
		ectx = facesContext.getExternalContext();

		regulationAccepted = false;
                personalData = false;
                marketingData = false;
	}

	@Begin
	public String registerAction() {
		initialize();
		setActivationUrl(activationUrl);
		log.info(activationUrl);

		return "registration";
	}

	@End
        
        public void SendToOperation() throws Exception {
            MailBean mailBean = ComponentLookup.lookupComponent("op.mailBean");
            	try {
			log.info(" >>>>>>>>>>>>>>>>>> SendToOperation()");
                       
                        
			 mailBean.sendRegistrationWithOperation( userRegistration.getPhone(), userRegistration.getLogin());
                         userRegistration.setPhone(""); 
                         userRegistration.setLogin("");
		} catch (Exception e) {
			log.error("EXCEPTION:", e);
			throw new Exception();
		}
        }
        
	public String saveUser() {
		boolean loginValidate = checkLoginValidate();

		if (!loginValidate) {
			addCallback(false);
			return "";
		}

		boolean userNotExist;

		try {
			userNotExist = checkuUserLoginExist();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			userNotExist = false;

			String message = BundlesUtils.getMessageResourceString("messages",
					"login_exist_error", null, ectx.getRequestLocale());
			FacesMessages.instance().add(FacesMessage.SEVERITY_ERROR, message);
		}

		if (!userNotExist) {
			addCallback(false);
			return "";
		}

		password = userRegistration.getPassword();

		if (validateForm()) {

			log.info("validate form correct");
                        userRegistration.setAgree(marketingData);
			userRegistration.setActive(false);
			userRegistration.setRemoved(false);
			userRegistration.setIsCompany(false);
			userRegistration.setFirstLogin(true);
			userRegistration.setCreationDate(new Date());
			userRegistration.setActivateKey(ActivateUtil
					.getActivationCode(userRegistration.getLogin()));
			userRegistration.setUserRole(UserRole.user);

			userRegistration
					.setPassword(LoginUtil.generatePasswordHash(
							userRegistration.getPassword(),
							userRegistration.getLogin()));
			// userRegistration.setCreationDate(new Date());

			this.activationCode = ActivateUtil
					.getActivationCode(userRegistration.getLogin());

			log.info("user activation code: " + activationCode);
			log.info("user login: " + userRegistration.getLogin());

			// save user
			try {
				bdUser.saveUser(userRegistration);
				
				/*if(userRegistration.getFirstName().isEmpty() == false){
					BonusService.run("fieldFirstNameRegister",userRegistration);
				}
				if(userRegistration.getSurname().isEmpty() == false){
					BonusService.run("fieldSurnameRegister",userRegistration);
				}*/
				if(userRegistration.getLogin().isEmpty() == false){
					BonusService.run("fieldLoginRegister",userRegistration);
				}
				if(userRegistration.getPassword().isEmpty() == false){
					BonusService.run("fieldPasswordRegister",userRegistration);
				}
				
				BonusService.run("validRegister",userRegistration);
				
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				String addUserFail = BundlesUtils.getMessageResourceString(
						"messages", "add_error", null, ectx.getRequestLocale());
				userRegistration.setPassword(password);
				FacesMessages.instance().add(FacesMessage.SEVERITY_ERROR,
						addUserFail);
				addCallback(false);
				return "";
			}

			// sent confirm mail
			try {
				sentEmail();
			} catch (Exception e) {

				log.info("Locale: " + ectx.getRequestLocale());
				log.error(e.getMessage(), e);

				String mailFail = BundlesUtils.getMessageResourceString(
						"messages", "user.register.mail.fail", null,
						ectx.getRequestLocale());

				FacesMessages.instance().add(FacesMessage.SEVERITY_ERROR,
						mailFail);
				userRegistration.setPassword(password);

				try {
					bdUser.deleteUser(userRegistration);
				} catch (Exception e1) {
					log.error(e1.getMessage(), e1);
					String addUserFail = BundlesUtils.getMessageResourceString(
							"messages", "add_error", null,
							ectx.getRequestLocale());
					FacesMessages.instance().add(FacesMessage.SEVERITY_ERROR,
							addUserFail);
					addCallback(false);
					return "";
				}
				addCallback(false);
				return "";
			}
			addCallback(true);
			return "";
		}
		addCallback(false);
		return "";
	}

	public void sentEmail() throws Exception {

		MailBean mailBean = ComponentLookup.lookupComponent("op.mailBean");

		log.info("sent email confirmation");
		log.info(activationUrl + "/activate.seam?code="
				+ userRegistration.getActivateKey() + "&login="
				+ userRegistration.getLogin());

		try {
			log.info("getting template...");
			mailBean.sendRegistrationEmail(userRegistration,
					activationUrl + "/op-web/activate.seam?code="
							+ userRegistration.getActivateKey() + "&login="
							+ userRegistration.getLogin());
		} catch (Exception e) {
			log.error("EXCEPTION:", e);
			throw new Exception();
		}
	}

	public Boolean validateForm() {

		boolean formValidate = false;
		boolean passwordValidate = checkPasswordValidate();
		boolean regulationsValidate = checkRegulationsValidate();
                boolean personalDataValidate = checkPersonalDataValidate();

		if (passwordValidate) {
			if (regulationsValidate) {
                            if (personalDataValidate) {
                                    formValidate = true;
                            } else {
                                    formValidate = false;
                            }
                        }
		}
		log.info("validate form: " + formValidate);

		return formValidate;
	}

	public boolean checkRegulationsValidate() {
		boolean regulationsValidate = true;

		if (!regulationAccepted) {

			String message = BundlesUtils.getMessageResourceString("messages",
					"regulations.error", null, ectx.getRequestLocale());
			FacesMessages.instance().add(FacesMessage.SEVERITY_WARN, message);
			regulationsValidate = false;
		}

		return regulationsValidate;
	}
        
        public boolean checkPersonalDataValidate() {
		boolean personalDataValidateValidate = true;

		if (!personalData) {

			String message = BundlesUtils.getMessageResourceString("messages",
					"personalData.error", null, ectx.getRequestLocale());
			FacesMessages.instance().add(FacesMessage.SEVERITY_WARN, message);
			personalDataValidateValidate = false;
		}

		return personalDataValidateValidate;
	}
        


	public boolean checkPasswordValidate() {
		boolean passwordValidate = true;
		if (!userRegistration.getPassword().equals(
				userRegistration.getPassword2())) {

			String message = BundlesUtils.getMessageResourceString("messages",
					"password_error", null, ectx.getRequestLocale());
			FacesMessages.instance().add(FacesMessage.SEVERITY_WARN, message);
			passwordValidate = false;

		}

		log.info("passwordValidate: " + passwordValidate);

		return passwordValidate;
	}

	public boolean checkLoginValidate() {
		return true;
	}

	public boolean checkuUserLoginExist() throws Exception {

		boolean userExist = false;

		try {
			userExist = bdUser.checkLocalUserExist(userRegistration.getLogin());

		} catch (Exception e) {
			throw new Exception();
		}

		if (userExist) {
			String message = BundlesUtils.getMessageResourceString("messages",
					"login_exist", null, ectx.getRequestLocale());
			FacesMessages.instance().add(FacesMessage.SEVERITY_WARN, message);
		}

		log.info("userExist: " + userExist);

		return !userExist;
	}

	public UserApp getUserRegistration() {
		return userRegistration;
	}

	public void setUserRegistration(UserApp userRegistration) {
		this.userRegistration = userRegistration;
	}

	public String getActivationCode() {
		return activationCode;
	}

	public void setActivationCode(String activationCode) {
		this.activationCode = activationCode;
	}

	public String getActivationUrl() {
		return activationUrl;
	}

	public void setActivationUrl(String activationUrl) {
		this.activationUrl = activationUrl;
	}

	public boolean isRegulationAccepted() {
		return regulationAccepted;
	}
        
	public void setRegulationAccepted(boolean regulationAccepted) {
		this.regulationAccepted = regulationAccepted;
	}
        
	public void setPersonalData(boolean personalData) {
		this.personalData = personalData;
	}
        
        public boolean istPersonalData() {
		return personalData;
	}

        public boolean getPersonalData() {
            return personalData;
        } 
        
        public void setMarketingData(boolean marketingData) {
		this.marketingData = marketingData;
	}
        
        public boolean istMarketingData() {
		return marketingData;
	}

        public boolean getMarketingData() {
            return marketingData;
        } 

	public boolean isExecutionAgree() {
		return executionAgree;
	}

	public void setExecutionAgree(boolean executionAgree) {
		this.executionAgree = executionAgree;
	}

	public List<Integer> getDays() {
		List<Integer> days = new ArrayList<Integer>();
		for (int a = 1; a < 32; a++) {
			days.add(a);
		}

		return days;
	}

	public List<Month> getMonths() {
		return MonthUtil.getMonths();
	}

	public List<Integer> getYears() {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());

		List<Integer> years = new ArrayList<Integer>();
		for (int a = 1920; a <= calendar.get(Calendar.YEAR); a++) {
			years.add(a);
		}

		return years;
	}

	private void addCallback(boolean result) {
		RequestContext.getCurrentInstance().addCallbackParam(
				"registerSuccessful", result);
	}
}