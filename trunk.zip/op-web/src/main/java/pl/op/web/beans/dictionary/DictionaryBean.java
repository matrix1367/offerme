package pl.op.web.beans.dictionary;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.Install;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Startup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AreaDao;
import pl.op.dao.CityDao;
import pl.op.dao.SectorDao;
import pl.op.dao.SettingsDao;
import pl.op.dao.StereotypeDao;
import pl.op.dao.StreetDao;
import pl.op.dao.TariffDao;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Street;
import pl.op.model.dict.Tariff;
import pl.op.model.stereotype.Sector;
import pl.op.model.stereotype.Stereotype;
import pl.op.settings.Settings;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class DictionaryBean. This class stores all lists downloaded from
 * database.
 */
@Startup
@AutoCreate
@Install
@Name("op.dictionaryBean")
@Scope(ScopeType.APPLICATION)
public class DictionaryBean implements Serializable {

	private static final long serialVersionUID = 127829701776172984L;

	private static int NEXT_AUCTION_MONTHS_THRESHOLD = 3;
	private static int AUCTION_DURATION_DAY = 3;
	public static int ACTUAL_INVOICE_BUFFOR_DAYS = 14;

	private Logger log = LoggerFactory.getLogger(DictionaryBean.class);

	private List<Area> areasList;
	private List<City> citiesList;
	private List<Street> streetsList;
	private List<Tariff> tariffsList;
	private List<Stereotype> stereotypeList;
	private List<Sector> sectorList;

	private HashMap<Integer, List<City>> citiesMap;
	private HashMap<Integer, List<City>> villagesMap;

	private Integer auctionDurationDays;
	private Integer nextAuctionMonthsThreshold;

	private AreaDao areaDao;
	private CityDao cityDao;
	private StreetDao streetDao;
	private TariffDao tariffDao;
	private StereotypeDao stereotypeDao;
	private SectorDao sectorDao;
	private SettingsDao settingsDao;

	public DictionaryBean() {
		log.info("DictionaryBean constructor");
		initialize();
	}

	/**
	 * Initialize the DictionaryBean.
	 */
	private void initialize() {
		areaDao = GuiceSingleton.getInstance().getInstance(AreaDao.class);
		cityDao = GuiceSingleton.getInstance().getInstance(CityDao.class);
		streetDao = GuiceSingleton.getInstance().getInstance(StreetDao.class);
		tariffDao = GuiceSingleton.getInstance().getInstance(TariffDao.class);
		stereotypeDao = GuiceSingleton.getInstance().getInstance(
				StereotypeDao.class);
		sectorDao = GuiceSingleton.getInstance().getInstance(SectorDao.class);
		settingsDao = GuiceSingleton.getInstance().getInstance(
				SettingsDao.class);

		citiesMap = new HashMap<Integer, List<City>>();
		villagesMap = new HashMap<Integer, List<City>>();
		areasList = new ArrayList<Area>();
		citiesList = new ArrayList<City>();
		streetsList = new ArrayList<Street>();
		tariffsList = new ArrayList<Tariff>();
		stereotypeList = new ArrayList<Stereotype>();
		sectorList = new ArrayList<Sector>();
		auctionDurationDays = 3;

		refreshAreas();
		refreshCities();
		refreshStreets();
		refreshTariffs();
		refreshStereotypes();
		refreshSectors();
		refreshAuctionDurationDays();
		refreshNextAuctionMonthsThreshold();
	}

	/**
	 * Refresh lists of all elements.
	 */
	public void refreshAllLists() {
		refreshAreas();
		refreshCities();
		refreshStreets();
		refreshTariffs();
		refreshStereotypes();
		refreshSectors();
		refreshAuctionDurationDays();
		refreshNextAuctionMonthsThreshold();
	}

	/**
	 * Refresh areas.
	 */
	public void refreshAreas() {
		try {
			areasList = areaDao.getAreas(new Area());
		} catch (Exception e) {
			log.error("Error while getting AreasList : ", e);
			e.printStackTrace();
		}
	}

	/**
	 * Refresh cities.
	 */
	public void refreshCities() {
		try {
			citiesList = cityDao.getCitiesList();
                        //citiesList = new ArrayList<City>();
			for (City city : citiesList) {
				if (city.getHasStatus() != null && city.getHasStatus()) {
					if (!citiesMap.containsKey(city.getArea().getAreaId())) {
						citiesMap.put(city.getArea().getAreaId(),
								new ArrayList<City>());
					}
					citiesMap.get(city.getArea().getAreaId()).add(city);
				} else {
					if (!villagesMap.containsKey(city.getArea().getAreaId())) {
						villagesMap.put(city.getArea().getAreaId(),
								new ArrayList<City>());
					}
					villagesMap.get(city.getArea().getAreaId()).add(city);
				}
			}
			log.info("cities map size: " + citiesMap.size());
			log.info("villages map size: " + villagesMap.size());
		} catch (Exception e) {
			log.error("Error while getting CitiesList : ", e);
			e.printStackTrace();
		}

	}

	/**
	 * Refresh streets.
	 */
	public void refreshStreets() {
		try {
			streetsList = streetDao.getStreetsList();
		} catch (Exception e) {
			log.error("Error while getting StreetsList : ", e);
			e.printStackTrace();
		}
	}

	/**
	 * Refresh tariffs.
	 */
	public void refreshTariffs() {
		try {
			tariffsList = tariffDao.getTariffs(new Tariff());
		} catch (Exception e) {
			log.error("Error while getting TariffsList : ", e);
			e.printStackTrace();
		}
	}

	/**
	 * Refresh stereotypes.
	 */
	public void refreshStereotypes() {
		try {
			stereotypeList = stereotypeDao.getStereotypes(new Sector());
		} catch (Exception e) {
			log.error("Error while getting stereotypeList : ", e);
			e.printStackTrace();
		}
	}

	/**
	 * Refresh sectors.
	 */
	public void refreshSectors() {
		try {
			sectorList = sectorDao.getSector();
		} catch (Exception e) {
			log.error("Error while getting sectorList : ", e);
			e.printStackTrace();
		}
	}

	/**
	 * Refresh next auction months threshold.
	 */
	public void refreshNextAuctionMonthsThreshold() {
		try {
			Settings setting = settingsDao
					.getSettingByType("nextAuctionMonthsThreshold");
			if (null == setting) {
				addDefaultNextAuctionMonthsThreshold();
				nextAuctionMonthsThreshold = NEXT_AUCTION_MONTHS_THRESHOLD;
			} else {
				nextAuctionMonthsThreshold = setting.getSettingValue();
			}
		} catch (Exception e) {
			log.error("Error while refreshing auctionDurationDays: ", e);
			e.printStackTrace();
		}
	}

	/**
	 * Adds the default next auction months threshold.
	 * 
	 * @throws Exception
	 *             the exception
	 */
	private void addDefaultNextAuctionMonthsThreshold() throws Exception {
		Settings setting = new Settings();
		setting.setSettingName("Interwał pomiędzy następną aukcją a końcem umowy");
		setting.setSettingType("nextAuctionMonthsThreshold");
		setting.setSettingValue(NEXT_AUCTION_MONTHS_THRESHOLD);
		settingsDao.saveSetting(setting);
	}

	/**
	 * Refresh auction duration days.
	 */
	public void refreshAuctionDurationDays() {
		try {
			Settings setting = settingsDao
					.getSettingByType("auctionDurationDays");
			if (null == setting) {
				addDefaultAuctionDurationDays();
				auctionDurationDays = AUCTION_DURATION_DAY;
			} else {
				auctionDurationDays = setting.getSettingValue();
			}
		} catch (Exception e) {
			log.error("Error while refreshing auctionDurationDays: ", e);
			e.printStackTrace();
		}
	}

	/**
	 * Adds the default auction duration days.
	 * 
	 * @throws Exception
	 *             the exception
	 */
	private void addDefaultAuctionDurationDays() throws Exception {
		Settings setting = new Settings();
		setting.setSettingName("Czas trwania aukcji(dni)");
		setting.setSettingType("auctionDurationDays");
		setting.setSettingValue(AUCTION_DURATION_DAY);

		settingsDao.saveSetting(setting);
	}

	public List<Area> getAreasList() {
		return areasList;
	}

	public void setAreasList(List<Area> areasList) {
		this.areasList = areasList;
	}

	public List<City> getCitiesList() {
		return citiesList;
	}

	public void setCitiesList(List<City> citiesList) {
		this.citiesList = citiesList;
	}

	public List<Street> getStreetsList() {
		return streetsList;
	}

	public void setStreetsList(List<Street> streetsList) {
		this.streetsList = streetsList;
	}

	public List<Tariff> getTariffsList() {
		return tariffsList;
	}

	public void setTariffsList(List<Tariff> tariffsList) {
		this.tariffsList = tariffsList;
	}

	public List<Stereotype> getStereotypesList() {
		return stereotypeList;
	}

	public List<Sector> getSectorList() {
		return sectorList;
	}

	public Integer getAuctionDurationDays() {
		return auctionDurationDays;
	}

	public HashMap<Integer, List<City>> getCitiesMap() {
		return citiesMap;
	}

	public void setCitiesMap(HashMap<Integer, List<City>> citiesMap) {
		this.citiesMap = citiesMap;
	}

	public HashMap<Integer, List<City>> getVillagesMap() {
		return villagesMap;
	}

	public void setVillagesMap(HashMap<Integer, List<City>> villagesMap) {
		this.villagesMap = villagesMap;
	}

	public Integer getNextAuctionMonthsThreshold() {
		return nextAuctionMonthsThreshold;
	}

	public void setNextAuctionMonthsThreshold(Integer nextAuctionMonthsThreshold) {
		this.nextAuctionMonthsThreshold = nextAuctionMonthsThreshold;
	}
}