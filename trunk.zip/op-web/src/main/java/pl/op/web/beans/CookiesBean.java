package pl.op.web.beans;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.Cookie;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class CookiesBean.
 */
@Name("op.cookiesBean")
@Scope(ScopeType.SESSION)
public class CookiesBean implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 2L;
    private Logger log = LoggerFactory.getLogger(CookiesBean.class);
    private boolean barVisible = true;
    Map<String, Object> requestCookieMap;
    private ExternalContext ctx;
    Map<String, Object> cookieProperties = new HashMap<String, Object>();

    /**
     * Instantiates a new cookies bean.
     */
    public CookiesBean() {
        //log.info("CookiesBean constructor");
        if(!isInitialized()) {
            initialize();
        }
    }

    /**
     * Checks if is initialized.
     * 
     * @return true, if is initialized
     */
    private boolean isInitialized() {
        if(ctx == null) {
            return false;
        }
        return true;
    }

    /**
     * Initialize.
     */
    private void initialize() {
        //log.info("CookiesBean initialization...");
        refreshCookie();
        //log.info("CookiesBean initialized");
       // log.info("CookiesBean setting maxAge to 365");
        cookieProperties.put("maxAge", 60 * 60 * 24 * 365);
    }

    /**
     * Refresh cookie.
     */
    private void refreshCookie() {
        if(!barVisible)
            return;
        //log.info("refreshCookie");
        ctx = FacesContext.getCurrentInstance().getExternalContext();
        getRequestCookieMap();
    }

    /**
     * Gets the request cookie map.
     * 
     * @return the request cookie map
     */
    private void getRequestCookieMap() {
        requestCookieMap = ctx.getRequestCookieMap();
    }

    /**
     * Accept cookies.
     */
    public void acceptCookies() {
        try {
            //log.info("CookiesBean acceptCookies()");
            ctx.addResponseCookie("cookieInfo", "false", cookieProperties);
            // log.warn("setting cookie: " +
            // ((Cookie)requestCookieMap.get("cookieInfo")).getValue());
            barVisible = false;
           // log.info("CookiesBean accepted cookies...");
        } catch (Exception e) {
            log.error("Problem while accepting cookies: ", e);
        }
        barVisible = false;
    }

    /**
     * Gets the bar visible.
     * 
     * @return the barVisible
     */
    public boolean getBarVisible() {
        if(!barVisible)
            return barVisible;
        refreshCookie();
        Cookie cookie = (Cookie) requestCookieMap.get("cookieInfo");
        // log.info("cookie is: " + cookie.getValue());
        if(cookie != null && cookie.getValue().equals("false")) {
            return barVisible = false;
        }
        return barVisible = true;
    }

    /**
     * Sets the bar visible.
     * 
     * @param barVisible
     *            the barVisible to set
     */
    public void setBarVisible(boolean barVisible) {
        this.barVisible = barVisible;
    }

}
