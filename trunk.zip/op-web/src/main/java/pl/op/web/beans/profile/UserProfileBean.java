package pl.op.web.beans.profile;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.security.Identity;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.op.dao.AgreementDao;
import pl.op.dao.AreaDao;
import pl.op.dao.BuildingDao;
import pl.op.dao.CityDao;
import pl.op.dao.DistributorDao;
import pl.op.dao.InvoiceDao;
import pl.op.dao.LocationDao;
import pl.op.dao.MeasureDao;
import pl.op.dao.MeterModelDao;
import pl.op.dao.PPEDao;
import pl.op.dao.PrefQuestDao;
import pl.op.dao.QuestValueDao;
import pl.op.dao.SalesmanDao;
import pl.op.dao.StreetDao;
import pl.op.dao.TariffDao;
import pl.op.dao.UserDao;
import pl.op.model.contract.Agreement;
import pl.op.model.contract.AgreementType;
import pl.op.model.contract.DurationType;
import pl.op.model.contract.Invoice;
import pl.op.model.contract.InvoicePriceComponentValue;
import pl.op.model.contract.Location;
import pl.op.model.contract.PPE;
import pl.op.model.contract.PPEStatus;
import pl.op.model.device.Device;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Distributor;
import pl.op.model.dict.MeterModel;
import pl.op.model.dict.PPETariff;
import pl.op.model.dict.Street;
import pl.op.model.dict.Tariff;
import pl.op.model.question.PreferenceQuestion;
import pl.op.model.question.QuestionValue;
import pl.op.model.salesman.Salesman;
import pl.op.model.stereotype.AcType;
import pl.op.model.stereotype.Building;
import pl.op.model.stereotype.BuildingType;
import pl.op.model.stereotype.HeatingBuildingType;
import pl.op.model.stereotype.HeatingWaterType;
import pl.op.model.stereotype.IsolationBuildingTime;
import pl.op.model.stereotype.Sector;
import pl.op.model.stereotype.WarmBuildingOutside;
import pl.op.model.stereotype.WindowsType;
import pl.op.model.user.UserApp;
import pl.op.util.CloudUtil;
import pl.op.util.DictUtil;
import pl.op.util.LocationUtil;
import pl.op.util.MessageUtil;
import pl.op.util.PpeUtil;
import pl.op.util.UserUtil;
import pl.op.validation.Validations;
import pl.op.web.beans.AdminBean;
import pl.op.web.beans.bill.BillInvoiceBean;
import pl.op.web.beans.dashboard.DashboardBean;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.beans.wizard.WizardBuildingBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.common.LoginUtil;
import pl.op.web.listener.GuiceSingleton;
import pl.op.web.service.AutoCloudGenerator;

/**
 * The Class UserProfileBean.
 */
@Name("op.userProfileBean")
@Scope(ScopeType.SESSION)
public class UserProfileBean {

    private Logger log = LoggerFactory.getLogger(UserProfileBean.class);

    private FacesContext facesContext;
    private ExternalContext ectx;

    private UserApp userApp;
    private List<Sector> sectorList;

    private PPE selectedPpe;
    private PPE tempSelectedPpe;
    private PPE newPpe;
    private List<PPE> userPpes;
    private Invoice ppeInvoice;
    private List<InvoicePriceComponentValue> priceComponentValues;
    private Integer locationPpeId;
    private Agreement agreement;
    private Agreement tempAgreement;
    private Distributor tmpDistributor = null;

    private Location selectedLocation;
    private List<Location> locationList;
    private List<IsolationBuildingTime> isolationBuildingTime = new ArrayList<IsolationBuildingTime>();
    private List<WindowsType> windowsType = new ArrayList<WindowsType>();
    private List<WarmBuildingOutside> warmBuildingOutside = new ArrayList<WarmBuildingOutside>();
    private List<HeatingBuildingType> heatingBuildingType = new ArrayList<HeatingBuildingType>();
    private List<HeatingWaterType> heatingWaterType = new ArrayList<HeatingWaterType>();
    private List<BuildingType> buildingType = new ArrayList<BuildingType>();
    private List<AcType> acType = new ArrayList<AcType>();

    private List<City> cities;
    private List<Area> areas;
    private List<Street> streets;
    private List<Tariff> tariffs;
    private List<Salesman> salesmans;
    private List<Distributor> distributors;
    private List<AgreementType> agreementTypes;
    private List<DurationType> durationTypes;
    private List<MeterModel> meterModels;

    private List<PreferenceQuestion> preferenceQuestionList;
    private PrefQuestDao prefQuestDao;

    private Integer cityId;
    private Integer tariffId;
    private Integer tempTariffId;
    private Integer areaId;
    private Integer locationId;
    private Integer meterModelId;
    private Integer tempMeterModelId;

    private String salesman;
    private String tempSalesman;
    private String distributor;
    private String tempDistributor;
    private String tariffName;
    private String tempTariffName;
    private String chartDurationType;

    private Date chartDateFrom;
    private Date chartDateTo;
    private Date chartMaxDateTo = null;

    private boolean editDetailsMode;
    private boolean editPpeMode;
    private boolean formInvoiceMode;
    private boolean viewChartPpeMode;
    private boolean editPpeAgreementMode;
    private boolean editPpeMeterMode;
    private boolean editBuildingMode;
    private boolean editPpeDeviceMode;
    private boolean locationCityType;
    private boolean meterInteligent;
    private boolean canViewChart;

    private String password1;
    private String password2;
    private String password0;

    private UserDao userDao;
    private LocationDao locationDao;
    private PPEDao ppeDao;
    private BuildingDao buildingDao;
    private AreaDao areaDao;
    private TariffDao tariffDao;
    private DistributorDao distributorDao;
    private MeterModelDao meterModelDao;
    private CityDao cityDao;
    private StreetDao streetDao;
    private SalesmanDao salesmanDao;
    private AgreementDao agreementDao;
    private QuestValueDao questValueDao;
    private InvoiceDao invoiceDao;
    private MeasureDao measureDao;

    private WizardBuildingBean wizardBuildingBean;
    private DictionaryBean dictionaryBean;
    private AdminBean adminBean;
    private UserApp fakeUser = new UserApp();
      
    /**
     * Instantiates a new user profile bean.
     */
    public UserProfileBean() {
        log.info("UserProfileBean");

        initializeDao();
        initializeVars();
    }

    /**
     * Initialize dao.
     */
    public void initializeDao() {
        log.info("initializeDao");

        userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);
        ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);
        locationDao = GuiceSingleton.getInstance().getInstance(LocationDao.class);
        buildingDao = GuiceSingleton.getInstance().getInstance(BuildingDao.class);
        areaDao = GuiceSingleton.getInstance().getInstance(AreaDao.class);
        tariffDao = GuiceSingleton.getInstance().getInstance(TariffDao.class);
        distributorDao = GuiceSingleton.getInstance().getInstance(DistributorDao.class);
        meterModelDao = GuiceSingleton.getInstance().getInstance(MeterModelDao.class);
        cityDao = GuiceSingleton.getInstance().getInstance(CityDao.class);
        streetDao = GuiceSingleton.getInstance().getInstance(StreetDao.class);
        salesmanDao = GuiceSingleton.getInstance().getInstance(SalesmanDao.class);
        agreementDao = GuiceSingleton.getInstance().getInstance(AgreementDao.class);
        prefQuestDao = GuiceSingleton.getInstance().getInstance(PrefQuestDao.class);
        questValueDao = GuiceSingleton.getInstance().getInstance(QuestValueDao.class);
        invoiceDao = GuiceSingleton.getInstance().getInstance(InvoiceDao.class);
        measureDao = GuiceSingleton.getInstance().getInstance(MeasureDao.class);
    }

    /**
     * Initialize vars.
     */
    public void initializeVars() {
        log.info("initializeVars");

        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();

        editDetailsMode = false;
        editPpeMode = false;
        editPpeAgreementMode = false;
        editPpeMeterMode = false;
        editBuildingMode = false;
        editPpeDeviceMode = false;
        meterInteligent = false;
        viewChartPpeMode = false;
        locationCityType = true;
        formInvoiceMode = false;

        userPpes = new ArrayList<PPE>();
        locationList = new ArrayList<Location>();
        wizardBuildingBean = ComponentLookup.lookupComponent("op.wizardBuildingBean");
        dictionaryBean = ComponentLookup.lookupComponent("op.dictionaryBean");
        adminBean = ComponentLookup.lookupComponent("op.adminBean");
    }

    /**
     * Initialize on load.
     */
    public void initializeOnLoad() {
        log.info("initializeOnLoad");

        if(!isInitializeEnums()) {
            initializeEnums();
        }

        clearSelectedPpe();
        clearSelectedLocation();

        try {
            if(!isInitializedDicts()) {
                initializeDicts();
            }

            userApp = UserUtil.getLoggedUserInstance();

            userPpes = ppeDao.getPPEsByUser(userApp);
            log.info("userPpes.size() - " + userPpes.size());

            sectorList = DictUtil.getSectorListByType(userApp.getIsCompany());
            locationList = new ArrayList<Location>();

            locationList = locationDao.getLocationByUserApp(userApp);
            log.info("locationList.size() - " + locationList.size());
            log.info("locationList: " + locationList.toString());

            tariffs = dictionaryBean.getTariffsList();
            distributors = distributorDao.getDistributors();
            salesmans = salesmanDao.getAllSalesmans();
            meterModels = meterModelDao.getMeterModels();

            preparePrefQuestion();
            UserDeviceBean userDeviceBean = ComponentLookup.lookupComponent("op.profileDeviceBean");
             log.info("UserDeviceBean userDeviceBean");
            
            userDeviceBean.initializeOnLoad();
            
        } catch (Exception e) {
            log.error("Problem while initialize on load user profile bean: ", e);
        }
    }

    /**
     * Checks if is initialized dicts.
     * 
     * @return true, if is initialized dicts
     */
    private boolean isInitializedDicts() {
        if(null == areas) {
            return false;
        }
        if(areas.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Initialize dicts.
     */
    private void initializeDicts() {
        areas = dictionaryBean.getAreasList();
    }

    /**
     * Prepare pref question.
     * 
     * @throws Exception
     *             the exception
     */
    private void preparePrefQuestion() throws Exception {
       log.info("preparePrefQuestion");

        PreferenceQuestion filterpreferenceQuestion = new PreferenceQuestion();        
        filterpreferenceQuestion.setStereotype(userApp.getSector().getStereotype());         
        filterpreferenceQuestion.setUserId(userApp.getUserId());        
        preferenceQuestionList = prefQuestDao.getPreferenceQuestionList(filterpreferenceQuestion);         
        for(PreferenceQuestion pq : preferenceQuestionList) {             
            pq.setStereotype(userApp.getSector().getStereotype());
            pq.setUserId(userApp.getUserId());
            QuestionValue answer = questValueDao.getQuestionValue(pq);             
            pq.setQuestionValue(answer);
        }         
    }

    /**
     * Checks if is initialize.
     * 
     * @return true, if is initialize
     */
    public boolean isInitialize() {
        log.info("isInitialize");

        if(null == userPpes || userPpes.isEmpty()) {
            return false;
        }

        if(null == locationList || locationList.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Checks if is initialize enums.
     * 
     * @return true, if is initialize enums
     */
    public boolean isInitializeEnums() {
        log.info("isInitializeEnums");
        if(isolationBuildingTime.equals(null) || windowsType.equals(null)) {
            return false;
        }

        if(isolationBuildingTime.isEmpty() || windowsType.isEmpty()) {
            return false;
        }
        return true;
    }

    /**
     * Initialize enums.
     */
    public void initializeEnums() {
        log.info("initializeEnums");

        isolationBuildingTime = wizardBuildingBean.getIsolationBuildingTime();
        windowsType = wizardBuildingBean.getWindowsType();
        warmBuildingOutside = wizardBuildingBean.getWarmBuildingOutside();
        heatingBuildingType = wizardBuildingBean.getHeatingBuildingType();
        heatingWaterType = wizardBuildingBean.getHeatingWaterType();
        buildingType = wizardBuildingBean.getBuildingType();
        acType = wizardBuildingBean.getAcType();
    }

    /**
     * Clear selected ppe.
     */
    public void clearSelectedPpe() {
        log.info("clearSelectedPpe");
        selectedPpe = new PPE();
        selectedPpe.setTariff(null);
        selectedPpe.setLocation(new Location());
        selectedPpe.getLocation().setUserApp(userApp);

        clearSelectedPpe(true);

        locationId = 0;
        areaId = null;
        cityId = null;
        tariffId = null;
        meterModelId = null;

        salesman = null;
        distributor = null;

        agreement = new Agreement();
        agreement.setDurationType(null);

        ppeInvoice = new Invoice();
        priceComponentValues = new ArrayList<InvoicePriceComponentValue>();

        editPpeMode = false;
    }

    /**
     * Clear selected ppe.
     * 
     * @param onlyLocation
     *            the only location
     */
    public void clearSelectedPpe(boolean onlyLocation) {
        selectedPpe.getLocation().setStreet(new Street());
        selectedPpe.getLocation().getStreet().setCity(new City());
        selectedPpe.getLocation().getStreet().getCity().setArea(new Area());
    }

    /**
     * Prepare change to password.
     */
    public void prepareChangeToPassword() {

        this.password0 = "";
        this.password1 = "";
        this.password2 = "";

    }

    /**
     * Change password.
     */
    public void changePassword() {

        userApp = adminBean.getUserLog();

        if(password1.equals(password2)) {

            String hashPassword = LoginUtil.generatePasswordHash(password0, userApp.getLogin());
            String hashNewPassword = LoginUtil.generatePasswordHash(password1, userApp.getLogin());

            if(hashPassword.equals(userApp.getPassword())) {
                userApp.setPassword(hashNewPassword);
                try {
                    userDao.updatePassword(userApp);
                    info("message.changePasswordComplete");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                warning("message.badPasswords");
            }

        } else {
            this.password0 = "";
            warning("message.differentPasswords");
        }

    }

    /**
     * Info.
     * 
     * @param message_code
     *            the message_code
     */
    @SuppressWarnings({ "deprecation" })
    public void info(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_INFO,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    /**
     * Warning.
     * 
     * @param message_code
     *            the message_code
     */
    @SuppressWarnings({ "deprecation", "unused" })
    public void warning(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_WARN,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    /**
     * Error.
     * 
     * @param message_code
     *            the message_code
     */
    @SuppressWarnings({ "deprecation" })
    public void error(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_ERROR,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    /**
     * Gets the user app.
     * 
     * @return the user app
     */
    public UserApp getUserApp() {
        return userApp;
    }

    /**
     * Sets the user app.
     * 
     * @param userApp
     *            the new user app
     */
    public void setUserApp(UserApp userApp) {
        this.userApp = userApp;
    }

    /**
     * Validate pesel.
     * 
     * @param user
     *            the user
     * @return true, if successful
     */
    private boolean validatePesel(UserApp user) {
        boolean valid = false;
        Integer result = null;
        try {
            result = pl.op.validation.Validations.validPesel(user.getPesel(), user.getBirthDate());
        } catch (Exception e) {
            log.info("Problem while validate pesel: ", e);
        }

        if(result != null) {
            switch (result) {
                case 0:
                    valid = true;
                    break;
                default:
                    warning("invalid.pesel." + result);
            }
        }
        return valid;
    }

    /**
     * Update user details.
     * 
     * @return true, if successful
     */
    public boolean updateUserDetails() {
        try {

            if(!userApp.getIsCompany() && validatePesel(userApp) == false) {
                log.info("invalid");
                return false;
            }
            if(!userApp.getIsCompany() && userApp.getBirthDate().after(new Date())) {
                warning("warning.date");
                return false;
            }

            if(userApp.getIsCompany() && !Validations.validNip(userApp.getNip())) {
                warning("warning.nip");
                return false;
            }
            if(userApp.getIsCompany() && !Validations.validRegon(userApp.getRegon())) {
                warning("warning.regon");
                return false;
            }

            userApp.setSector(new Sector());
            userApp.getSector().setSectorId(userApp.getSectorId());
            userDao.updateUser(userApp);

            for(Sector sector : sectorList) {
                if(sector.getSectorId().intValue() == userApp.getSectorId().intValue()) {
                    userApp.setSector(sector);
                    break;
                }
            }

            updateUserPpes();

            editDetailsMode = false;
            info("update.user.details.success");

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            error("update.user.details.error");
        }

        return false;

    }

    /**
     * Gets the edits the details mode.
     * 
     * @return the edits the details mode
     */
    public Boolean getEditDetailsMode() {
        return editDetailsMode;
    }

    /**
     * Sets the edits the details mode.
     * 
     * @param editDetailsMode
     *            the new edits the details mode
     */
    public void setEditDetailsMode(Boolean editDetailsMode) {
        if(editDetailsMode) {
            fakeUser = new UserApp();
            fakeUser.setFirstName(userApp.getFirstName());
            fakeUser.setSurname(userApp.getSurname());
            fakeUser.setCompanyName(userApp.getCompanyName());
            fakeUser.setNip(userApp.getNip());
            fakeUser.setRegon(userApp.getRegon());
            fakeUser.setKrs(userApp.getKrs());
            fakeUser.setPhone(userApp.getPhone());
        } else {
            userApp.setFirstName(fakeUser.getFirstName());
            userApp.setSurname(fakeUser.getSurname());
            userApp.setCompanyName(fakeUser.getCompanyName());
            userApp.setNip(fakeUser.getNip());
            userApp.setRegon(fakeUser.getRegon());
            userApp.setKrs(fakeUser.getKrs());
            userApp.setPhone(fakeUser.getPhone());
        }

        this.editDetailsMode = editDetailsMode;
    }

    /**
     * Gets the edits the ppe mode.
     * 
     * @return the edits the ppe mode
     */
    public Boolean getEditPpeMode() {
        return editPpeMode;
    }

    /**
     * Sets the edits the ppe mode.
     * 
     * @param editPpeMode
     *            the new edits the ppe mode
     */
    public void setEditPpeMode(Boolean editPpeMode) {
        this.editPpeMode = editPpeMode;
    }

    /**
     * Gets the edits the building mode.
     * 
     * @return the edits the building mode
     */
    public Boolean getEditBuildingMode() {
        return editBuildingMode;
    }

    /**
     * Sets the edits the building mode.
     * 
     * @param editBuildingMode
     *            the new edits the building mode
     */
    public void setEditBuildingMode(Boolean editBuildingMode) {
        this.editBuildingMode = editBuildingMode;
    }

    /**
     * Gets the sector list.
     * 
     * @return the sector list
     */
    public List<Sector> getSectorList() {
        return sectorList;
    }

    /**
     * Gets the name from sector.
     * 
     * @param sector
     *            the sector
     * @return the name from sector
     */
    public String getNameFromSector(Sector sector) {
        if(userApp.getIsCompany().equals(true)) {
            return sector.getSectorName();
        }

        return sector.getStereotype().getStereotypeName();
    }

    /**
     * Gets the wizard building bean.
     * 
     * @return the wizard building bean
     */
    public WizardBuildingBean getWizardBuildingBean() {
        return wizardBuildingBean;
    }

    /**
     * Sets the wizard building bean.
     * 
     * @param wizardBuildingBean
     *            the new wizard building bean
     */
    public void setWizardBuildingBean(WizardBuildingBean wizardBuildingBean) {
        this.wizardBuildingBean = wizardBuildingBean;
    }

    /**
     * Gets the isolation building time.
     * 
     * @return the isolation building time
     */
    public List<IsolationBuildingTime> getIsolationBuildingTime() {
        return isolationBuildingTime;
    }

    /**
     * Sets the isolation building time.
     * 
     * @param isolationBuildingTime
     *            the new isolation building time
     */
    public void setIsolationBuildingTime(List<IsolationBuildingTime> isolationBuildingTime) {
        this.isolationBuildingTime = isolationBuildingTime;
    }

    /**
     * Gets the windows type.
     * 
     * @return the windows type
     */
    public List<WindowsType> getWindowsType() {
        return windowsType;
    }

    /**
     * Sets the windows type.
     * 
     * @param windowsType
     *            the new windows type
     */
    public void setWindowsType(List<WindowsType> windowsType) {
        this.windowsType = windowsType;
    }

    /**
     * Gets the warm building outside.
     * 
     * @return the warm building outside
     */
    public List<WarmBuildingOutside> getWarmBuildingOutside() {
        return warmBuildingOutside;
    }

    /**
     * Sets the warm building outside.
     * 
     * @param warmBuildingOutside
     *            the new warm building outside
     */
    public void setWarmBuildingOutside(List<WarmBuildingOutside> warmBuildingOutside) {
        this.warmBuildingOutside = warmBuildingOutside;
    }

    /**
     * Gets the heating building type.
     * 
     * @return the heating building type
     */
    public List<HeatingBuildingType> getHeatingBuildingType() {
        return heatingBuildingType;
    }

    /**
     * Sets the heating building type.
     * 
     * @param heatingBuildingType
     *            the new heating building type
     */
    public void setHeatingBuildingType(List<HeatingBuildingType> heatingBuildingType) {
        this.heatingBuildingType = heatingBuildingType;
    }

    /**
     * Gets the heating water type.
     * 
     * @return the heating water type
     */
    public List<HeatingWaterType> getHeatingWaterType() {
        return heatingWaterType;
    }

    /**
     * Sets the heating water type.
     * 
     * @param heatingWaterType
     *            the new heating water type
     */
    public void setHeatingWaterType(List<HeatingWaterType> heatingWaterType) {
        this.heatingWaterType = heatingWaterType;
    }

    /**
     * Gets the building type.
     * 
     * @return the building type
     */
    public List<BuildingType> getBuildingType() {
        return buildingType;
    }

    /**
     * Sets the building type.
     * 
     * @param buildingType
     *            the new building type
     */
    public void setBuildingType(List<BuildingType> buildingType) {
        this.buildingType = buildingType;
    }

    /**
     * Gets the ac type.
     * 
     * @return the ac type
     */
    public List<AcType> getAcType() {
        return acType;
    }

    /**
     * Sets the ac type.
     * 
     * @param acType
     *            the new ac type
     */
    public void setAcType(List<AcType> acType) {
        this.acType = acType;
    }

    /**
     * Gets the user ppes.
     * 
     * @return the user ppes
     */
    public List<PPE> getuserPpes() {
        if(!isInitialize()) {
            initializeOnLoad();
        }
        return userPpes;
    }

    /**
     * Sets the user ppes.
     * 
     * @param userPpes
     *            the new user ppes
     */
    public void setuserPpes(List<PPE> userPpes) {
        this.userPpes = userPpes;
    }

    /**
     * Update user ppes.
     */
    public void updateUserPpes() {
        try {
            userPpes = ppeDao.getPPEsByUser(userApp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Gets the selected ppe.
     * 
     * @return the selected ppe
     */
    public PPE getSelectedPpe() {
        return selectedPpe;
    }

    /**
     * Sets the selected ppe.
     * 
     * @param selectedPpe
     *            the new selected ppe
     */
    public void setSelectedPpe(PPE selectedPpe) {
        this.selectedPpe = selectedPpe;
        onSelectedPpe();
    }

    /**
     * On selected ppe.
     */
    public void onSelectedPpe() {
        log.info("onSelectedPpe - #" + selectedPpe.getPpeId());

        locationId = selectedPpe.getLocation().getLocationId();
        areaId = selectedPpe.getLocation().getStreet().getCity().getArea().getAreaId();
        cityId = selectedPpe.getLocation().getStreet().getCity().getCityId();
        try {
            prepareTariffOnPpeSelect();
            prepareAgreementOnPpeSelect();
            prepareMeterModelOnPpeSelect();
            prepareVarsOnPpeSelect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Prepare tariff on ppe select.
     * 
     * @throws Exception
     *             the exception
     */
    public void prepareTariffOnPpeSelect() throws Exception {
        log.info("prepareTariffOnPpeSelect");

        Tariff tmpActualTariff = ppeDao.getActualTariff(selectedPpe);

        tariffId = tmpActualTariff.getTariffId();
        tariffName = tmpActualTariff.getTariffName();

        selectedPpe.setTariff(tmpActualTariff);
    }

    /**
     * Prepare agreement on ppe select.
     * 
     * @throws Exception
     *             the exception
     */
    public void prepareAgreementOnPpeSelect() throws Exception {
        log.info("prepareAgreementOnPpeSelect");

        agreement = agreementDao.getLastAgreementByPpeId(selectedPpe.getPpeId());
        prepareSalesmanToAgreement();
        prepareDistributorToAgreement();
    }

    /**
     * Prepare salesman to agreement.
     */
    public void prepareSalesmanToAgreement() {
        log.info("prepareSalesmanToAgreement");

        salesman = agreement.getSalesman().getSalesmanName();
        log.info("salesman = " + salesman);
    }

    /**
     * Prepare distributor to agreement.
     */
    public void prepareDistributorToAgreement() {
        log.info("prepareDistributorToAgreement");

        Distributor distributor = selectedPpe.getCurrentDistributor();

        if(distributors != null && distributor != null) {
            if(!distributors.isEmpty()) {
                for(int i = 0; i < distributors.size(); i++) {
                    Distributor d = distributors.get(i);
                    if(d.getDistributorId() == distributor.getDistributorId())
                        this.distributor = d.getName();
                }
            }
        }

        log.info("distributor = " + this.distributor);
    }

    /**
     * Prepare meter model on ppe select.
     */
    public void prepareMeterModelOnPpeSelect() {
        log.info("prepareMeterModelOnPpeSelect");

        MeterModel meterModel = selectedPpe.getMeterModel();
        if(meterModel != null) {
            meterModelId = meterModel.getMeterModelId();
            meterInteligent = meterModel.getIsIntelligent();
        }
    }

    /**
     * Prepare vars on ppe select.
     */
    public void prepareVarsOnPpeSelect() {
        log.info("prepareVarsOnPpeSelect");

        this.editPpeAgreementMode = false;
        this.editPpeMeterMode = false;
        this.tempSelectedPpe = new PPE(selectedPpe);
        this.tempAgreement = new Agreement(agreement);
        this.tempMeterModelId = (meterModelId != null) ? new Integer(meterModelId) : null;
        this.tempTariffId = (tariffId != null) ? new Integer(tariffId) : null;
        this.tempTariffName = (tariffName != null) ? new String(tariffName) : null;
        this.tempSalesman = (salesman != null) ? new String(salesman) : null;
        this.tempDistributor = (this.distributor != null) ? new String(this.distributor) : null;
    }

    /**
     * On meter model select.
     * 
     * @param event
     *            the event
     */
    public void onMeterModelSelect(AjaxBehaviorEvent event) {
        try {
            for(MeterModel meterModel : meterModels) {
                if(meterModel.getMeterModelId().intValue() == meterModelId.intValue()) {
                    meterInteligent = meterModel.getIsIntelligent();
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Revert ppe meter data.
     */
    public void revertPpeMeterData() {
        try {
            log.info("revertPpeMeterData");
            selectedPpe.setCode(tempSelectedPpe.getCode());
            selectedPpe.setMeterNo(tempSelectedPpe.getCode());
            meterModelId = tempMeterModelId;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Revert agreement data.
     */
    public void revertAgreementData() {
        log.info("revertAgreementData");
        try {
            agreement = new Agreement(tempAgreement);
            salesman = tempSalesman;
            distributor = tempDistributor;
            tariffId = tempTariffId;
            tariffName = tempTariffName;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * On ppe tariff select.
     * 
     * @param event
     *            the event
     */
    public void onPpeTariffSelect(AjaxBehaviorEvent event) {
        try {
            Tariff tariff = tariffDao.getTariffById(tariffId);

            selectedPpe.setTariff(tariff);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Go to bills.
     * 
     * @return the string
     */
    public String goToBills() {
        BillInvoiceBean billinvoiceBean = ComponentLookup.lookupComponent("op.billInvoiceBean");
        if(null != newPpe) {
            log.info("newPpeId: " + newPpe.getPpeId());
            billinvoiceBean.invoiceAddAction(newPpe);
        } else {
            billinvoiceBean.invoiceAddAction();
        }
        return "bills";
    }

    /**
     * Save ppe.
     * 
     * @return the string
     */
    public String savePPE() {
        log.info("[savePPE]");
        try {
            if(agreement.getDateFrom() != null && agreement.getDateTo() != null
                    && agreement.getDateFrom().after(agreement.getDateTo())) {
                warning("warning.two.dates.invalid");
                return "";
            }
            
            if (!locationCityType) {
                cityId= null;
            }
            Street s = new Street();
            City city = new City();
            city.setCityId(cityId);
            city.setCityName(selectedPpe.getLocation().getStreet().getCity().getCityName());
            city = cityDao.getCity(city);

            if(city == null) {
                city = new City();
                city.setCityName(selectedPpe.getLocation().getStreet().getCity().getCityName());
            }

            city.setArea(areaDao.getAreaById(areaId));

            s.setStreetName(selectedPpe.getLocation().getStreet().getStreetName());
            s.setCity(city);

            Street street = streetDao.getStreet(s);

            if(street == null)
                street = s;

            street.setCity(city);
            selectedPpe.getLocation().setStreet(street);

            String objectType = PpeUtil.uniquePPEObjectType(selectedPpe.getObjectType(), userPpes);
            selectedPpe.setObjectType(objectType);
            selectedPpe.setPpeStatus(PPEStatus.INVOICE_MISSING);

            if(selectedPpe.getLocation().getLocationId() == null) {
                selectedPpe.getLocation().setLocationId(null);
                selectedPpe.getLocation().setDevices(new ArrayList<Device>());
                selectedPpe.getLocation().setInvoices(new ArrayList<Invoice>());
                selectedPpe.getLocation().setBuilding(new Building());
                selectedPpe.getLocation().setPpes(new ArrayList<PPE>());
                selectedPpe.getLocation().setBuilding(new Building());

                buildingDao.saveBuilding(selectedPpe.getLocation().getBuilding());

                if(street.getStreetId() == null) {
                    streetDao.saveStreet(street);
                    log.info("new street #" + street.getStreetId());
                }

                locationDao.saveLocation(selectedPpe.getLocation());
                log.info("new location #" + selectedPpe.getLocation().getLocationId());

                updateLocationList();

                invoiceDao.saveInvoice(ppeInvoice);
            }

            if(savePpeDistributor() == false) {
                deleteSelectedPpe();
                throw new Exception();
            }

            selectedPpe.setTariff(tariffDao.getTariffById(tariffId));
            selectedPpe.setCurrentDistributor(tmpDistributor);
            selectedPpe.setMeterModel(meterModelDao.getMeterModelById(meterModelId));

            ppeDao.savePPE(selectedPpe);
            log.info("new ppe #" + selectedPpe.getPpeId());

            if(savePpeAgreementData(false) == false) {
                deleteSelectedPpe();
                throw new Exception();
            }
            
            log.info("PPE \n id:" + selectedPpe.getPpeId());
            
            AutoCloudGenerator.autoCloudGenerateForNewPpe(userApp, selectedPpe);
            refreshPpeListInDashboardBean();

            newPpe = selectedPpe;
            clearSelectedPpe();
            updateUserPpes();

            info("update.user.ppe.success");
            RequestContext context = RequestContext.getCurrentInstance();
            context.execute("ppeInvcDlg.show()");
            
            BillInvoiceBean billinvoiceBean = ComponentLookup.lookupComponent("op.billInvoiceBean");
            billinvoiceBean.InicializePPE();
         
        } catch (Exception e) {
            e.printStackTrace();
            error("update.user.ppe.error");
        }
        return "";
    }

    /**
     * Refresh ppe list in dashboard bean.
     */
    private void refreshPpeListInDashboardBean() {
        DashboardBean dashboardBean = ComponentLookup.lookupComponent("op.dashboardBean");
        dashboardBean.refreshPPEs();
    }

    /**
     * Save ppe distributor.
     * 
     * @return true, if successful
     */
    public boolean savePpeDistributor() {
        try {
            if(tmpDistributor == null && distributor != null) {
                Distributor dis = null;

                for(int i = 0; i < distributors.size(); i++) {
                    if(distributors.get(i).getName().equals(distributor)) {
                        dis = distributors.get(i);
                        break;
                    }
                }

                if(dis == null) {
                    dis = new Distributor();
                    dis.setName(distributor);
                    distributors.add(dis);
                }

                dis.setName(distributor);

                if(dis.getDistributorId() == null) {
                    distributorDao.saveDistributor(dis);
                    log.info("new distributor #" + dis.getDistributorId());
                }

                tmpDistributor = dis;
            }
        } catch (Exception e) {
            log.info("Problem while savePpeDistributor: ", e);
            return false;
        }

        return true;
    }

    /**
     * Save ppe agreement data.
     * 
     * @return true, if successful
     */
    public boolean savePpeAgreementData() {
        return savePpeAgreementData(true);
    }

    /**
     * Save ppe agreement data.
     * 
     * @param withMessages
     *            the with messages
     * @return true, if successful
     */
    public boolean savePpeAgreementData(Boolean withMessages) {
        try {
            if(agreement.getDurationType() == DurationType.fixed
                    && !agreement.getDateFrom().before(agreement.getDateTo())) {
                warning("warning.two.dates.invalid");
                return false;
            }

            Salesman sales = null;

            for(int i = 0; i < salesmans.size(); i++) {
                if(salesmans.get(i).getSalesmanName().equals(salesman)) {
                    sales = salesmans.get(i);
                    break;
                }
            }

            if(sales == null) {
                sales = new Salesman();
                sales.setSalesmanName(salesman);
                sales.setRemoved(false);
                salesmans.add(sales);
            }

            if(sales.getSalesmanId() == null) {
                salesmanDao.saveSalesman(sales);
                log.info("new salesman #" + sales.getSalesmanId());
            }

            savePpeDistributor();

            agreement.setSalesman(sales);
            agreement.setAgreementId(null);
            agreement.setPpeId(selectedPpe.getPpeId());

            agreementDao.saveAgreement(agreement);
            agreementDao.saveAgreementPPE(agreement);

            PPETariff ppeTariff = new PPETariff();

            ppeTariff.setPpe(selectedPpe);
            ppeTariff.setPpeTariffId(tariffId);
            ppeTariff.setStartDate(new Date());
            tariffDao.savePPETariff(ppeTariff);

            tmpDistributor = null;
            editPpeAgreementMode = false;

            PpeUtil.setPPEValue(selectedPpe);

            if(withMessages) {
                info("save.agreementData.success");
                updateUserPpes();
            }
        } catch (Exception e) {
            if(withMessages)
                error("save.agreementData.error");
            log.info("Problem while saveAgreementData: ", e);
            return false;
        }

        return true;
    }

    /**
     * Save ppe meter date.
     * 
     * @return true, if successful
     */
    public boolean savePpeMeterDate() {
        try {
            if(meterModelId != null) {
                selectedPpe.setMeterModel(meterModelDao.getMeterModelById(meterModelId));
            }
            ppeDao.updatePPE(selectedPpe);

            info("save.ppe.meterData.success");
            editPpeMeterMode = false;

            updateUserPpes();
        } catch (Exception e) {
            error("save.ppe.meterData.error");
            log.info("Problem while save meter data: ", e);

            return false;
        }

        return true;
    }

    /**
     * Delete selected ppe.
     */
    public void deleteSelectedPpe() {
       
        if (!PpeUtil.canEditPpe(selectedPpe)) {
             MessageUtil.displayMessageInfo("warnning.delete.ppe.join.ppe.auction");
            return;
        }
        try {
            selectedPpe.setRemoved(true);
            ppeDao.deletePPE(selectedPpe);
            int ppeId = selectedPpe.getPpeId().intValue();

            if(userPpes.contains(selectedPpe)) {
                userPpes.remove(selectedPpe);
                selectedPpe = null;
            }

            refreshPpeListInDashboardBean();

            CloudUtil.updateCloudVolumeByPpeId(ppeId);
            info("remove.ppe.success");
            
            BillInvoiceBean billinvoiceBean = ComponentLookup.lookupComponent("op.billInvoiceBean");
         billinvoiceBean.InicializePPE();
         
        } catch (Exception e) {
            e.printStackTrace();
            error("remove.ppe.error");
        }
    }

    /**
     * Gets the selected location.
     * 
     * @return the selected location
     */
    public Location getSelectedLocation() {
        return selectedLocation;
    }

    /**
     * Sets the selected location.
     * 
     * @param selectedLocation
     *            the new selected location
     */
    public void setSelectedLocation(Location selectedLocation) {
        this.selectedLocation = selectedLocation;
    }

    /**
     * Clear selected location.
     */
    public void clearSelectedLocation() {
        log.info("clearSelectedLocation");
        selectedLocation = new Location();
        selectedLocation.setBuilding(new Building());

        editBuildingMode = false;
    }

    /**
     * On location building select.
     * 
     * @param event
     *            the event
     */
    public void onLocationBuildingSelect(SelectEvent event) {
        try {
            selectedLocation = (Location) event.getObject();
            log.info("update selectedLocation #" + selectedLocation.getLocationId());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * On location ppe select.
     * 
     * @param event
     *            the event
     */
    public void onLocationPpeSelect(AjaxBehaviorEvent event) {
        try {
            if(locationId.equals(0)) {
                clearSelectedPpeLocation();
            } else {
                Location location = getSelectedLocationInstance(locationId);
                if(null != location) {
                    updateSelectedPpeLocationFields(location);
                } else {
                    log.info("location not found");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Clear selected ppe location.
     */
    private void clearSelectedPpeLocation() {
        selectedPpe.getLocation().setLocationId(null);
        selectedPpe.getLocation().setZipCode(null);
        selectedPpe.getLocation().setHomeNo(null);
        selectedPpe.getLocation().setFlatNo(null);
        selectedPpe.getLocation().getStreet().setStreetName(null);
        selectedPpe.getLocation().getStreet().getCity().setCityName(null);

        locationId = 0;
        areaId = null;
        cityId = null;
    }

    /**
     * Gets the selected location instance.
     * 
     * @param id
     *            the id
     * @return the selected location instance
     */
    private Location getSelectedLocationInstance(Integer id) {
        for(int i = 0; i < locationList.size(); i++) {
            Location location = locationList.get(i);
            if(location.getLocationId().intValue() == id.intValue()) {
                return location;
            }
        }

        return null;
    }

    /**
     * Update selected ppe location fields.
     * 
     * @param location
     *            the location
     */
    private void updateSelectedPpeLocationFields(Location location) {
        try {
            selectedPpe.getLocation().setLocationId(location.getLocationId());
            selectedPpe.getLocation().setZipCode(location.getZipCode());
            selectedPpe.getLocation().setHomeNo(location.getHomeNo());
            selectedPpe.getLocation().setFlatNo(location.getFlatNo());

            locationCityType = location.getStreet().getCity().getHasStatus();
            locationId = location.getLocationId();
            areaId = location.getStreet().getCity().getArea().getAreaId();
            cityId = location.getStreet().getCity().getCityId();

            String streetName = location.getStreet().getStreetName();
            String cityName = location.getStreet().getCity().getCityName();

            onAreaSelect();
            onCitySelect();

            selectedPpe.getLocation().getStreet().setStreetName(streetName);
            if(null == selectedPpe.getLocation().getStreet().getCity()) {
                selectedPpe.getLocation().getStreet().setCity(new City());
                selectedPpe.getLocation().getStreet().getCity().setCityId(cityId);
            }
            selectedPpe.getLocation().getStreet().getCity().setCityName(cityName);

            log.info("update location(#" + location.getLocationId() + ") in selectedPpe");
        } catch (Exception e) {
            log.error("Problem while update ppe location data: ", e);
        }
    }

    /**
     * On location in ppe as template select.
     * 
     * @param locationId
     *            the location id
     */
    public void onLocationInPpeAsTemplateSelect(Integer locationId) {
        Location location = null;
        if(locationList != null) {
            if(locationList.size() > 0) {
                for(Location l : locationList) {
                    if(l.getLocationId().equals(locationId))
                        location = l;
                }
            }
        }

        if(location != null) {
            selectedPpe.getLocation().setStreet(location.getStreet());
        }
    }

    /**
     * Update user location.
     */
    public void updateUserLocation() {
        try {
            buildingDao.updateBuilding(selectedLocation.getBuilding());

            clearSelectedLocation();

            info("update.user.building.success");
        } catch (Exception e) {
            e.printStackTrace();
            error("update.user.building.error");
        }
    }

    /**
     * Gets the location list.
     * 
     * @return the location list
     */
    public List<Location> getLocationList() {
        return locationList;
    }

    /**
     * Sets the location list.
     * 
     * @param locationList
     *            the new location list
     */
    public void setLocationList(List<Location> locationList) {
        this.locationList = locationList;
    }

    /**
     * Update location list.
     */
    public void updateLocationList() {
        try {
            locationList = locationDao.getLocationByUserApp(userApp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Checks if is location city type.
     * 
     * @return true, if is location city type
     */
    public boolean isLocationCityType() {
        return locationCityType;
    }

    /**
     * Sets the location city type.
     * 
     * @param locationCityType
     *            the new location city type
     */
    public void setLocationCityType(boolean locationCityType) {
        this.locationCityType = locationCityType;
    }

    /**
     * Gets the location ppe id.
     * 
     * @return the location ppe id
     */
    public Integer getLocationPpeId() {
        return locationPpeId;
    }

    /**
     * Sets the location ppe id.
     * 
     * @param locationPpeId
     *            the new location ppe id
     */
    public void setLocationPpeId(Integer locationPpeId) {
        this.locationPpeId = locationPpeId;
    }

    /**
     * Gets the cities.
     * 
     * @return the cities
     */
    public List<City> getCities() {
        return cities;
    }

    /**
     * Sets the cities.
     * 
     * @param cities
     *            the new cities
     */
    public void setCities(List<City> cities) {
        this.cities = cities;
    }

    /**
     * On area select.
     */
    public void onAreaSelect() {
        if(locationCityType == true) {
            log.info("onAreaSelect");
            try {
                log.info("geCities to area: #" + areaId);
                cities = dictionaryBean.getCitiesMap().get(areaId);
            } catch (Exception e) {
                log.info("Problem while load cities when area select: ", e);
            }
        }
    }

    /**
     * On city select.
     */
    public void onCitySelect() {
        log.info("onCitySelect");
        Integer cityId = selectedPpe.getLocation().getStreet().getCity().getCityId();

        City city = new City();
        city.setCityId(cityId);
        try {
            Street street = new Street();
            street.setCity(city);
            streets = streetDao.getStreets(street);

            selectedPpe.getLocation().getStreet().setStreetName(null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Gets the areas.
     * 
     * @return the areas
     */
    public List<Area> getAreas() {
        return areas;
    }

    /**
     * Sets the areas.
     * 
     * @param areas
     *            the new areas
     */
    public void setAreas(List<Area> areas) {
        this.areas = areas;
    }

    /**
     * Gets the distributors.
     * 
     * @return the distributors
     */
    public List<Distributor> getDistributors() {
        return distributors;
    }

    /**
     * Sets the distributors.
     * 
     * @param distributors
     *            the new distributors
     */
    public void setDistributors(List<Distributor> distributors) {
        this.distributors = distributors;
    }

    /**
     * Gets the agreement types.
     * 
     * @return the agreement types
     */
    public List<AgreementType> getAgreementTypes() {
        agreementTypes = new ArrayList<AgreementType>();

        for(AgreementType t : AgreementType.values()) {
            t.setLabel(BundlesUtils.getMessageResourceString("messages", "agreement.type." + t, null,
                    Locale.getDefault()));

            agreementTypes.add(t);
        }
        return agreementTypes;
    }

    /**
     * Sets the agreement types.
     * 
     * @param agreementTypes
     *            the new agreement types
     */
    public void setAgreementTypes(List<AgreementType> agreementTypes) {
        this.agreementTypes = agreementTypes;
    }

    /**
     * Gets the duration types.
     * 
     * @return the duration types
     */
    public List<DurationType> getDurationTypes() {
        durationTypes = new ArrayList<DurationType>();

        for(DurationType t : DurationType.values()) {
            t.setLabel(BundlesUtils.getMessageResourceString("messages", "duration.type." + t, null,
                    Locale.getDefault()));

            durationTypes.add(t);
        }
        return durationTypes;
    }

    /**
     * Sets the duration types.
     * 
     * @param durationTypes
     *            the new duration types
     */
    public void setDurationTypes(List<DurationType> durationTypes) {
        this.durationTypes = durationTypes;
    }

    /**
     * Gets the city id.
     * 
     * @return the city id
     */
    public Integer getCityId() {
        return cityId;
    }

    /**
     * Sets the city id.
     * 
     * @param cityId
     *            the new city id
     */
    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    /**
     * Gets the tariff id.
     * 
     * @return the tariff id
     */
    public Integer getTariffId() {
        return tariffId;
    }

    /**
     * Sets the tariff id.
     * 
     * @param tariffId
     *            the new tariff id
     */
    public void setTariffId(Integer tariffId) {
        this.tariffId = tariffId;
    }

    /**
     * Gets the area id.
     * 
     * @return the area id
     */
    public Integer getAreaId() {
        return areaId;
    }

    /**
     * Sets the area id.
     * 
     * @param areaId
     *            the new area id
     */
    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    /**
     * Gets the location id.
     * 
     * @return the location id
     */
    public Integer getLocationId() {
        return locationId;
    }

    /**
     * Sets the location id.
     * 
     * @param locationId
     *            the new location id
     */
    public void setLocationId(Integer locationId) {
        this.locationId = locationId;
    }

    /**
     * Gets the meter model id.
     * 
     * @return the meter model id
     */
    public Integer getMeterModelId() {
        return meterModelId;
    }

    /**
     * Sets the meter model id.
     * 
     * @param meterModelId
     *            the new meter model id
     */
    public void setMeterModelId(Integer meterModelId) {
        this.meterModelId = meterModelId;
    }

    /**
     * Gets the streets.
     * 
     * @return the streets
     */
    public List<Street> getStreets() {
        return streets;
    }

    /**
     * Sets the streets.
     * 
     * @param streets
     *            the new streets
     */
    public void setStreets(List<Street> streets) {
        this.streets = streets;
    }

    /**
     * Auto complete village.
     * 
     * @param query
     *            the query
     * @return the list
     */
    public List<String> autoCompleteVillage(String query) {
        return LocationUtil.autoCompleteCity(query, areaId, false);
    }

    /**
     * Auto complete street.
     * 
     * @param query
     *            the query
     * @return the list
     */
    public List<String> autoCompleteStreet(String query) {
        List<String> suggestions = new ArrayList<String>();

        for(Street s : streets) {
            if(s.getStreetName().startsWith(query))
                suggestions.add(s.getStreetName());
        }
        return suggestions;
    }

    /**
     * Gets the tariffs.
     * 
     * @return the tariffs
     */
    public List<Tariff> getTariffs() {
        return tariffs;
    }

    /**
     * Sets the tariffs.
     * 
     * @param tariffs
     *            the new tariffs
     */
    public void setTariffs(List<Tariff> tariffs) {
        this.tariffs = tariffs;
    }

    /**
     * Gets the salesmans.
     * 
     * @return the salesmans
     */
    public List<Salesman> getSalesmans() {
        return salesmans;
    }

    /**
     * Sets the salesmans.
     * 
     * @param salesmans
     *            the new salesmans
     */
    public void setSalesmans(List<Salesman> salesmans) {
        this.salesmans = salesmans;
    }

    /**
     * Gets the meter models.
     * 
     * @return the meter models
     */
    public List<MeterModel> getMeterModels() {
        return meterModels;
    }

    /**
     * Sets the meter models.
     * 
     * @param meterModels
     *            the new meter models
     */
    public void setMeterModels(List<MeterModel> meterModels) {
        this.meterModels = meterModels;
    }

    /**
     * Gets the salesman.
     * 
     * @return the salesman
     */
    public String getSalesman() {
        return salesman;
    }

    /**
     * Sets the salesman.
     * 
     * @param salesman
     *            the new salesman
     */
    public void setSalesman(String salesman) {
        this.salesman = salesman;
    }

    /**
     * Gets the distributor.
     * 
     * @return the distributor
     */
    public String getDistributor() {
        return distributor;
    }

    /**
     * Sets the distributor.
     * 
     * @param distributor
     *            the new distributor
     */
    public void setDistributor(String distributor) {
        this.distributor = distributor;
    }

    /**
     * Gets the agreement.
     * 
     * @return the agreement
     */
    public Agreement getAgreement() {
        return agreement;
    }

    /**
     * Sets the agreement.
     * 
     * @param agreement
     *            the new agreement
     */
    public void setAgreement(Agreement agreement) {
        this.agreement = agreement;
    }

    /**
     * Gets the tariff name.
     * 
     * @return the tariff name
     */
    public String getTariffName() {
        return tariffName;
    }

    /**
     * Sets the tariff name.
     * 
     * @param tariffName
     *            the new tariff name
     */
    public void setTariffName(String tariffName) {
        this.tariffName = tariffName;
    }

    /**
     * Checks if is edits the ppe agreement mode.
     * 
     * @return true, if is edits the ppe agreement mode
     */
    public boolean isEditPpeAgreementMode() {
        return editPpeAgreementMode;
    }

    /**
     * Sets the edits the ppe agreement mode.
     * 
     * @param editPpeAgreementMode
     *            the new edits the ppe agreement mode
     */
    public void setEditPpeAgreementMode(boolean editPpeAgreementMode) {
        this.editPpeAgreementMode = editPpeAgreementMode;
    }

    /**
     * Checks if is edits the ppe meter mode.
     * 
     * @return true, if is edits the ppe meter mode
     */
    public boolean isEditPpeMeterMode() {
        return editPpeMeterMode;
    }

    /**
     * Sets the edits the ppe meter mode.
     * 
     * @param editPpeMeterMode
     *            the new edits the ppe meter mode
     */
    public void setEditPpeMeterMode(boolean editPpeMeterMode) {
        this.editPpeMeterMode = editPpeMeterMode;
    }

    /**
     * Can edit ppe.
     * 
     * @param ppe
     *            the ppe
     * @return the boolean
     */
    public Boolean canEditPpe(PPE ppe) {
        return PpeUtil.canEditPpe(ppe);
    }

    /**
     * Gets the preference question list.
     * 
     * @return the preference question list
     */
    public List<PreferenceQuestion> getPreferenceQuestionList() {
        return preferenceQuestionList;
    }

    /**
     * Sets the preference question list.
     * 
     * @param preferenceQuestionList
     *            the new preference question list
     */
    public void setPreferenceQuestionList(List<PreferenceQuestion> preferenceQuestionList) {
        this.preferenceQuestionList = preferenceQuestionList;
    }

    /**
     * Gets the pref quest dao.
     * 
     * @return the pref quest dao
     */
    public PrefQuestDao getPrefQuestDao() {
        return prefQuestDao;
    }

    /**
     * Sets the pref quest dao.
     * 
     * @param prefQuestDao
     *            the new pref quest dao
     */
    public void setPrefQuestDao(PrefQuestDao prefQuestDao) {
        this.prefQuestDao = prefQuestDao;
    }

    /**
     * Save preferences question answer.
     */
    public void savePreferencesQuestionAnswer() {
        try {
            log.info("preferenceQuestionList size: " + preferenceQuestionList.size());
            for(PreferenceQuestion pq : preferenceQuestionList) {
                QuestionValue answer = pq.getQuestionValue();

                answer.setStereotype(userApp.getSector().getStereotype());
                answer.setUserApp(userApp);
                answer.setPreferenceQuestion(pq);

                if(answer.getQuestionValueId() == null)
                    questValueDao.saveQuestionValue(answer);
                else
                    questValueDao.updateQuestionValue(answer);

            }
            info("save.user.preferences.success");
        } catch (Exception e) {
            error("save.user.preferences.error");
            e.printStackTrace();
        }
    }

    /**
     * Checks if is edits the ppe device mode.
     * 
     * @return true, if is edits the ppe device mode
     */
    public boolean isEditPpeDeviceMode() {
        return editPpeDeviceMode;
    }

    /**
     * Sets the edits the ppe device mode.
     * 
     * @param editPpeDeviceMode
     *            the new edits the ppe device mode
     */
    public void setEditPpeDeviceMode(boolean editPpeDeviceMode) {
        this.editPpeDeviceMode = editPpeDeviceMode;
    }

    /**
     * Generate title to send mistake.
     * 
     * @return the string
     */
    public String generateTitleToSendMistake() {
        String topic = "Błąd w danych w PPE - ";

        topic += selectedPpe.getLocation().getLocationName();

        return topic;
    }

    /**
     * Gets the actual tariff by ppe index.
     * 
     * @param ppe
     *            the ppe
     * @return the actual tariff by ppe index
     */
    public String getActualTariffByPpeIndex(PPE ppe) {
        try {
            ppe.setTariff(ppeDao.getActualTariff(ppe));
            return ppe.getTariff().getTariffName();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "";
    }

    /**
     * Checks if is view chart ppe mode.
     * 
     * @return true, if is view chart ppe mode
     */
    public boolean isViewChartPpeMode() {
        return viewChartPpeMode;
    }

    /**
     * Sets the view chart ppe mode.
     * 
     * @param viewChartPpeMode
     *            the new view chart ppe mode
     */
    public void setViewChartPpeMode(boolean viewChartPpeMode) {
        this.viewChartPpeMode = viewChartPpeMode;
    }

    /**
     * Gets the ppe invoice.
     * 
     * @return the ppe invoice
     */
    public Invoice getPpeInvoice() {
        return ppeInvoice;
    }

    /**
     * Sets the ppe invoice.
     * 
     * @param ppeInvoice
     *            the new ppe invoice
     */
    public void setPpeInvoice(Invoice ppeInvoice) {
        this.ppeInvoice = ppeInvoice;
    }

    /**
     * Gets the price component values.
     * 
     * @return the price component values
     */
    public List<InvoicePriceComponentValue> getPriceComponentValues() {
        return priceComponentValues;
    }

    /**
     * Sets the price component values.
     * 
     * @param priceComponentValues
     *            the new price component values
     */
    public void setPriceComponentValues(List<InvoicePriceComponentValue> priceComponentValues) {
        this.priceComponentValues = priceComponentValues;
    }

    /**
     * Checks if is form invoice mode.
     * 
     * @return true, if is form invoice mode
     */
    public boolean isFormInvoiceMode() {
        return formInvoiceMode;
    }

    /**
     * Sets the form invoice mode.
     * 
     * @param formInvoiceMode
     *            the new form invoice mode
     */
    public void setFormInvoiceMode(boolean formInvoiceMode) {
        this.formInvoiceMode = formInvoiceMode;
    }

    /**
     * Gets the chart duration type.
     * 
     * @return the chart duration type
     */
    public String getChartDurationType() {
        return chartDurationType;
    }

    /**
     * Sets the chart duration type.
     * 
     * @param chartDurationType
     *            the new chart duration type
     */
    public void setChartDurationType(String chartDurationType) {
        this.chartDurationType = chartDurationType;
    }
   

    /**
     * Gets the chart date from.
     * 
     * @return the chart date from
     */
    public Date getChartDateFrom() {
        return chartDateFrom;
    }

    /**
     * Sets the chart date from.
     * 
     * @param chartDateFrom
     *            the new chart date from
     */
    public void setChartDateFrom(Date chartDateFrom) {
        log.info("setChartDateFrom");
        this.chartDateFrom = chartDateFrom;

        if(chartDurationType.equals("week")) {
            chartDateTo = new Date(chartDateFrom.getTime() + (1000 * 3600 * 24 * 7));
            chartMaxDateTo = new Date(chartDateTo.getTime());
            log.info("chartMaxDateTo - " + chartMaxDateTo);
        } else if(chartDurationType.equals("day")) {
            chartDateTo = new Date(chartDateFrom.getTime());
            chartMaxDateTo = new Date(chartDateFrom.getTime());
        } else {
            chartDateTo = new Date(chartDateFrom.getTime());
            chartDateTo.setMonth(chartDateTo.getMonth() + 11);
            chartMaxDateTo = null;
        }
    }

    /**
     * Gets the chart date to.
     * 
     * @return the chart date to
     */
    public Date getChartDateTo() {
        return chartDateTo;
    }

    /**
     * Sets the chart date to.
     * 
     * @param chartDateTo
     *            the new chart date to
     */
    public void setChartDateTo(Date chartDateTo) {
        this.chartDateTo = chartDateTo;
    }

    /**
     * Initialize view chart ppe mode.
     * 
     * @param ppe
     *            the ppe
     */
    @SuppressWarnings("deprecation")
    public void initializeViewChartPpeMode(PPE ppe) {
        log.info("initialize");
        setSelectedPpe(ppe);

        viewChartPpeMode = true;
        chartDurationType = "month";
        Date now = new Date();

        chartDateFrom = new Date(now.getYear(), 0, 1);
        chartDateTo = new Date(now.getYear(), 11, 31);
    }

    /**
     * Chart duration type change.
     * 
     * @param event
     *            the event
     */
    @SuppressWarnings("deprecation")
    public void chartDurationTypeChange(AjaxBehaviorEvent event) {
        log.info("chartDurationTypeChange");
        if(chartDurationType.equals("month")) {
            chartDateTo = new Date(chartDateFrom.getTime());
            chartDateTo.setMonth(chartDateTo.getMonth() + 13);
            chartDateTo.setDate(-1);
            chartMaxDateTo = chartDateTo;
        } else if(chartDurationType.equals("week")) {
            if(chartDateFrom != null) {
                chartDateTo = new Date((chartDateFrom.getTime() + (1000 * 3600 * 24 * 7)));
                chartMaxDateTo = new Date(chartDateTo.getTime());
            }
        } else {
            if(chartDateFrom != null) {
                chartDateTo = new Date(chartDateFrom.getTime());
                chartMaxDateTo = new Date(chartDateFrom.getTime());
            }
        }
    }

    /**
     * Gets the chart max date to.
     * 
     * @return the chart max date to
     */
    public Date getChartMaxDateTo() {
        return chartMaxDateTo;
    }

    /**
     * Sets the chart max date to.
     * 
     * @param chartMaxDateTo
     *            the new chart max date to
     */
    public void setChartMaxDateTo(Date chartMaxDateTo) {
        this.chartMaxDateTo = chartMaxDateTo;
    }

    /**
     * Gets the password1.
     * 
     * @return the password1
     */
    public String getPassword1() {
        return password1;
    }

    /**
     * Sets the password1.
     * 
     * @param password1
     *            the new password1
     */
    public void setPassword1(String password1) {
        this.password1 = password1;
    }

    /**
     * Gets the password2.
     * 
     * @return the password2
     */
    public String getPassword2() {
        return password2;
    }

    /**
     * Sets the password2.
     * 
     * @param password2
     *            the new password2
     */
    public void setPassword2(String password2) {
        this.password2 = password2;
    }

    /**
     * Gets the password0.
     * 
     * @return the password0
     */
    public String getPassword0() {
        return password0;
    }

    /**
     * Sets the password0.
     * 
     * @param password0
     *            the new password0
     */
    public void setPassword0(String password0) {
        this.password0 = password0;
    }

    /**
     * Checks if is meter inteligent.
     * 
     * @return true, if is meter inteligent
     */
    public boolean isMeterInteligent() {
        return meterInteligent;
    }

    /**
     * Sets the meter inteligent.
     * 
     * @param isMeterInteligent
     *            the new meter inteligent
     */
    public void setMeterInteligent(boolean isMeterInteligent) {
        this.meterInteligent = isMeterInteligent;
    }

    /**
     * Can view chart.
     * 
     * @return true, if successful
     */
    public boolean canViewChart() {
        if(viewChartPpeMode == false) {
            log.info("viewChartPpeMode is false");
            canViewChart = false;
            return false;
        }
        if(PPEStatus.INVOICE_MISSING.equals(selectedPpe.getPpeStatus())) {
            log.info("PPEStatus is INVOICE_MISSING");
            canViewChart = false;
            return false;
        }

        canViewChart = true;
        return true;
    }

    /**
     * Gets the can view chart.
     * 
     * @return the can view chart
     */
    public boolean getCanViewChart() {
        return canViewChart;
    }
}
