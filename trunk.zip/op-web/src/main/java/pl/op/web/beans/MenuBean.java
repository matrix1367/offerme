package pl.op.web.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.security.Identity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.op.dao.UserDao;
import pl.op.model.contract.OperatorInvoice;
import pl.op.model.user.UserApp;
import pl.op.web.beans.auction.AuctionArchiveBean;
import pl.op.web.beans.auction.AuctionInProgressBean;
import pl.op.web.beans.auction.AuctionJoinedBean;
import pl.op.web.beans.bonus.BonusBean;
import pl.op.web.beans.bonus.PointsBean;
import pl.op.web.beans.cloud.CloudBean;
import pl.op.web.beans.cloud.SalesmanCloudBean;
import pl.op.web.beans.dynamicText.DynamicTextBean;
import pl.op.web.beans.faq.FaqBean;
import pl.op.web.beans.log.OperatorInvoiceBean;
import pl.op.web.beans.log.SalesmanBean;
import pl.op.web.beans.message.MessageBean;
import pl.op.web.beans.profile.UserProfileBean;
import pl.op.web.beans.settings.SettingsBean;
import pl.op.web.beans.user.EditDataBean;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;
import pl.op.web.service.BonusService;

@Name("op.menuBean")
@Scope(ScopeType.SESSION)
public class MenuBean implements Serializable {

    private static final long serialVersionUID = 1L;
    private String editMenuItemSelected;
    private String editTopMenuItemSelected;
    private int activeIndex;
    private boolean administration;

    private boolean showLoginDialog = false;

    private String impVersion;
    private String backTo = "";

    @SuppressWarnings("unused")
    private List<UserApp> users;

    @SuppressWarnings("unused")
    private UserDao userDao;

    @In(value = "#{op.adminBean}", scope = ScopeType.SESSION, required = true)
    private AdminBean adminBean;

    @In(value = "#{op.operatorInvoiceBean}", scope = ScopeType.SESSION, required = true)
    private OperatorInvoiceBean operatorInvoiceBean;

    public MenuBean() {
        log.info("MenuBean constructor");
        initialize();
    }

    private void initialize() {
        administration = false;

        userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);

        editTopMenuItemSelected = "home";
        activeIndex = 0;

        editTopMenuItemSelected = "menuEvents";
        editMenuItemSelected = "menuEvents";

    }

    private Logger log = LoggerFactory.getLogger(MenuBean.class);

    public String settingAction() {
        administration = false;
        activeIndex = 6;

        editMenuItemSelected = "leftMenuSettings";
        getCssForEditMenuItem("");

        editTopMenuItemSelected = "topMenuSettings";
        getCssForEditTopMenuItem("");

        EditDataBean editDataBean = ComponentLookup.lookupComponent("op.editDataeBean");
        return editDataBean.startEditAction();
    }

    public String reportAction() {
        administration = false;
        activeIndex = 5;

        editMenuItemSelected = "leftMenuReports";
        getCssForEditMenuItem("");

        editTopMenuItemSelected = "topMenuReports";
        getCssForEditTopMenuItem("");

        return "userHome";
    }

    public String homeAction() {
        administration = false;
        return "userHome";
    }
    
    public String wizard() {
        administration = false;
        return "wizard";
    }
    
    public String homeLoggedoutAction() {
        administration = false;
        return "login";
    }

    public void onPageLoad() {
        this.editTopMenuItemSelected = "home";
    }

    public String pricesAction() {
        if(Identity.instance().isLoggedIn()) {
            return "pricesLoggedIn";
        } else {
            return "prices";
        }
    }

    public String aboutAction() {
        if(Identity.instance().isLoggedIn()) {
            return "aboutLoggedIn";
        } else {
            return "about";
        }
    }

    public String offertAction() {
        if(Identity.instance().isLoggedIn()) {
            return "offertLoggedIn";
        } else {
            return "offert";
        }
    }

    public String getCssForEditMenuItem(String editMenuItem) {
        String styleClass = new String();

        if(editMenuItem.equals(editMenuItemSelected)) {
            styleClass = "ui-state-highlight";
        } else {
            styleClass = "ui-menuitem-link";
        }

        return styleClass;
    }

    public void setEditMenuItemSelected(String editMenuItemSelected) {
        this.editMenuItemSelected = editMenuItemSelected;
    }

    public String getCssForEditTopMenuItem(String editMenuItem) {
        String styleClass = new String();

        if(editMenuItem.equals(editTopMenuItemSelected)) {
            styleClass = "ui-highlight";
        } else {
            styleClass = "ui-menuitem-link";
        }

        return styleClass;
    }

    /**
     * The method checks whether the user is logged in and returns the
     * corresponding string. Used in prices.xhtml and pricesLoggedIn.xhtml
     * 
     * @return string value of CSS class style
     */
    public String getBorderColor() {
        if(Identity.instance().isLoggedIn()) {
            return "orange-border";
        } else {
            return "blue-border";
        }
    }

    public String backToPortfolio() {
        activeIndex = 0;
        administration = false;

        editMenuItemSelected = "leftMenuOrder";
        editTopMenuItemSelected = "topMenuOrder";

        return "/pages/user/userLoggedIn";
    }

    public String administrationAction() {
        administration = false;

        editMenuItemSelected = "leftMenuUsers";
        getCssForEditMenuItem("");

        editTopMenuItemSelected = "Admin";
        getCssForEditTopMenuItem("");

        return adminBean.listUsers();
    }

    public String xmlImportAction() {
        return "xmlImport";
    }

    public String loginAction() {
        showLoginDialog = true;
        return "login";
    }

    public void setEditTopMenuItemSelected(String editTopMenuItemSelected) {
        this.editTopMenuItemSelected = editTopMenuItemSelected;
    }

    public int getActiveIndex() {
        return activeIndex;
    }

    public void setActiveIndex(int activeIndex) {
        this.activeIndex = activeIndex;
    }

    public boolean isAdministration() {
        return administration;
    }

    public void setAdministration(boolean administration) {
        this.administration = administration;
    }

    public String salesmanLogAction() {
        administration = false;
        return "salesmanLog";
    }

    public String userLogAction() {
        administration = false;
        return "userLog";
    }

    public String ppeLogAction() {
        administration = false;
        return "ppeLog";
    }

    public String auctionAction() {
        administration = false;

        pl.op.web.beans.auction.operator.AuctionInProgressBean bean = ComponentLookup
                .lookupComponent("op.operatorAuctionInProgressBean");
        bean.searchAuctions();

        return "operatorAuctions";
    }

    public String myAuctionAction() {
        administration = false;

        BonusService.run("enterAuction", adminBean.getUserLog());
        AuctionJoinedBean auctionJoinedBean = ComponentLookup.lookupComponent("op.auctionJoinedBean");
        auctionJoinedBean.initializeOnLoad();

        AuctionInProgressBean auctionInProgressBean = ComponentLookup.lookupComponent("op.auctionInProgressBean");
        auctionInProgressBean.initializeOnLoad();

        AuctionArchiveBean auctionArchiveBean = ComponentLookup.lookupComponent("op.auctionArchiveBean");
        auctionArchiveBean.initializeOnLoad();

        return "userAuctions";
    }

    public String salesmanAuctionAction() {
        administration = false;

        BonusService.run("enterAuction", adminBean.getUserLog());

        pl.op.web.beans.auction.salesman.AuctionInProgressBean bean = ComponentLookup
                .lookupComponent("op.salesmanAuctionInProgressBean");
        bean.searchAuctions();

        return "salesmanAuctions";
    }

    public String userProfileAction() {
        administration = false;

        BonusService.run("enterProfil", adminBean.getUserLog());

        UserProfileBean userProfileBean = ComponentLookup.lookupComponent("op.userProfileBean");
        userProfileBean.initializeVars();
        userProfileBean.initializeOnLoad();

        return "userProfile";
    }

    public String cloudAction() {
        log.info("cloudAction");
        administration = false;

        CloudBean cloudBean = ComponentLookup.lookupComponent("op.cloudBean");
        cloudBean.initializeOnLoad();

        return "clouds";
    }

    public String salesmanCloudAction() {
        log.info("salesmanCloudAction");
        administration = false;

        SalesmanCloudBean salesmanCloudBean = ComponentLookup.lookupComponent("op.salesmanCloudBean");
        salesmanCloudBean.initializeOnLoad();

        return "salesmanClouds";
    }

    public String salesmanProfileAction() {
        administration = false;
        SalesmanBean salesmanBean = ComponentLookup.lookupComponent("op.salesmanBean");
        salesmanBean.updateSalesmanAssignedToUser();
        return "salesmanProfile";
    }

    public String logAction() {
        administration = false;

        operatorInvoiceBean.setOperatorInvoices(new ArrayList<OperatorInvoice>());

        return "logs";
    }
    
    public String banerListAction() {
        DynamicTextBean dynamicTextBean = ComponentLookup.lookupComponent("op.dynamicTextBean");
        dynamicTextBean.refreshDynamicTextList();
        return "banerList";
    }
   

    public String mailAction() {
        administration = false;

        MessageBean messageBean = ComponentLookup.lookupComponent("op.messageBean");
        NewsletterBean newsletterBean = ComponentLookup.lookupComponent("op.newsletterBean");

        messageBean.refreshInboxMessageList();
        messageBean.refreshOutboxMessageList();
        newsletterBean.searchNewsletters();

        users = new ArrayList<UserApp>();
        return "mailBox";
    }

    public String settingsAction() {
        SettingsBean settingsBean = ComponentLookup.lookupComponent("op.settingsBean");
        settingsBean.refreshSettingsList();
        return "settingsList";
    }

    public String bonusAction() {

        BonusBean bonusBean = ComponentLookup.lookupComponent("op.bonusBean");
        bonusBean.loadBonus();
        return "bonus";
    }

    public String billsAction() {
        return "bills";
    }

    public String pointsAction() {

        PointsBean pointsBean = ComponentLookup.lookupComponent("op.pointsBean");
        pointsBean.loadPoints();

        BonusService.run("enterPoints", adminBean.getUserLog());

        return "points";
    }

    public String unavailableAction() {
        return "unavailable";
    }

    public String listAlldictionaries() {
        administration = false;
        return "dictionaries";
    }

    public String adminLogin() {       
            return "loginAdmin";       
    }
    
    public String  faqAction() {
        FaqBean faqBean = ComponentLookup.lookupComponent("op.faqBean");
        faqBean.refreshAndShowFaqList();
        if(Identity.instance().isLoggedIn()) {
            return "faq-loggedIn";
        } else {
            return "faq-loggedOut";
        }
    }
    
	public String goBackToPage() {
		return backTo;
	}

    public String getImpVersion() {
        return impVersion;
    }

    public void setImpVersion(String impVersion) {
        this.impVersion = impVersion;
    }

    public boolean isShowLoginDialog() {
        return showLoginDialog;
    }

    public void setShowLoginDialog(boolean showLoginDialog) {
        this.showLoginDialog = showLoginDialog;
    }

    public String getBackTo() {
            return backTo;
    }

    public void setBackTo(String backTo) {
            this.backTo = backTo;
    }
    
    public boolean isFirstLogin() throws Exception {
        UserApp userApp = userDao.getUserByLogin(Identity.instance().getUsername());
        if (userApp != null) {
            return userApp.getFirstLogin();
        }
        else
        {
            return false;
        }
    }
}