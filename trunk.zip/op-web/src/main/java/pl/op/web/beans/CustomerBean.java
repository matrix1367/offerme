package pl.op.web.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.LocaleSelector;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.CityDao;
import pl.op.dao.LocationDao;
import pl.op.dao.PPEDao;
import pl.op.dao.StereotypeDao;
import pl.op.dao.StreetDao;
import pl.op.dao.UserDao;
import pl.op.model.contract.Location;
import pl.op.model.contract.PPE;
import pl.op.model.contract.PPEFilter;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Street;
import pl.op.model.stereotype.Sector;
import pl.op.model.stereotype.Stereotype;
import pl.op.model.user.UserApp;
import pl.op.model.user.UserRole;
import pl.op.web.beans.log.OperatorAgreementBean;
import pl.op.web.beans.log.OperatorInvoiceBean;
import pl.op.web.beans.log.PPEBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

@Name("op.customerBean")
@Scope(ScopeType.SESSION)
public class CustomerBean implements Serializable {

    private static final long serialVersionUID = -1395415501234435829L;

    private Logger log = LoggerFactory.getLogger(CustomerBean.class);

    private enum Scenario {
        EDIT, CREATE, REMOVE
    }

    @In
    private LocaleSelector localeSelector;

    private UserDao userDao;
    private PPEDao ppeDao;
    private LocationDao locationDao;
    private StereotypeDao stereotypeDao;
    private CityDao cityDao;
    private StreetDao streetDao;

    private Scenario ppeScenario;
    private Scenario customerScenario;

    private UserApp[] selected;
    private UserApp userApp;
    private UserApp filter;
    private UserApp customer;

    private List<UserApp> customerList;
    private List<Stereotype> stereotypes;
    private List<Sector> sectors;

    private PPE ppeSelected;
    private PPE ppe;

    private List<PPE> ppes;
    private List<City> cities;
    private List<Street> streets;

    private boolean admin;
    private boolean disableButtons;
    private boolean disablePPEButtons;
    private boolean chooseCustomerButtonsVisible;
    private boolean disabledUserStereotypeButton;

    private String returnProceedAction;
    private String returnCancelAction;

    private boolean wizard = false;

    private FacesContext facesContext;
    private ExternalContext ectx;

    @In(value = "#{op.adminBean}", scope = ScopeType.SESSION, required = true)
    private AdminBean adminBean;

    public CustomerBean() {
        initialize();
    }

    public void initialize() {
        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();

        userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);
        ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);
        stereotypeDao = GuiceSingleton.getInstance().getInstance(StereotypeDao.class);
        cityDao = GuiceSingleton.getInstance().getInstance(CityDao.class);
        streetDao = GuiceSingleton.getInstance().getInstance(StreetDao.class);
        try {
            stereotypes = stereotypeDao.getStereotypes(new Sector());
            sectors = stereotypeDao.getSectors(new Sector());
            streets = streetDao.getStreets(new Street());
        } catch (Exception e) {
            e.printStackTrace();
        }

        clearCustomer();
        clearCustomerFilter();
    }

    private void initialize(boolean admin) {
        userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);
        ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);

        userApp = adminBean.getUserLog();

        listCities();

        disableButtons = true;
        disablePPEButtons = true;
        disabledUserStereotypeButton = true;
        filter = new UserApp();

        chooseCustomerButtonsVisible = false;
    }

    public String openWizard() {
        return "wizard";
    }

    public String openCustomerForm() {
        // AdminBean adminBean =
        // ComponentLookup.lookupComponent("op.adminBean");

        initialize(false);

        log.info("userApp: " + userApp + ", id: " + userApp.getUserId());
        selected = new UserApp[] { userApp };

        return editCustomer();
    }

    public String editCustomer() {
        customerScenario = Scenario.EDIT;

        if(selected != null && selected.length != 0 && selected[0].getUserId() != null) {
            log.info("!!! 1");
            try {
                userApp = userDao.getUserAppbyId(selected[0].getUserId());
            } catch (Exception e1) {
                log.error("!!! " + e1.getMessage());
                e1.printStackTrace();
            }

            if(userApp != null) {
                log.info("!!! 2");
                try {
                    userApp.setLocations(locationDao.getLocationByUserApp(userApp));
                } catch (Exception e) {
                    log.error("!!! " + e.getMessage());
                    e.printStackTrace();
                }

                if(admin) {
                    return "customerAdminEdit";
                }

                return "customerEdit";
            }
        }

        return "customerList";
    }

    public String saveCustomer() {

        if(!validatePesel(customer))
            return "customerEdit";

        try {
            if(customer.getUserId() != null)
                userDao.updateUser(customer);
            else
                userDao.saveUser(customer);
        } catch (Exception e) {

            e.printStackTrace();
        }

        PPEBean ppeBean = ComponentLookup.lookupComponent("op.ppeBean");
        ppeBean.setActiveTab("1");

        return "logs";
    }

    public void onRowSelect(SelectEvent event) {
        disableButtons = false;
    }

    public void onRowUnselect(UnselectEvent event) {
        disableButtons = true;
    }

    public void onPPERowSelect(SelectEvent event) {
        disablePPEButtons = false;
    }

    public void onPPERowUnselect(UnselectEvent event) {
        disablePPEButtons = true;
    }

    public void clearCustomerFilter() {
        filter = new UserApp();

        Location l = new Location();
        City c = new City();
        c.setArea(new Area());

        Street s = new Street();
        s.setCity(c);

        l.setStreet(s);

        Sector b = new Sector();
        b.setStereotype(new Stereotype());
        filter.setUserRole(UserRole.user);
        filter.setLocation(l);
        filter.setSector(b);
    }

    public void clearCustomer() {
        customer = new UserApp();

        disableButtons = true;
    }

    public void filterCustomerList() {
        try {
            customerList = userDao.getUsers(filter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void initializeNew() {
        clearCustomer();
    }

    public void deleteCustomer() {
        try {
            userDao.deleteUser(customer);
        } catch (Exception e) {
            e.printStackTrace();
        }

        filterCustomerList();
        clearCustomer();
    }

    public String list() {

        selected = null;
        disableButtons = true;

        try {
            customerList = userDao.getUsers(filter);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "customerList";
    }

    public String profileStatusConverter(Boolean status) {
        return BundlesUtils.getMessageResourceString("messages", "salesman.state." + status.toString(), null,
                Locale.getDefault());
    }

    private void listCities() {
        /*
         * Language userLanguage = adminBean.getUserLog().getLanguage(); City
         * cityFilter = new City(); cityFilter.setLanguage(userLanguage); try {
         * cities = cityService.getCityList(cityFilter); } catch (Exception e) {
         * e.printStackTrace(); }
         */
    }

    public void initializeCustomerDetails() {
        PPEFilter filter = new PPEFilter();
        filter.setUser(customer);

        try {
            ppes = ppeDao.getPPEsByFilter(filter);
        } catch (Exception e) {
            e.printStackTrace();
        }

        OperatorInvoiceBean operatorInvoiceBean = ComponentLookup.lookupComponent("op.operatorInvoiceBean");
        operatorInvoiceBean.clearOperatorInvoice();
        operatorInvoiceBean.setSalesmanInvoice(false);

        OperatorAgreementBean operatorAgreementBean = ComponentLookup.lookupComponent("op.operatorAgreementBean");
        operatorAgreementBean.initializeAgreement(false);
    }

    public String cancelCustomerEdit() {
        return "logs";
    }

    public UserDao getUserDao() {
        return userDao;
    }

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    public PPEDao getPpeDao() {
        return ppeDao;
    }

    public void setPpeDao(PPEDao ppeDao) {
        this.ppeDao = ppeDao;
    }

    public Scenario getPpeScenario() {
        return ppeScenario;
    }

    public void setPpeScenario(Scenario ppeScenario) {
        this.ppeScenario = ppeScenario;
    }

    public Scenario getCustomerScenario() {
        return customerScenario;
    }

    public void setCustomerScenario(Scenario customerScenario) {
        this.customerScenario = customerScenario;
    }

    public UserApp[] getSelected() {
        return selected;
    }

    public void setSelected(UserApp[] selected) {
        this.selected = selected;
    }

    public UserApp getUserApp() {
        return userApp;
    }

    public void setUserApp(UserApp userApp) {
        this.userApp = userApp;
    }

    public UserApp getFilter() {
        return filter;
    }

    public void setFilter(UserApp filter) {
        this.filter = filter;
    }

    public PPE getPpeSelected() {
        return ppeSelected;
    }

    public void setPpeSelected(PPE ppeSelected) {
        this.ppeSelected = ppeSelected;
    }

    public PPE getPpe() {
        return ppe;
    }

    public void setPpe(PPE ppe) {
        this.ppe = ppe;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    public boolean isDisableButtons() {
        return disableButtons;
    }

    public void setDisableButtons(boolean disableButtons) {
        this.disableButtons = disableButtons;
    }

    public boolean isDisablePPEButtons() {
        return disablePPEButtons;
    }

    public void setDisablePPEButtons(boolean disablePPEButtons) {
        this.disablePPEButtons = disablePPEButtons;
    }

    public boolean isChooseCustomerButtonsVisible() {
        return chooseCustomerButtonsVisible;
    }

    public void setChooseCustomerButtonsVisible(boolean chooseCustomerButtonsVisible) {
        this.chooseCustomerButtonsVisible = chooseCustomerButtonsVisible;
    }

    public boolean isDisabledUserStereotypeButton() {
        return disabledUserStereotypeButton;
    }

    public void setDisabledUserStereotypeButton(boolean disabledUserStereotypeButton) {
        this.disabledUserStereotypeButton = disabledUserStereotypeButton;
    }

    public String getReturnProceedAction() {
        return returnProceedAction;
    }

    public void setReturnProceedAction(String returnProceedAction) {
        this.returnProceedAction = returnProceedAction;
    }

    public String getReturnCancelAction() {
        return returnCancelAction;
    }

    public void setReturnCancelAction(String returnCancelAction) {
        this.returnCancelAction = returnCancelAction;
    }

    public boolean isWizard() {
        return wizard;
    }

    public void setWizard(boolean wizard) {
        this.wizard = wizard;
    }

    public List<UserApp> getCustomerList() {
        return customerList;
    }

    public void setCustomerList(List<UserApp> customerList) {
        this.customerList = customerList;
    }

    public UserApp getCustomer() {
        return customer;
    }

    public void setCustomer(UserApp customer) {
        this.customer = customer;
    }

    public List<PPE> getPpes() {
        return ppes;
    }

    public void setPpes(List<PPE> ppes) {
        this.ppes = ppes;
    }

    public Double countVolume() {
        Double volume = new Double(0);
        if(ppes != null) {
            for(PPE p : ppes) {
                volume += p.getValue() != null ? p.getValue() : new Double(0);
            }
        }
        return volume;
    }

    public String initializePPEDetails() {
        PPEBean ppeBean = ComponentLookup.lookupComponent("op.ppeBean");
        ppeBean.setPpe(ppeSelected);
        ppeBean.initializePPE();

        return "ppeDetails";
    }

    public List<Sector> getSectors() {
        return sectors;
    }

    public void setSectors(List<Sector> sectors) {
        this.sectors = sectors;
    }

    public List<Stereotype> getStereotypes() {
        return stereotypes;
    }

    public void setStereotypes(List<Stereotype> stereotypes) {
        this.stereotypes = stereotypes;
    }

    private boolean validatePesel(UserApp user) {
        boolean valid = false;
        Integer result = null;
        try {
            result = pl.op.validation.Validations.validPesel(user.getPesel(), user.getBirthDate());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        if(result != null) {
            switch (result) {
                case 0:
                    valid = true;
                    break;
                default:
                    warning("invalid.pesel." + result);
            }
        }
        return valid;
    }

    @SuppressWarnings({ "deprecation" })
    private void warning(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_WARN,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    public List<City> getCities() {
        cities = new ArrayList<City>();

        if(filter.getLocation().getStreet().getCity().getArea().getAreaId() != null) {
            Area area = new Area();
            area.setAreaId(filter.getLocation().getStreet().getCity().getArea().getAreaId());
            try {
                City city = new City();
                city.setArea(area);
                cities = cityDao.getCities(city);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return cities;
    }

    public void setCities(List<City> cities) {
        this.cities = cities;
    }

    public List<Street> getStreets() {
        return streets;
    }

    public void setStreets(List<Street> streets) {
        this.streets = streets;
    }

    public List<String> autocompleteStreet(String query) {
        List<String> suggestions = new ArrayList<String>();

        for(Street s : streets) {
            if(s.getStreetName().startsWith(query))
                suggestions.add(s.getStreetName());
        }
        return suggestions;
    }
}
