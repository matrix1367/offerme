package pl.op.web.listener;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContextEvent;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import pl.op.dao.EventDao;
import pl.op.model.bonus.Event;

/**
 * The Class EventOp.
 */
public class EventOp implements javax.servlet.ServletContextListener {

    private Logger log = LoggerFactory.getLogger(EventOp.class);

    /*
     * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
     */
    @Override
    public void contextDestroyed(ServletContextEvent arg0) {
    }

    /*
     * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
     */
    @Override
    public void contextInitialized(ServletContextEvent event) {
        try {
            log.info(">>>>>>>>>>>>>>>>>> START LOAD EVENTS");
            createEvents(event);
            log.info(">>>>>>>>>>>>>>>>>> END LOAD EVENTS");
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Creates the events from xml file.
     * 
     * @param event
     *            the event
     * @throws ParserConfigurationException
     *             the parser configuration exception
     * @throws SAXException
     *             the SAX exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public void createEvents(ServletContextEvent event) throws ParserConfigurationException, SAXException, IOException {

        File xmlFile = new File(event.getServletContext().getRealPath("/resources/xml/eventsOp.xml"));

        if(xmlFile.exists()) {
            log.info("/resources/xml/eventsOp.xml exists");
            EventDao eventDao = GuiceSingleton.getInstance().getInstance(EventDao.class);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("eventOp");
            for(int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                if(nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    String codeName = eElement.getElementsByTagName("codeName").item(0).getTextContent().toLowerCase();
                    String name = eElement.getElementsByTagName("name").item(0).getTextContent();
                    String description = eElement.getElementsByTagName("description").item(0).getTextContent();
                    try {
                        if(eventDao.getEventByCodeName(codeName) == null) {
                            log.info("create: " + codeName);
                            Event newEvent = new Event();
                            newEvent.setEventCodeName(codeName);
                            newEvent.setEventName(name);
                            newEvent.setEventDescription(description);
                            eventDao.saveEvent(newEvent);
                        } else {
                            log.info("find: " + codeName);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {
            log.info("/resources/xml/eventsOp.xml no exists");
        }

    }

}
