package pl.op.web.listener;

import org.mybatis.guice.XMLMyBatisModule;
import org.slf4j.LoggerFactory;

import pl.op.dao.*;

import com.google.inject.*;


public class GuiceSingletonExternal {

	private static Injector oSingletonClass;

	private GuiceSingletonExternal() {

	}

	public static Injector getInstance() {
		if (oSingletonClass == null) {
			LoggerFactory.getLogger(GuiceSingletonExternal.class).info(
					"Creating guice external context...");

			oSingletonClass =  Guice.createInjector(new PrivateModule() {
	            @Override
	            protected void configure() {
	                install(new XMLMyBatisModule() {

	                    @Override
	                    protected void initialize() {
	                       setClassPathResource("mybatis.configuration.xml");
	                       setEnvironmentId("development");
	                    }
	                });
	               
	                //expose(ContractorInterface.class);
	            
	            }
	            
	        }, new PrivateModule() {
	        	@Override
	            protected void configure() {
	        	  install(new XMLMyBatisModule() {

	                    @Override
	                    protected void initialize() {
	                       setClassPathResource("mybatis.external.xml");
	                       setEnvironmentId("development");
	                    }
	                });
	                //expose(ExternalInterface.class);
	        }
		});

			if (oSingletonClass == null) {
				LoggerFactory.getLogger(GuiceSingletonExternal.class).error(
						"guice external context is null!!!!!!!!!!!!!!!!!!!!!!!!!!!");

			}
		}
		return oSingletonClass;
	}

}
