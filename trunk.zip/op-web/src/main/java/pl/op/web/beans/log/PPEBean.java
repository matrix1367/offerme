package pl.op.web.beans.log;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map.Entry;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.op.dao.AgreementDao;
import pl.op.dao.AuctionDao;
import pl.op.dao.CityDao;
import pl.op.dao.CloudDao;
import pl.op.dao.DistributorDao;
import pl.op.dao.LocationDao;
import pl.op.dao.MeterModelDao;
import pl.op.dao.PPEDao;
import pl.op.dao.SalesmanDao;
import pl.op.dao.StreetDao;
import pl.op.dao.TariffDao;
import pl.op.dao.UserDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.auction.PriceComponent;
import pl.op.model.auction.PriceComponentValue;
import pl.op.model.auction.ZoneType;
import pl.op.model.cloud.Cloud;
import pl.op.model.cloud.CloudFilter;
import pl.op.model.cloud.VolumeEnum;
import pl.op.model.contract.Agreement;
import pl.op.model.contract.AgreementType;
import pl.op.model.contract.DurationType;
import pl.op.model.contract.PPE;
import pl.op.model.contract.PPEFilter;
import pl.op.model.contract.PPEStatus;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Distributor;
import pl.op.model.dict.MeterModel;
import pl.op.model.dict.PPETariff;
import pl.op.model.dict.Street;
import pl.op.model.dict.Tariff;
import pl.op.model.salesman.Salesman;
import pl.op.model.user.UserApp;
import pl.op.util.CloudUtil;
import pl.op.util.MessageUtil;
import pl.op.util.PpeUtil;
import pl.op.web.beans.AdminBean;
import pl.op.web.beans.bill.BillInvoiceBean;
import pl.op.web.beans.cloud.CloudBean;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class PPEBean.
 */
@Name("op.ppeBean")
@Scope(ScopeType.SESSION)
public class PPEBean implements Serializable {

    private static final long serialVersionUID = 7657279753756327544L;

    private List<PPE> ppeList;
    private List<Area> areas;
    private List<City> cities;
    private List<Street> streets;
    private List<Distributor> distributors;
    private List<Tariff> tariffs;
    private List<Salesman> salesmans;
    private List<Cloud> clouds;
    private List<PPEStatus> ppeStatuses;
    private List<DurationType> durationTypes;
    private List<MeterModel> meterModels;
    private List<VolumeEnum> volumes;

    private PPEFilter ppeFilter;
    private PPE ppe;
    private Agreement lastAgreement;

    private PPEDao ppeDao;
    private CityDao cityDao;
    private StreetDao streetDao;
    private TariffDao tariffDao;
    private SalesmanDao salesmanDao;
    private CloudDao cloudDao;
    private MeterModelDao meterModelDao;
    private LocationDao locationDao;
    private AuctionDao auctionDao;
    private AgreementDao agreementDao;
    private UserDao userDao;

    private DistributorDao distributorDao;
    private boolean buttonsVisible = true;
    private boolean cloudButtonsDisabled = true;

    private CloudBean cloudBean;

    private Cloud selectedCloud;

    private DictionaryBean dictionaryBean;

    // zmienne pomocnicze do templatek
    private Integer meterModelId;
    private String activeTab = "0";

    /**
     * Instantiates a new PPE bean.
     */
    public PPEBean() {
        log.info("PPEBean constructor");
        initialize();
    }

    private Logger log = LoggerFactory.getLogger(PPEBean.class);

    /**
     * Initialize.
     */
    private void initialize() {
        initializeDao();
        initializeVars();
        try {
            initializeDicts();
            clearPPEFilter();
            clearPPE();
            filterPPEList();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Initialize dao.
     */
    private void initializeDao() {
        log.info("initializeDao");

        ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);
        cityDao = GuiceSingleton.getInstance().getInstance(CityDao.class);
        streetDao = GuiceSingleton.getInstance().getInstance(StreetDao.class);
        distributorDao = GuiceSingleton.getInstance().getInstance(DistributorDao.class);
        tariffDao = GuiceSingleton.getInstance().getInstance(TariffDao.class);
        salesmanDao = GuiceSingleton.getInstance().getInstance(SalesmanDao.class);
        cloudDao = GuiceSingleton.getInstance().getInstance(CloudDao.class);
        meterModelDao = GuiceSingleton.getInstance().getInstance(MeterModelDao.class);
        locationDao = GuiceSingleton.getInstance().getInstance(LocationDao.class);
        auctionDao = GuiceSingleton.getInstance().getInstance(AuctionDao.class);
        agreementDao = GuiceSingleton.getInstance().getInstance(AgreementDao.class);
        userDao = GuiceSingleton.getInstance().getInstance(UserDao.class);
    }

    /**
     * Initialize vars.
     */
    private void initializeVars() {
        log.info("initializeVars");

        cloudBean = ComponentLookup.lookupComponent("op.cloudBean");
        dictionaryBean = ComponentLookup.lookupComponent("op.dictionaryBean");
        activeTab = "0";
    }

    /**
     * Initialize dicts.
     *
     * @throws Exception the exception
     */
    private void initializeDicts() throws Exception {
        log.info("initializeDicts");

        areas = dictionaryBean.getAreasList();
        streets = dictionaryBean.getStreetsList();
        distributors = distributorDao.getDistributors();
        tariffs = dictionaryBean.getTariffsList();
        salesmans = salesmanDao.getAllSalesmans();
        meterModels = meterModelDao.getMeterModels();
    }

    /**
     * Prepare ppe for chart.
     *
     * @param ppe the ppe
     * @return the ppe
     */
    public PPE preparePPEForChart(PPE ppe) {
        try {
            ppe.setTariff(ppeDao.getActualTariff(ppe));
        } catch (Exception e) {
            log.error("Problem while setting PPE Tariff: ", e);
        }
        return ppe;
    }

    public  List<PriceComponentValue> getPercentValue(PPE ppe) {
        List<PriceComponentValue> result = new ArrayList<PriceComponentValue>();
        
        PpeUtil util = GuiceSingleton.getInstance().getInstance(PpeUtil.class);
        HashMap<ZoneType, Double> volumeMaps = util.prepareYearVolumeMapsForPPE(ppe);
        for(Entry<ZoneType, Double> entry : volumeMaps.entrySet()) {
           
                PriceComponentValue princComponentValue = new PriceComponentValue();
                 if (entry.getValue() != 0) {
                     Double valuePPE =ppe.getValue();
                     switch (ppe.getValueUnit()) {
                         case MWH:{
                             valuePPE = valuePPE * 10.0;
                             break;
                         }
                         case GWH : {
                             valuePPE = valuePPE * 10000.0;
                             break;
                         }
                         case TWH : {
                             valuePPE = valuePPE * 10000000.0;
                         }
                     }
                     princComponentValue.setValue(entry.getValue() / valuePPE );
                     } else {
                     princComponentValue.setValue(0.0);
                 }
                PriceComponent priceComponent = new PriceComponent();                
                priceComponent.setZoneType(entry.getKey());        
                princComponentValue.setPriceComponent(priceComponent);
                result.add(princComponentValue);
            
        }
        return result;
    }

    /**
     * Clear ppe filter.
     */
    public void clearPPEFilter() {
        ppeFilter = new PPEFilter();
    }

    /**
     * Clear ppe.
     */
    public void clearPPE() {
        ppe = new PPE();
        buttonsVisible = true;
        meterModelId = 0;
    }

    /**
     * Filter ppe list.
     */
    public void filterPPEList() {
        try {
            ppeFilter.countVolume();
            ppeList = ppeDao.getPPEsByFilter(ppeFilter);

            for (PPE p : ppeList) {
                p.setTariff(ppeDao.getActualTariff(p));
            }
        } catch (Exception e) {
            log.error("Problem while filter ppe List: ", e);
        }
    }

    /**
     * On ppe select.
     *
     * @param event the event
     */
    public void onPPESelect(SelectEvent event) throws Exception {
        buttonsVisible = false;
        MeterModel meterModel = ppe.getMeterModel();
        if (meterModel != null) {
            meterModelId = meterModel.getMeterModelId();
        }
        lastAgreement = agreementDao.getLastAgreementByPpeId(ppe.getPpeId());
        if (lastAgreement != null) {
            log.info("lastAgreement is not null");
            log.info("lastAgreement " + lastAgreement.getAgreementId());
            log.info("lastAgreement " + lastAgreement.getDateFrom());
            log.info("lastAgreement " + lastAgreement.getDateTo());
            log.info("lastAgreement " + lastAgreement.getAgreementType().getLabel());
            log.info("lastAgreement " + lastAgreement.getDurationType().name());
        } else {
            log.info("lastAgreement is null");
        }
    }

    public void setLastAgreement(Agreement agr) {
        lastAgreement = agr;
    }

    public Agreement getLastAgreement() {
        return lastAgreement;
    }

    /**
     * On ppe unselect.
     *
     * @param event the event
     */
    public void onPPEUnselect(UnselectEvent event) {
        clearPPE();
    }

    /**
     * Delete ppe.
     */
    public void deletePPE() {
        if (!PpeUtil.canEditPpe(ppe)) {
            MessageUtil.displayMessageInfo("warnning.delete.ppe.join.ppe.auction");
            return;
        }
        try {
            ppeDao.deletePPE(ppe);
            CloudUtil.updateCloudVolumeByPpeId(ppe.getPpeId());
        } catch (Exception e) {
            e.printStackTrace();
        }

        BillInvoiceBean billinvoiceBean = ComponentLookup.lookupComponent("op.billInvoiceBean");
        billinvoiceBean.InicializePPE();

        clearPPE();
        filterPPEList();
    }

    /**
     * Initialize new.
     */
    public void initializeNew() {
        clearPPE();
    }

    /**
     * Save ppe.
     */
    public void savePPE() {
        try {
            if (meterModelId != null && meterModelId > 0) {
                MeterModel tmpMeterModel = new MeterModel();
                tmpMeterModel.setMeterModelId(meterModelId);
                ppe.setMeterModel(tmpMeterModel);
            }

            if (ppe.getPpeId() == null) {
                ppeDao.savePPE(ppe);
            } else {
                PPE ppe_old = ppeDao.getPPEById(ppe.getPpeId().longValue());
                if (ppe_old.getPpeStatus() == PPEStatus.AIMED_TO_AGREEMENT && ppe.getPpeStatus() == PPEStatus.DURING_AGREEMENT) {
                    //uaktualnij data w koncie użytkownika.
                    log.info("zmiana stanu w ppe");
                    Auction auction = auctionDao.getAuctionFromPPE(ppe.getPpeId());
                    if (auction != null) {
                        log.info("Data umowy aukcji :" + auction.getEndContractDate());
                        log.info("Data umowy aukcji :" + auction.getBeginContractDate());

                        Agreement agreement = new Agreement();
                        agreement.setDateFrom(auction.getBeginContractDate());
                        agreement.setDateTo(auction.getEndContractDate());
                        agreement.setPpeId(ppe.getPpeId());
                        agreement.setAgreementType(AgreementType.sellAndDistr);
                        agreement.setDurationType(DurationType.fixed);

                        UserApp user = userDao.getUserByPPE(ppe.getPpeId());
                        agreement.setUserApp(user);

                        List<AuctionOffer> auctionofferts = auction.getAuctionOffers();
                        log.info("size auction offert from auction.getAuctionOfferts()");
                        List<AuctionOffer> auctionOfferts_get = auctionDao.getAuctionOffers(auction);
                        log.info("size auction offert from auction.auctionOfferts_get()");
                        AuctionOffer auctionOffer = auctionOfferts_get.get(auctionOfferts_get.size() - 1);
                        Salesman salesman = auctionOffer.getSalesman();
                        agreement.setSalesman(salesman);
                        //Agreement agreement = agreementDao
                        //   

                    //    if(agreement.getSalesman().getSalesmanId() == null)
                        //    if(salesmanDao.getSalesmanByName(agreement.getSalesman().getSalesmanName()) == null) {
                        //         salesmanDao.saveSalesman(agreement.getSalesman());
                        //     }
                        agreementDao.saveAgreement(agreement);
                        agreementDao.saveAgreementPPE(agreement);

                    } else {
                        log.info("aucioni is null");
                    }
                } else {
                    log.info("brak zmiany  stanu w ppe");
                }
                ppeDao.updatePPE(ppe);

                PPETariff ppeTariff = new PPETariff();
                ppeTariff.setPpe(ppe);

                tariffDao.updatePPETariff(ppeTariff);
                tariffDao.savePPETariff(ppeTariff);

                Street street = streetDao.getStreet(ppe.getLocation().getStreet());

                if (street == null) {
                    streetDao.saveStreet(ppe.getLocation().getStreet());
                }

                locationDao.updateLocation(ppe.getLocation());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        activeTab = "0";
        clearPPE();

        BillInvoiceBean billinvoiceBean = ComponentLookup.lookupComponent("op.billInvoiceBean");
        billinvoiceBean.InicializePPE();
    }

    /**
     * Initialize ppe.
     */
    public void initializePPE() {
        CloudFilter cF = new CloudFilter();
        cF.setUser(ppe.getLocation().getUserApp());
        try {
            clouds = cloudDao.getClouds(cF);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Ppe volume.
     *
     * @return the string
     */
    public String ppeVolume() {
        return "";
    }

    /**
     * Gets the ppe list.
     *
     * @return the ppe list
     */
    public List<PPE> getPpeList() {
        return ppeList;
    }

    /**
     * Sets the ppe list.
     *
     * @param ppeList the new ppe list
     */
    public void setPpeList(List<PPE> ppeList) {
        this.ppeList = ppeList;
    }

    /**
     * Gets the ppe filter.
     *
     * @return the ppe filter
     */
    public PPEFilter getPpeFilter() {
        return ppeFilter;
    }

    /**
     * Sets the ppe filter.
     *
     * @param ppeFilter the new ppe filter
     */
    public void setPpeFilter(PPEFilter ppeFilter) {
        this.ppeFilter = ppeFilter;
    }

    /**
     * Gets the ppe.
     *
     * @return the ppe
     */
    public PPE getPpe() {
        return ppe;
    }

    /**
     * Sets the ppe.
     *
     * @param ppe the new ppe
     */
    public void setPpe(PPE ppe) {
        this.ppe = ppe;
    }

    /**
     * Checks if is buttons visible.
     *
     * @return true, if is buttons visible
     */
    public boolean isButtonsVisible() {
        return buttonsVisible;
    }

    /**
     * Sets the buttons visible.
     *
     * @param buttonsVisible the new buttons visible
     */
    public void setButtonsVisible(boolean buttonsVisible) {
        this.buttonsVisible = buttonsVisible;
    }

    /**
     * Gets the areas.
     *
     * @return the areas
     */
    public List<Area> getAreas() {
        return areas;
    }

    /**
     * Sets the areas.
     *
     * @param areas the new areas
     */
    public void setAreas(List<Area> areas) {
        this.areas = areas;
    }

    /**
     * Gets the cities.
     *
     * @return the cities
     */
    public List<City> getCities() {
        cities = new ArrayList<City>();

        if (null == ppeFilter) {
            clearPPEFilter();
        }
        try {
            if (ppeFilter.getPpe().getLocation().getStreet().getCity().getArea().getAreaId() != null) {
                Area area = new Area();
                area.setAreaId(ppeFilter.getPpe().getLocation().getStreet().getCity().getArea().getAreaId());
                log.info(ppeFilter.getPpe().getLocation().getStreet().getCity() + "");

                if (null == ppeFilter.getPpe().getLocation().getStreet().getCity().getHasStatus()
                        || true == ppeFilter.getPpe().getLocation().getStreet().getCity().getHasStatus()) {
                    cities = dictionaryBean.getCitiesMap().get(area.getAreaId());
                } else {
                    cities = dictionaryBean.getVillagesMap().get(area.getAreaId());
                }
            }
        } catch (Exception e) {
            log.error("Problem while get Cities to filter: ", e);
        }

        return cities;
    }

    /**
     * Cities edit.
     *
     * @return the list
     */
    public List<City> citiesEdit() {
        List<City> cities = new ArrayList<City>();

        if (ppe.getLocation().getStreet().getCity().getArea().getAreaId() != null) {
            Area area = new Area();
            area.setAreaId(ppe.getLocation().getStreet().getCity().getArea().getAreaId());
            try {
                City city = new City();
                city.setArea(area);
                cities = cityDao.getCities(city);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return cities;
    }

    /**
     * Autocomplete street.
     *
     * @param query the query
     * @return the list
     */
    public List<String> autocompleteStreet(String query) {
        List<String> suggestions = new ArrayList<String>();

        for (Street s : streets) {
            if (s.getStreetName().startsWith(query)) {
                suggestions.add(s.getStreetName());
            }
        }
        return suggestions;
    }

    /**
     * Sets the cities.
     *
     * @param cities the new cities
     */
    public void setCities(List<City> cities) {
        this.cities = cities;
    }

    /**
     * Gets the streets.
     *
     * @return the streets
     */
    public List<Street> getStreets() {
        return streets;
    }

    /**
     * Sets the streets.
     *
     * @param streets the new streets
     */
    public void setStreets(List<Street> streets) {
        this.streets = streets;
    }

    /**
     * Gets the distributors.
     *
     * @return the distributors
     */
    public List<Distributor> getDistributors() {
        return distributors;
    }

    /**
     * Sets the distributors.
     *
     * @param distributors the new distributors
     */
    public void setDistributors(List<Distributor> distributors) {
        this.distributors = distributors;
    }

    /**
     * Gets the tariffs.
     *
     * @return the tariffs
     */
    public List<Tariff> getTariffs() {
        return tariffs;
    }

    /**
     * Sets the tariffs.
     *
     * @param tariffs the new tariffs
     */
    public void setTariffs(List<Tariff> tariffs) {
        this.tariffs = tariffs;
    }

    /**
     * Gets the salesmans.
     *
     * @return the salesmans
     */
    public List<Salesman> getSalesmans() {
        return salesmans;
    }

    /**
     * Sets the salesmans.
     *
     * @param salesmans the new salesmans
     */
    public void setSalesmans(List<Salesman> salesmans) {
        this.salesmans = salesmans;
    }

    /**
     * Gets the clouds.
     *
     * @return the clouds
     */
    public List<Cloud> getClouds() {
        return clouds;
    }

    /**
     * Sets the clouds.
     *
     * @param clouds the new clouds
     */
    public void setClouds(List<Cloud> clouds) {
        this.clouds = clouds;
    }

    /**
     * Sets the selected cloud.
     *
     * @param selectedCloud the new selected cloud
     */
    public void setSelectedCloud(Cloud selectedCloud) {
        this.selectedCloud = selectedCloud;
    }

    /**
     * Gets the selected cloud.
     *
     * @return the selected cloud
     */
    public Cloud getSelectedCloud() {
        return selectedCloud;
    }

    /**
     * Cloud details.
     *
     * @return the string
     */
    public String cloudDetails() {
        return cloudBean.initializeCloudDetailsForUser(selectedCloud);
    }

    /**
     * Cloud edit.
     *
     * @return the string
     */
    public String cloudEdit() {
        return cloudBean.initializeCloudEdit(selectedCloud);
    }

    /**
     * Checks if is cloud buttons disabled.
     *
     * @return true, if is cloud buttons disabled
     */
    public boolean isCloudButtonsDisabled() {
        return cloudButtonsDisabled;
    }

    /**
     * Sets the cloud buttons disabled.
     *
     * @param cloudButtonsDisabled the new cloud buttons disabled
     */
    public void setCloudButtonsDisabled(boolean cloudButtonsDisabled) {
        this.cloudButtonsDisabled = cloudButtonsDisabled;
    }

    /**
     * On cloud select.
     *
     * @param event the event
     */
    public void onCloudSelect(SelectEvent event) {
        cloudButtonsDisabled = false;
    }

    /**
     * On cloud unselect.
     *
     * @param event the event
     */
    public void onCloudUnselect(UnselectEvent event) {
        cloudButtonsDisabled = true;
        selectedCloud = new Cloud();
    }

    /**
     * Gets the ppe statuses.
     *
     * @return the ppe statuses
     */
    public List<PPEStatus> getPpeStatuses() {
        ppeStatuses = new ArrayList<PPEStatus>();

        for (PPEStatus t : PPEStatus.values()) {
            t.setLabel(BundlesUtils.getMessageResourceString("messages", "ppe.status." + t, null, Locale.getDefault()));

            ppeStatuses.add(t);
        }

        return ppeStatuses;
    }

    /**
     * Sets the ppe statuses.
     *
     * @param ppeStatuses the new ppe statuses
     */
    public void setPpeStatuses(List<PPEStatus> ppeStatuses) {
        this.ppeStatuses = ppeStatuses;
    }

    /**
     * Gets the duration types.
     *
     * @return the duration types
     */
    public List<DurationType> getDurationTypes() {
        durationTypes = new ArrayList<DurationType>();

        for (DurationType t : DurationType.values()) {
            t.setLabel(BundlesUtils.getMessageResourceString("messages", "duration.type." + t, null,
                    Locale.getDefault()));

            durationTypes.add(t);
        }
        return durationTypes;
    }

    /**
     * Sets the duration types.
     *
     * @param durationTypes the new duration types
     */
    public void setDurationTypes(List<DurationType> durationTypes) {
        this.durationTypes = durationTypes;
    }

    /**
     * Gets the meter models.
     *
     * @return the meter models
     */
    public List<MeterModel> getMeterModels() {
        return meterModels;
    }

    /**
     * Sets the meter models.
     *
     * @param meterModels the new meter models
     */
    public void setMeterModels(List<MeterModel> meterModels) {
        this.meterModels = meterModels;
    }

    /**
     * Gets the volumes.
     *
     * @return the volumes
     */
    public List<VolumeEnum> getVolumes() {
        volumes = new ArrayList<VolumeEnum>();

        for (VolumeEnum a : VolumeEnum.values()) {
            a.setLabel(BundlesUtils.getMessageResourceString("messages", "cloud.volume." + a, null, Locale.getDefault()));
            volumes.add(a);
        }

        return volumes;
    }

    /**
     * Sets the volumes.
     *
     * @param volumes the new volumes
     */
    public void setVolumes(List<VolumeEnum> volumes) {
        this.volumes = volumes;
    }

    /**
     * Gets the meter model id.
     *
     * @return the meter model id
     */
    public Integer getMeterModelId() {
        return meterModelId;
    }

    /**
     * Sets the meter model id.
     *
     * @param meterModelId the new meter model id
     */
    public void setMeterModelId(Integer meterModelId) {
        this.meterModelId = meterModelId;
    }

    /**
     * Gets the active tab.
     *
     * @return the active tab
     */
    public String getActiveTab() {
        return activeTab;
    }

    /**
     * Sets the active tab.
     *
     * @param activeTab the new active tab
     */
    public void setActiveTab(String activeTab) {
        this.activeTab = activeTab;
    }
}
