package pl.op.web.beans;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.SectorDao;
import pl.op.dao.StereotypeDao;
import pl.op.model.stereotype.Sector;
import pl.op.model.stereotype.Stereotype;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

@Name("op.sectorBean")
@Scope(ScopeType.SESSION)
public class SectorBean {

	private Logger log = LoggerFactory.getLogger(SectorBean.class);

	private List<Sector> sectorList;
	private Sector selectedSector;
	private Sector newSector;

	private boolean edit;

	// buttons disable
	private boolean disableShow = true;
	private boolean disableEdit = true;
	private boolean disableRemove = true;

	private SectorDao sectorDao;
	private StereotypeDao stereotypeDao;
	
	private StereotypeBean stereotypeBean;
		
	public SectorBean() {
		log.info("SectorBean constructor");
		initialize();
	}

	private void initialize() {
		notAvailableAction();
		sectorDao = GuiceSingleton.getInstance().getInstance(SectorDao.class);
		stereotypeDao = GuiceSingleton.getInstance().getInstance(StereotypeDao.class);

		stereotypeBean = ComponentLookup.lookupComponent("op.stereotypeBean");
		
		stereotypeBean.listStereotype();
		sectorList = new ArrayList<Sector>();
	}

	// Dictionary Sector
	private void prepareSectorList() {
		try {
			sectorList = sectorDao.getSector();
			for (Sector entry : sectorList) {
				entry.setStereotype(stereotypeDao.getStereotypeById(entry.getStereotype().getStereotypeId()));
			}
		} catch (Exception e) {
			log.error("error while getting sector: ", e);
		}
	}

	public void refreshSectorList() {
		prepareSectorList();
	}

	public String addSector() {
		edit = false;
		selectedSector = new Sector();
		newSector = new Sector();
		newSector.setStereotype(new Stereotype());
		prepareSectorList();
		return "sector";
	}

	public String cancelAddSector() {
		notAvailableAction();
		prepareSectorList();
		return "dictionaries";
	}

	public String saveSector() {
		Stereotype stereotype = null;
		try {
			stereotype = stereotypeDao.getStereotypeById(newSector.getStereotype().getStereotypeId());
		} catch (Exception e) {
			log.error(
					"Error while getStereotypeById(newSector.getStereotype().getStereotypeId()): ",
					e);
		}
		try {
			if (edit) {
				selectedSector.setStereotype(stereotype);
				sectorDao.updateSector(selectedSector);
			} else {
				newSector.setStereotype(stereotype);
				sectorDao.saveSector(newSector);
			}
		} catch (Exception e) {
			log.error("Error while saveSector: ", e);
		}
		prepareSectorList();
		return "dictionaries";
	}

	public void deleteSector() {
		try {
			sectorDao.deleteSector(selectedSector);
		} catch (Exception e) {
			log.error("Error while deleteSector: ", e);
		}
		prepareSectorList();
		notAvailableAction();
	}

	public String editSector() {
		edit = true;
		newSector = selectedSector;
		stereotypeBean.listStereotype();
		return "sector";
	}

	public void onRowSelectDictionariesList(SelectEvent event) {
		availableAction();
	}

	public void onRowUnselectDictionariesList(UnselectEvent event) {
		notAvailableAction();
	}

	public void availableAction() {
		disableShow = false;
		disableEdit = false;
		disableRemove = false;
	}

	public void notAvailableAction() {
		selectedSector = new Sector();

		disableShow = true;
		disableEdit = true;
		disableRemove = true;
	}

	public Sector getNewSector() {
		return newSector;
	}

	public void setNewSector(Sector newSector) {
		this.newSector = newSector;
	}

	public Sector getSelectedSector() {
		return selectedSector;
	}

	public void setSelectedSector(Sector selectedSector) {
		this.selectedSector = selectedSector;
	}

	public List<Sector> getSectorList() {
		return sectorList;
	}

	public void setSectorList(List<Sector> sectorList) {
		this.sectorList = sectorList;
	}

	public boolean isDisableShow() {
		return disableShow;
	}

	public void setDisableShow(boolean disableShow) {
		this.disableShow = disableShow;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}

	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}
}
