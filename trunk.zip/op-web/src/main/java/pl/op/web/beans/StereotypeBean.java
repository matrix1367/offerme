package pl.op.web.beans;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.StereotypeDao;
import pl.op.model.stereotype.Sector;
import pl.op.model.stereotype.Stereotype;
import pl.op.web.common.BundlesUtils;
import pl.op.web.listener.GuiceSingleton;

@Name("op.stereotypeBean")
@Scope(ScopeType.SESSION)
public class StereotypeBean implements Serializable {

	private static final long serialVersionUID = 4678949437531953613L;

	private Logger log = LoggerFactory.getLogger(StereotypeBean.class);

	public final String SAVE_PATH = "/images/stereotypes/";
	
	private Stereotype stereotype;
	private List<Stereotype> stereotypeList;
	private StereotypeDao stereotypeDao;
	private boolean edit;
	private UploadedFile image;

	private FacesContext facesContext;
	private ExternalContext ectx;

	// disable buttons
	private boolean disableShow;
	private boolean disableEdit;
	private boolean disableRemove;

	public StereotypeBean() {
		log.info("StereotypeBean constructor");
		facesContext = FacesContext.getCurrentInstance();
		ectx = facesContext.getExternalContext();
		stereotypeDao = GuiceSingleton.getInstance().getInstance(StereotypeDao.class);
		stereotype = new Stereotype();
		initialize();
	}

	public void initialize() {
		notAvailableAction();
	}

	public void listStereotype() {
		notAvailableAction();
		stereotype = new Stereotype();
		
		try {
			stereotypeList = stereotypeDao.getStereotypes(new Sector());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		edit = false;
	}

	public String saveStereotype() {
			try {
				if (edit) {
					stereotypeDao.updateStereotype(stereotype);
				} else {
					stereotypeDao.saveStereotype(stereotype);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			listStereotype();
			return "dictionaries";
	}

	public String addStereotype() {
		edit = false;

		stereotype = new Stereotype();
		stereotype.setCreationDate(new Date());
		stereotype.setRemoved(false);

		return "stereotype";
	}

	public void deleteStereoType() {
		stereotype.setRemoved(true);
		try {
			stereotypeDao.updateStereotype(stereotype);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		listStereotype();
	}

	public String editStereotype() {
		edit = true;
		return "stereotype";
	}

	public void onRowSelectAuditList(SelectEvent event) {
		availableAction();
	}
	
	public void onRowUnselectAuditList(UnselectEvent event) {
		notAvailableAction();
	}
		
	public void availableAction() {
		disableShow = false;
		disableEdit = false;
		disableRemove = false;
	}

	public void notAvailableAction() {
		disableShow = true;
		disableEdit = true;
		disableRemove = true;
	}

	public String cancelStereotype() {
		stereotype = new Stereotype();
		notAvailableAction();
		return "dictionaries";
	}

	public Stereotype getStereotype() {
		return stereotype;
	}

	public void setStereotype(Stereotype stereotype) {
		this.stereotype = stereotype;
	}

	public List<Stereotype> getStereotypeList() {
		return stereotypeList;
	}

	public void setStereotypeList(List<Stereotype> stereotypeList) {
		this.stereotypeList = stereotypeList;
	}

	public boolean isDisableShow() {
		return disableShow;
	}

	public void setDisableShow(boolean disableShow) {
		this.disableShow = disableShow;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}
	
	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}

	public UploadedFile getImage() {
		return image;
	}

	public void setImage(UploadedFile image) {
		this.image = image;
	}

	@SuppressWarnings({ "unused", "deprecation" })
	private void warning(String message_code) {
		FacesMessages.instance().add(
				FacesMessage.SEVERITY_WARN,
				BundlesUtils.getMessageResourceString("messages", message_code,
						null, ectx.getRequestLocale()));
	}

	public boolean checkRequired() {
		return !edit;
	}
}