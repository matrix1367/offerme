package pl.op.web.beans;

import java.io.Serializable;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.*;

import com.google.common.base.Strings;

import pl.op.dao.HelpPageDao;
import pl.op.model.cms.HelpPage;
import pl.op.web.listener.GuiceSingleton;

@Name("op.helpBean")
@Scope(ScopeType.PAGE)
public class HelpBean  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private transient HelpPageDao helpPageDao;

	public HelpBean() {
		
	}
	
	String helpPageViewId;

	private HelpPage helpPage;
	
	public String getHelpPageViewId() {
		return helpPageViewId;
	}
	public void setHelpPageViewId(String helpPageViewId) {
		this.helpPageViewId =  rewrite(helpPageViewId);
		if(!Strings.isNullOrEmpty(this.helpPageViewId)){
			helpPage = getHelpPageDao().findByViewId(this.helpPageViewId);
		}
	}

	private String rewrite(String helpPageViewId2) {
		
		if(!Strings.isNullOrEmpty(helpPageViewId2) && helpPageViewId2.endsWith(".seam")){
			return helpPageViewId2.substring(0,helpPageViewId2.length()-5);
		}
		return helpPageViewId2;
	}
	public HelpPage getHelpPage(){
		return helpPage;
	}
	public List<HelpPage> getAllHelpPages(){
		return getHelpPageDao().findAll();
	}
	
	public String showHelpPage(HelpPage helpPage){
		setHelpPageViewId(helpPage.getViewId());
		return "help";
	}
	public String back(){
		setHelpPageViewId(null);
		return "help";
	}
	
	protected HelpPageDao getHelpPageDao() {
		if(helpPageDao == null){
			helpPageDao = GuiceSingleton.getInstance().getInstance(HelpPageDao.class);
		}
		return helpPageDao;
	}
	
}
