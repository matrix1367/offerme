package pl.op.web.beans.faq;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.FaqDao;
import pl.op.model.faq.Faq;
import pl.op.model.faq.QuestionType;
import pl.op.model.msg.Message;
import pl.op.web.beans.AdminBean;
import pl.op.web.beans.message.MessageBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.ComponentLookup;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class FaqBean. This class manages the FAQ messages in application. Can
 * add/edit/delete data from database table named "tb_faq".
 */
@Name("op.faqBean")
@Scope(ScopeType.SESSION)
public class FaqBean implements Serializable {

	private static final long serialVersionUID = 2621109280186027543L;

	private Logger log = LoggerFactory.getLogger(FaqBean.class);

	private List<Faq> faqList;
	private Faq newFaq;
	private Faq selectedFaq;
	private Message newMessage;

	private Map<String, List<Faq>> faqCategoryList;

	@SuppressWarnings("unused")
	private List<QuestionType> questionType;

	private boolean edit;

	private String messageTopic;

	private boolean addToFaq = false;
	private boolean sendToOperators = false;
	private boolean faqNotEdited = true;
	private boolean faqListEmpty = false;

	private boolean disableShow = true;
	private boolean disableEdit = true;
	private boolean disableRemove = true;

	private FaqDao faqDao;

	MessageBean messageBean = ComponentLookup.lookupComponent("op.messageBean");
	AdminBean adminBean = ComponentLookup.lookupComponent("op.adminBean");

	public FaqBean() {
		log.info("FaqBean constructor");
		initialize();
	}

	/**
	 * Initialize the FaqBean.
	 */
	private void initialize() {
		faqDao = GuiceSingleton.getInstance().getInstance(FaqDao.class);

		faqList = new ArrayList<Faq>();
		newFaq = new Faq();
		selectedFaq = new Faq();

		messageTopic = BundlesUtils.getMessageResourceString("messages",
				"mailBox.newMessage.faqTopic", null, Locale.getDefault());

		messageBean.clearMessage();
	}

	/**
	 * Downloads FAQ from database and prepares list for display.
	 */
	private void prepareFaqCategoryList() {

		faqCategoryList = new HashMap<String, List<Faq>>();

		for (QuestionType type : QuestionType.values()) {
			String questionType = "faq.questionType." + type.toString();
			try {
				List<Faq> faqListByQuestionType = faqDao
						.getFaqByQuestionType(type.toString());

				if (faqListByQuestionType == null) {
					continue;
				}

				if (faqListByQuestionType.isEmpty() == false) {
					faqCategoryList.put(questionType, faqListByQuestionType);
				}
			} catch (Exception e) {
				log.info("Problem while select question by question Type:", e);
			}
		}

		log.info("faq size: " + faqCategoryList.size());

	}

	/**
	 * Checks the list is empty or not.
	 */
	private void checkListContent() {
		if (faqList.size() != 0) {
			faqListEmpty = false;
		} else {
			faqListEmpty = true;
		}
	}

	/**
	 * Downloads the FAQ list and show it on FAQ page and in administration
	 * page.
	 */
	private void prepareAndShowFaqList() {
		try {
			faqList = faqDao.showFaq();
		} catch (Exception e) {
			log.error("Error while getting faqList : ", e);
			e.printStackTrace();
		}

		checkListContent();
	}

	/**
	 * Downloads the FAQ list and show it on administration page.
	 */
	private void prepareFaqList() {
		try {
			faqList = faqDao.getFaq();
		} catch (Exception e) {
			log.error("Error while getting faqList : ", e);
			e.printStackTrace();
		}

		checkListContent();
	}

	/**
	 * Gets the faq assigned to inbox message.
	 * 
	 */
	public void getFaqAssignedToMessageInbox() {
		selectedFaq = new Faq();
		Integer messageId = messageBean.getSelectedInboxMessage()
				.getMessageId();
		try {
			selectedFaq = faqDao.getFaqByMessageId(messageId);
		} catch (Exception e) {
			log.error("Error while getting FAQ by inbox message : ", e);
			e.printStackTrace();
		}
		if (adminBean.getUserLog().getUserRole().name().equals("operator")) {
			if (selectedFaq.getQuestionAnswer() != null) {
				faqNotEdited = true;
			} else {
				faqNotEdited = false;
			}
		}
	}

	/**
	 * Gets the faq assigned to outbox message.
	 * 
	 */
	public void getFaqAssignedToMessageOutbox() {
		selectedFaq = new Faq();
		Integer messageId = messageBean.getSelectedOutboxMessage()
				.getMessageId();
		try {
			selectedFaq = faqDao.getFaqByMessageId(messageId);
		} catch (Exception e) {
			log.error("Error while getting FAQ by outbox message : ", e);
			e.printStackTrace();
		}
		if (adminBean.getUserLog().getUserRole().name().equals("operator")) {
			if (selectedFaq.getQuestionAnswer() != null) {
				faqNotEdited = true;
			} else {
				faqNotEdited = false;
			}
		}
	}

	/**
	 * Cleans the "Ask Question" drawer on XHTML page.
	 */
	public void cleanAskQuestion() {
		messageBean.clearMessage();
		newFaq = new Faq();
	}

	/**
	 * Refresh the FAQ list and show it on administration page.
	 */
	public void refreshFaqList() {
		prepareFaqList();
		prepareFaqCategoryList();
		checkListContent();
	}

	/**
	 * Refresh the FAQ list and show it on administration page.
	 */
	public void refreshAndShowFaqList() {
		prepareAndShowFaqList();
		prepareFaqCategoryList();
		checkListContent();
	}

	/**
	 * Prepares the data for XHTML template to add new FAQ.
	 * 
	 * @return the string
	 */
	public String addFaq() {
		edit = false;
		selectedFaq = new Faq();
		newFaq = new Faq();
		newFaq.setRemoved(false);
		return "faqEdit";
	}

	/**
	 * Cancel add faq.
	 * 
	 * @return the string
	 */
	public String cancelAddFaq() {
		notAvailableAction();
		checkListContent();
		return "dictionaries";
	}

	/**
	 * Saves FAQ defined in XHTML template.
	 * 
	 * @return the string
	 */
	public String addNewFaq() {
		try {
			if (edit) {
				selectedFaq.setRemoved(false);
				faqDao.updateFaq(selectedFaq);
			} else {
				newFaq.setRemoved(false);
				faqDao.newFaq(newFaq);

				selectedFaq = new Faq();
				newFaq = new Faq();
				newFaq.setRemoved(false);
			}
		} catch (Exception e) {
			log.error("Error while newFaq : ", e);
			e.getStackTrace();
		}
		prepareFaqList();
		checkListContent();

		info("messages.save.complete");

		return "faqEdit";
	}

	/**
	 * Sets the boolean "removed" to false and makes FAQ visible on
	 * administration page.
	 */
	public void addUserFaqToList() {
		selectedFaq.setRemoved(!addToFaq);
		selectedFaq.setVisible(false);
		try {
			faqDao.updateFaq(selectedFaq);
		} catch (Exception e) {
			log.error("Error while addUserFaqToList : ", e);
			e.printStackTrace();
		}
		newMessage = new Message();

		newMessage.setTopic(selectedFaq.getQuestion());
		newMessage.setContent(selectedFaq.getQuestionAnswer());

		messageBean.setSelectedUsers(new ArrayList<Integer>());
		messageBean.getSelectedUsers().add(
				messageBean.getSelectedInboxMessage().getMessageSender()
						.getUser().getUserId());

		messageBean.replyMessage(newMessage);

		selectedFaq = new Faq();
	}

	/**
	 * Adds the new faq from user.
	 */
	public void addNewFaqFromUser() {
		newFaq.setMessage(new Message());

		messageBean.getNewMessage().setTopic(messageTopic);
		messageBean.addMessageToFaq();
		newFaq.setRemoved(true);
		newFaq.setVisible(false);
		newFaq.setQuestion(messageBean.getNewMessage().getContent());
		newFaq.getMessage().setMessageId(
				messageBean.getNewMessage().getMessageId());

		try {
			faqDao.newFaq(newFaq);
		} catch (Exception e) {
			log.error("Error while newFaqFromUser : ", e);
			e.getStackTrace();
		}
	}

	/**
	 * Deletes the faq.
	 */
	public void deleteFaq() {
		try {
			faqDao.deleteFaq(selectedFaq);
		} catch (Exception e) {
			log.error("Error while deleteFaq: ", e);
			e.getStackTrace();
		}
		prepareFaqList();
		notAvailableAction();
		checkListContent();
	}

	/**
	 * Edits the faq.
	 * 
	 * @return the string
	 */
	public String editFaq() {
		edit = true;
		newFaq = selectedFaq;
		return "faqEdit";
	}

	/**
	 * On row select faq list.
	 * 
	 * @param event
	 *            the event
	 */
	public void onRowSelectFaqList(SelectEvent event) {
		availableAction();
	}

	/**
	 * On row unselect faq list.
	 * 
	 * @param event
	 *            the event
	 */
	public void onRowUnselectFaqList(UnselectEvent event) {
		notAvailableAction();
	}

	/**
	 * Activates if action on selected element is available.
	 */
	public void availableAction() {
		disableShow = false;
		disableEdit = false;
		disableRemove = false;
	}

	/**
	 * Activates if action on selected element is not available.
	 */
	public void notAvailableAction() {
		selectedFaq = new Faq();

		disableShow = true;
		disableEdit = true;
		disableRemove = true;
	}

	public List<Faq> getFaqList() {
		return faqList;
	}

	public void setFaqList(List<Faq> faqList) {
		this.faqList = faqList;
	}

	public Faq getNewFaq() {
		return newFaq;
	}

	public void setNewFaq(Faq newFaq) {
		this.newFaq = newFaq;
	}

	public Faq getSelectedFaq() {
		return selectedFaq;
	}

	public void setSelectedFaq(Faq selectedFaq) {
		this.selectedFaq = selectedFaq;
	}

	public boolean isDisableShow() {
		return disableShow;
	}

	public void setDisableShow(boolean disableShow) {
		this.disableShow = disableShow;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}

	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}

	public Map<String, List<Faq>> getFaqCategoryList() {
		return faqCategoryList;
	}

	public void setFaqCategoryList(Map<String, List<Faq>> faqCategoryList) {
		this.faqCategoryList = faqCategoryList;
	}

	public List<QuestionType> getQuestionType() {

		List<QuestionType> questionType = new ArrayList<QuestionType>();

		for (QuestionType e : QuestionType.values()) {
			log.debug("Question Type name: " + e.name());
			questionType.add(e);
		}
		return questionType;
	}

	public void setQuestionType(List<QuestionType> questionType) {
		this.questionType = questionType;
	}

	public Boolean getAddToFaq() {
		return addToFaq;
	}

	public void setAddToFaq(Boolean addToFaq) {
		this.addToFaq = addToFaq;
	}

	public boolean isSendToOperators() {
		return sendToOperators;
	}

	public void setSendToOperators(boolean sendToOperators) {
		this.sendToOperators = sendToOperators;
	}

	public boolean isFaqNotEdited() {
		return faqNotEdited;
	}

	public void setFaqNotEdited(boolean faqNotEdited) {
		this.faqNotEdited = faqNotEdited;
	}

	public boolean isFaqListEmpty() {
		return faqListEmpty;
	}

	public void setFaqListEmpty(boolean faqListEmpty) {
		this.faqListEmpty = faqListEmpty;
	}

	@SuppressWarnings({ "deprecation" })
	private void info(String message_code) {
		FacesMessages.instance().add(
				FacesMessage.SEVERITY_INFO,
				BundlesUtils.getMessageResourceString("messages", message_code,
						null, FacesContext.getCurrentInstance()
								.getExternalContext().getRequestLocale()));
	}
}