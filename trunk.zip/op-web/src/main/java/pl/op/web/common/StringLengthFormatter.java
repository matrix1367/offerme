package pl.op.web.common;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@FacesConverter(value = "op.StringLengthFormatter")
public class StringLengthFormatter implements Converter {
	
	private Logger log = LoggerFactory.getLogger(StringLengthFormatter.class);

	private static final String MAX_LENGTH = "30";
	
	private String length = null;
	
	@Override
	public Object getAsObject(FacesContext arg0, UIComponent arg1, String txt) {
		log.debug("->>>>>>>>>>>> StringLengthFormatter.getAsObject() " + length);
		
		setLengthParam();
		
		if (length != null && txt != null) {
			int len = Integer.parseInt(length);
			
			if (txt.length() > len) {
				return txt.substring(0, len) + "...";
			}
		}
		
		return txt;
	}

	@Override
	public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) {
		log.debug("->>>>>>>>>>>> StringLengthFormatter.getAsString() " + length);
		
		setLengthParam();
		
		String txt = null;
		
		if (arg2 instanceof String) {
			txt = (String) arg2;
			
		} else {
			txt = arg2.toString();
		}
		
		if (length != null && txt != null) {
			int len = Integer.parseInt(length);
			
			if (txt.length() > len) {
				return txt.substring(0, len) + "...";
			}
		}
		
		return txt;
	}
	
	private void setLengthParam() {
		if (length == null) {
			length = MAX_LENGTH;
		}
	}

	public String getLength() {
		return length;
	}

	public void setLength(String length) {
		this.length = length;
	}
	
}
