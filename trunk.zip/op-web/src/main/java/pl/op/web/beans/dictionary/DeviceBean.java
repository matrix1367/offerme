package pl.op.web.beans.dictionary;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.DeviceDao;
import pl.op.model.device.Device;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class DeviceBean. This class manages the devices in application. Can
 * add/edit/delete data from database table named "tb_device".
 */
@Name("op.deviceBean")
@Scope(ScopeType.SESSION)
public class DeviceBean implements Serializable {

	private static final long serialVersionUID = 2274479344938430635L;

	private Logger log = LoggerFactory.getLogger(DeviceBean.class);

	private List<Device> devicesList;
	private Device newDevice;
	private Device selectedDevice;

	private boolean edit;
	private boolean disableShow = true;
	private boolean disableEdit = true;
	private boolean disableRemove = true;
	private boolean colapseDeviceList = true;

	private DeviceDao deviceDao;

	public DeviceBean() {
		log.info("DictionaryBean constructor");
		initialize();
	}

	/**
	 * Initialize the DeviceBean.
	 */
	private void initialize() {
		notAvailableAction();
		deviceDao = GuiceSingleton.getInstance().getInstance(DeviceDao.class);

		devicesList = new ArrayList<Device>();
	}

	/**
	 * Downloads devices from database and prepares list for display.
	 */
	public void refreshDEviceList() {
		try {
			devicesList = deviceDao.getDevices();
		} catch (Exception e) {
			log.error("error while getting devices: ", e);
		}
	}

	/**
	 * Prepares the data for XHTML template to add new Area.
	 * 
	 * @return the string
	 */
	public String addDevice() {
		edit = false;
		selectedDevice = new Device();
		newDevice = new Device();
		return "devices";
	}

	/**
	 * Cancel add device.
	 * 
	 * @return the string
	 */
	public String cancelAddDevice() {
		notAvailableAction();
		colapseDeviceList = false;
		return "dictionaries";
	}

	/**
	 * Saves device defined in XHTML template.
	 * 
	 * @return the string
	 */
	public String saveDevice() {
		try {
			if (edit) {
				deviceDao.updateDevice(selectedDevice);
			} else {
				deviceDao.saveDevice(newDevice);
			}
		} catch (Exception e) {
			log.error("Error while saveDevice: ", e);
		}
		refreshDEviceList();
		colapseDeviceList = false;
		return "dictionaries";
	}

	/**
	 * Deletes device form database.
	 * 
	 * @return the string
	 */
	public String deleteDevice() {
		try {
			deviceDao.deleteDevice(selectedDevice);
		} catch (Exception e) {
			log.error("Error while deleteDevice: ", e);
		}
		refreshDEviceList();
		notAvailableAction();
		colapseDeviceList = false;
		return "dictionaries";
	}

	/**
	 * Edits the device selected from XHTML template.
	 * 
	 * @return the string
	 */
	public String editDevice() {
		edit = true;
		newDevice = selectedDevice;
		return "devices";
	}

	/**
	 * On row select dictionaries list.
	 * 
	 * @param event
	 *            the event
	 */
	public void onRowSelectDictionariesList(SelectEvent event) {
		availableAction();
	}

	/**
	 * On row unselect dictionaries list.
	 * 
	 * @param event
	 *            the event
	 */
	public void onRowUnselectDictionariesList(UnselectEvent event) {
		notAvailableAction();
	}

	/**
	 * Activates if action on selected element is available.
	 */
	public void availableAction() {
		disableShow = false;
		disableEdit = false;
		disableRemove = false;
	}

	/**
	 * Activates if action on selected element is not available.
	 */
	public void notAvailableAction() {
		selectedDevice = new Device();

		disableShow = true;
		disableEdit = true;
		disableRemove = true;
	}

	public Device getNewDevice() {
		return newDevice;
	}

	public void setNewDevice(Device newDevice) {
		this.newDevice = newDevice;
	}

	public List<Device> getDevicesList() {
		return devicesList;
	}

	public void setDevicesList(List<Device> devicesList) {
		this.devicesList = devicesList;
	}

	public Device getSelectedDevice() {
		return selectedDevice;
	}

	public void setSelectedDevice(Device selectedDevice) {
		this.selectedDevice = selectedDevice;
	}

	public boolean isDisableShow() {
		return disableShow;
	}

	public void setDisableShow(boolean disableShow) {
		this.disableShow = disableShow;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public boolean isDisableRemove() {
		return disableRemove;
	}

	public void setDisableRemove(boolean disableRemove) {
		this.disableRemove = disableRemove;
	}

	public boolean isColapseDeviceList() {
		return colapseDeviceList;
	}

	public void setColapseDeviceList(boolean colapseDeviceList) {
		this.colapseDeviceList = colapseDeviceList;
	}
}