package pl.op.web.common;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.primefaces.component.picklist.PickList;
import org.primefaces.model.DualListModel;

import pl.op.model.user.UserApp;

@FacesConverter("UserConverter")
public class UserConverter implements Converter {

	private Log log = LogFactory.getLog(UserConverter.class);

	public UserApp getAsObject(FacesContext facesContext, UIComponent component,
			String submittedValue) {
		if (component instanceof PickList) {
			DualListModel<UserApp> dualList = (DualListModel) ((PickList) component)
					.getValue();

			for (Object o : dualList.getSource()) {
				String id = "" + ((UserApp) o).getUserId();
				if (submittedValue.equals(id)) {
					return (UserApp) o;
				}
			}
			
			for (Object o : dualList.getTarget()) {
				String id = "" + ((UserApp) o).getUserId();
				if (submittedValue.equals(id)) {
					return (UserApp) o;
				}
			}
		}

		return null;
	}

	public String getAsString(FacesContext facesContext, UIComponent component,
			Object value) {
		return (value).toString();
	}

}
