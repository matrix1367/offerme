package pl.op.web.beans.user;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;

import pl.op.dao.UserDao;
import pl.op.model.user.UserApp;
import pl.op.web.beans.AdminBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.listener.GuiceSingleton;

@Name("op.editDataBean")
@Scope(ScopeType.SESSION)
public class EditDataBean {

	private UserApp userApp;
	private UserApp userAppLog;
	private String nameValue;
	private String phoneValue;

	private UserDao dao;
	private FacesContext facesContext;
	private ExternalContext ectx;
	private Boolean renderedFieldLocale;

	private Logger log = LoggerFactory.getLogger(EditDataBean.class);

	public EditDataBean() {
		log.info("EditDataBean constructor");
		dao = GuiceSingleton.getInstance().getInstance(UserDao.class);
		initialize();
	}

	private void initialize() {

		facesContext = FacesContext.getCurrentInstance();
		ectx = facesContext.getExternalContext();

		renderedFieldLocale = true;

	}

	public String startEditAction() {

		initialize();

		// get current user login
		FacesContext ctx = FacesContext.getCurrentInstance();
		AdminBean adminBean = (AdminBean) ctx.getApplication().getELResolver()
				.getValue(ctx.getELContext(), null, "op.adminBean");

		userAppLog = adminBean.getUserLog();

		try {
			userApp = dao.getUserByLogin(userAppLog.getLogin());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			String message = BundlesUtils.getMessageResourceString("messages",
					"user_data_error", null, ectx.getRequestLocale());
			FacesMessages.instance().add(message);
		}

		return "view_user";
	}

	public UserApp getUserApp() {
		return userApp;
	}

	public void setUserApp(UserApp userApp) {
		this.userApp = userApp;
	}

	public String getNameValue() {
		return nameValue;
	}

	public void setNameValue(String nameValue) {
		this.nameValue = nameValue;
	}

	public String getPhoneValue() {
		return phoneValue;
	}

	public void setPhoneValue(String phoneValue) {
		this.phoneValue = phoneValue;
	}

	public Boolean getRenderedFieldLocale() {
		return renderedFieldLocale;
	}

	public void setRenderedFieldLocale(Boolean renderedFieldLocale) {
		this.renderedFieldLocale = renderedFieldLocale;
	}


	public String editUserAction() {
		String phone = BundlesUtils.getMessageResourceString("messages",
				"prefix_phone", null, ectx.getRequestLocale());

		if (userApp.getPhone() != null) {
			if (userApp.getPhone().trim().length() > 0) {
				phone = userApp.getPhone();
			}
		}

		userApp.setPhone(phone);

		return "edit_user";
	}

	public String saveUserAction() {

		if (userApp.getPhone() != null) {
			if (userApp.getPhone().trim().length() <= 3) {
				userApp.setPhone(null);
			}
		}
		
		try {

			if (userApp.getPhoneActivated() == null) {
				userApp.setPhoneActivated(false);
			}

			dao.updateUser(userApp);
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				String message = BundlesUtils.getMessageResourceString(
				"messages", "update_error", null, ectx.getRequestLocale());
				FacesMessages.instance().add(FacesMessage.SEVERITY_ERROR, message);
				return "";
			}
		
		
		String message = BundlesUtils.getMessageResourceString("messages",
		"update_success", null, ectx.getRequestLocale());
		FacesMessages.instance().add(FacesMessage.SEVERITY_INFO, message);
		
		startEditAction();
		return "view_user";
	}


	public String updateUserAction() {

		phoneValue = BundlesUtils.getMessageResourceString("messages", "empty",
		null, ectx.getRequestLocale());

		nameValue = "";

		nameValue = userApp.getFirstName() + " " + userApp.getSurname();

		if (userApp.getPhone() != null) {
			if (userApp.getPhone().trim().length() > 3) {
				phoneValue = userApp.getPhone();
			}
		}


		return "edit_confirm";
	}
	
	public String cancelUpdateUserAction() {
		startEditAction();
		return "view_user";
	}

	public String backToEditAction() {
		return "edit_user";
	}
}