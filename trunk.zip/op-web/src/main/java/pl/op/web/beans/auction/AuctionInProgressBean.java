package pl.op.web.beans.auction;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Transient;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pl.op.dao.AgreementDao;
import pl.op.dao.InvoiceDao;
import pl.op.dao.PPEDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionFilter;
import pl.op.model.auction.AuctionOffer;
import pl.op.model.auction.AuctionOfferDiffrent;
import pl.op.model.auction.AuctionStatus;
import pl.op.model.auction.PriceComponentValue;
import pl.op.model.auction.ZoneType;
import pl.op.model.cloud.Cloud;
import pl.op.model.contract.Agreement;
import pl.op.model.contract.Invoice;
import pl.op.model.contract.InvoicePriceComponentValue;
import pl.op.model.contract.PPE;
import pl.op.model.contract.PPEStatus;
import pl.op.model.dict.Area;
import pl.op.model.dict.City;
import pl.op.model.dict.Tariff;
import pl.op.model.stereotype.Stereotype;
import pl.op.model.user.UserApp;
import pl.op.util.AuctionUtil;
import pl.op.util.MessageUtil;
import pl.op.util.PpeUtil;
import pl.op.util.UserUtil;
import pl.op.web.beans.bill.BillInvoiceBean;
import pl.op.web.beans.dictionary.DictionaryBean;
import pl.op.web.common.ComponentLookup;
import pl.op.web.comparator.AuctionByOfferPriceComparator;
import pl.op.web.comparator.AuctionByScoreComparator;
import pl.op.web.listener.GuiceSingleton;

/**
 * The Class AuctionInProgressBean.
 */
@Name("op.auctionInProgressBean")
@Scope(ScopeType.SESSION)
public class AuctionInProgressBean {

    private Logger log = LoggerFactory.getLogger(AuctionInProgressBean.class);
    public static final long HOUR = 3600 * 1000;

    private List<Auction> auctions;
    private Auction selectedAuction;
    private UserApp userApp;
    private Invoice lastInvoiceForPpe;
    private boolean haveActualInvoiceForPpe;
    private Agreement lastAgreementForPpe;
    private Date canJoinToNextAuctionAt;

    private AuctionBean auctionBean;

    private PPEDao ppeDao;
    private InvoiceDao invoiceDao;
    private AgreementDao agreementDao;

    // Filters
    private AuctionFilter auctionFilter;
    private List<PPE> userPpes;

    private Integer userPpeId;
    private PPE selectedPpe;

    private boolean buttonsDisabled = true;
    private boolean galleryView = true;

    private Double actualNettoYearPrice;
    private Double actualConstantValue;

    private Double propositionNettoYearPrice;
    private Double propositionConstantValue;

    /**
     * Instantiates a new auction in progress bean.
     */
    public AuctionInProgressBean() {
        initializeDao();
        initializeVars();
    }

    /**
     * Initialize dao.
     */
    private void initializeDao() {
        log.info("initializeDao");

        ppeDao = GuiceSingleton.getInstance().getInstance(PPEDao.class);
        invoiceDao = GuiceSingleton.getInstance().getInstance(InvoiceDao.class);
        agreementDao = GuiceSingleton.getInstance().getInstance(AgreementDao.class);
    }

    /**
     * Initialize vars.
     */
    private void initializeVars() {
        log.info("initializeVars");
        auctionBean = ComponentLookup.lookupComponent("op.auctionBean");
        userApp = UserUtil.getLoggedUserInstance();

        userPpes = new ArrayList<PPE>();
        userPpeId = null;

        propositionNettoYearPrice = 0.0;

        initializeFilter();
    }

    /**
     * Initialize on load.
     */
    public void initializeOnLoad() {
        log.info("initializeOnLoad");

        try {
            userPpes = ppeDao.getPPEsByUser(userApp);
            setDefaultUserPpeId();

            prepareGlobalMessage();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Checks if is initialized.
     *
     * @return true, if is initialized
     */
    private boolean isInitialized() {
        if (null == userPpes) {
            return false;
        }
        if (userPpes.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Sets the default user ppe id.
     */
    private void setDefaultUserPpeId() {
        if (!userPpes.isEmpty()) {
            userPpeId = userPpes.get(0).getPpeId();
            log.info("ppeId: " + userPpeId);

            selectedPpe = userPpes.get(0);
            updateLastAgreementForPpe(userPpeId);
            updateLastInvoiceForPpe(userPpeId);

            log.info("find user ppes => " + userPpes.size());
        }
    }

    /**
     * Initialize filter.
     */
    public void initializeFilter() {
        clearFilter();
        auctionFilter.getAuction().getCloud().addUser(userApp);
        auctionFilter.getAuction().getCloud().setStereotype(userApp.getSector().getStereotype());
        auctionFilter.setAgreementDurationMonth("const-12");
        auctionFilter.setOrderBy("price-ASC");

        selectedAuction = new Auction();
    }

    /**
     * Clear selected auction.
     */
    public void clearSelectedAuction() {
        selectedAuction = new Auction();
        selectedAuction.setAuctionOffers(new ArrayList<AuctionOffer>());

        Cloud cloud = new Cloud();
        cloud.setTariff(new Tariff());
        cloud.setStereotype(new Stereotype());
        cloud.setAreas(new ArrayList<Area>());
        cloud.setCities(new ArrayList<City>());
        selectedAuction.setCloud(cloud);
    }

    /**
     * Clear filter.
     */
    public void clearFilter() {
        clearSelectedAuction();

        auctionFilter = new AuctionFilter();
        auctionFilter.setAuction(selectedAuction);
        auctionFilter.setAuctionAttribute(null);
        auctionFilter.setEndTime(null);
        auctionFilter.setSeller(false);
    }

    /**
     * Have more than one object.
     *
     * @return the boolean
     */
    public Boolean haveMoreThanOneObject() {
        log.info("haveMoreThanOneObject");

        if (!userPpes.isEmpty()) {
            if (userPpes.size() > 1) {
                return true;
            }
        }

        return false;
    }

    /**
     * Update auction location.
     *
     * @param ppeId the ppe id
     */
    public void updateAuctionLocation(Integer ppeId) {
        log.info("AuctionInProgressBean:update auctions list");

        if (ppeId > 0) {
            userPpeId = ppeId;
        }

        if (userPpeId != null) {
            if (userPpeId > 0) {
                for (PPE ppe : userPpes) {
                    if (ppe.getPpeId().intValue() == userPpeId.intValue()) {
                        selectedPpe = ppe;
                        if (null == ppe.getTariff()) {
                            try {
                                ppe.setTariff(ppeDao.getActualTariff(ppe));
                            } catch (Exception e) {
                                log.error("Problem while update auction location - get actual tariff: ", e);
                            }
                        }

                        auctionFilter.updateLocationDataInCloud(ppe, true, true);

                        if (!updateLastInvoiceForPpe(userPpeId)) {
                            MessageUtil.displayMessageInfo("auction.message.invoiceMissing");
                        }
                        updateLastAgreementForPpe(userPpeId);

                        searchAuctions();
                    }
                }

            }
        }
    }

    /**
     * Update agreement param.
     *
     * @param param the param
     */
    public void updateAgreementParam(String param) {
        log.info("updateAgreementParam");

        auctionFilter.setAgreementDurationMonth(param);

        searchAuctions();
    }

    /**
     * Update order.
     *
     * @param order the order
     */
    public void updateOrder(String order) {
        log.info("updateOrder");
        auctionFilter.setOrderBy(order);

        searchAuctions();
    }

    /**
     * Search auctions.
     */
    public void searchAuctions() {
        log.info("Searching auctions...");

        auctionFilter.getAuction().setStatus(AuctionStatus.INPROGRESS);

        auctions = auctionBean.searchAuctionsForUser(auctionFilter);
        if (auctions != null) {
            if (!auctions.isEmpty()) {
                for (Auction auction : auctions) {
                    if (lastInvoiceForPpe != null) {
                        auction.setActualUserInvoice(lastInvoiceForPpe);
                    }
                }
                log.info("find " + auctions.size() + " auctions");
                sortAuctions();
            } else {
                log.info("auctions not found, auctions is empty.");
            }
        } else {
            log.info("auctions not found, auctions error.");
        }
    }

    /**
     * Sort auctions.
     */
    public void sortAuctions() {
        if (auctionFilter.getOrderColumn().equals("price")) {
            log.info("sort auction by price - " + auctionFilter.getOrderType());
            Collections.sort(auctions, new AuctionByOfferPriceComparator(auctionFilter.getOrderType()));
        } else {
            log.info("sort auction by score - " + auctionFilter.getOrderType());
            Collections.sort(auctions, new AuctionByScoreComparator(auctionFilter.getOrderType()));
        }
    }

    /**
     * Gets the auctions.
     *
     * @return the auctions
     */
    public List<Auction> getAuctions() {
        return auctions;
    }

    /**
     * Sets the auctions.
     *
     * @param auctions the new auctions
     */
    public void setAuctions(List<Auction> auctions) {
        this.auctions = auctions;
    }

    /**
     * Gets the auction filter.
     *
     * @return the auction filter
     */
    public AuctionFilter getAuctionFilter() {
        return auctionFilter;
    }

    /**
     * Sets the auction filter.
     *
     * @param auctionFilter the new auction filter
     */
    public void setAuctionFilter(AuctionFilter auctionFilter) {
        this.auctionFilter = auctionFilter;
    }

    /**
     * Checks if is buttons disabled.
     *
     * @return true, if is buttons disabled
     */
    public boolean isButtonsDisabled() {
        return buttonsDisabled;
    }

    /**
     * Sets the buttons disabled.
     *
     * @param buttonsDisabled the new buttons disabled
     */
    public void setButtonsDisabled(boolean buttonsDisabled) {
        this.buttonsDisabled = buttonsDisabled;
    }

    /**
     * Gets the user app.
     *
     * @return the user app
     */
    public UserApp getUserApp() {
        return userApp;
    }

    /**
     * Sets the user app.
     *
     * @param userApp the new user app
     */
    public void setUserApp(UserApp userApp) {
        this.userApp = userApp;
    }

    /**
     * Gets the user ppe id.
     *
     * @return the user ppe id
     */
    public Integer getUserPpeId() {
        if (!isInitialized()) {
            initializeOnLoad();
        }
        return userPpeId;
    }

    /**
     * Sets the user ppe id.
     *
     * @param userPpeId the new user ppe id
     */
    public void setUserPpeId(Integer userPpeId) {
        this.userPpeId = userPpeId;
    }

    /**
     * Gets the user ppes.
     *
     * @return the user ppes
     */
    public List<PPE> getUserPpes() {
        if (!isInitialized()) {
            initializeOnLoad();
        }
        return userPpes;
    }

    /**
     * Sets the user ppes.
     *
     * @param userPpes the new user ppes
     */
    public void setUserPpes(List<PPE> userPpes) {
        this.userPpes = userPpes;
    }

    /**
     * Gets the last invoice for ppe.
     *
     * @return the last invoice for ppe
     */
    @Transient
    public Invoice getLastInvoiceForPpe() {
        return lastInvoiceForPpe;
    }

    /**
     * Sets the last invoice for ppe.
     *
     * @param lastInvoiceForPpe the new last invoice for ppe
     */
    public void setLastInvoiceForPpe(Invoice lastInvoiceForPpe) {
        this.lastInvoiceForPpe = lastInvoiceForPpe;
    }

    /**
     * Update last invoice for ppe.
     *
     * @param id the id
     */
    public boolean updateLastInvoiceForPpe(Integer id) {
        log.info("updateLastInvoiceForPpe");
        try {
            log.info("update lastInvoceByPpeId to ppe #" + id);
            lastInvoiceForPpe = invoiceDao.getLastInvoiceByPpeId(id);

            if (lastInvoiceForPpe != null) {
                updateHaveActualInvoiceForPpe(true);
                selectedPpe.updateActualInvoice(lastInvoiceForPpe);
                log.info("lastPPEInvoice #" + lastInvoiceForPpe.getInvoiceId());
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            log.error("Problem while update last invoice for ppe: ", e);
            return false;
        }
    }

    /**
     * Gets the last agreement for ppe.
     *
     * @return the last agreement for ppe
     */
    public Agreement getLastAgreementForPpe() {
        return lastAgreementForPpe;
    }

    /**
     * Sets the last agreement for ppe.
     *
     * @param lastAgreementForPpe the new last agreement for ppe
     */
    public void setLastAgreementForPpe(Agreement lastAgreementForPpe) {
        this.lastAgreementForPpe = lastAgreementForPpe;
    }

    /**
     * Update last agreement for ppe.
     *
     * @param id the id
     */
    public void updateLastAgreementForPpe(Integer id) {
        log.info("updateLastAgreementForPpe");
        try {
            log.info("update lastAgreementByPpeId to ppe #" + id);
            lastAgreementForPpe = agreementDao.getLastAgreementByPpeId(id);

            if (lastAgreementForPpe != null) {
                selectedPpe.updateActualAgreement(lastAgreementForPpe);
                log.info("lastAgreementByPpeId #" + lastAgreementForPpe.getAgreementId());
            }
        } catch (Exception e) {
            log.error("Problem while update last agreement for ppe: ", e);
        }
    }

    /**
     * Gets the can join to next auction at.
     *
     * @return the can join to next auction at
     */
    public Date getCanJoinToNextAuctionAt() {
        return canJoinToNextAuctionAt;
    }

    /**
     * Sets the can join to next auction at.
     *
     * @param canJoinToNextAuctionAt the new can join to next auction at
     */
    public void setCanJoinToNextAuctionAt(Date canJoinToNextAuctionAt) {
        this.canJoinToNextAuctionAt = canJoinToNextAuctionAt;
    }

    /**
     * Can join to auction.
     *
     * @return true, if successful
     */
    public boolean canJoinToAuction() {
        return canJoinToAuction(selectedAuction);
    }

    /**
     * Can join to auction.
     *
     * @param auction the auction
     * @return true, if successful
     */
    public boolean canJoinToAuction(Auction auction) {
        try {
            if (null == selectedPpe) {
                return false;
            }
            if (null == auction) {
                return false;
            }
            if (null == auction.getAuctionId()) {
                return false;
            }

            AuctionUtil auctionUtil = new AuctionUtil(userApp, auction, selectedPpe);
            return auctionUtil.canJoinToAuction();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Assign user to auction.
     *
     * @return the string
     */
    public String assignUserToAuction() {
        if (null != selectedAuction) {
            return assignUserToAuction(selectedAuction);
        }

        return "";
    }

    /**
     * Assign user to auction.
     *
     * @param auction the auction
     * @return the string
     */
    public String assignUserToAuction(Auction auction) {
        log.info("assign user #" + userApp.getUserId() + " to auction #" + auction.getAuctionId());

        Date now = new Date();
        if (auction.getFinishDate().getTime() > now.getTime()) {
            try {
                auctionBean.assignUserToAuction(auction, userApp, selectedPpe);
                PpeUtil.setStatusForPPE(selectedPpe, PPEStatus.JOINED);

                AuctionJoinedBean auctionJoinedBean = ComponentLookup.lookupComponent("op.auctionJoinedBean");
                auctionJoinedBean.updateAuctionLocation(selectedPpe.getPpeId());

                MessageUtil.displayMessageInfo("user.join.to.auction");
            } catch (Exception e) {
                log.error("Problem while change ppe Status after join to auction: ", e);
            }
        } else {
            log.info("auction is ended");
        }

        return "userAuctions";
    }

    /**
     * Gets the selected auction.
     *
     * @return the selected auction
     */
    public Auction getSelectedAuction() {
        return selectedAuction;
    }

    /**
     * Sets the selected auction.
     *
     * @param selectedAuction the new selected auction
     */
    public void setSelectedAuction(Auction selectedAuction) {
        this.selectedAuction = selectedAuction;
    }

    /**
     * Update selected auction.
     *
     * @param selectedAuction the selected auction
     */
    public void updateSelectedAuction(Auction selectedAuction) {
        log.info("update selected auction #" + selectedAuction.getAuctionId());
        this.selectedAuction = selectedAuction;

        updateHaveActualInvoiceForPpe(true);
    }

    /**
     * On auction select.
     *
     * @param event the event
     */
    public void onAuctionSelect(SelectEvent event) {
        buttonsDisabled = false;
    }

    /**
     * Checks if is gallery view.
     *
     * @return true, if is gallery view
     */
    public boolean isGalleryView() {
        return galleryView;
    }

    /**
     * Sets the gallery view.
     *
     * @param galleryView the new gallery view
     */
    public void setGalleryView(boolean galleryView) {
        this.galleryView = galleryView;
    }

    /**
     * Change gallery view.
     */
    public void changeGalleryView() {
        log.info("changeGalleryView");
        clearSelectedAuction();

        buttonsDisabled = true;
        if (galleryView == true) {
            galleryView = false;
        } else {
            galleryView = true;
        }
    }

    /**
     * Checks if is have actual invoice for ppe.
     *
     * @return true, if is have actual invoice for ppe
     */
    public boolean isHaveActualInvoiceForPpe() {
        return haveActualInvoiceForPpe;
    }

    /**
     * Sets the have actual invoice for ppe.
     *
     * @param haveActualInvoiceForPpe the new have actual invoice for ppe
     */
    public void setHaveActualInvoiceForPpe(boolean haveActualInvoiceForPpe) {
        this.haveActualInvoiceForPpe = haveActualInvoiceForPpe;
    }

    /**
     * Update have actual invoice for ppe.
     *
     * @param compare the compare
     */
    public void updateHaveActualInvoiceForPpe(Boolean compare) {
        log.info("updateHaveActualInvoiceForPpe");
        if (compare == true) {
            haveActualInvoiceForPpe = false;

            if (null != lastInvoiceForPpe) {
                haveActualInvoiceForPpe = isInvoiceActual();
            } else {
                log.info("lastInvoiceForPpe is null");
            }
        } else {
            haveActualInvoiceForPpe = true;
        }
    }

    /**
     * Checks if is invoice actual.
     *
     * @return true, if is invoice actual
     */
    private boolean isInvoiceActual() {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DAY_OF_MONTH, -(getInvoiceDuration()));
        cal.add(Calendar.DAY_OF_MONTH, -DictionaryBean.ACTUAL_INVOICE_BUFFOR_DAYS);

        if (lastInvoiceForPpe.getDateTo().compareTo(cal.getTime()) < 0) {
            return false;
        }

        return true;
    }

    /**
     * Gets the invoice duration.
     *
     * @return the invoice duration
     */
    private int getInvoiceDuration() {
        return (int) ((lastInvoiceForPpe.getDateTo().getTime() - lastInvoiceForPpe.getDateFrom().getTime()) / 1000 / 3600 / 24);
    }

    /**
     * Prepare global message.
     */
    public void prepareGlobalMessage() {
        log.info("repareGlobalMessage");

        if (null == selectedPpe) {
            return;
        }

        AuctionUtil auctionUtil = new AuctionUtil(userApp, selectedPpe);
        auctionUtil.prepareGlobalMessage();
    }

    /**
     * Gets the actual constant value.
     *
     * @return the actual constant value
     */
    public Double getActualConstantValue() {
        return actualConstantValue;
    }

    /**
     * Sets the actual constant value.
     *
     * @param actualConstantValue the new actual constant value
     */
    public void setActualConstantValue(Double actualConstantValue) {
        this.actualConstantValue = actualConstantValue;
    }

    /**
     * Gets the proposition constant value.
     *
     * @return the proposition constant value
     */
    public Double getPropositionConstantValue() {
        return propositionConstantValue;
    }

    /**
     * Sets the proposition constant value.
     *
     * @param propositionConstantValue the new proposition constant value
     */
    public void setPropositionConstantValue(Double propositionConstantValue) {
        this.propositionConstantValue = propositionConstantValue;
    }

    /**
     * Sets the actual netto year price.
     *
     * @param actualNettoYearPrice the new actual netto year price
     */
    public void setActualNettoYearPrice(Double actualNettoYearPrice) {
        this.actualNettoYearPrice = actualNettoYearPrice;
    }

    /**
     * Sets the proposition netto year price.
     *
     * @param propositionNettoYearPrice the new proposition netto year price
     */
    public void setPropositionNettoYearPrice(Double propositionNettoYearPrice) {
        this.propositionNettoYearPrice = propositionNettoYearPrice;
    }

    /**
     * Gets the selected ppe value.
     *
     * @return the selected ppe value
     */
    public Double getSelectedPpeValue() {
        return (null != selectedPpe) ? selectedPpe.getValue() * 1000 : 0.0;
    }

    /**
     * Gets the economy compare.
     *
     * @return the economy compare
     */
    public List<AuctionOfferDiffrent> getEconomyCompare() {
        List<AuctionOfferDiffrent> result = new ArrayList<AuctionOfferDiffrent>();

        try {
            if (!canGenerateEconomy()) {
                return result;
            }

            HashMap<Integer, InvoicePriceComponentValue> invoicePriceComponentValuesMap = getInvoiceNotConstantPriceComponentValuesMap();
            log.info("invoicePriceComponentValuesMap: " + invoicePriceComponentValuesMap);

            AuctionOffer auctionOffer = selectedAuction.getActualAuctionOffer();
            if (null != auctionOffer && null != auctionOffer.getAuctionOfferId()) {
                for (PriceComponentValue priceComponentValue : auctionOffer.getPriceComponentValues()) {
                    if (!priceComponentValue.getPriceComponent().isConstant()) {
                        if (invoicePriceComponentValuesMap.containsKey(priceComponentValue.getPriceComponent()
                                .getPriceComponentId())) {
                            Double actualPrice = invoicePriceComponentValuesMap.get(
                                    priceComponentValue.getPriceComponent().getPriceComponentId()).getValue() / 1000;
                            AuctionOfferDiffrent auctionOfferDiffrent = new AuctionOfferDiffrent(actualPrice,
                                    priceComponentValue.getValue().doubleValue());

                            result.add(auctionOfferDiffrent);
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error("Problem while getEconomyCompare: ", e);
        }

        return result;
    }

    private boolean canGenerateEconomy() {
        if (null == selectedAuction) {
            return false;
        }
        if (null == selectedAuction.getAuctionId()) {
            return false;
        }

        return true;
    }

    /**
     * Gets the invoice not constant price component values map.
     *
     * @return the invoice not constant price component values map
     */
    public HashMap<Integer, InvoicePriceComponentValue> getInvoiceNotConstantPriceComponentValuesMap() throws Exception {
        HashMap<Integer, InvoicePriceComponentValue> result = new HashMap<Integer, InvoicePriceComponentValue>();

        if (null == selectedPpe) {
            return result;
        }

        Invoice ppeInvoice = selectedPpe.getActualInvoice();
        if (null != ppeInvoice) {
            for (InvoicePriceComponentValue priceComponentValue : ppeInvoice.getInvoicePriceComponentValue()) {
                if (!priceComponentValue.getPriceComponent().isConstant()) {
                    result.put(priceComponentValue.getPriceComponent().getPriceComponentId(), priceComponentValue);
                }
            }
        } else {
            log.info("null invoice");
        }

        return result;
    }

    /**
     * Gets the actual netto year price.
     *
     * @return the actual netto year price
     */
    public Double getActualNettoYearPrice() {
        if (null == selectedPpe) {
            return 0.0;
        }
        Invoice ppeInvoice = selectedPpe.getActualInvoice();
        actualConstantValue = null;

        PpeUtil util = GuiceSingleton.getInstance().getInstance(PpeUtil.class);

        Map<ZoneType, Double> tmpMap = util.prepareYearVolumeMapsForPPE(selectedPpe);
        Map<ZoneType, Double> map = new HashMap<ZoneType, Double>();
        for (Map.Entry<ZoneType, Double> entry : tmpMap.entrySet()) {
            ZoneType key = entry.getKey();
            Double value = entry.getValue();
            Double old_value = 0.0;
            if (map.containsKey(key)) {
                old_value = map.get(key);
            }
            map.put(key, old_value + value);
        }

        try {
            Double notConstantComponentValue = 0.0;
            //przelicz ile możesz zaoszczędzić    
            if (null != ppeInvoice) {
                //long invoiceDurationDays = ((ppeInvoice.getDateTo().getTime() - ppeInvoice.getDateFrom().getTime()) / 1000 / 3600 / 24);
                //log.info("invoiceDurationDays: " + invoiceDurationDays);
                for (InvoicePriceComponentValue priceComponentValue : ppeInvoice.getInvoicePriceComponentValue()) {
                    if (!priceComponentValue.getPriceComponent().isConstant()) {
                        Double value = 1.0;

                    
                        if (priceComponentValue.getPriceComponent() != null) {
                            if (priceComponentValue.getPriceComponent().getZoneType() != null) {
                                if (map.containsKey(priceComponentValue.getPriceComponent().getZoneType())) {
                                    value = map.get(priceComponentValue.getPriceComponent().getZoneType());

                                } else {
                                   // log.info("Klucz nie istnieje " + priceComponentValue.getPriceComponent().getZoneType().name());
                                }
                            } else {
                                //log.info("priceComponentValue.getPriceComponent().getZoneType() != null");
                            }
                        } else {
                            //log.info("priceComponentValue.getPriceComponent() != null");
                        }
                       
                            notConstantComponentValue += priceComponentValue.getValue() * value;
                        
                    } else {
                        if (priceComponentValue.getValue() > 0) {
                            actualConstantValue = priceComponentValue.getValue() * 12;
                        }
                    }
                }
            }

            if (null != actualConstantValue) {
                actualConstantValue = actualConstantValue * 1.23;
            }

            actualNettoYearPrice = notConstantComponentValue / 1000;
           // actualNettoYearPrice = notConstantComponentValue * (selectedPpe.getValue() * 1000);
            return actualNettoYearPrice;
        } catch (Exception e) {
            log.error("Problem while calculate ActualNettoYearPrice: ", e);
            return 0.0;
        }
    }

    /**
     * Gets the actual brutto year price.
     *
     * @return the actual brutto year price
     */
    public Double getActualBruttoYearPrice() {
        return actualNettoYearPrice * 1.23;
    }

    /**
     * Gets the actual brutto year price whith constant.
     *
     * @return the actual brutto year price whith constant
     */
    public Double getActualBruttoYearPriceWhithConstant() {
        return getActualBruttoYearPrice() + actualConstantValue;
    }

    /**
     * Gets the proposition netto year price.
     *
     * @return the proposition netto year price
     */
    //przelicz ile możesz zaoszczędzić
    public Double getPropositionNettoYearPrice() {
        log.info("getPropositionNettoYearPrice");
        if(null != selectedAuction) {
            log.info("getPropositionNettoYearPrice:null != selectedAuction " + selectedAuction.getAuctionId());   
            
        }
        if (!hasAuctionOffer()) {
            log.info("getPropositionNettoYearPrice:hasAuctionOffer");
            propositionNettoYearPrice = 0.0;
            return 0.0;
        }
        log.info("getPropositionNettoYearPrice2");
        AuctionOffer auctionOffer = selectedAuction.getActualAuctionOffer();
        propositionConstantValue = null;

        PpeUtil util = GuiceSingleton.getInstance().getInstance(PpeUtil.class);

        Map<ZoneType, Double> tmpMap = util.prepareYearVolumeMapsForPPE(selectedPpe);
        Map<ZoneType, Double> map = new HashMap<ZoneType, Double>();
        for (Map.Entry<ZoneType, Double> entry : tmpMap.entrySet()) {
            ZoneType key = entry.getKey();
            Double value = entry.getValue();
            Double old_value = 0.0;
            if (map.containsKey(key)) {
                old_value = map.get(key);
            }
            map.put(key, old_value + value);
        }
        log.info("getPropositionNettoYearPrice3");
        try {
            Double notConstantComponentValue = 0.0;

            if (null != auctionOffer) {
                log.info("auctionOffer is not null");
                for (PriceComponentValue priceComponentValue : auctionOffer.getPriceComponentValues()) {
                    if (!priceComponentValue.getPriceComponent().isConstant()) {
                        Double value = 1.0;

                        // notConstantComponentValue += priceComponentValue.getValue();
                        if (priceComponentValue.getPriceComponent() != null) {
                            if (priceComponentValue.getPriceComponent().getZoneType() != null) {
                                if (map.containsKey(priceComponentValue.getPriceComponent().getZoneType())) {
                                    value = map.get(priceComponentValue.getPriceComponent().getZoneType());

                                } else {
                                    log.info("Klucz nie istnieje " + priceComponentValue.getPriceComponent().getZoneType().name());
                                }
                            } else {
                                log.info("priceComponentValue.getPriceComponent().getZoneType() != null");
                            }
                        } else {
                            log.info("priceComponentValue.getPriceComponent() != null");
                        }
                       
                        notConstantComponentValue += priceComponentValue.getValue() * value;
                       
                    } else {
                        if (priceComponentValue.getValue() > 0) {
                            propositionConstantValue = priceComponentValue.getValue() * 12;
                        }
                    }
                }
            }

            if (null != propositionConstantValue) {
                propositionConstantValue = propositionConstantValue * 1.23;
            }
              //  propositionNettoYearPrice *= 1000;
            //propositionNettoYearPrice = notConstantComponentValue * (selectedPpe.getValue() * 1000);

            propositionNettoYearPrice = notConstantComponentValue;

            return propositionNettoYearPrice;
        } catch (Exception e) {
            log.error("Problem while calculate ActualNettoYearPrice: ", e);
            return 0.0;
        }
    }

    /**
     * Checks for auction offer.
     *
     * @return true, if successful
     */
    private boolean hasAuctionOffer() {
        if (null == selectedAuction) {
            log.info("null == selectedAuction");
            return false;
        }
        if (null == selectedAuction.getAuctionOffers()) {
            log.info("null == selectedAuction.getAuctionOffers()");
            return false;
        }

        return true;
    }

    /**
     * Gets the proposition brutto year price.
     *
     * @return the proposition brutto year price
     */
    public Double getPropositionBruttoYearPrice() {
        return propositionNettoYearPrice * 1.23;
    }

    /**
     * Gets the proposition brutto year price whith constant.
     *
     * @return the proposition brutto year price whith constant
     */
    public Double getPropositionBruttoYearPriceWhithConstant() {
        return getPropositionBruttoYearPrice() + propositionConstantValue;
    }

    /**
     * Go to bills.
     *
     * @return the string
     */
    public String goToBills() {
        BillInvoiceBean billinvoiceBean = ComponentLookup.lookupComponent("op.billInvoiceBean");
        if (null != selectedPpe) {
            log.info("newPpeId: " + selectedPpe.getPpeId());
            billinvoiceBean.invoiceAddAction(selectedPpe);
        } else {
            billinvoiceBean.invoiceAddAction();
        }
        return "bills";
    }
}
