package pl.op.web.lazy;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

import pl.op.dao.AuctionDao;
import pl.op.model.auction.Auction;
import pl.op.model.auction.AuctionFilter;

public class LazyAuction extends LazyDataModel<Auction> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1148534885257596229L;

	private AuctionDao auctionDao;
	private AuctionFilter auctionFilter;

	public LazyAuction(AuctionDao auctionDao, AuctionFilter auctionFilter) {
		this.auctionDao = auctionDao;
		this.auctionFilter = auctionFilter;
	}

	@Override
	public List<Auction> load(int first, int pageSize, String sortField,
			SortOrder sortOrder, Map<String, String> filters) {
		
		List<Auction> auctions = new ArrayList<Auction>();

		try {
			auctions = auctions = auctionDao.getAuctions(auctionFilter);

			for (int i = 0; i < auctions.size(); i++) {
				auctions.get(i).setPotentialUsers(
						auctionDao.getPotentialUsers(auctions.get(i)));
				auctions.get(i).setSalesmans(
						auctionDao.getAuctionSalesmans(auctions.get(i)));
			}
			
			this.setRowCount(auctionDao.getAuctionsCount(auctionFilter));

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return auctions;
	}

}
