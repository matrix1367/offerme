/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pl.op.session;

import org.jboss.seam.annotations.Name;

/**
 *
 * @author Bettin Maciej
 */
@Name("op.GlobalConstants")
public class GlobalConstants {

    /**
     * path to uploade file 
     */
    public static String pathUpload = "/u01/apache-tomcat-7.0.34/webapps/upload/";

    public static String pathInvoice = "/u01/apache-tomcat-7.0.34/webapps/op-web/images/upload";

}
