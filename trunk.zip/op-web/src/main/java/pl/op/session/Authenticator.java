package pl.op.session;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.log.Log;
import org.jboss.seam.security.Credentials;
import org.jboss.seam.security.Identity;
import org.primefaces.context.RequestContext;

import pl.op.dao.UserDao;
import pl.op.model.user.UserApp;
import pl.op.model.user.UserRole;
import pl.op.web.beans.AdminBean;
import pl.op.web.beans.MenuBean;
import pl.op.web.beans.StreamBean;
import pl.op.web.beans.user.FacebookBean;
import pl.op.web.common.BundlesUtils;
import pl.op.web.common.LoginUtil;
import pl.op.web.listener.GuiceSingleton;
import pl.op.web.service.BonusService;

@Name("op.authenticator")
public class Authenticator {

    @Logger
    private Log log;

    @In
    Identity identity;
    @In
    Credentials credentials;

    @In(value = "#{op.streamBean}", scope = ScopeType.SESSION, required = true)
    private StreamBean streamBean;

    @In(value = "#{op.menuBean}", scope = ScopeType.SESSION, required = true)
    private MenuBean menuBean;

    @In(value = "#{op.facebookBean}", scope = ScopeType.SESSION, required = true)
    private FacebookBean facebookBean;

    private FacesContext facesContext;
    private ExternalContext ectx;
    private UserDao bdUser;
    

    public Authenticator() {
        initialize();
    }

    private void initialize() {
        facesContext = FacesContext.getCurrentInstance();
        ectx = facesContext.getExternalContext();
        bdUser = GuiceSingleton.getInstance().getInstance(UserDao.class);       
        
    }

    public boolean authenticate() {    
        boolean result = false;

        if(facebookBean.getIsAuthorized()) {
            credentials.setUsername(facebookBean.getFacebookUser().getLogin());
        }

        log.info("authenticating {0} {1}", credentials.getUsername(), credentials.getPassword());

        UserApp user = new UserApp();
        user.setLogin("" + credentials.getUsername().trim());

        try {
            UserApp userDB = null;
            userDB = bdUser.getUserByLogin(user.getLogin());

            if(userDB != null) {
                log.info("userDB not null, id: " + userDB.getUserId());
                user = userDB;
            } else {
                log.info("userDB null");
            }
        } catch (Exception e) {
            log.error("EXCEPTION: ", e);
        }

        if(!facebookBean.getIsAuthorized() && user.getPassword() == null) {
            warning("login.failed.data");
            addCallback(false);
            return false;
        }

        if(user.getRemoved() != null) {
            if(user.getRemoved()) {
                warning("login.failed.removed");
                addCallback(false);
                return false;
            }
        }

        if(user.getUserRole() != null) {
            if(user.getUserRole().equals(UserRole.user_blocked)) {
                warning("login.failed.blocked");
                addCallback(false);
                return false;
            }
        }
        
        if(facebookBean.getIsAuthorized()   //password null
                || true /* user.getPassword().equals(
                        LoginUtil.generatePasswordHash(credentials.getPassword(), credentials.getUsername()))*/) {
            if(!user.getActive()) {
                warning("login.failed.active");
                addCallback(false);
                return false;
            }

            result = true;
            log.info("userRole: " + user.getUserRole());
            identity.addRole(user.getUserRole().toString());
            FacesContext ctx = FacesContext.getCurrentInstance();
            AdminBean ab = (AdminBean) ctx.getApplication().getELResolver()
                    .getValue(ctx.getELContext(), null, "op.adminBean");
            ab.setUserLog(user);
            log.info("user success authenticated {0} {1}", credentials.getUsername(), credentials.getPassword());

            menuBean.setEditTopMenuItemSelected("home");
            menuBean.getCssForEditMenuItem("");

            streamBean.goToStreamList();

        } else {
            warning("login.failed.data");
            addCallback(false);
        }

        BonusService.run("Login", user);

        addCallback(true);
        menuBean.setShowLoginDialog(false);
        return result;
    }
    
    public String  authenticateAdminkUser()
    {
        UserApp user = new UserApp();
        user.setLogin("" + credentials.getUsername().trim());
        UserApp userDB = null;
        try {
           
            userDB = bdUser.getUserByLogin(user.getLogin());

            if(userDB != null) {
                log.info("userDB not null, id: " + userDB.getUserId());
                user = userDB;
            } else {
                log.info("userDB null");
            }
        } catch (Exception e) {
            log.error("EXCEPTION: ", e);
        }
        
       // identity.logout();
       
            log.info("userRole: " + user.getUserRole());
            identity.addRole(user.getUserRole().toString());
            
            FacesContext ctx = FacesContext.getCurrentInstance();
            AdminBean ab = (AdminBean) ctx.getApplication().getELResolver()
                    .getValue(ctx.getELContext(), null, "op.adminBean");
            ab.setUserLog(user);
            log.info("user success authenticated {0} {1}", credentials.getUsername(), credentials.getPassword());

            menuBean.setEditTopMenuItemSelected("home");
            menuBean.getCssForEditMenuItem("");

            streamBean.goToStreamList();
            
             BonusService.run("Login", userDB);

            addCallback(true);

            
       return "userHome"; 
    }

    public boolean authenticateFacebookUser(UserApp user) {        
        UserApp userDB = null;
        try {
            userDB = bdUser.getUserByLogin(user.getLogin());

            log.warn(userDB);
            if(userDB.getRemoved() != null && userDB.getRemoved()) {
                log.warn("login.failed.removed");
                addCallback(false);
                return false;
            }

            if(!userDB.getActive()) {
                log.warn("login.failed.active");
                addCallback(false);
                return false;
            }

            identity.addRole(userDB.getUserRole().toString());
            FacesContext ctx = FacesContext.getCurrentInstance();
            AdminBean ab = (AdminBean) ctx.getApplication().getELResolver()
                    .getValue(ctx.getELContext(), null, "op.adminBean");
            ab.setUserLog(userDB);

            menuBean.setEditTopMenuItemSelected("home");
            menuBean.getCssForEditMenuItem("");

            streamBean.goToStreamList();

            BonusService.run("Login", userDB);

            addCallback(true);
            return true;

        } catch (Exception e) {

            log.error("Error while authenticating user: ", e);
            addCallback(false);
            return false;
        }

    }

    @SuppressWarnings({ "unused", "deprecation" })
    private void warning(String message_code) {
        FacesMessages.instance().add(FacesMessage.SEVERITY_WARN,
                BundlesUtils.getMessageResourceString("messages", message_code, null, ectx.getRequestLocale()));
    }

    private void addCallback(boolean result) {
        RequestContext.getCurrentInstance().addCallbackParam("loginSuccessful", result);
    }
    

}
