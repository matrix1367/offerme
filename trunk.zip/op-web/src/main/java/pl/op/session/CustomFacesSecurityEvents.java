package pl.op.session;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Install;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Startup;
import org.jboss.seam.annotations.intercept.BypassInterceptors;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.FacesSecurityEvents;

@Name("org.jboss.seam.security.facesSecurityEvents")
@Scope(ScopeType.APPLICATION)
@Install(precedence= Install.APPLICATION)
@BypassInterceptors
@Startup
public class CustomFacesSecurityEvents extends FacesSecurityEvents
{
    @Override
    public Severity getLoginFailedMessageSeverity()
    {
         return Severity.WARN;
    }
    
    @Override
    public void addAlreadyLoggedInMessage(){}
    
    @Override
    public String getLoginFailedMessageKey()
    {
       return "";
    }
    
    @Override
    public String getLoginFailedMessage()
    {
       return "";
    }
}